"""Run etl convertion step
"""

import argparse
import sys
from os import path

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E
try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core')
from cdmkit.cdmredshift import etl_core as sql_core


# ======= Start ===============================================================

etl_print('Job load.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-s", dest="source_data_conf_file", required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-cs", dest="create_schema", type=str)
parser.add_argument("-cdp", dest="cdp_compatible", action="store_true")
parser.add_argument("-d", dest="notebook_run", action="store_true")

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False
)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to load.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
source_data_conf_file = parsed.source_data_conf_file
run_id = parsed.run_id
cdp_compatible = parsed.cdp_compatible
should_create_schema = parsed.create_schema != "no"
should_overwrite_schema = parsed.create_schema == "overwrite"
notebook_run = parsed.notebook_run

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'load')

try:
    source_data_conf_path = path.join(etl_home, 'conf', source_data_conf_file)
    source_conf = configs.SourceConfig(source_data_conf_path)
except (OSError, IOError, ValueError) as e:
    etl_print(
        'Failed to read configuration file "{filename}"\n{exception}'
        .format(
            filename=source_data_conf_path,
            exception=str(e)
        ),
        ETLMessageType.Error
    )
    sys.exit(1)

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="load")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.SourceDataLoader(session, etl_conf)
else:
    runner = sql_core.SourceDataLoader(session, etl_conf)

if should_create_schema:
    schema_tags = {b.get("schema", "source_schema") for b in source_conf.source_batches}
    schema_names = {etl_conf.schemas[s_tag] for s_tag in schema_tags}
    for s_name in schema_names:
        session.create_schema(s_name, overwrite=should_overwrite_schema)

# ======= 4. Run job ==========================================================
try:
    runner.run(source_conf.source_batches, cdp_compatible=cdp_compatible)
except E.JobExecException as e:
    etl_print('Job load.py failed', ETLMessageType.Failed)
    etl_print(str(e), ETLMessageType.Error)
    sys.exit(1)
session.close()

# ======= 5. Create run log ===================================================

if run_id is None:
    etl_print(
        'Run report is not created. Missing -r parameter',
        ETLMessageType.Warning
    )
else:
    try:
        write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'load')
    except (E.JobReportException, AttributeError) as e:
        etl_print(
            'Run report is not created\n' + str(e),
            ETLMessageType.Warning
        )

if notebook_run: return_code = 0

etl_print('Job load.py finished')

# ======= End ================================================================
