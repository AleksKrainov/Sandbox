import datetime
import itertools
import json
import logging
import os
import re
import sys
import traceback
from copy import deepcopy

from pyspark.sql.types import StructType
from pyspark.sql.utils import AnalysisException, ParseException
import pyspark.sql.functions as functions

from cdmkit.core import configs, etl_print, ETLMessageType, utils
from cdmkit.core.job_reports import (
    QAStepInfo,
    ColumnStatsBase, SourceColumnStats,
    CDMDataStats, SourceDataStats,
)
from cdmkit.core.sql_tools import (
    SPARK, apply_schemas, apply_params, resolve_if_macros, only_comments_in, strip_comments,
    split_into_queries, replace_identity
)
from cdmkit.core.run_log import RunLog
from cdmkit.core import exceptions as E


# Python 2 + Unicode = trouble
if sys.version_info[0] == 2:
    # HACK: may cause weird behavior:
    # https://anonbadger.wordpress.com/2015/06/16/why-sys-setdefaultencoding-will-break-code/
    reload(sys)     # noqa
    sys.setdefaultencoding("utf-8")
    str = unicode   # noqa
    etl_print(
        (
            "You are using a deprecated version of Python. Consider upgrading to v3 ASAP. "
            "If this is accidental, try adjusting spark_settings.ini by setting "
            "'spark.pyspark.python = /path/to/python3' (the correct path can be "
            "found by running 'which python3' in the shell). "
            "If you use Unicode literals within the project, it's strongly "
            "advised to use Python 3 to avoid encoding-related errors."
        ),
        ETLMessageType.Warning
    )


class SourceDataLoader(object):
    """Source data load adapter."""

    DEFAULT_OPT_VALUES = {
        "src_format":      "csv",
        # data load options
        "compression":     "none",
        "header":          True,
        "delimiter":       ",",
        "encoding":        "utf-8",
        "quote":           "\"",
        "escape_char":     None,
        "escape_quotes":   None,
        "null_value":      None,
        "dateformat":      "yyyy-MM-dd",
        "timestampformat": "yyyy-MM-dd'T'HH:mm:ss",
        "infer_schema":    False,
        # postprocess options
        "num_partitions":  None,
        "sample_conf":     None,
        "generate_util_columns": True,
        "exclude_columns": None,
    }
    INTERNAL_TO_SPARK_OPTS = {
        "compression":     "compression",
        "header":          "header",
        "delimiter":       "sep",
        "encoding":        "encoding",
        "quote":           "quote",
        "escape_char":     "escape",
        "escape_quotes":   "charToEscapeQuoteEscaping",
        "null_value":      "nullValue",
        "dateformat":      "dateFormat",
        "timestampformat": "timestampFormat",
        "infer_schema":    "inferSchema",
    }

    def __init__(self, session, etl_conf):
        """Initialize job runner.

        Args:
            session (:class:`cdmkit.core.connections.SparkConnection`): Connection wrapper, with open Spark session.
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object.

        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.run_log = RunLog()

    def run(self, source_batches, cdp_compatible=False):
        """Triggers a job.

        Args:
            source_batches (list): a list of data configurations from SourceConfig.
            cdp_compatible (boolean): load using CREATE TABLE instead of saveAsTable

        Returns:
            list: record counts for every loaded table.

        """
        source_batch_counts = []
        for batch in source_batches:
            tables_counts = []
            schema_name = self.__etl_conf.schemas[batch.get("schema", "source_schema")]
            files_location = batch.get("files_location") or batch["s3_root"]
            for source_table in batch["source_tables"]:
                source_file_path = os.path.join(self.norm_path(files_location), source_table["path"])
                src_format, load_options, post_options = self.prepare_table_options(source_table, batch)
                table_name = source_table["table"]

                table_count = self.indicate_start(table_name, source_file_path)
                try:
                    with self.run_log.running("load_table", table_name=table_name, source_file_path=source_file_path):
                        df = self._perform_load(src_format, source_file_path, source_table, load_options)
                        df = self._postprocess(df, table_name, **post_options)
                        if cdp_compatible:
                            """CDP doesn't work well with saveAsTable.
                               Using SQL CREATE TABLE as a workaround.
                               The plan is:
                                    1. Read source file as usual
                                    2. Execute CREATE TABLE
                                    3. Find location that CDP decided to use for the table (No, it won't be in the default warehouse. Yes, CDP hates you)
                                    4. Save files to that location
                            """
                            self.__session.conn.sql("DROP TABLE IF EXISTS {schema_name}.{table_name} PURGE".format(schema_name=schema_name,
                                                                                                       table_name=table_name))
                            table_format = batch.get("format") or "parquet"
                            table_fields = ",\n".join([" ".join(x) for x in df.dtypes])
                            self.__session.conn.sql("CREATE TABLE {schema_name}.{table_name} ({table_fields}) STORED AS {table_format} TBLPROPERTIES('external.table.purge'='true')"
                                                                                                         .format(schema_name=schema_name,
                                                                                                                 table_name=table_name,
                                                                                                                 table_fields=table_fields,
                                                                                                                 table_format=table_format))

                            table_location = str(self.__session.conn.sql("desc formatted {schema_name}.{table_name}".format(schema_name=schema_name,
                                                                                                              table_name=table_name))
                                                                                                      .filter("col_name = 'Location'")
                                                                                                      .take(1)[0]["data_type"])

                            df.write.format(table_format).save(table_location, mode="overwrite")
                        else:
                            df.write.saveAsTable(schema_name + '.' + table_name, mode="overwrite")
                        table_count = self.indicate_finish(df, table_count)
                        if df.count() == 0:
                            etl_print('Empty file.', ETLMessageType.Warning)
                        tables_counts.append(table_count)
                except Exception as exc:
                    self.indicate_failure(table_name, exc)
            source_batch_counts.append(tables_counts)

        return source_batch_counts

    def prepare_table_options(self, table_conf, batch_conf):
        """Define load and postprocess configuration.

        Args:
            table_conf (dict): table configuration from SourceConfig.
            batch_conf (dict): whole batch configuration from SourceConfig.

        Returns:
            tuple: data file format (str), load options (dict), postprocess options (dict).

        """
        option_values = utils.merge_dicts(self.DEFAULT_OPT_VALUES, batch_conf, table_conf)
        src_format = option_values["src_format"]
        load_options = {
            v: option_values[k]
            for k, v in self.INTERNAL_TO_SPARK_OPTS.items()}
        post_options = {
            opt: option_values[opt]
            for opt in ["num_partitions", "sample_conf", "generate_util_columns", "exclude_columns"]
        }
        return src_format, load_options, post_options

    def prepare_table_schema(self, table_conf, infer_schema=False):
        """Construct StructType from internal schema configuration.

        Args:
            table_conf (dict): table configuration from SourceConfig.
            infer_schema (bool): make Spark define table schema. Defaults to False.

        Returns:
            pyspark.sql.types.StructType: schema of data being loaded.

        """
        schema_conf = table_conf.get('fields', table_conf.get('fields'))
        if infer_schema is True:
            return None
        elif schema_conf is None and infer_schema is False:
            raise E.JobExecException(
                "No table schema specified and infer_schema is False. "
                "Check configuration (table '{t}').".format(t=table_conf["table"])
            )

        fields = StructType()
        for source_field in schema_conf:
            try:
                spark_datatype = self.__session.types.to_native(
                    source_field["type"],
                    length=source_field.get("length"),
                    precision=source_field.get("precision"),
                    scale=source_field.get("scale")
                )
            except KeyError as exc:
                raise E.JobExecException(
                    "Data type '{dt}' not supported. "
                    "Check configuration (table '{t}', field '{f}').".format(
                        dt=source_field["type"], f=source_field["field"],
                        t=table_conf["table"]
                    ),
                    cause=exc
                )
            except ValueError as exc:
                raise E.JobExecException(
                    "Wrong parameter values for '{dt}' datatype. "
                    "Check configuration (table '{t}', field '{f}').".format(
                        dt=source_field["type"], f=source_field["field"],
                        t=table_conf["table"]
                    ),
                    cause=exc
                )
            else:
                fields.add(source_field["field"],
                           data_type=spark_datatype,
                           nullable=not source_field.get("required", not source_field.get("nullable", True)))

        return fields

    def _perform_load(self, src_format, src_path, table_conf, options):    # pragma: no cover
        # 1) schema is not applied when provided via option()/options() calls (PySpark bug)
        # 2) schema=None causes Exception when provided via schema() call
        # 3) but there's also a "schema" param in load(), which works fine
        # 4) ...
        # 5) PROFIT!
        table_schema = self.prepare_table_schema(table_conf, options['inferSchema'])
        columns = self.__session.conn.read.format(src_format) \
                                        .options(**options) \
                                        .load(path=src_path) \
                                        .columns

        if table_schema is not None and len(columns) != 0 and len(columns) != len(table_schema):
            raise E.JobExecException(
                "The number of fields specified doesn't match the number of fields in the loaded file. "
                "Check configuration (table '{t}').".format(t=table_conf["table"])
            )
        
        return self.__session.conn.read.format(src_format) \
                                       .options(**options) \
                                       .load(path=src_path, schema=table_schema)

    def _postprocess(self, df, table_name, num_partitions, sample_conf,
                     generate_util_columns, exclude_columns):
        """Apply transformations to all data loaded.

        Args:
            df (DataFrame): initial dataframe loaded from file.
            table_name (str): table name, without schema.
            num_partitions (int): controls partitioning. Defaults to None (not applied).
            sample_conf (dict): controls sampling. Defaults to None (not applied).
            generate_util_columns (bool): whether to add 'load_row_id' etc. Defaults to True.
            exclude_columns (list): omit some columns. Defaults to None (not applied).

        Returns:
            DataFrame: filtered DataFrame.

        """
        if num_partitions is not None:
            df = df.repartition(num_partitions)
        df = self.apply_sample(df, sample_conf)
        if generate_util_columns is True:
            df = df.withColumn('load_table_id', functions.lit(table_name))
            df = df.withColumn('load_row_id', functions.monotonically_increasing_id())
        df = self.exclude_columns(df, exclude_columns)

        return df

    def apply_sample(self, df, sample_conf):
        """Applies transformations, needed to load sample data from the source file.

        Args:
            df (pyspark.sql.DataFrame): an existing dataframe, aimed to the source to be loaded.
            sample_conf (dict): json-formatted parameters for transformation.

        Example of sample_conf:
            "tableSample":
            {
              "fraction": "0.1",
              "limit": "1000",
              "fields":
                [
                  {"field": "region", "values": ["2", "4"]}
                  # or:
                  {"field": "region", "foreignTable": "staff", "foreignField": "role"}
                ]
            }
        The field filter is applied first, then fraction limitation, then implicit limit.

        Returns:
            pyspark.sql.DataFrame: a transformed dataframe.

        """
        if sample_conf is None:
            return df

        sample_fields = sample_conf.get("fields", list())
        sample_fraction = sample_conf.get("fraction")
        sample_limit = sample_conf.get("limit")
        # df.sampleByKey(), df.sampleBy()
        # http://stackoverflow.com/questions/32238727/stratified-sampling-in-spark
        # syntax!
        for fld in sample_fields:
            if fld.get("field") is not None:
                if fld.get("foreignTable") is not None and fld.get("foreignField") is not None:
                    df_f = self.__session.conn.table(fld["foreignTable"])
                    df = df.join(df_f, functions.col(fld["field"]) == functions.col(fld["foreignField"])).select(df.columns)
                elif fld.get("values") is not None:
                    df = df.where(functions.col(fld["field"]).isin(fld["values"]))

        if sample_fraction is not None:
            df = df.sample(withReplacement=False, fraction=float(sample_fraction), seed=None)

        if sample_limit is not None:
            df = df.limit(sample_limit)

        return df

    @staticmethod
    def exclude_columns(df, to_exclude):
        if to_exclude is None:
            return df
        for column in to_exclude:
            df = df.drop(column)
        return df

    @staticmethod
    def norm_path(filepath):
        if os.name == "nt" and os.path.splitdrive(filepath)[0] != '':
            # normalize only local Windows paths
            return os.path.normpath(filepath)
        else:
            return filepath

    @staticmethod
    def indicate_start(table_name, source_path):
        table_count = dict()
        table_count["table"] = table_name
        table_count["source_file"] = source_path

        logging.info("Loading " + source_path)
        etl_print(
            'Loading table "{tbl}"'.format(tbl=table_name),
            ETLMessageType.Running
        )

        return table_count

    @staticmethod
    def indicate_failure(table_name, exception):
        etl_print('', ETLMessageType.Failed)
        logging.error("Failed to load %s table.\n%s", table_name, traceback.format_exc())
        raise E.JobExecException(cause=exception)

    def indicate_finish(self, df, table_count):
        table_count["count"] = df.count()
        etl_print('File loaded', ETLMessageType.Ok)
        return table_count


class WorkflowRunner(object):
    """Runs ETL workflow and collects execution details."""

    def __init__(self, session, etl_conf, should_count):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            should_count (bool): collect number of records in affected tables. Defaults to True.
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.run_info = dict()
        self.fail_info = dict()
        self.should_count = should_count
        self.params = etl_conf.params
        self.run_log = RunLog()

    def run(self, workflow):
        """Run all SQL queries."""
        for statement in workflow:
            if statement.get('doc_info') and self.should_count:
                old_count = self._get_table_count(statement['doc_info']['table'], zero_on_fail=True)
            start_time = datetime.datetime.now()

            try:
                with self.run_log.running("run_sql_statement", statement_id=statement['id']):
                    self.run_sql_statement(statement['sql'])
            except Exception as e:
                self.fail_info = {
                    'statement_id': statement['id'],
                    'error': str(e)
                }
                raise E.JobExecException(cause=e)

            end_time = datetime.datetime.now()
            if statement.get('doc_info') and self.should_count:
                with self.run_log.running("get_table_count", table_name=statement['doc_info']['table']):
                    new_count = self._get_table_count(statement['doc_info']['table'])
                if new_count is not None:
                    self.run_info[statement['id']] = {
                        'run_time': str(end_time - start_time),
                        'count': new_count - old_count
                    }

        if self.should_count:
            self._collect_tables_info(workflow)

    def run_sql_statement(self, sql_statement):
        """Run single SQL statement against database.

        Args:
            sql_statement (str): SQL statement without semicolon.

        """
        # Fetch count for tmp_ table before it is dropped
        query_drops_tmp_table = re.match(
            r"(drop\s+table\s+)(if\s+exists\s+)?(@{1}[a-z_0-9]+[.]{1}tmp_[a-z_0-9]+)",
            strip_comments(sql_statement.lower())
        )
        if query_drops_tmp_table and self.should_count:
            tmp_table = query_drops_tmp_table.group(3)
            self.run_info[tmp_table] = {
                'run_time': None,
                'count': self._get_table_count(tmp_table)
            }
        sql_statement = apply_schemas(sql_statement, self.__etl_conf.schemas)
        if '@db.dbms' in self.__etl_conf.params and 'db.dbms' in sql_statement:
            etl_print("Macros 'db.dbms' will be skipped. There is a regular parameter with the same name.", ETLMessageType.Warning)
        else:
            sql_statement = sql_statement.replace('db.dbms', self.__session.dialect)
        sql_statement = apply_params(sql_statement, self.params)
        # sql_statement = self.__apply_location(sql_statement)
        # --noid will be DEPRECATED - cut out legacy comments unconditionally
        if '--@IF build_type = dev' in sql_statement:
            etl_print(
                "Legacy construct '--@IF build_type = dev' is found!"
                + " Please remove it or replace with new-style @IF."
                + " '--noid' option will be deprecated in v1.3.0.",
                ETLMessageType.Warning
            )
        sql_statement = self.__remove_row_id(sql_statement)
        sql_statement = resolve_if_macros(sql_statement)

        if '@IDENTITY' in sql_statement:
            #replace
            etl_print("Replace @IDENTITY macros")
            sql_statement = replace_identity(sql_statement, SPARK)

        etl_print('\n{sql}'.format(sql=sql_statement))

        if '@RECOMPUTE_IDS' in sql_statement:
            recompute_args = self.parse_recompute_func(sql_statement)
            if recompute_args is not None:
                self.__recompute_ids(*recompute_args)
            else:
                args_str = sql_statement.strip()
                args_str = args_str.split('(')[1]
                args_str = args_str.split(')')[0]
                args = args_str.split(',')
                self.__recompute_ids(args[0], args[1])
        elif '@PARTITION_BY' in sql_statement:
            args = sql_statement.replace('@PARTITION_BY(', '').replace(')', '').split(',')
            table = args[0].strip()
            partColumns = [col.strip() for col in args[1:]]
            self.__partition_by(table, partColumns)
        elif only_comments_in(sql_statement):
            etl_print("Nothing to do, skipping..")
        else:
            etl_print(
                'Running SQL statement',
                ETLMessageType.Running
            )
            try:
                self.__session.execute(sql_statement)
            except Exception as e:
                etl_print('', ETLMessageType.Failed)
                raise E.JobExecException(cause=e)

            etl_print('', ETLMessageType.Ok)

    def __apply_location(self, script):
        data_location = self.__etl_conf.__dict__.get('data_location')
        if re.search('@location\(.*\)', script) and data_location is not None:
            location_string = re.search('@location\(.*\)', script).group(0).replace('@location(', data_location).replace(')', '/')
            script = re.sub(r'@location\(.*\)', "'" + location_string + "'", script)

        return script

    def _get_table_count(self, table_name, zero_on_fail=False):
        """Get number of records in specified table.

        Args:
            table_name (str): Table reference, with schema variable ('@some_schema.some_table') or not ('real_schema.some_table').
            zero_on_fail (bool): When True, 0 is returned instead of None when table doesn't exist. Defaults to False.

        Returns:
            int: Number of records. None is returned by default on failure.

        """
        real_name = apply_schemas(table_name, self.__etl_conf.schemas)
        try:
            count = self.__session.conn.table(real_name).count()
        except (AnalysisException, ParseException):
            # table does not exist
            etl_print("Failed to fetch '{}' table count".format(real_name), ETLMessageType.Warning)
            count = 0 if zero_on_fail else None
        return count

    def _collect_tables_info(self, workflow):
        # collect meaningful annotations
        annotations = (w['doc_info'] for w in workflow if (w.get('doc_info') or {}) != {})
        # ensure each table is listed once
        tables_to_count = set(
            itertools.chain.from_iterable((
                a["source_table"] + [a["table"]]
                for a in annotations
            ))
        )
        for table in tables_to_count:
            with self.run_log.running("get_table_count", table_name=table):
                table_count = self._get_table_count(table)
            if table_count is not None:
                self.run_info[table] = {
                    'run_time': None,
                    'count': table_count
                }

    @staticmethod
    def parse_recompute_func(sql):
        m = re.search('(?<=@recompute_ids\()(.+),(.*)(?=\))', sql.lower())
        if m is None:
            return None
        table, column = map(lambda it: it.strip(), m.group(1, 2))
        return table, column

    # TODO refactor
    def __recompute_ids(self, table, column):
        df = self.__session.conn.table(table)
        self.__session.conn.sql("DROP TABLE IF EXISTS {table_name}_temp PURGE".format(table_name=table))
        df = df.withColumn(column, functions.monotonically_increasing_id())
        df.write.saveAsTable(table + '_temp', mode="overwrite")
        self.__session.conn.sql("DROP TABLE IF EXISTS {table_name} PURGE".format(table_name=table))
        self.__session.conn.sql("CREATE TABLE {table_name} STORED AS PARQUET AS SELECT * FROM {table_name}_temp".format(table_name=table))
        self.__session.conn.sql("DROP TABLE IF EXISTS {table_name}_temp PURGE".format(table_name=table))

    def __partition_by(self, table, partColumns):
        df = self.__session.conn.table(table)
        self.__session.sql("DROP TABLE IF EXISTS {}_temp PURGE".format(table))
        df.write.partitionBy(partColumns).saveAsTable(table + '_temp', mode="overwrite")
        self.__session.sql("DROP TABLE IF EXISTS {table_name} PURGE".format(table_name=table))
        self.__session.sql("ALTER TABLE {table_name}_temp RENAME TO {table_name}".format(table_name=table))

    def __remove_row_id(self, script):
        script = script.replace('--@IF build_type = dev', '')
        # do not remove the closing tag - might be from another @IF
        # script = script.replace('--@ENDIF', '')
        return script


class SamplePatientsHistoryGenerator:
    SAMPLE_ROW_COUNT = 5

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.Config`): job configuration object
        """
        self.__session = session
        self.__conf = conf
        self.__etl_conf = etl_conf
        self.stats = list()

    def run(self):
        """Collect patient records."""
        if self.__conf.patient_limit is not None:
            pat_records = self.__get_patients_sample()
        else:
            pat_records = self.__get_specified_patients()

        for patient in pat_records:
            patient_rec = dict()
            patient_rec['key'] = patient
            patient_rec['source_records'] = self.__get_source_patient_records(patient)
            patient_rec['cdm_records'] = self.__get_cdm_patient_records(patient)

            self.stats.append(patient_rec)

    def __get_patients_sample(self):
        query = 'SELECT {columns} FROM {schema_name}.{table_name} ORDER BY RAND() LIMIT {pat_num}'.format(
                columns=','.join(self.__conf.source_patient_key),
                schema_name=self.__etl_conf.schemas['source_schema'],
                table_name=self.__conf.source_patient_table,
                pat_num=self.__conf.patient_limit)
        etl_print('Collecting source patients sample')
        etl_print(query)

        df = self.__session.conn.sql(query)
        pats = df.toJSON().collect()
        patients = [json.loads(str(row)) for row in pats]

        return patients

    def __get_specified_patients(self):
        # {column_name: [values], ...}
        predicates = dict(zip(
            self.__conf.patients[0],
            zip(*[col.values() for col in self.__conf.patients])
        ))
        # construct where clause
        where_cases = ' AND '.join(
            ['{column} IN {values}'.format(column=key, values=tuple([str(v) for v in val]))
             for key, val in predicates.items()]
        )
        query = 'SELECT {columns} FROM {schema_name}.{table_name} WHERE {cases}'.format(
            columns=','.join(self.__conf.source_patient_key),
            schema_name=self.__etl_conf.schemas['source_schema'],
            table_name=self.__conf.source_patient_table,
            cases=where_cases
        )
        etl_print('Collecting source patients sample')
        etl_print(query)

        df = self.__session.conn.sql(query)
        pats = df.toJSON().collect()
        patients = [json.loads(str(row)) for row in pats]

        return patients

    def __get_cdm_patient(self, source_patient):
        etl_print(
            'Looking for CDM patient for source_patient {source_patient}'
            .format(source_patient=str(source_patient))
        )
        qualification = self.__conf.source_cdm_join_rule
        for column in source_patient:
            qualification = qualification.replace(column, str(source_patient[column]))

        query = 'SELECT person_id FROM {schema_name}.cdm_person WHERE {qual}'.format(
                schema_name=self.__etl_conf.schemas['cdm_schema'],
                table_name=self.__conf.source_patient_table,
                qual=qualification)

        row = self.__session.conn.sql(query).take(1)

        if row:
            return int(row[0][0])
        return -1

    def __get_source_patient_records(self, patient):
        records = dict()
        for table in self.__conf.source_tables:
            qualification = ' AND '.join([field + " = '" + str(patient[field]) + "'" for field in self.__conf.source_patient_key])
            query = "SELECT * FROM {schema_name}.{table_name} WHERE {qual}".format(
                schema_name=self.__etl_conf.schemas['source_schema'],
                table_name=table['table'],
                qual=qualification)

            try:
                df = self.__session.conn.sql(query)
            except Exception as e:
                print(table['table'] + ' FAILED.' + str(e))

            columns_dict = {col: None for col in df.columns}
            records_list = list()
            for row in df.toJSON().collect():
                row_dict = columns_dict
                row_dict.update(json.loads(row))
                records_list.append(row_dict)

            records[table['table']] = records_list

        return records

    def __get_cdm_patient_records(self, patient):
        records = dict()
        person_id = self.__get_cdm_patient(patient)

        for table in self.__conf.cdm_tables:
            query = "SELECT * FROM {schema_name}.{table_name} WHERE person_id = {person}".format(
                schema_name=self.__etl_conf.schemas['cdm_schema'],
                table_name=table['table'],
                person=person_id)

            try:
                df = self.__session.conn.sql(query)
            except Exception as e:
                print(table['table'] + ' FAILED.' + str(e))

            columns_dict = {col: None for col in df.columns}
            records_list = list()
            for row in df.toJSON().collect():
                row_dict = columns_dict
                row_dict.update(json.loads(row))
                records_list.append(row_dict)

            records[table['table']] = records_list

        return records


class CDMDDLCreator:
    """Creates and executes DDL statements for CDM tables."""

    RULE_COL = "rule_id"

    @property
    def util_fields(self):
        return [
            {"field": self.RULE_COL, "type": "string", "length": 100},
            {"field": "load_table_id", "type": "string", "length": 50},
            {"field": "load_row_id", "type": "bigint"}
        ]

    def __init__(self, session, etl_conf, row_id, cdm_schema_conf, tables=None):
        """Create runner instance.

        Args:
            session (:class:`cdmkit.core.etl_connections.SparkConnection`): Connection wrapper, with open DB session.
            etl_conf (:class:`cdmkit.core.etl_configs.ETLConf`): .etlconf configuration object.
            row_id (bool): Whether to add utility fields or not (True by default).
            cdm_schema_conf (:class:`cdmkit.core.etl_configs.CDMTablesConfig`): Job configuration.
            tables (list): Run job only for specified tables, if present. A list of (str) table names.

        Returns:
            type: Description of returned object.

        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__cdm_schema_conf = cdm_schema_conf
        self.__row_id = row_id
        self.__tables = tables
        self.__typo_checker = utils.CDMTablesTypoChecker()
        self.run_log = RunLog()

    def run(self):
        ddl_statements = list()
        if self.__tables is None:
            for table in self.__cdm_schema_conf.tables:
                ddl_statements.append(self.generate_ddl_table(table))
        else:
            for table in self.__cdm_schema_conf.tables:
                if self.__is_table_excluded(table['table']):
                    continue
                ddl_statements.append(self.generate_ddl_table(table))

        # execute all generated SQL
        for table, drop, create in ddl_statements:
            with self.run_log.running("create_table", table_name=table):
                etl_print("Creating table '{}'...".format(table), ETLMessageType.Running)
                self.__session.execute(drop, create)
                etl_print("", ETLMessageType.Ok)

    def generate_ddl_table(self, table_def):
        """Generate DDL statement for CDM tables.

        Args:
            table_def (dict): Table definition from `self.__cdm_schema_conf`.

        Returns:
            tuple: (table_name, drop_query, create_query), all str.

        """
        schema_tag = getattr(self.__cdm_schema_conf, "schema", self.default_schema_tag)

        if isinstance(table_def.get('partition_by'), str):
            table_def['partition_by'] = [table_def['partition_by']]
        partition_fields = table_def.get("partition_by", [])

        all_field_names = [f["field"] for f in (table_def["fields"] + (self.util_fields if self.__row_id else []))]
        for field in partition_fields:
            if field not in all_field_names:
                raise E.JobExecException(
                    "Can not match the partition field with the table fields. "
                    "Check configuration (table '{t}', field '{f}').".format(t=table_def["table"], f=field)
                )
        if len(partition_fields) > len(set(partition_fields)):
            raise E.JobExecException(
                "There are duplicate field names in 'partition_by' section. "
                "Check configuration (table '{t}').".format(t=table_def["table"])
            )
        if len(partition_fields) >= len(all_field_names):
            raise E.JobExecException(
                "The number of partitions can not be more or equal to the number of fields. "
                "Check configuration (table '{t}').".format(t=table_def["table"])
            )

        storage_format = table_def.get("storage_format") or getattr(self.__cdm_schema_conf, "storage_format", "PARQUET")
        table_properties = table_def.get("table_properties", {})
        if getattr(self.__cdm_schema_conf, "storage_format", "").upper() == storage_format.upper():
            for atr, val in getattr(self.__cdm_schema_conf, "table_properties", dict()).items():
                if atr not in table_properties:
                    table_properties[atr] = val

        drop_ddl = 'DROP TABLE IF EXISTS `{schema_name}`.`{table_name}` PURGE'.format(
            schema_name=self.__etl_conf.schemas[schema_tag],
            table_name=table_def['table']
        )
        create_ddl = "CREATE TABLE `{schema_name}`.`{table_name}`\n{fields}\nUSING {format}\n{partitioning}".format(
            schema_name=self.__etl_conf.schemas[schema_tag],
            table_name=table_def['table'],
            fields=self._generate_ddl_fields(table_def),
            partitioning=self._generate_ddl_partitioning(partition_fields),
            format=storage_format.upper()
        )
        # NOTE it makes sense to store external location for CDM separately
        # not in etlconf. Also, TODO make explicit flag for external tables.
        cdm_ext_location = getattr(self.__cdm_schema_conf, 'data_location', None)
        if cdm_ext_location is not None:
            create_ddl += " LOCATION '{data_location}/{table_name}/'\n".format(
                data_location=cdm_ext_location, table_name=table_def['table']
            )
        if table_properties != {}:
            create_ddl += "TBLPROPERTIES({})".format(self._generate_tblproperties(table_properties))
        return (table_def['table'], drop_ddl, create_ddl)

    def _generate_ddl_fields(self, table_def):
        """Generate DDL definition for table fields.

        Args:
            table_def (dict): Table definition from `self.__cdm_schema_conf`.

        Returns:
            str: Part of DDL query which defines table fields.

        """
        all_fields = table_def['fields'] + (self.util_fields if self.__row_id else [])
        fields_formatted = ",\n".join([self._get_field_sql_expr(f) for f in all_fields])
        return ' (\n{f}\n) '.format(f=fields_formatted)

    def _generate_ddl_partitioning(self, partition_fields):
        """Generate partition spec part of DDL.

        Args:
            partition_fields (list): List of field names that should be used for table partitioning.

        Returns:
            str: Part of DDL query which defines table partitioning.

        """
        if not partition_fields:
            return ""
        fields_formatted = ",\n".join(["`{}`".format(f) for f in partition_fields])
        return ' PARTITIONED BY (\n{p}\n) '.format(p=fields_formatted)

    def _get_field_sql_expr(self, field_def):
        native_type = self.__session.types.to_native(
            field_def['type'],
            length=field_def.get("length"),
            precision=field_def.get("precision"),
            scale=field_def.get("scale")
        )
        # NOTE: 'NOT NULL' and other constraints are supported only in Hive 3.0+
        return '`{field}` {field_type}'.format(
            field=field_def['field'],
            field_type=native_type
        )

    @staticmethod
    def _generate_tblproperties(tblproperties):
        property_string = ''
        for atr, val in tblproperties.items():
            property_string += ' "' + atr + '"="' + val + '",'
        return property_string[1:-1]

    def __is_table_excluded(self, table_name):
        for specified_table in self.__tables:
            if table_name == specified_table:
                return False
        for specified_table in self.__tables:
            if self.__typo_checker.check(specified_table, table_name):
                etl_print(
                    "Table '{tbl}' is skipped on your command."
                    " Did you make a typo or misspell the name? ('{tbl_by_user}')"
                    .format(tbl=table_name, tbl_by_user=specified_table),
                    ETLMessageType.Warning
                )
                return True

        etl_print("Table {} is skipped on your command".format(table_name))
        return True

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"

    def set_ddl_conf(self, ddl_conf):
        self.__cdm_schema_conf = ddl_conf


class CDMVerifier:
    """CDM tables unit testing adapter."""

    RULE_COL = "rule_id"

    def __init__(self, session, etl_conf, conf, skip_warnings=False):
        """Initialize job runner.

        Args:
            session (:class:`cdmkit.core.etl_connections.SparkConnection`): Connection wrapper.
            etl_conf (:class:`cdmkit.core.etl_configs.ETLConf`): .etlconf configuration object.
            conf (:class:`core.etl_configs.CDMTablesConfig`): Job configuration.
            skip_warnings (bool): verifier will skip lower severity tests.

        """
        self.__session = session
        self.__cdm_conf = conf
        self.__etl_conf = etl_conf
        self.__fk_df_list = dict()
        self.__skip_warnings = skip_warnings or self.__cdm_conf.__dict__.get('skip_warnings')
        self.report = dict()
        self.run_log = RunLog()

    def run(self):
        """Run CDM tables unit testing.

        Returns:
            dict: Unit testing report.

        """
        self.report['created_date'] = str(datetime.datetime.now())
        self.report['tables'] = list()

        failed_tables = list()

        if self.__skip_warnings:
            etl_print("Skipping low severity checks")

        for table in self.__cdm_conf.tables:
            etl_print(
                'Verifying table "{tbl}"'.format(tbl=table['table']),
                ETLMessageType.Running)
            with self.run_log.running("verify_table", table=table['table']):
                errors = self._test_table(table)
                scores = {k: len(list(g)) for k, g in itertools.groupby(errors, lambda x: x[0])}
            if not errors:
                etl_print('', ETLMessageType.Ok)
                table['result'] = 'Passed'
                self.report['tables'].append(table)
                continue
            if scores.get("no_data") is not None and len(scores) == 1:
                etl_print('', ETLMessageType.Ok)
                table['result'] = 'No data'
            elif scores.get("error"):
                etl_print('', ETLMessageType.Failed)
                table['result'] = 'Failed'
                failed_tables.append(table['table'])
            else:
                etl_print('', ETLMessageType.Ok)
                etl_print(
                    "Table '{}' has no errors but {} warnings".format(table['table'], scores["warning"]),
                    ETLMessageType.Warning)
                table['result'] = 'Warning'
            table['result_details'] = [self._format_err_msg(*e) for e in errors]
            self.report['tables'].append(table)

        if not failed_tables:
            etl_print('Unit testing passed')
        else:
            etl_print(
                'Unit testing failed for tables: {}'.format(', '.join(failed_tables)),
                ETLMessageType.Error)
        return self.report

    def _test_table(self, table_def):
        """Wrapper func for single table testing."""
        schema_tag = getattr(self.__cdm_conf, "schema", self.default_schema_tag)
        table_full_name = utils.locate_table(self.__session, self.__etl_conf.schemas[schema_tag], table_def['table'])
        df = self.__session.conn.table(table_full_name)

        errors = list()
        if self._perform_test(df) is True:
            errors.append(("no_data", "No data in the whole table '{}'".format(table_def['table'])))
            return errors
        errors.extend(self.__check_rec_uniqueness(table_def, df))
        errors.extend(self.__check_rec_constraints(table_def, df))
        errors.extend(self.__check_col_constraints(table_def, df))

        if not self.__skip_warnings and table_def.get('rules') is not None:
            errors.extend(self.__check_rule_coverage(table_def, df))

        for rule_def in table_def.get('rules', list()):
            if not isinstance(rule_def['rule'], list):
                rule_def['rule'] = [rule_def['rule']]
            if self._perform_test(df.filter(self.RULE_COL + " IN ('{rls}')".format(rls="','".join(rule_def['rule'])))) is True:
                errors.append(
                    (
                        "warning",
                        "No data for rule '{rls}' in '{t}'"
                        .format(t=table_def['table'], rls="','".join(rule_def['rule']))
                    )
                )
                continue
            errors.extend(self.__check_rec_uniqueness(rule_def, df))
            errors.extend(self.__check_rec_constraints(rule_def, df))
            errors.extend(self.__check_col_constraints(rule_def, df))
        return errors

    @staticmethod
    def _format_err_msg(severity, msg):
        return "{0}: {1}".format(severity.capitalize(), msg)

    @staticmethod
    def _perform_test(df):
        return df.limit(1).count() == 0

    def __check_rec_uniqueness(self, table_def, df):
        """Look for duplicates by fields defined in `table_def.unique`."""
        errors = list()
        if table_def.get("unique"):
            rules = table_def.get('rule')   # None for whole-table checks
            rule_string = '1=1'
            if rules:
                rule_string = self.RULE_COL + " IN ('{rls}')".format(rls="','".join(rules))
            if df.filter(rule_string).select(table_def["unique"]).distinct().count() != df.filter(rule_string).count():
                table_def['violated'] = ['unique']
                error_message = "Duplicates{rls} by fields [{unique}]".format(
                    rls="" if not rules else " (rule '{}')".format("', '".join(rules)),
                    unique=', '.join(table_def["unique"])
                )
                errors.append(("error", error_message))
        return errors

    def __check_rec_constraints(self, table_def, df):
        """Check record level constraints, like "required" and "length"."""
        all_checks = dict()
        errors = list()
        for field_def in table_def['fields']:
            field_checks = list()
            field_def['violated'] = list()
            if field_def.get("required"):
                field_checks.append((
                    "required",
                    '{field} is null'.format(field=field_def['field']),
                    "error"
                ))
            if field_def.get("value"):
                legacy = field_def.get("value") == ["Null"]
                if field_def.get("value") == [None] or legacy:
                    field_checks.append((
                        "value",
                        '{field} is not null'.format(field=field_def['field']),
                        "error"
                    ))
                else:
                    field_checks.append((
                        "value",
                        "{field} not in ('{value_list}')".format(
                            field=field_def['field'],
                            value_list="','".join(field_def.get("value"))),
                        "error"
                    ))
            if not self.__skip_warnings:
                if field_def.get("length") is not None:
                    field_checks.append((
                        "length",
                        'length({field}) > {max_length}'.format(
                            field=field_def['field'],
                            max_length=field_def.get("length")),
                        "warning"
                    ))
                if field_def.get("range", [None, None]) != [None, None]:
                    field_checks.append((
                        "range",
                        (
                            ('' if field_def['range'][0] is None else '{field} < {range[0]}')
                          + ('' if any([x is None for x in field_def['range']]) else ' OR ')
                          + ('' if field_def['range'][1] is None else '{field} > {range[1]}')
                        ).format(**field_def),
                        "warning"
                    ))
            all_checks[field_def['field']] = field_checks
        check_string = ' OR '.join([cond for _, cond, _ in itertools.chain(*all_checks.values())])
        if not check_string:
            return errors

        rules = table_def.get('rule')   # None for whole-table checks
        if rules:
            check_string = "(" + check_string + ") AND " + self.RULE_COL + " IN ('{rls}')".format(rls="','".join(rules))

        general_test_passed = self._perform_test(df.filter(check_string))
        if general_test_passed:
            return errors

        for field_def in table_def['fields']:
            for test_name, check_cond, severity in all_checks[field_def["field"]]:
                if rules:
                    check_cond = check_cond + " AND " + self.RULE_COL + " IN ('{rls}')".format(rls="','".join(rules))
                if self._perform_test(df.filter(check_cond)) is False:
                    field_def['violated'].append(test_name)
                    error_message = '{fld}{rls} - {cnd}'.format(
                        fld=field_def["field"], cnd=test_name,
                        rls="" if not rules else " (rule '{}')".format("', '".join(rules))
                    )
                    errors.append((severity, error_message))

        return errors

    def __check_col_constraints(self, table_def, df):
        """Check columns level constraints, like "identity"."""
        errors = list()
        rules = table_def.get('rule')

        for field_def in table_def["fields"]:
            if field_def.get("type") == 'identity':
                errors.extend(self.__check_field_identity(field_def, df))
            if field_def.get("type") == 'event_date' and not self.__skip_warnings:
                errors.extend(self.__check_event_dates(field_def, df))
            if field_def.get("foreign_key"):
                errors.extend(self.__check_foreign_keys(field_def, df, rules))
            if field_def.get("type") == 'concept_id':
                errors.extend(self.__check_concept_id(field_def, df, rules))

        return errors

    def __check_field_identity(self, field_def, table_df):
        """Check identity field (no duplicates)."""
        errors = list()
        col_distinct_df = table_df.select(field_def['field']).distinct()
        test_result = col_distinct_df.count() == table_df.count()
        if test_result is False:
            field_def['violated'].append('type')
            errors.append((
                "error",
                '{} - identity data type'.format(field_def['field'])
            ))
        return errors

    def __check_foreign_keys(self, field_def, table_df, rules):
        """Check referential integrity.

        There can be several foreign keys specified, which means that
        values from checked column should be present in ANY of foreign keys.
        """
        self.__collect_fk(field_def)

        errors = list()
        field_name = field_def['field']
        filtered_df = self._prefilter(table_df, rules, field_name, field_def.get("allow_zero"))
        col_distinct_df = filtered_df \
            .select(field_name) \
            .where(filtered_df[field_name].isNotNull()) \
            .distinct()

        constraint = field_def['foreign_key']
        if not isinstance(constraint, list):
            constraint = [constraint]

        for fk in constraint:
            # exclude values from each foreign key
            col_distinct_df = col_distinct_df.subtract(self.__fk_df_list[fk])
        foreign_key_test_passed = self._perform_test(col_distinct_df)
        if foreign_key_test_passed is False:
            error_message = '{fld}{rls} - foreign key constraints'.format(
                fld=field_name,
                rls="" if not rules else " (rule '{}')".format("', '".join(rules))
            )
            logging.info(error_message)
            field_def['violated'].append('foreign_key')
            errors.append(("error", error_message))

        return errors

    def __check_concept_id(self, field_def, table_df, rules):
        """Check concept_id specific stuff (vocs, domains etc)."""
        if self.__fk_df_list.get('concept.concept_id') is None:
            self.__collect_special_fk('voc_schema', 'concept', 'concept_id', \
                                       ['concept_id', 'vocabulary_id', 'domain_id', 'invalid_reason', 'standard_concept'])

        check_df = self._prefilter(table_df, rules, field_def['field'], field_def.get("allow_zero"))
        CHECK_FUNCS = (
            ("concept_id",  self._check_concept_id_type, "error"),
            ("allow_zero",  self._check_zero_concept,    "error"),
            ("domain",      self._check_domain,          "error"),
            ("vocabulary",  self._check_vocabulary,      "error"),
            ("is_standard", self._check_is_standard,     "error")
        )
        errors = list()

        for condition, checkfunc, severity in CHECK_FUNCS:
            this_result = checkfunc(field_def, check_df)
            if this_result is False:
                error_message = '{fld}{rls} - {cnd}'.format(
                    fld=field_def['field'], cnd=condition,
                    rls="" if not rules else " (rule '{}')".format("', '".join(rules))
                )
                logging.info(error_message)
                errors.append((severity, error_message))
                field_def['violated'].append(condition)

        return errors

    def __check_event_dates(self, field_def, table_df):
        """
        Check event dates against OMOP constraints and common sense
        Checks:
            - year of event date should be >= patient's year of birth
            - event data should be <= patient's death date + N days (default 60)
            - event date should be inside either observation period or payer plan period
            - event date should be inside start and end dates of a corresponding visit_occurrence

        """
        # Default number of days is defined by Themis
        num_days = self.__cdm_conf.__dict__.get('days_allowed_after_death') or 60
        errors = list()

        dfs_to_take = {
            'person': ['person_id', 'year_of_birth'],
            'death':  ['death_date', 'person_id'],
            # skipping period checks because out-of-period events are now valid in OMOP
            #'cdm_observation_period': ['observation_period_id', 'person_id', 'observation_period_start_date', 'observation_period_end_date'],
            #'cdm_payer_plan_period':  ['payer_plan_period_id', 'person_id', 'payer_plan_period_start_date', 'payer_plan_period_end_date'],
        }

        fields_needed = ['person_id', field_def['field']]

        if field_def.get('inside_visit_dates'):
            fields_needed.append('visit_occurrence_id')
            dfs_to_take['visit_occurrence'] = ['visit_occurrence_id', 'visit_start_date', 'visit_end_date']


        for name, fields in dfs_to_take.items():
            self.__collect_special_fk(self.default_schema_tag, name, fields[0], fields)

        event_df = table_df.select(fields_needed).filter('{event_field} is not null'.format(event_field=field_def['field']))

        check_dfs = {
            'year of event < year of birth':
                    event_df.join(self.__fk_df_list['person.person_id'], 'person_id') \
                            .filter('year({event_field}) < year_of_birth' \
                            .format(event_field=field_def['field'])),

            #'event date outside observation or payer plan period':
            #        event_df.join(self.__fk_df_list['cdm_observation_period.observation_period_id'], \
            #                                        [
            #                                            event_df['person_id'] == self.__fk_df_list['cdm_observation_period.observation_period_id']['person_id'],
            #                                            event_df[field_def['field']].between(self.__fk_df_list['cdm_observation_period.observation_period_id']['observation_period_start_date'],
            #                                                                                 self.__fk_df_list['cdm_observation_period.observation_period_id']['observation_period_end_date'])
            #                                        ], 'leftanti') \
            #                .join(self.__fk_df_list['cdm_payer_plan_period.payer_plan_period_id'], \
            #                                        [
            #                                            event_df['person_id'] == self.__fk_df_list['cdm_payer_plan_period.payer_plan_period_id']['person_id'],
            #                                            event_df[field_def['field']].between(self.__fk_df_list['cdm_payer_plan_period.payer_plan_period_id']['payer_plan_period_start_date'],
            #                                                                                 self.__fk_df_list['cdm_payer_plan_period.payer_plan_period_id']['payer_plan_period_end_date'])
            #                                        ], 'leftanti')
        }

        if field_def['field'] != 'death_date':
            check_dfs['event date > death date + {num} days'.format(num=num_days)] = \
                    event_df.join(self.__fk_df_list['death.death_date'], 'person_id') \
                            .filter('{event_field} > date_add(death_date,{num_days})' \
                                .format(event_field=field_def['field'], num_days=num_days))

        if 'visit_occurrence_id' in event_df.columns:
            check_dfs['event date outside related visit occurrence dates'] = \
                    event_df.filter('visit_occurrence_id IS NOT NULL').join(self.__fk_df_list['visit_occurrence.visit_occurrence_id'], \
                                [
                                    event_df['visit_occurrence_id'] == self.__fk_df_list['visit_occurrence.visit_occurrence_id']['visit_occurrence_id'],
                                    event_df[field_def['field']].between(self.__fk_df_list['visit_occurrence.visit_occurrence_id']['visit_start_date'],
                                                                         self.__fk_df_list['visit_occurrence.visit_occurrence_id']['visit_end_date'])
                                ], 'leftanti')


        for check in check_dfs:
            if self._perform_test(check_dfs[check]) is False:
                field_def['violated'].append(check)
                error_message = '{fld} - {cnd}'.format(fld=field_def['field'], cnd=check)
                errors.append(('warning', error_message))

        return errors


    def __check_rule_coverage(self, table_def, df):
        """Check that all rules present in target table have some coverage in unit test config"""
        errors = list()
        rules_in_conf = list()
        rules_in_df = [r[self.RULE_COL] for r in df.select(self.RULE_COL).distinct().collect()]

        for rule_def in table_def['rules']:
            rules_in_conf.extend(rule_def['rule'])

        rules_not_in_conf = ', '.join([i for i in rules_in_df if i not in rules_in_conf])

        if rules_not_in_conf:
            errors = [('warning', 'Rules potentially not covered by unit tests: ' + rules_not_in_conf)]

        return errors


    def __collect_special_fk(self, schema, table, main_field, required_fields):
        table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[schema], table)

        table_df = self.__session.conn \
            .table(table_name) \
            .select(required_fields) \
            .persist()
        self.__fk_df_list['{}.{}'.format(table, main_field)] = table_df


    def __collect_fk(self, field_def):
        constraint = field_def['foreign_key']
        if not isinstance(constraint, list):
            constraint = [constraint]

        for fk in constraint:
            if self.__fk_df_list.get(fk) is None:
                fk_schema_tag, fk_table, fk_field = fk.strip('@').split('.')
                fk_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[fk_schema_tag], fk_table)
                fk_df = self.__session.conn.table(fk_table_name).select(fk_field).distinct().persist()
                self.__fk_df_list[fk] = fk_df

    def _prefilter(self, df, rules, field_name, zero_allowed):
        fields_needed = field_name if not rules else [field_name, self.RULE_COL]
        df = df.select(fields_needed).distinct()
        if rules:
            df = df.filter(functions.col(self.RULE_COL).isin(rules))
        if zero_allowed:
            df = df.filter(functions.col(field_name) != 0)
        return df

    def _check_concept_id_type(self, field_def, df):
        """Check that all values are actually concept_ids present in vocabulary."""
        voc_df = self.__fk_df_list['concept.concept_id']
        # filter out zero concept_id to avoid data skew
        test_df = df.filter(df[field_def['field']] != 0) \
                    .join(voc_df, voc_df['concept_id'] == df[field_def['field']], "left_outer") \
                    .where(voc_df['concept_id'].isNull())
        return self._perform_test(test_df)

    def _check_zero_concept(self, field_def, df):
        if field_def.get("allow_zero") is not False:
            return None
        test_df = df.where(functions.col(field_def['field']) == 0)
        return self._perform_test(test_df)

    def _check_domain(self, field_def, df):
        if not field_def.get("domain"):
            return None
        voc_df = self.__fk_df_list['concept.concept_id']
        test_df = df.join(voc_df, voc_df['concept_id'] == df[field_def['field']]) \
                    .where(~voc_df['domain_id'].isin(field_def['domain']))
        return self._perform_test(test_df)

    def _check_vocabulary(self, field_def, df):
        if not field_def.get("vocabulary"):
            return None
        voc_df = self.__fk_df_list['concept.concept_id']
        test_df = df.join(voc_df, voc_df['concept_id'] == df[field_def['field']]) \
                    .where(~voc_df['vocabulary_id'].isin(field_def['vocabulary']))
        return self._perform_test(test_df)

    def _check_is_standard(self, field_def, df):
        if field_def.get("is_standard") is not True:
            return None
        voc_df = self.__fk_df_list['concept.concept_id']
        test_df = df.join(voc_df, voc_df['concept_id'] == df[field_def['field']]) \
                    .where((voc_df['standard_concept'].isNull()) |
                           (voc_df['standard_concept'] != "S") |
                           (voc_df['invalid_reason'].isNotNull()))
        return self._perform_test(test_df)

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"


class QARunner:
    """QA Scripts adapter."""

    def __init__(self, session, etl_home, etl_conf, conf=None, skip_warnings=False):
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.__etl_home = etl_home
        self.skip_warnings = skip_warnings
        self.__qa_results = list()
        self.run_log = RunLog()

    def run(self):
        """Run all QA scripts referenced in configuration file."""
        for script in self.__conf.scripts:
            script_path = os.path.join(self.__etl_home, "qa", script["script"])
            self.run_file(script_path)

    def run_file(self, file_path):
        """Run a single QA script, referenced by file path.

        Args:
            file_path (str): a full path to QA script.

        Returns:
            None

        """
        logging.info("Running QA script '%s'", file_path)
        etl_print("Running QA script '{script}'".format(script=file_path))
        with open(file_path) as script_file:
            script_contents = script_file.read()
        self.__qa_results.extend(self._run_qa_script(script_contents, file_path))

    def qa_results(self):
        return self.__qa_results

    def _get_params(self):
        """Get parameter values from ETLConf.

        Takes general 'params' section and 'params' from 'qa',
        values from the latter take precedence.

        Returns:
            dict: parameter names/values.

        """
        main_params = self.__etl_conf.params
        qa_params = dict()
        if self.__conf is not None:
            qa_params = self.__conf.get('params', {})
        return utils.merge_dicts(main_params, qa_params)

    def _run_qa_script(self, qa_script, file_name):
        """Run a set of QA queries from a single QA script.

        Transforms SQL code before execution, in this order:
        1) replaces schema tags with values;
        2) replaces parameter tags with values;
        3) splits the code into separate queries.

        Args:
            qa_script (str): the contents of QA script, SQL code.
            file_name (str): full path to QA script file.

        Returns:
            list: QA results.

        """
        qa_results = []
        script_name = os.path.split(file_name)[-1]
        qa_script = apply_schemas(qa_script, self.__etl_conf.schemas)
        qa_script = apply_params(qa_script, self._get_params())
        for query_id, sql_statement in enumerate(split_into_queries(qa_script)):
            if only_comments_in(sql_statement):
                continue
            etl_print('QA statement:\n{stm}'.format(stm=sql_statement))
            etl_print('Running QA statement', ETLMessageType.Running)
            with self.run_log.running("qa_run_statement", script_name=script_name, query_id=query_id):
                run_info = self._run_qa_statement(sql_statement, script_name)
            qa_results.append(run_info)
            if str(run_info.result).startswith("ERROR"):
                etl_print('', ETLMessageType.Failed)
            else:
                etl_print('', ETLMessageType.Ok)
            if run_info.result is None:
                etl_print('Previous QA query was skipped.', ETLMessageType.Warning)

        return qa_results

    def _run_qa_statement(self, sql_statement, script_name=None):
        """Run a single QA query.

        Args:
            sql_statement (str): Description of parameter `sql_statement`.

        Returns:
            type: Description of returned object.

        """
        qa_info = QAStepInfo.from_statement(sql_statement, script_name)
        if self.skip_warnings and qa_info.severity == "warning":
            return qa_info

        logging.info("Running SQL Statement: %s", sql_statement)
        try:
            df = self.__session.conn.sql(sql_statement)
            qa_info.result = df.head()[0]
            logging.info('QA Query returned ' + str(qa_info.result))
        except Exception as e:
            # do not raise, record error message for report
            qa_info.result = "ERROR:\n{}".format(e)
            logging.error("Failed to run statement. " + traceback.format_exc())

        return qa_info


class CDMUnloader(object):
    """CDM data unload adapter."""
    DEFAULT_OPT_VALUES = {
        "exclude_columns": None,
        "files_number":    None,
        "target_format":   "csv",
        "unload_mode":     "overwrite",
        "compression":     "none",
        "header":          True,
        "delimiter":       ",",
        "quote":           "\"",
        "escape":          None,
        "escape_quotes":   None,
        "quote_all":       None,
        "null_value":      None,
        "dateformat":      "yyyy-MM-dd",
        "timestampformat": "yyyy-MM-dd'T'HH:mm:ss",
        "trim_leading_space": False,
        "trim_trailing_space": False
    }
    INTERNAL_TO_SPARK_OPTS = {
        "compression":     "compression",
        "header":          "header",
        "delimiter":       "sep",
        "quote":           "quote",
        "escape":          "escape",
        "escape_quotes":   "escapeQuotes",
        "quote_all":       "quoteAll",
        "null_value":      "nullValue",
        "dateformat":      "dateFormat",
        "timestampformat": "timestampFormat",
        "trim_leading_space": "ignoreLeadingWhiteSpace",
        "trim_trailing_space": "ignoreTrailingWhiteSpace"
    }

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.UnloadConfig`): job configuration object
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.run_log = RunLog()

    def run(self):
        """Export data from target tables."""

        for folder in self.__conf.folders:
            if self.__conf.files_location.startswith('file:/') and self.__session.conn.sparkContext.master != 'local':
                etl_print("Files location starts with 'file:/'!", ETLMessageType.Error)
                raise ValueError("You cannot save files locally now. Please set 'master' to 'local' for the job in .eltconf")
            for table in folder["tables"]:
                table_options, data_options = self.prepare_table_options(self.__conf.files_location, folder, table)
                self.warn_strip_whitespaces(table_options["table_name"], data_options["target_format"], data_options["options"])
                self.indicate_start(table_options, data_options)
                try:
                    with self.run_log.running("unload_table", table_name=table_options["table_name"], target_file_path=data_options['final_path']):
                        table_df = self.prepare_table_data(**table_options)
                        self._perform_unload(table_df, **data_options)
                        if data_options['target_path'] != data_options['final_path']:
                            self._move_dir_with_single_file(data_options['target_path'], data_options['final_path'])
                except Exception as exc:
                    self.indicate_failure(table_options, data_options, exc)
                self.indicate_finish(table_options, data_options)

    def prepare_table_options(self, files_location, folder_conf, table_conf):
        """Prepares all params from unload config for one table.

        Table params override folder-level ones.
        Data is taken from @target_schema (if present, else from @cdm_schema).

        Args:
            files_location (str): where all files from this config file will be put.
            folder_conf (dict): whole folder configuration.
            table_conf (dict): table-specific configuration.

        Returns:
            tuple (dict, dict): params for DB retrieval, params for unload.

        """
        # where to get from
        schema_tag = folder_conf.get('schema', self.default_schema_tag)
        try:
            table_name = ".".join([self.__etl_conf.schemas[schema_tag], table_conf['table']])
        except KeyError:
            raise KeyError("Invalid schema tag: '{}'".format(schema_tag))
        option_values = utils.merge_dicts(self.DEFAULT_OPT_VALUES, folder_conf, table_conf)
        # where to put
        target_format = option_values["target_format"]
        target_path = os.path.join(files_location, folder_conf["folder"], table_conf['path'])
        final_path = target_path
        unload_mode = option_values["unload_mode"]
        options = {
            v: option_values[k]
            for k, v in self.INTERNAL_TO_SPARK_OPTS.items()
        }
        # if a single file
        if final_path.endswith(".{}".format(target_format)):
            temp_dir = os.path.join(files_location, folder_conf["folder"],
                                     "temp_{}".format(datetime.datetime.now().strftime('%y-%m-%d_%H-%M-%S-%f')))
            option_values["files_number"] = 1
            target_path = temp_dir

        table_options = {
            "table_name": table_name, "exclude_columns": option_values["exclude_columns"],
            "files_number": option_values["files_number"]
        }
        data_options = {
            "target_format": target_format,
            "target_path": target_path, "final_path": final_path,
            "unload_mode": unload_mode, "options": options
        }
        return table_options, data_options

    def prepare_table_data(self, table_name, exclude_columns, files_number):
        """Loads table data into DataFrame,
        excluding specified columns and repartitioning if necessary.

        Args:
            table_name (str): full table name with schema.
            exclude_columns (list of str): unnecessary column names.
            files_number (int): explicit number of partitions.

        Returns:
            DataFrame: table data to be unloaded.

        """
        # without .coalesce(x) or .repartition() it generates as many files as there partitions.
        # We should make it configurable to match import needs;
        # also see http://stackoverflow.com/questions/31674530/write-single-csv-file-using-spark-csv
        df = self.__session.conn.table(table_name)
        df = CDMUnloader.exclude_columns(df, exclude_columns)
        if files_number is not None:
            df = df.repartition(files_number)
        return df

    @staticmethod
    def exclude_columns(df, to_exclude):
        if to_exclude is None:
            return df
        for column in to_exclude:
            df = df.drop(column)
        return df

    @staticmethod
    def _perform_unload(df, target_format, target_path, final_path, unload_mode, options):
        return df.write.format(target_format) \
                       .options(**options) \
                       .mode(unload_mode) \
                       .save(target_path)

    def _move_dir_with_single_file(self, curr_path, final_path):
        from py4j.java_gateway import java_import
        java_import(self.__session.conn._jvm, 'org.apache.hadoop.fs.Path')
        fs = self.__session.conn._jvm.Path(final_path).getFileSystem(self.__session.conn._jsc.hadoopConfiguration())
        file = fs.globStatus(self.__session.conn._jvm.Path(os.path.join(curr_path, 'part*')))[0].getPath().getName()

        curr_name = self.__session.conn._jvm.Path(os.path.join(curr_path, file))
        final_name = self.__session.conn._jvm.Path(final_path)
        fs.rename(curr_name, final_name)
        fs.delete(self.__session.conn._jvm.Path(curr_path), True)

    @staticmethod
    def indicate_start(table_options, data_options):
        table_name = table_options['table_name']
        etl_print(
            "Unloading table '{}'".format(table_name),
            ETLMessageType.Running)
        logging.info("Unloading table '%s' to %s", table_name, data_options['target_path'])

    @staticmethod
    def indicate_failure(table_options, data_options, exception):
        etl_print('', ETLMessageType.Failed)
        etl_print("Unload process failed for table '{}'. See error details below:"
                  .format(table_options["table_name"]), ETLMessageType.Error)
        traceback.print_exc(file=sys.stdout)
        logging.error("Failed to unload table '%s' to %s.\n%s",
                      table_options["table_name"], data_options['target_path'], traceback.format_exc())
        raise E.JobExecException(cause=exception)

    @staticmethod
    def indicate_finish(table_options, data_options):
        etl_print('', ETLMessageType.Ok)
        logging.info("Table '%s' has been successfully unloaded to %s",
                     table_options["table_name"], data_options['target_path'])

    def warn_strip_whitespaces(self, table_name, target_format, option):
        """
        Rise a warning about trim leading/trailing whitespaces in csv:
        """

        if target_format != 'csv':
            return

        version_nums = self.__session.server_version().split('.')
        leading_version_num = int(version_nums[0] + version_nums[1])

        if leading_version_num < 22:
            etl_print(
                "Your spark version is older than 2.2.0. Leading/trailing whitespace will be trimmed in CSV for table {}".format(table_name),
                ETLMessageType.Warning
            )
        else:
            ignoreLeadingWhiteSpace = bool(option["ignoreLeadingWhiteSpace"])
            ignoreTrailingWhiteSpace = bool(option["ignoreTrailingWhiteSpace"])

            if ignoreLeadingWhiteSpace:
                etl_print(
                    "Parameter trim_leading_space is True so all leading whitespace will be dropped in csv for table {}.".format(table_name),
                    ETLMessageType.Warning
                )

            if ignoreTrailingWhiteSpace:
                etl_print("Parameter trim_trailing_space is True so all trailing whitespace will be dropped in csv for table {}.".format(table_name),
                ETLMessageType.Warning
            )

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"


class CustomStatsGenerator:
    """Generator for custom stats section of srcstats and cdmstats jobs."""

    _concept_df = None

    def generate_custom_stats(self, stat_bundle):
        """Calculate custom statistics.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info
        """
        CUSTOM_STATS = {
            'pie':                   self.__generate_custom_stats_pie,
            'mapping_rate':          self.__generate_custom_stats_mapping_rate,
            'top_values':            self.__generate_custom_stats_top_values,
            'top_mapped_concepts':   self.__generate_custom_stats_top_mapped_concepts,
            'top_unmapped_concepts': self.__generate_custom_stats_top_unmapped_concepts,
            'foreign_keys_rate':     self.__generate_custom_stats_foreign_key_rate,
            'distribution':          self.__generate_custom_stats_distribution,
            'first_last_values':     self.__generate_custom_stats_boundary_values
        }
        if stat_bundle['stat']['type'] not in CUSTOM_STATS:
            etl_print('', ETLMessageType.Failed)
            raise E.ConfigException("Unsupported custom stat type: '{}'".format(stat_bundle['stat']['type']))

        return CUSTOM_STATS[stat_bundle['stat']['type']](stat_bundle)

    def __generate_custom_stats_pie(self, stat_bundle):
        """Collect distinct values distribution for pie chart.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            list: custom stat data
        """
        val_counts = stat_bundle['table_df'].groupBy(stat_bundle['stat']['column']) \
                                            .agg({stat_bundle['stat']['column']: 'count'}) \
                                            .limit(100) \
                                            .select(functions.col(stat_bundle['stat']['column']).cast('string'), 'count({})'.format(stat_bundle['stat']['column'])) \
                                            .collect()
        value_names = dict()
        if stat_bundle['stat'].get('is_concept') is True:
            value_names = self.__translate_concept_ids(*[v[stat_bundle['stat']['column']] for v in val_counts if v[stat_bundle['stat']['column']] is not None])

        data = list()
        for val_count in val_counts:
            value = val_count[stat_bundle['stat']['column']]
            if stat_bundle['stat'].get('is_concept') is True and value is not None:
                value = value_names.get(int(value))
            data.append({
                'value': value,
                'count': val_count['count({col_name})'.format(col_name=stat_bundle['stat']['column'])]
            })
        return data

    @staticmethod
    def __generate_custom_stats_mapping_rate(stat_bundle):
        """Calculate mapping rate for a concept_id field.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            dict: custom stat data
        """
        table_df = stat_bundle['table_df'].where(stat_bundle['stat']['source_column'] + ' IS NOT NULL')
        unmapped_records_count = table_df.where(stat_bundle['stat']['column'] + ' = 0').count()
        amended_records_count = table_df.where(stat_bundle['stat']['column'] + ' > 2000000000').count()
        mapped_records_count = table_df.count() - unmapped_records_count - amended_records_count
        table_df_distinct = table_df.groupBy(stat_bundle['stat']['source_column']).agg({stat_bundle['stat']['column']: 'max'})
        unmapped_codes_count = table_df_distinct.where('max({col_name})'.format(col_name=stat_bundle['stat']['column']) + ' = 0').count()
        table_df_amended = table_df.groupBy(stat_bundle['stat']['source_column']).agg({stat_bundle['stat']['column']: 'min'})
        amended_codes_count = table_df_amended.where('min({})'.format(stat_bundle['stat']['column']) + ' > 2000000000').count()
        mapped_codes_count = table_df_distinct.count() - unmapped_codes_count - amended_codes_count
        return {
            "records": [
                {'value': 'mapped', 'count': mapped_records_count},
                {'value': 'amended', 'count': amended_records_count},
                {'value': 'unmapped', 'count': unmapped_records_count}
            ],
            "codes": [
                {'value': 'mapped', 'count': mapped_codes_count},
                {'value': 'amended', 'count': amended_codes_count},
                {'value': 'unmapped', 'count': unmapped_codes_count}
            ]
        }

    def __generate_custom_stats_top_values(self, stat_bundle):
        """Collect top N values.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            list: custom stat data
        """
        data = list()
        table_df = stat_bundle['table_df'].where(stat_bundle['stat']['column'] + ' IS NOT NULL')
        val_counts = table_df.groupBy(stat_bundle['stat']['column']) \
                                     .agg({stat_bundle['stat']['column']: 'count'}) \
                                     .orderBy('count({})'.format(stat_bundle['stat']['column']), ascending=False) \
                                     .limit(stat_bundle['stat']['num']) \
                                     .select(functions.col(stat_bundle['stat']['column']).cast('string'), 'count({})'.format(stat_bundle['stat']['column'])) \
                                     .collect()
        for val in val_counts:
            data.append({
                'value': val[stat_bundle['stat']['column']],
                'count': val['count({col_name})'.format(col_name=stat_bundle['stat']['column'])]
            })
        return data

    def __generate_custom_stats_top_mapped_concepts(self, stat_bundle):
        """Collect top N mapped concepts with concept names.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            list: custom stat data
        """
        data = list()
        mapped_df = stat_bundle['table_df'].where(stat_bundle['stat']['column'] + ' != 0')
        val_counts_mapped = mapped_df.groupBy(stat_bundle['stat']['column']) \
                                     .agg({stat_bundle['stat']['column']: 'count'}) \
                                     .orderBy('count({})'.format(stat_bundle['stat']['column']), ascending=False) \
                                     .limit(stat_bundle['stat']['num']) \
                                     .collect()

        value_names = self.__translate_concept_ids(*[v[stat_bundle['stat']['column']] for v in val_counts_mapped if v[stat_bundle['stat']['column']] is not None])

        for val in val_counts_mapped:
            data.append({
                'value': value_names.get(val[stat_bundle['stat']['column']]),
                'count': val['count({col_name})'.format(col_name=stat_bundle['stat']['column'])]
            })
        return data

    def __generate_custom_stats_top_unmapped_concepts(self, stat_bundle):
        """Collect top N unmapped source codes.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            list: custom stat data
        """
        data = list()
        mapped_df = stat_bundle['table_df'].where(stat_bundle['stat']['concept_column'] + ' = 0')
        val_counts_mapped = mapped_df.groupBy(stat_bundle['stat']['column']) \
                                     .agg({stat_bundle['stat']['column']: 'count'}) \
                                     .orderBy('count({})'.format(stat_bundle['stat']['column']), ascending=False) \
                                     .limit(stat_bundle['stat']['num']) \
                                     .collect()
        for val in val_counts_mapped:
            data.append({
                'value': val[stat_bundle['stat']['column']],
                'count': val['count({col_name})'.format(col_name=stat_bundle['stat']['column'])]
            })
        return data

    def __generate_custom_stats_foreign_key_rate(self, stat_bundle):
        """Calculate the percentage of values from foreign column present in current field.

        Referenced field might contain duplicates.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            dict: custom stat data
        """
        distincts_count = stat_bundle['table_df'].select(stat_bundle['stat']['column']).distinct().count()
        ref_table_count = stat_bundle['ref_table_df'].select(stat_bundle['ref_field_name']).distinct().count()
        return {
            'mapped': distincts_count,
            'unmapped': ref_table_count - distincts_count
        }

    def __generate_custom_stats_distribution(self, stat_bundle):
        """Prepare data for Distribution custom stat.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            list: custom stat data
        """
        data = list()
        selector = stat_bundle['stat']['column']
        if stat_bundle['stat'].get('extract_year'):
            selector = functions.year(selector).alias(stat_bundle['stat']['column'])
        column_df = stat_bundle['table_df'].select(selector)
        val_counts_mapped = column_df.groupBy(stat_bundle['stat']['column']) \
                                     .count() \
                                     .orderBy(stat_bundle['stat']['column']) \
                                     .collect()
        for val in val_counts_mapped:
            data.append({
                'value': str(val[0]),
                'count': val[1]
            })
        return data

    def __generate_custom_stats_boundary_values(self, stat_bundle):
        """Prepare data for Top/Bottom Values custom stat.

        Args:
            stat_bundle (dict): contains table dataframes and stat conf info

        Returns:
            dict: extracted values, by key ('first_values', 'last_values').
        """
        values_amount = stat_bundle['stat'].get('num', 10)
        column_name = stat_bundle['stat']['column']
        data = {
            'first_values': [],
            'last_values': []
        }
        column_df = stat_bundle['table_df'].select(column_name).distinct().persist()
        first_values = column_df.orderBy(column_name) \
                                .limit(values_amount) \
                                .collect()
        last_values = column_df.orderBy(column_name, ascending=False) \
                               .limit(values_amount) \
                               .collect()
        for row_1, row_2 in zip(first_values, last_values):
            data['first_values'].append(str(row_1[0]))
            data['last_values'].append(str(row_2[0]))
        column_df.unpersist()
        return data

    def __translate_concept_ids(self, *concept_ids):
        df = self._concept_df.where(functions.col('concept_id').isin(list(concept_ids))).select('concept_id', 'concept_name')
        res = [{r[0]: r[1]} for r in df.collect()]
        return {k: v for d in res for k, v in d.items()}


class CDMStatsGenerator:
    """CDM Statistics generator."""
    RULE_COL = "rule_id"

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.CDMStatsConfig`): job configuration object
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.stats = CDMDataStats()
        self.__concept_df = None
        self.__custom_stats_gen = CustomStatsGenerator()
        self.run_log = RunLog()

    def run(self):
        """Generate CDM stats."""
        self.stats.created_date = datetime.datetime.now()
        for table in self.__conf.tables:
            etl_print("Generating stats for '{table}' table.".format(table=table['table']))
            try:
                with self.run_log.running("table_stats", table=table['table']):
                    table_stats = self.generate_table_stats(table)
                    if table_stats.stats.count > 0:
                        self.stats.vocabs = list(set(self.fetch_vocabularies(table_stats.table_name) + self.stats.vocabs))
            except Exception as e:
                raise E.JobExecException(cause=e)
            self.stats.table_stats.append(table_stats)

    def generate_table_stats(self, table_conf):
        """Generate stats for a single CDM table.

        Args:
            table_conf: stats configuration for the table

        Returns:
            :class:`CDMDataStats.TableStats`
        """
        table_stats = CDMDataStats.TableStats(table_conf['table'])
        schema_tag = self.__conf.__dict__.get("schema") or self.default_schema_tag
        table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[schema_tag], table_stats.table_name)
        df = self.__session.conn.table(table_name)

        with self.run_log.running("rule_stats", table=table_conf["table"], rule_id=None):
            table_stats.stats = self.__generate_rule_stats(df)
        if table_stats.stats.count == 0:
            return table_stats

        if self.__conf.generate_table_data_sample is True:
            table_stats.data_sample = self.__generate_table_data_sample(df)

        if 'custom_stats' in table_conf:
            custom_stats_list = list()
            custom_stats_conf = deepcopy(table_conf['custom_stats'])
            for stat in custom_stats_conf:
                etl_print(
                    "Generating custom stat '{stat_type}'".format(
                        stat_type=stat['type']),
                    ETLMessageType.Running
                )
                vocs_required = (stat['type'] == 'top_mapped_concepts') or (stat.get('is_concept') is True)
                if vocs_required:
                    # also used for by-rule custom stats later
                    self.__fetch_voc_concept_df()

                stat_bundle = {
                    'table_df': df,
                    'stat': stat
                }
                if stat['type'] == 'foreign_keys_rate':
                    fk_ref = configs.ForeignKeyRef(stat['target_table'])
                    fk_tbl_name = utils.locate_table(
                        self.__session,
                        self.__etl_conf.schemas[fk_ref.schema_tag or schema_tag],
                        fk_ref.table_name)
                    stat_bundle['ref_table_df'] = self.__session.conn.table(fk_tbl_name)
                    stat_bundle['ref_field_name'] = fk_ref.field_name or stat['column']

                stat['data'] = self.__custom_stats_gen.generate_custom_stats(stat_bundle)
                custom_stats_list.append(stat)
                etl_print('', ETLMessageType.Ok)

            table_stats.custom_stats = custom_stats_list

        if self.RULE_COL not in df.columns:
            return table_stats

        rule_ids = self.collect_table_rules(df)
        rules_list = list()

        for rule_id in rule_ids:
            if len(rule_ids) == 1:
                # skip when single rule_id in whole table (CDMK-252)
                stats_copy = deepcopy(table_stats.stats)
                stats_copy.rule_id = rule_id
                rules_list.append(stats_copy)
                break
            etl_print(
                "Generating stats for '{rule_id}' rule"
                .format(rule_id=rule_id)
            )
            with self.run_log.running("rule_stats", table=table_conf["table"], rule_id=rule_id):
                rule_stats = self.__generate_rule_stats(df, rule_id=rule_id)

            if 'custom_stats' in table_conf and \
               table_conf.get('generate_custom_stats_by_rule', self.__conf.generate_custom_stats_by_rule) is True:
                rule_custom_stats = list()
                rule_custom_stats_conf = deepcopy(table_conf['custom_stats'])
                for stat in rule_custom_stats_conf:
                    subset_df = df.where("{rule_col} = '{rule_id}'".format(rule_col=self.RULE_COL, rule_id=rule_id))
                    stat_bundle = {
                        'table_df': subset_df,
                        'stat': stat,
                    }
                    if stat['type'] == 'foreign_keys_rate':
                        fk_ref = configs.ForeignKeyRef(stat['target_table'])
                        fk_tbl_name = utils.locate_table(
                            self.__session,
                            self.__etl_conf.schemas[fk_ref.schema_tag or schema_tag],
                            fk_ref.table_name)
                        stat_bundle['ref_table_df'] = self.__session.conn.table(fk_tbl_name)
                        stat_bundle['ref_field_name'] = fk_ref.field_name or stat['column']

                    etl_print(
                        "Generating custom stat '{stat_type}' ('{rule_id}' rule)"
                        .format(stat_type=stat['type'], rule_id=rule_id),
                        ETLMessageType.Running
                    )
                    stat['data'] = self.__custom_stats_gen.generate_custom_stats(stat_bundle)
                    rule_custom_stats.append(stat)
                    etl_print('', ETLMessageType.Ok)
                rule_stats.custom_stats = rule_custom_stats
            rules_list.append(rule_stats)

        table_stats.rules = rules_list
        return table_stats

    def __generate_rule_stats(self, table_df, rule_id=None):
        """Count table-level basic statistics.

        Operates on all records by default, but if rule_id is present, operates on a subset.

        Args:
            table_df (:class:`DataFrame`): Spark dataframe for the table
            rule_id (:obj:`str`, optional): business rule name

        Returns:
            :class:`CDMDataStats.RuleSubsetStats`
        """
        rule_stats = CDMDataStats.RuleSubsetStats()

        if rule_id is None:
            df = table_df
        elif rule_id == "None":
            df = table_df.where(table_df[self.RULE_COL].isNull())
        else:
            df = table_df.where(table_df[self.RULE_COL] == rule_id)

        rule_stats.count = df.count()

        rule_stats.rule_id = rule_id
        if rule_id is None or self.__conf.generate_stats_by_rule is True:
            rule_stats.column_stats = self.__generate_column_stats(df, rule_stats.count)

        return rule_stats

    def __generate_column_stats(self, table_df, table_count=0):
        """Calculate basic column-level statistics.

        Args:
            table_df (:class:`DataFrame`): Spark dataframe for the table.
            table_count (int): number of records in the table. Defaults to 0.

        Returns:
            list: array of ColumnStatsBase objects.
        """
        column_stats_df = table_df

        column_stats = list()

        for column, column_type in column_stats_df.dtypes:
            # NOTE disable persist/unpersist in case of OoM errors
            column_df = column_stats_df.select(column).persist()

            data_sample = list()
            nulls_count = 0
            distincts_count = 0

            if table_count > 0:
                distincts_count = column_df.distinct().count()
                nulls_count = column_df.where("{clm} IS NULL".format(clm=column)).count()
                data_sample = self.__get_top_values(column_df, column, \
                                                    self.__conf.column_data_sample_rows, table_count!=distincts_count)

                if "_concept_id" in column:
                    self.__fetch_voc_concept_df()
                    translated_concepts = self.__translate_concept_ids(*[val["value"] for val in data_sample])
                    data_sample = [
                        {
                            "value": val['value'],
                            "name": translated_concepts[int(val['value'])] if val['value'] is not None else None,
                            "count": val['count']
                        } for val in data_sample
                    ]

            column_df.unpersist()

            column_stats.append(ColumnStatsBase(column, column_type, data_sample, nulls_count, distincts_count))

        return column_stats

    def __get_top_values(self, column_df, column_name, limit, is_grouping):
        if is_grouping:
            distincts = column_df.groupBy(column_name) \
                                 .count() \
                                 .orderBy(functions.col('count').desc()) \
                                 .limit(limit) \
                                 .select(functions.col(column_name).cast('string'), 'count') \
                                 .collect()
            return [
                {
                    "value": val[column_name],
                    "count": val['count']
                } for val in distincts
            ]
        else:
            return [
                {
                    "value": val[column_name],
                    "count": 1
                } for val in column_df.select(functions.col(column_name).cast('string')).take(limit)
            ]

    def __generate_table_data_sample(self, table_df):
        result = list()
        data_sample = table_df.select('*').take(self.__conf.table_data_sample_rows)
        for ds in data_sample:
            result.append(
                {key: str(value) for key, value in ds.asDict().items()}
            )
        return result

    def __translate_concept_ids(self, *concept_ids):
        df = self.__concept_df.where(functions.col('concept_id').isin(list(concept_ids))).select('concept_id', 'concept_name')
        res = [{r[0]: r[1]} for r in df.collect()]
        return {k: v for d in res for k, v in d.items()}

    def __fetch_voc_concept_df(self):
        if self.__concept_df is not None:
            # noop on consequent calls
            return
        concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['voc_schema'], 'concept')
        self.__concept_df = self.__session.conn.table(concept_table_name) \
            .select('concept_id', 'concept_name')
        self.__custom_stats_gen._concept_df = self.__concept_df

    def fetch_vocabularies(self, table_name):
        """Fetch all vocabularies are used in provided table

        Args:
            table_name (str): Table for what vocabularies must be extracted
        Returns:
            [List]: List of vocabularies are used in provided table
        """
        schema_tag = self.__conf.__dict__.get("schema") or self.default_schema_tag
        concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['voc_schema'], 'concept')
        table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[schema_tag], table_name)
        table_df = self.__session.conn.table(table_name)
        query = (
            "SELECT DISTINCT c.vocabulary_id"
            " FROM {table} as src"
            " INNER JOIN {concept} as c"
            " ON c.concept_id = src.{column}"
            " WHERE {column} != 0"
        )
        vocabularies = set()

        for column, _ in table_df.dtypes:
            if "_concept_id" in column and "_type_concept_id" not in column: 
                df = self.__session.conn.sql(query.format(table=table_name, concept=concept_table_name, column=column))
                vocabularies.update([r['vocabulary_id'] for r in df.collect()])

        return list(vocabularies)

    def collect_table_rules(self, table_df):
        """Collect distinct rule_id values from table.

        If table does not contain 'rule_id' field -> return empty list.
        If table does not contain 'rule_id' other than NULL -> return empty list.

        Args:
            table_df (:class:`DataFrame`): Spark dataframe for the table

        Returns:
            list: list of string rule ids or empty list
        """
        if self.RULE_COL not in table_df.columns:
            return list()
        rule_rows = table_df.select(self.RULE_COL).distinct().collect()
        rules = [str(row[self.RULE_COL]) for row in rule_rows]
        if rules == ["None"]:
            # NULL is the only value -> column is present, but no rules
            return list()
        return rules

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"


class SourceDataStatsGenerator:
    """Source Data Statistics generator."""
    default_schema_tag = "source_schema"

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.StatsConfig`): job configuration object
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.stats = SourceDataStats()
        self.__custom_stats_gen = CustomStatsGenerator()
        self.run_log = RunLog()

    def run(self):
        """Generate source data stats."""
        self.stats.created_date = datetime.datetime.now()
        schema_tag = self.__conf.schema or self.default_schema_tag
        schema = self.__etl_conf.schemas[schema_tag]

        should_autodiscover = len(self.__conf.tables) == 0
        is_error = False
        if should_autodiscover:
            source_tables = self.get_source_tables(schema)
            located_table = self.locate_tables(source_tables, schema)
        else:
            located_table = self.locate_tables(self.__conf.tables, schema)
            for table in located_table:
                if len(table["table"]) == 0:
                    is_error = True
                    etl_print("Table {} has not been found!".format(table["table_conf"]["table"]), ETLMessageType.Error)

        if is_error:
            raise ValueError("Some of the tables have not been found. Please check table names")
        if len(located_table) == 0:
            raise ValueError("No tables are found in '{}' schema.".format(schema))

        for table in located_table:
            etl_print(
                'Generating source stats for table "{table}"'
                .format(table=table["table_conf"]['table']))
            try:
                with self.run_log.running("srcstats_table", table=table["table"]):
                    table_stats = self.generate_table_stats(table, schema)
                    self.stats.table_stats.append(table_stats)
            except Exception as e:
                etl_print(
                    'Failed to generate table stats\n{exc}'.format(exc=e),
                    ETLMessageType.Failed
                )

    def get_source_tables(self, schema):
        """
        Try to get all tables from source schema

        Args:
            schema: String which represent schema where table is kept

        Returns:
            List of source tables
        """
        etl_print("Getting all tables from the source schema")
        return [
            {"table": table}
            for table in self.__session.get_table_list(schema)
        ]

    def locate_tables(self, tables, schema):
        """
        Try to locate all tables

        Args:
            tables: list of stats configuration for tables which must be located
            schema: String which represent schema where table is kept

        Returns:
            List of table with "location"
        """
        etl_print("Locating all stats tables")
        table_list = self.__session.get_table_list(schema)
        located_tables = []
        for table in tables:
            locating_table = {
                "table_conf": table,
                "table": ""
            }

            if table["table"] in table_list:
                locating_table["table"] = "{}.{}".format(schema, table["table"])
            located_tables.append(locating_table)

        return located_tables

    def generate_table_stats(self, table, schema):
        """Generate stats for a single table.

        Args:
            table: stats configuration for the table
            schema: String which represent schema where table is kept

        Returns:
            :class:`SourceDataStats.SourceTableStats`
        """
        table_conf = table["table_conf"]
        table_stats = SourceDataStats.SourceTableStats(table_conf['table'])
        table_name = table["table"]
        table_df = self.__session.conn.table(table_name)
        table_stats.count = table_df.count()

        if 'fields' in table_conf:
            columns_list = [
                {"name": column_name, "type": column_type, "is_skipped": False}
                if column_name in table_conf['fields']
                else {"name": column_name, "type": column_type, "is_skipped": True}
                for (column_name, column_type) in table_df.dtypes
            ]
        else:
            columns_list = [
                {"name": column_name, "type": column_type, "is_skipped": False}
                for (column_name, column_type) in table_df.dtypes
            ]
        table_stats.stats = self.__generate_column_stats(
            table_df=table_df,
            count=table_stats.count,
            columns_list=columns_list,
            limit=self.__conf.column_data_sample_rows
        )

        if 'custom_stats' in table_conf:
            custom_stats_list = list()
            custom_stats_conf = deepcopy(table_conf['custom_stats'])
            for stat in custom_stats_conf:
                etl_print(
                    "Generating custom stat '{stat_type}' for '{column}' field".format(
                        stat_type=stat['type'], column=stat['column']),
                    ETLMessageType.Running
                )

                stat_bundle = {
                    'table_df': table_df,
                    'stat': stat
                }
                if stat['type'] == 'foreign_keys_rate':
                    fk_ref = configs.ForeignKeyRef(stat['target_table'])
                    fk_tbl_name = utils.locate_table(
                        self.__session,
                        self.__etl_conf.schemas[fk_ref.schema_tag]
                        if fk_ref.schema_tag is not None
                        else schema,
                        fk_ref.table_name)
                    stat_bundle['ref_table_df'] = self.__session.conn.table(fk_tbl_name)
                    stat_bundle['ref_field_name'] = fk_ref.field_name or stat['column']

                stat['data'] = self.__custom_stats_gen.generate_custom_stats(stat_bundle)
                custom_stats_list.append(stat)
                etl_print('', ETLMessageType.Ok)

            table_stats.custom_stats = custom_stats_list

        return table_stats

    def __generate_column_stats(self, table_df, count, columns_list, limit):
        """Calculate basic column-level statistics.

        Args:
            table_df (:class:`DataFrame`): Spark dataframe for the table
            count (int): total number of records
            columns_list (list): array of fields (dict)

        Returns:
            list: array of SourceColumnStats objects
        """
        column_stats = list()
        for column in columns_list:
            if column['is_skipped']:
                col_stats = SourceColumnStats(column['name'], column['type'], [], is_skipped=True)
                etl_print(
                    "Field '{col}' is skipped".format(col=column['name']),
                    ETLMessageType.Warning
                )
            else:
                etl_print(
                    'Generating source stats for column "{col}".'.format(col=column['name']),
                    ETLMessageType.Running
                )
                column_df = table_df.select(column['name']).persist()
                distincts_count = column_df.distinct().count()
                nulls_count = column_df.where("{clm} IS NULL".format(clm=column['name'])) \
                                       .count()
                data_sample = self.__get_top_values(column_df, column['name'], limit, count != distincts_count)
                data_type = 0
                if distincts_count == count:
                    data_type = 1
                elif distincts_count == 1:
                    data_type = 2

                col_stats = SourceColumnStats(
                    column['name'], column['type'], data_sample,
                    nulls_count, distincts_count, data_type, is_skipped=False)
                etl_print('', ETLMessageType.Ok)

            column_stats.append(col_stats)
            column_df.unpersist()

        return column_stats

    def __get_top_values(self, column_df, column_name, limit, is_grouping):
        if is_grouping:
            distincts = column_df.groupBy(column_name) \
                                 .count() \
                                 .orderBy(functions.col('count').desc()) \
                                 .limit(limit) \
                                 .select(functions.col(column_name).cast('string'), 'count') \
                                 .collect()
            return [
                {
                    "value": val[column_name],
                    "count": val['count']
                } for val in distincts
            ]
        else:
            return [
                {
                    "value": val[column_name],
                    "count": 1
                } for val in column_df.select(functions.col(column_name).cast('string')).take(limit)
            ]


class CustomVocMerger:
    """Builds custom vocabulary tables from vocabulary stage files."""

    POSTFIXES = {
        'new':      '_stage_new',
        'old':      '_stage_old',
        'amend':    '_amend'
    }

    def __init__(self, session, etl_conf, conf):
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.__update_etl_conf_schemas(conf.schemas)
        # todo: i think we should add like env vars from the info we have in etlconf (and even maybe take real env vars)
        self.__etl_conf.__dict__['params']['dbms'] = 'spark'
        self.CHECK_FUNCTIONS_MAPPING = {
            'concept':                self.__check_concept_stage,
            'concept_relationship':   self.__check_concept_relationship_stage,
            'concept_ancestor':       self.__check_concept_ancestor_stage,
            'vocabulary':             self.__check_vocabulary_stage
        }
        self.__ddl_creator = CDMDDLCreator(session, etl_conf, row_id=False, cdm_schema_conf=None, tables=None)
        self.__workflow_runner = WorkflowRunner(session, etl_conf, should_count=False)
        self.error_list = []
        self.warning_list = []
        self.run_log = RunLog()
        # reuse run_log in child runners to collect full run info
        self.__ddl_creator.run_log = self.run_log
        self.__workflow_runner.run_log = self.run_log

    def __update_etl_conf_schemas(self, schema_refs):
        for schema_ref_name in schema_refs.keys():
            schema_ref = schema_refs[schema_ref_name]
            self.__etl_conf.schemas[schema_ref_name] = self.__etl_conf.schemas[schema_ref]

    def run(self):
        for ddl_conf_file in self.__conf.ddl_conf_files:
            ddl_conf = configs.CDMTablesConfig(ddl_conf_file)
            if ddl_conf_file.endswith("old_stage_ddl.conf"):
                schema_name = self.__etl_conf.schemas[ddl_conf.schema]
                # filter out stage tables that already exist
                already_exist = list()
                for tbl in [t['table'] for t in ddl_conf.tables]:
                    try:
                        voc_table_name = utils.locate_table(self.__session, schema_name, tbl)
                        already_exist.append(tbl)
                    except ValueError:
                        pass
                if not already_exist and not self.__conf.empty_old:
                    raise E.JobExecException(
                        "No 'old' custom voc stages found. Either load the old stage files or use '--empty-old'"
                    )
                ddl_conf.tables = [t for t in ddl_conf.tables if t['table'] not in already_exist]
            elif ddl_conf_file.endswith("new_stage_ddl.conf"):
                schema_name = self.__etl_conf.schemas[ddl_conf.schema]
                already_exist = list()
                for tbl in [t['table'] for t in ddl_conf.tables]:
                    try:
                        voc_table_name = utils.locate_table(self.__session, schema_name, tbl)
                        already_exist.append(tbl)
                    except ValueError:
                        pass
                if not already_exist and not self.__conf.empty_new:
                    raise E.JobExecException(
                        "No 'new' custom voc stages found. Either load the new stage files or use '--empty-new'"
                    )
                ddl_conf.tables = [t for t in ddl_conf.tables if t['table'] not in already_exist]
            self.__ddl_creator.set_ddl_conf(ddl_conf)
            self.__ddl_creator.run()

        if not self._check_custom_voc_stages():
            raise E.JobExecException("There are errors in the custom voc stages")

        for script in self.__conf.workflow:
            self.__workflow_runner.run(script['statements'])

    def _check_custom_voc_stages(self):
        """Checks freshly uploaded stage with the previous one and OMOP vocs

        Returns:
            bool: True if no errors found, False otherwise
        """
        tables_to_check = [
            'concept',
            'concept_relationship',
            'concept_ancestor',
            'vocabulary'
        ]
        for table in tables_to_check:
            self.CHECK_FUNCTIONS_MAPPING[table]()

        for warning in self.warning_list:
            etl_print(warning['message'] + '\n' + warning['info'], ETLMessageType.Warning)
        for error in self.error_list:
            etl_print(error['message'] + '\n' + error['info'], ETLMessageType.Error)
        failed_checks_counts = {
            'no': len(self.warning_list) | len(self.error_list),
            'warning': len(self.error_list),
            'error': 0
        }
        return failed_checks_counts[self.__conf.ignore_level] == 0

    def __check_concept_stage(self):
        pass

    def __check_concept_relationship_stage(self):
        stages = ['old', 'new']
        for stage in stages:
            codes = self.__get_nonexistent_codes('concept_relationship', 'concept_code_1', 'vocabulary_id_1', stage)
            if len(codes) > 0:
                self.error_list.append({
                    'message': 'Nonexistent codes (no OMOP or staged) in concept_relationship_{stage}'.format(stage=stage),
                    'info': 'Concepts: ' + ';\n'.join(map(lambda x: str(x), codes))
                })

    def __check_concept_ancestor_stage(self):
        stages = ['old', 'new']
        for stage in stages:
            codes = self.__get_nonexistent_codes('concept_ancestor', 'ancestor_concept_code', 'ancestor_vocabulary_id', stage)
            if len(codes) > 0:
                self.warning_list.append({
                    'message': 'Nonexistent codes (no OMOP or staged) in concept_ancestor_{stage}'.format(stage=stage),
                    'info': 'Concepts: ' + ';\n'.join(map(lambda x: str(x), codes))
                })

    def __check_vocabulary_stage(self):
        voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['omop_voc_schema'], 'vocabulary')
        new_voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['new_stage_schema'], 'vocabulary'+self.POSTFIXES['new'])
        old_voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['old_stage_schema'], 'vocabulary'+self.POSTFIXES['old'])

        voc_df = self.__get_sliced_df(voc_table_name, 'vocabulary_id', 'vocabulary_version')
        new_voc_df = self.__get_sliced_df(new_voc_table_name, 'vocabulary_id', 'vocabulary_version')
        old_voc_df = self.__get_sliced_df(old_voc_table_name, 'vocabulary_id', 'vocabulary_version')

        voc_date = self.__get_voc_version_date(voc_df)
        new_voc_date = self.__get_voc_version_date(new_voc_df)
        old_voc_date = self.__get_voc_version_date(old_voc_df)

        if new_voc_date < old_voc_date and not (self.__conf.empty_old or self.__conf.empty_new):
            self.error_list.append({
                'message': 'Version of vocabularies in new stage is older than in the old',
                'info': 'New version: ' + str(new_voc_date) + '\nOld version: ' + str(old_voc_date)
            })
        if new_voc_date != voc_date and not self.__conf.empty_new:
            self.error_list.append({
                'message': 'Version of vocabularies in new stage does not match version of OMOP vocabularies',
                'info': 'New version: ' + str(new_voc_date) + '\nOMOP voc version: ' + str(voc_date)
            })

    def __get_nonexistent_codes(self, table_name, code_field, voc_field, stage='new'):
        """Searches for nonexistent codes in the specified table.

        Args:
            table_name (str): Name of the table to check
            code_field (str): Name of the field with concept code
            voc_field (str): Name of the field with vocab id
            stage (str): Name of the stage to check

        Returns:
            list: List of nonexistent codes
        """
        concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['omop_voc_schema'], 'concept')
        stage_concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[stage+'_stage_schema'], 'concept'+self.POSTFIXES[stage])
        target_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[stage+'_stage_schema'], table_name+self.POSTFIXES[stage])

        cdf = self.__get_sliced_df(concept_table_name, 'concept_code', 'vocabulary_id')
        stage_cdf = self.__get_sliced_df(stage_concept_table_name, 'concept_code', 'vocabulary_id')
        tdf = self.__get_sliced_df(target_table_name, code_field, voc_field)
        result_raw = tdf.subtract(cdf).subtract(stage_cdf).collect()  # maybe replace with left_anti join?

        return list(map(lambda x: x.asDict(), result_raw))

    def __get_sliced_df(self, table_name, *field_list):
        return self.__session.conn.table(table_name).select(*field_list)

    def __get_voc_version_date(self, df):
        try:
            unixtime = df\
                .where(df['vocabulary_id'] == 'None')\
                .withColumn('unixtime', functions.unix_timestamp(functions.split(df['vocabulary_version'], ' ')[1], 'dd-MMM-yy'))\
                .collect()[0]\
                .unixtime
        except IndexError:
            return datetime.date.min
        return datetime.date.fromtimestamp(unixtime)


class SrcToCdmCounts:
    none_table = 'NO Events or Visits'

    # source to cdm counts record (Link record)
    class SdcLink:
        def __init__(self, src_table_id, cdm_table_id, cdm_partial_count):
            self.src_table_id = src_table_id
            self.cdm_table_id = cdm_table_id
            self.cdm_partial_count = cdm_partial_count

        # as record in a flat list
        def to_json(self):
            return {
                "cdm_partial_count": self.cdm_partial_count,
                "cdm_table_id": self.cdm_table_id,
                "src_table_id": self.src_table_id
            }

    # total count for a source or cdm table (Node record)
    class SdcNode:
        def __init__(self, table_id, table_count):
            self.table_id = table_id
            self.table_count = table_count

        # as record in the flat list
        def to_json(self):
            return {
                "table_count": self.table_count,
                "table_id": self.table_id
            }

    # basic sdc list, aka Nodes list
    class SdcNodesList:
        sdc_list_type = 'nodes'
        sdc_items = []

        def clear(self):
            self.sdc_items = []

        def append_plain(self, sdc_item):
            self.sdc_items.append(sdc_item)

        def append(self, table_id, table_count):
            sdc_item = SrcToCdmCounts.SdcNode(table_id, table_count)
            self.sdc_items.append(sdc_item)

        def append_many(self, sdc_items):
            for sdc_item in sdc_items:
                self.sdc_items.append(sdc_item)

        def to_json(self):
            result = []
            for rec in self.sdc_items:
                result.append(rec.to_json())
            return {
                self.sdc_list_type: result
            }

    # Links list
    class SdcLinksList (SdcNodesList):
        sdc_list_type = 'links'

        def append(self, src_table_id, cdm_table_id, cdm_partial_count):
            strec = SrcToCdmCounts.SdcLink(src_table_id, cdm_table_id, cdm_partial_count)
            self.sdc_items.append(strec)

        def get_source_tables(self):
            result = []
            for rec in self.sdc_items:
                if rec.src_table_id not in result:
                    result.append(rec.src_table_id)
            return result

        def get_cdm_tables(self, src_table=""):
            result = []
            if src_table is None:
                src_table = ""
            for rec in self.sdc_items:
                if src_table == rec.src_table_id or src_table == "":
                    if rec.cdm_table_id not in result and not rec.cdm_table_id == SrcToCdmCounts.none_table:
                        result.append(rec.cdm_table_id)
            return result

    # connector to a spark session (to get counts from database)
    class SparkConnector:
        def __init__(self, session, src_schema, cdm_schema):
            self.session = session
            self.cdm_schema = cdm_schema
            self.src_schema = src_schema

            self.sql_mapped = \
                "SELECT load_table_id, COUNT(*) AS cnt FROM {cdm_schema}.{cdm_table} GROUP BY load_table_id "

            self.sql_unmapped = \
                "SELECT COUNT(*) AS cnt FROM {src_schema}.{src_table} s " + \
                "LEFT JOIN ({sql_mapped_ids}) c " + \
                "ON s.load_table_id = c.load_table_id " + \
                "AND s.load_row_id = c.load_row_id " + \
                "WHERE c.load_row_id IS NULL "

            # template sqls for union queries
            self.sql_mapped_ids = \
                "SELECT load_table_id, load_row_id FROM {schema}.{table_id} "

            self.sql_total_count = \
                "SELECT '{table_id}' AS table_id, COUNT(*) AS cnt FROM  {schema}.{table_id} "

        def get_sql_union(self, schema, tables_list, sql_single):
            result = ""
            for table_id in tables_list:
                if len(result) > 0:
                    result = result + " UNION ALL "
                result = result + sql_single.format(
                    schema=schema, table_id=table_id)
            return result

        def get_counts_mapped(self, cdm_table):
            result = []
            counts_rdd = self.session.sql(self.sql_mapped.format(
                cdm_schema=self.cdm_schema, cdm_table=cdm_table)).rdd.collect()
            for row in counts_rdd:
                sdc_link = SrcToCdmCounts.SdcLink(row['load_table_id'], cdm_table, row['cnt'])
                result.append(sdc_link)
            return result

        def get_counts_unmapped(self, src_table, cdm_tables):
            result = []
            counts_rdd = \
                self.session.sql(self.sql_unmapped.format(
                    src_schema=self.src_schema, src_table=src_table,
                    sql_mapped_ids=self.get_sql_union(self.cdm_schema, cdm_tables, self.sql_mapped_ids)
                )).rdd.collect()
            for row in counts_rdd:
                sdc_link = SrcToCdmCounts.SdcLink(src_table, SrcToCdmCounts.none_table, row['cnt'])
                result.append(sdc_link)
            return result

        def get_total_counts(self, schema, tables_list):
            result = []
            counts_rdd = \
                self.session.sql(
                    self.get_sql_union(schema, tables_list, self.sql_total_count)
                ).rdd.collect()
            for row in counts_rdd:
                sdc_node = SrcToCdmCounts.SdcNode(row['table_id'], row['cnt'])
                result.append(sdc_node)
            return result

    # SrcToCdmCounts methods
    def __init__(self):
        self.sdc_links = SrcToCdmCounts.SdcLinksList()
        self.sdc_nodes = SrcToCdmCounts.SdcNodesList()
        self.db_connector = None

    def to_json(self):
        report = {}
        report.update({'created_date': datetime.datetime.now()})
        report.update(self.sdc_links.to_json())
        report.update(self.sdc_nodes.to_json())
        return report

    def connect(self, session, src_schema, cdm_schema):
        self.db_connector = SrcToCdmCounts.SparkConnector(session, src_schema, cdm_schema)

    def fill_out(self, cdm_tables):
        # clean up
        self.sdc_links.clear()
        self.sdc_nodes.clear()

        # append links
        # append mapped
        for cdm_table in cdm_tables:
            counts = self.db_connector.get_counts_mapped(cdm_table)
            self.sdc_links.append_many(counts)
        # append unmapped
        src_tables = self.sdc_links.get_source_tables()
        for src_table in src_tables:
            counts = self.db_connector.get_counts_unmapped(
                src_table, self.sdc_links.get_cdm_tables(src_table))
            self.sdc_links.append_many(counts)

        # append nodes
        # append for source tables, only actual nodes
        nodes_list = self.sdc_links.get_source_tables()
        counts = self.db_connector.get_total_counts(self.db_connector.src_schema, nodes_list)
        self.sdc_nodes.append_many(counts)

        # append for cdm tables, only actual nodes
        nodes_list = self.sdc_links.get_cdm_tables()
        counts = self.db_connector.get_total_counts(self.db_connector.cdm_schema, nodes_list)
        self.sdc_nodes.append_many(counts)

    def save_to_json(self, output_file_name):
        try:
            with open(output_file_name, 'w') as outfile:
                json.dump(self.to_json(), outfile, indent=4)
            etl_print('', ETLMessageType.Ok)
            etl_print('Have written output file {0}'.format(output_file_name))
        except (OSError, ValueError, TypeError, IOError) as e:
            etl_print('', ETLMessageType.Failed)
            etl_print('Could not write output file {0}'.format(output_file_name))
            raise e


class CustomVocStatsGenerator:
    """Custom vocabularies Statistics generator."""

    POSTFIXES = {
        'final':    '_stage',
        'new':      '_stage_new',
        'old':      '_stage_old',
        'amend':    '_amend'
    }

    SCHEMAS = {
        'final':    'final_stage_schema',
        'new':      'new_stage_schema',
        'old':      'old_stage_schema',
        'amend':    'amend_schema'
    }

    TABLES = ['cdm_vocabulary', 'cdm_concept', 'cdm_concept_relationship', 'cdm_concept_ancestor']

    def __init__(self, session, etl_conf):
        self.__session = session
        self.__etl_conf = etl_conf

    def run(self):

        pie_stats = {
            'cdm_concept_stage': ['vocabulary_id', 'domain_id'],
            'cdm_concept_stage_old': ['vocabulary_id', 'domain_id'],
            'cdm_concept_relationship_stage': ['vocabulary_id_1', 'vocabulary_id_2', 'relationship_id']
        }
        stats = []
        for table in self.TABLES:
            for k, postfix in self.POSTFIXES.items():
                table_name = table+postfix
                full_table_name = utils.locate_table(
                    self.__session,
                    self.__etl_conf.schemas[self.SCHEMAS[k]],
                    table_name
                )

                # Calculate total
                table_stat = {'table': table_name, 'count': self.get_total(full_table_name), 'custom_stats': []}

                # Calculate stats for pie charts
                if pie_stats.get(table_name):
                    for column in pie_stats[table_name]:
                        table_stat['custom_stats'].append({
                            'type': 'pie',
                            'data': self.get_counts_by_column(full_table_name, column),
                            'column': column
                        })
                # Delta: new vocs
                if table_name == 'cdm_vocabulary_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_new_vocs()
                    })
                # Delta: changes in relationships
                if table_name == 'cdm_concept_relationship_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_relationship_delta()
                    })
                # Delta: new concepts
                if table_name == 'cdm_concept_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_new_concepts()
                    })

                stats.append(table_stat)
        self.stats = stats

    def get_total(self, table):
        query = "SELECT COUNT(*) AS cnt FROM {table}".format(table=table)
        df = self.__session.conn.sql(query)
        return df.collect()[0]['cnt']

    def get_counts_by_column(self, table, column_name, limit=100):
        query = (
            "SELECT {column_name}, COUNT(*) AS cnt "
            "FROM {table} "
            "GROUP BY {column_name} "
            "LIMIT {limit}"
        ).format(table=table, column_name=column_name, limit=limit)

        df = self.__session.conn.sql(query)

        return [{ 'value': r[column_name], 'count': r['cnt']} for r in df.collect()]

    def get_new_vocs(self):
        query = (
            "SELECT vocabulary_name "
            "FROM {final_stage_schema}.cdm_vocabulary_stage "
            "WHERE vocabulary_name IN ( "
            "  SELECT vocabulary_name "
            "  FROM {new_stage_schema}.cdm_vocabulary_stage_new "
            "  EXCEPT "
            "  SELECT vocabulary_name "
            "  FROM {old_stage_schema}.cdm_vocabulary_stage_old)".format(
                final_stage_schema=self.__etl_conf.schemas['final_stage_schema'],
                new_stage_schema=self.__etl_conf.schemas['new_stage_schema'],
                old_stage_schema=self.__etl_conf.schemas['old_stage_schema']
                )
        )

        df = self.__session.conn.sql(query)

        results = [{'vocabulary_name': r['vocabulary_name']} for r in df.collect()]
        return {
            'added': {
                'count': len(results),
                'data': results
            }
        }

    def get_new_concepts(self):
        query = (
            "SELECT COUNT(*) AS cnt "
            "FROM {final_stage_schema}.cdm_concept_stage a "
            "LEFT JOIN {old_stage_schema}.cdm_concept_stage_old b "
            "  ON a.vocabulary_id = b.vocabulary_id "
            "  AND a.concept_code = b.concept_code "
            "WHERE b.concept_code IS NULL".format(
                final_stage_schema=self.__etl_conf.schemas['final_stage_schema'],
                old_stage_schema=self.__etl_conf.schemas['old_stage_schema'],
            )
        )

        df = self.__session.conn.sql(query)

        return {
            'added': {
                'count': df.collect()[0]['cnt']
            }
        }

    def get_relationship_delta(self):

        def get_delta_count(table1, table2):
            query = (
                "SELECT COUNT(*) AS cnt "
                "FROM {table1} a "
                "  LEFT JOIN {table2} b "
                "  ON a.concept_code_1 = b.concept_code_1 "
                "  AND a.vocabulary_id_1 = b.vocabulary_id_1 "
                "  AND a.relationship_id = b.relationship_id "
                "  AND a.concept_id_2 = b.concept_id_2 "
                "WHERE a.relationship_id IN ('Maps to', 'Maps to value') "
                "  AND b.concept_code_1 IS NULL"
                .format(
                    schema_name=self.__etl_conf.schemas['cdm_schema'],
                    table1=table1,
                    table2=table2,
                )
            )
            df = self.__session.conn.sql(query)
            return df.collect()[0]['cnt']

        tables = [
            self.__etl_conf.schemas['final_stage_schema']+'.'+'cdm_concept_relationship_stage',
            self.__etl_conf.schemas['old_stage_schema']+'.'+'cdm_concept_relationship_stage_old'
        ]
        return {
                'added': {
                    'count': get_delta_count(tables[0], tables[1])
                },
                'replaced': {
                    'count': get_delta_count(tables[1], tables[0])
                },
            }


# ======= End ================================================================
