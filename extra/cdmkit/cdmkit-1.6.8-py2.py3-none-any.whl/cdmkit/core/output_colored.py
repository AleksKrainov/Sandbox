from __future__ import print_function
import datetime
from colorama import Fore, Style
import logging
import os

from cdmkit.core import enum

# colorama acts really weird on windows
# maybe we should remove it completely
# and colorama, too
if os.name == 'nt':
    from colorama import init
    init(convert=True)


ETLMessageType = enum(
    "ETLMessageType",
    ["Titles", "Info", "Warning", "Error", "Running", "Ok", "Failed"]
)


def etl_print(message, message_type=ETLMessageType.Info, log=True):
    color_dict = {
        ETLMessageType.Titles: Fore.MAGENTA,
        ETLMessageType.Info: Fore.WHITE + 'Info:',
        ETLMessageType.Warning: Fore.YELLOW + 'Warning:',
        ETLMessageType.Error: Fore.RED + 'Error:',
        ETLMessageType.Running: Fore.CYAN + 'Running:',
        ETLMessageType.Ok: Fore.GREEN + 'DONE',
        ETLMessageType.Failed: Fore.RED + 'FAILED'
    }

    if message_type == ETLMessageType.Titles:
        msg_info = '[' + datetime.datetime.now().strftime("%H:%M:%S") + '] '
        msg = color_dict[message_type] + msg_info + message + Style.RESET_ALL
        print(msg)
        return

    if message_type in [ETLMessageType.Ok, ETLMessageType.Failed]:
        msg = Style.RESET_ALL + '[' + color_dict[message_type] + Style.RESET_ALL + ']'
        print(msg)
        return

    result_str = color_dict[message_type] + Style.RESET_ALL

    msg_info = Style.RESET_ALL + '[' + datetime.datetime.now().strftime("%H:%M:%S") + '] ' + result_str
    msg_info = msg_info.ljust(34)
    msg = msg_info + '{message}{reset}'.format(reset=Style.RESET_ALL, message=message)

    if message_type == ETLMessageType.Running:
        msg = msg.ljust(120, '.')
        msg_end = ''
    else:
        msg_end = '\n'

    print(msg, end=msg_end)
    if log:
        logging.info('[' + datetime.datetime.now().strftime("%H:%M:%S") + '] ' + message)
