import sqlparse
import json

from cdmkit.core import enum


class SQLTraceInfo:
    def __init__(self):
        self.source_table = None
        self.target_table = None
        self.statement_groups = list()

    def __repr__(self):
        return json.dumps(
            [{'source_table': self.source_table},
             {'target_table': self.target_table},
             {'sql': self.sql_statement()}],
            sort_keys=True,
            indent=4
        )

    def sql_statement(self):
        return '\n'.join(self.statement_groups)


class SQLParser:
    """
    Main class for parsing SQL statements and generating SQLTraceInfo
    """
    Checkpoint = enum(
        "Checkpoint",
        ["key_insert", "key_from", "key_into"]
    )

    def __init__(self):
        pass

    def get_sql_trace(self, statement):
        """
        Parse SQL statement
        :param statement: sql statement
        :return: SQLTraceInfo object
        """
        trace = SQLTraceInfo()
        sql_dict = sqlparse.parse(statement)

        statement = ''
        found_checkpoint = None
        for token in sql_dict[0].tokens:
            if found_checkpoint == SQLParser.Checkpoint.key_from and type(token) is sqlparse.sql.Identifier:
                trace.source_table = token.normalized
                found_checkpoint = None

            if found_checkpoint == SQLParser.Checkpoint.key_into and isinstance(token, (sqlparse.sql.Function, sqlparse.sql.Identifier)):
                trace.target_table = token.normalized
                found_checkpoint = None

            checkpoint = self.__is_checkpoint(token)
            if checkpoint is not None:
                found_checkpoint = checkpoint

            if self.__is_group(token):
                trace.statement_groups.append(statement)

            statement += token.value

        trace.statement_groups.append(statement)
        return trace

    @staticmethod
    def __is_group(token):
        """
        :param token:
        :return:
        """
        return (token.is_group and type(token) is sqlparse.sql.Where) or \
            (token.is_keyword and 'JOIN' in token.normalized)

    @staticmethod
    def __is_checkpoint(token):
        if token.is_keyword and token.normalized.lower() == 'insert':
            return SQLParser.Checkpoint.key_insert

        if token.is_keyword and token.normalized.lower() == 'into':
            return SQLParser.Checkpoint.key_into

        if token.is_keyword and token.normalized.lower() == 'from':
            return SQLParser.Checkpoint.key_from

        return None

    __sql_dict = None
