import json
import datetime
import logging
import pkg_resources
import shutil
import sys
import itertools
from os import path, walk, listdir

from cdmkit.core import (etl_print, ETLMessageType)
from cdmkit.core import exceptions as E


# -----------------------------------------------------------------------
# EtlRunner utils
# -----------------------------------------------------------------------

# the following Spark parameters have to be set prior to JVM start:
DRIVER_JVM_PARAMS = (
    "spark.driver.memory",
    "spark.driver.extraClassPath",
    "spark.driver.extraJavaOptions",
    "spark.driver.extraLibraryPath",
    "spark.driver.defaultJavaOptions",  # since 3.0.0
    "spark.pyspark.python",
    "spark.pyspark.driver.python",
)

# static templates for submit_string
# CDMK-382: installation path may contain spaces -> has to be quoted
JOB_RUNNER_TMPL = '"' + path.join("{self.installation_path}", "{runner}") + '"'
JOB_ARGS_TMPL = [
    "-h {self.etl_home}",
    "-e {self.etl_conf_name}",
    "-r {self.run_id}_{submit_id}",
    "{add_params}"
]


def collect_files(runner):
    """Collect local files which should be pushed to server.

    Args:
        runner (EtlRunner): a runner configured for a particular job.

    Returns:
        str: a list of absolute paths, joined by ','.

    """
    collect_from = [
        # root folder, extension filter (str or tuple of)
        (path.join(runner.etl_home, 'temp', runner.args.environment), ".json"),
        (path.join(runner.etl_home, 'qa'), (".sql", ".hql")),
        (path.join(runner.etl_home, 'src'), (".sql", ".hql")),
        (path.join(runner.etl_home, 'conf'), (".conf", ".etlconf")),
        # Causes "Attempt to add (core/_init_.py) multiple times to the distributed cache."
        # Should use '--py-files' instead to distribute Python modules.
        # (path.join(runner.orchestration_home, 'cdmspark'), ".py"),
        # (path.join(runner.orchestration_home, 'core'), ".py")
    ]
    f_list = []
    for rdir, extf in collect_from:
        for root, dirs, files in walk(rdir):
            f_list.extend([path.join(root, f) for f in files if f.endswith(extf)])

    return ','.join(f_list)


def copy_conf_templates(obj, exclude=list()):
    """
    Check etlconf, collect conf names.
    If conf does not exist - copy appropriate template

    :param obj: current EtlRunner instance
    :param exclude: list of job sections which do not require templates
    """
    def copy_single_template(conf_name, template_name, target_dir):
        if not path.exists(path.join(obj.etl_home, target_dir, conf_name)):
            shutil.copyfile(
                pkg_resources.resource_filename('cdmkit', path.join('templates', template_name)),
                path.join(obj.etl_home, target_dir, conf_name)
            )

    # iterate through a flat list for jobs with single default configurations
    template_names = {
        "ddl": [
            {
                "template_name" : "ddl_cdm_v{0}.conf".format(obj.args.cdm_version),
                "target_name"   : "ddl_cdm.conf",
                "target_dir"    : "conf"
            }
        ],
        "load": [
            {
                "template_name" : "load_src_data.conf",
                "target_name"   : "load_src_data.conf",
                "target_dir"    : "conf"
            },
            {
                "template_name" : "load_omop_voc.conf",
                "target_name"   : "load_omop_voc.conf",
                "target_dir"    : "conf"
            }
        ],
        "custom_voc": [
            {
                "template_name" : "custom_voc.conf",
                "target_name"   : "custom_voc.conf",
                "target_dir"    : "conf"
            },
            {
                "template_name" : "load_voc_new_stage.conf",
                "target_name"   : "load_voc_new_stage.conf",
                "target_dir"    : "conf"
            },
            {
                "template_name" : "load_voc_old_stage.conf",
                "target_name"   : "load_voc_old_stage.conf",
                "target_dir"    : "conf"
            },
            {
                "template_name" : "load_voc_match.conf",
                "target_name"   : "load_voc_match.conf",
                "target_dir"    : "conf"
            }
        ],
        "run": [
            {
                "template_name" : "workflow.conf",
                "target_name"   : "workflow.conf",
                "target_dir"    : "conf"
            },
            # ETL Standard Scripts
            {
                "template_name" : "cdm_cdm_source.sql",
                "target_name"   : "cdm_cdm_source.sql",
                "target_dir"    : "src"
            },
            {
                "template_name" : "cdm_condition_era.sql",
                "target_name"   : "cdm_condition_era.sql",
                "target_dir"    : "src"
            },
            {
                "template_name" : "cdm_drug_era.sql",
                "target_name"   : "cdm_drug_era.sql",
                "target_dir"    : "src"
            },
            {
                "template_name" : "cdm_dose_era.sql",
                "target_name"   : "cdm_dose_era.sql",
                "target_dir"    : "src"
            }
        ],
        "verify": [
            {
                "template_name" : "ddl_cdm_v{0}.conf".format(obj.args.cdm_version),
                "target_name"   : "ddl_cdm.conf",
                "target_dir"    : "conf"
            }
        ], # TODO: templates for other CDM versions
        "qa": [
            {
                "template_name" : "qa.conf",
                "target_name"   : "qa.conf",
                "target_dir"    : "conf"
            }
        ],
        "srcstats": [
            {
                "template_name" : "src_stats.conf",
                "target_name"   : "src_stats.conf",
                "target_dir"    : "conf"
            }
        ],
        "stats": [
            {
                "template_name" : "cdm_stats.conf",
                "target_name"   : "cdm_stats.conf",
                "target_dir"    : "conf"
            }
        ],
        "unload": [
            {
                "template_name" : "unload_cdm_v{0}.conf".format(obj.args.cdm_version),
                "target_name"   : "unload_cdm.conf",
                "target_dir"    : "conf"
            }
        ],
        "patients_history": [
            {
                "template_name" : "patients_history.conf",
                "target_name"   : "patients_history.conf",
                "target_dir"    : "conf"
            }
        ],  # TODO: new template?
        "coverage_report": [
            {
                "template_name" : "coverage_report.conf",
                "target_name"   : "coverage_report.conf",
                "target_dir"    : "conf"
            }
        ]  # TODO: new template?
    }

    for job_name in obj.etl_conf.JOB_SECTIONS:
        if job_name in exclude or obj.etl_conf.job_is_unconfigured(job_name):
            continue
        # iterate through job names in etlconf, and through the templates config above
        etl_print("Copying templates for job '{}'".format(job_name), ETLMessageType.Running)
        for templ in template_names[job_name]:
            copy_single_template(templ["target_name"], templ["template_name"], templ["target_dir"])
        etl_print('', ETLMessageType.Ok)


def unfolderize(etl_home, workflow_batches):
    """
    Get records from workflow.conf which point
    to folders rather than single scripts.
    Replace them with a list of scripts from given folder.

    This works ONLY IF there's a naming convention
    which allows to get the correct execution order.
    Generator sorts scripts alphabetically.
    """
    for i, batch in enumerate(workflow_batches):
        if 'folder' in batch.keys():
            folder_batch = workflow_batches.pop(i)
            folder_path = path.join(etl_home, 'src', folder_batch['folder'])
            if not path.isdir(folder_path):
                raise E.JobExecException('{} is not a folder or does not exist'.format(folder_path))
            # NB: does sort scripts inside folders. ONE MORE TIME:
            # script names should follow naming convention,
            # otherwise there's no opportunity to predict the order.
            scripts_in_folder = sorted(filter(
                lambda x: x.endswith('.sql') or x.endswith('.hql'),
                itertools.chain.from_iterable([tup[2] for tup in walk(folder_path)])
            ))
            # apply 'exclude' filter if present
            if folder_batch.get('exclude'):
                scripts_in_folder = list(filter(
                    lambda y: y not in folder_batch.get('exclude'),
                    scripts_in_folder
                ))
            # insert separate script in place (i+0, i+1, ...)
            for j in range(len(scripts_in_folder)):
                workflow_batches.insert(
                    i + j,
                    {'script': path.join(folder_batch['folder'], scripts_in_folder[j])}
                )

    return workflow_batches


def apply_selection_range(conf):
    # I don't think that this is an appropriate place for this function, yet I've no idea where else to put it
    if conf.scripts_selection_range is None or \
            conf.scripts_selection_range['start'] is None and \
            conf.scripts_selection_range['stop'] is None:
        return 0

    new_workflow_batches = list()
    start_found = False
    end_found = False

    # if start script is not present, then the first script in workflow should be it
    if conf.scripts_selection_range['start'] is None:
        start_found = True

    for item in conf.workflow_batches:
        if conf.scripts_selection_range['start'] in item.values():
            start_found = True

        if start_found and not end_found:
            new_workflow_batches.append(item)

        if conf.scripts_selection_range['stop'] in item.values():
            end_found = True

    if len(new_workflow_batches) == 0:
        raise E.CLIArgsException(
            'The start script should be placed before the stop script. '
            'Or you have chosen a start script that does not exist.'
        )

    conf.workflow_batches = new_workflow_batches


def merge_dicts(*dicts):
    """Merges several dictionaries into one, with respect to precedence.

    Args:
        *dicts (dict): Several dicts, from least to most important.

    Returns:
        dict: Merged dictionary.

    """
    return dict(itertools.chain(*[x.items() for x in dicts]))


def locate_table(session, schema_name, table_name):
    """Helper func to workaround table prefixes/postfixes.

    It's so annoying when the job breaks because target table
    is named 'something_f' or 'voc_something' instead of 'something'.
    Strategy: try to locate tables using known name format options.

    Args:
        session: database session
        schema_name (str): schema name
        table_name (str): table name without schema

    Returns:
        str: fully-qualified table name

    Raises:
         ValueError: if table not found in schema anyway
    """
    FORMATS = ('{}', '{}_f', 'cdm_{}', 'voc_{}')
    for name_format in FORMATS:
        full_name = '{sch}.{tbl}'.format(
            sch=schema_name,
            tbl=name_format.format(table_name))
        try:
            session.execute('SELECT {top} * FROM {table} {limit}'.format(top=session.top_query.format(num=1),
                                                                         table=full_name,
                                                                         limit=session.limit_query.format(num=1)))
            # success -> return immediately
            return full_name
        except Exception:
            # do not raise, try another format
            continue
    raise ValueError(
        "Table '{tbl}' was not found in '{sch}' schema."
        .format(tbl=table_name, sch=schema_name))


class CDMTablesTypoChecker:
    """
    Checks whether a typo was made in a table name
    or if it's just a completely different table
    """

    __table_to_check = None
    __correct_table = None
    ALLOWED_DIFFS_AMOUNT = 2

    def __check_bias(self, start_idx_check, start_idx_correct, bias):
        is_biased = False

        for i in range(1, bias + 1):
            if self.__table_to_check[start_idx_check + i:] == self.__correct_table[start_idx_correct:] or \
               self.__table_to_check[start_idx_check - i:] == self.__correct_table[start_idx_correct:]:
                is_biased = True
                break

        return is_biased

    def check(self, table_to_check, correct_table):
        """
        Performs the check itself.
        If the amount of differences between both strings is more than ALLOWED_DIFFS_AMOUNT,
        considers it another table, not a typo
        Also checks if the name was misspeled, e.g. occurence instead of occurrence
        """
        self.__table_to_check = table_to_check
        self.__correct_table = correct_table
        diffs_count = 0

        for i in range(0, len(self.__table_to_check)):
            try:
                if self.__table_to_check[i] != self.__correct_table[i]:
                    if self.__check_bias(i, i, 2):
                        diffs_count += self.ALLOWED_DIFFS_AMOUNT
                        break
                    diffs_count += 1
            except IndexError:
                break

        if (-2 <= len(table_to_check) - len(correct_table) <= 2) and (0 < diffs_count <= self.ALLOWED_DIFFS_AMOUNT):
            return True
        if (0 < len(table_to_check) - len(correct_table) <= 1) and diffs_count == 0:
            return True

        return False


class ProjectStructureVerifier(object):
    """
    Runs basic checks of project structure.
    Does NOT raise any exceptions by itself, appends all errors to self.errors.
    """
    # rules as str to defer evaluation
    ETLCONF_RULES = [
        ("'db' in content.keys()", 'No db section in {etlconf}'),
        ("type(content.get('db')) == dict", 'db section in {etlconf} is not a dict'),
        (
            "'connection_name' in content['db'].keys() or 'dbms' in content['db'].keys()",
            'db section in {etlconf} does not contain dbms nor connection_name '
        ),
        ("'schemas' in content.keys()", 'No schemas section in {etlconf}'),
        ("type(content.get('schemas')) == dict", 'schemas section in {etlconf} is not a dict'),
        ("'source_schema' in content['schemas'].keys()", 'schemas section in {etlconf} does not contain source_schema'),
        ("'voc_schema' in content['schemas'].keys()", 'schemas section in {etlconf} does not contain voc_schema'),
        (
            "'cdm_schema' in content['schemas'].keys() or 'target_schema' in content['schemas'].keys()",
            'schemas section in {etlconf} does not contain cdm_schema nor target_schema'
        )
    ]

    def __init__(self, project_folder_path):
        self.project = path.split(project_folder_path)[1]
        self.paths = dict()
        self.envs = list()
        self.etlconf_paths = list()
        self.etlconf_contents = list()
        self.errors = list()
        self.paths['root'] = project_folder_path
        self.paths['conf'] = path.join(project_folder_path, 'conf')
        # self.paths['qa'] = path.join(project_folder_path, 'qa')
        self.paths['src'] = path.join(project_folder_path, 'src')

    def collect_etlconfs(self, conf_folder_path=None):
        """Collects full paths for .etlconf files in conf_folder.

        Args:
            conf_folder_path (str): Full path to conf folder. Defaults to {project_root}/conf/.

        """
        if conf_folder_path is None:
            conf_folder_path = self.paths['conf']
        self.etlconf_paths = list(filter(
            lambda c: path.splitext(c)[1] == '.etlconf',
            [path.join(conf_folder_path, p) for p in listdir(conf_folder_path)]
        )) or None
        if self.etlconf_paths:
            self.envs = [path.split(p)[1].split('.')[0] for p in self.etlconf_paths]

    def check_structure(self):
        """Just checks existence of every path in self.paths."""
        for folder, folder_path in self.paths.items():
            if not path.exists(folder_path):
                self.errors.append('{} folder does not exist in this project.'.format(folder))

    def check_etlconfs(self):
        """Checks etlconf file inner structure specified by ETLCONF_RULES."""
        if self.etlconf_paths is None:
            return
        for etlconf_path in self.etlconf_paths:
            with open(etlconf_path, 'r') as etlconf_file:
                content = json.load(etlconf_file)
            for rule, msg in self.ETLCONF_RULES:
                try:
                    if eval(rule) is not True:
                        self.errors.append(msg.format(etlconf=etlconf_path))
                except Exception:
                    self.errors.append('CRITICAL: ' + msg.format(etlconf=etlconf_path))
            self.etlconf_contents.append(content)

    def check_project(self, check_etlconfs=True):
        """Wrapper method which runs all the checks.

        Args:
            check_etlconfs (bool): Whether to check etlconfs structure. Defaults to True.

        Returns:
            list: A list of error messages, if any.

        """
        self.collect_etlconfs()
        self.check_structure()
        if check_etlconfs:
            self.check_etlconfs()

        return self.errors

    def get_environments(self):
        """Get envs and their etlconf contents.

        Returns:
            list: Envs as (env_name, etlconf_content) tuples.

        """
        return list(zip(self.envs, self.etlconf_contents))


# -----------------------------------------------------------------------
# Job scripts utility functions
# -----------------------------------------------------------------------


def create_log_file(etl_home, etl_conf_file, job, current_script=None):
    log_name = '{time}_{job}{script}.log'.format(
        time=str(datetime.datetime.now().strftime('%y-%m-%d_%H-%M-%S-%f')),
        job=job, script=format_script_name(current_script)
    )
    log_path = path.join(
        etl_home, 'log', path.splitext(etl_conf_file)[0], log_name
    )
    # StackOverflow promised this would work
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.basicConfig(filename=log_path, level=logging.INFO)
    logging.info(str(sys.argv))


def format_script_name(script_name):
    if script_name is None:
        return ""
    UNWANTED_CHARACTERS = ("/", "\\", ".")
    for ch in UNWANTED_CHARACTERS:
        script_name = script_name.replace(ch, "_")
    return "_" + script_name


def write_run_report(etl_home, etl_conf_file, run_id, report, job):
    etl_print('Writing run report', ETLMessageType.Running)

    run_log_name = '{job}_{run_id}.json'.format(job=job, run_id=run_id)
    run_log_path = path.join(
        etl_home, 'reports',
        path.splitext(etl_conf_file)[0], 'run_log', run_log_name
    )
    try:
        with open(run_log_path, 'w') as run_log_file:
            json.dump(report, run_log_file, indent=4)
    except (OSError, ValueError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise E.JobReportException(cause=exc)

    etl_print('', ETLMessageType.Ok)
