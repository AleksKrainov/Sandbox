from __future__ import print_function
import datetime
import logging

from cdmkit.core import enum


ETLMessageType = enum(
    "ETLMessageType",
    ["Titles", "Info", "Warning", "Error", "Running", "Ok", "Failed"]
)


def etl_print(message, message_type=ETLMessageType.Info, log=True):
    captions = {
        ETLMessageType.Titles: '|',
        ETLMessageType.Info: '<Info>',
        ETLMessageType.Warning: '~~~ Warning ~~~',
        ETLMessageType.Error: '### Error ###',
        ETLMessageType.Running: '*Running*',
        ETLMessageType.Ok: '= DONE =',
        ETLMessageType.Failed: '!!! FAILED !!!'
    }

    current_caption = captions[message_type]

    if message_type == ETLMessageType.Titles:
        msg_info = '[' + datetime.datetime.now().strftime("%H:%M:%S") + '] '
        msg_info = msg_info.ljust(30)
        msg = msg_info + current_caption + message + current_caption
        print(msg)
        return

    if message_type in [ETLMessageType.Ok, ETLMessageType.Failed]:
        msg = '[{}]'.format(current_caption)
        print(msg)
        return

    msg_info = '[' + datetime.datetime.now().strftime("%H:%M:%S") + '] ' + current_caption
    msg_info = msg_info.ljust(34)
    msg = msg_info + '{message}'.format(message=message)

    if message_type == ETLMessageType.Running:
        msg = msg.ljust(120, '.')
        msg_end = ''
    else:
        msg_end = '\n'

    print(msg, end=msg_end)
    if log:
        logging.info('[' + datetime.datetime.now().strftime("%H:%M:%S") + '] ' + message)
