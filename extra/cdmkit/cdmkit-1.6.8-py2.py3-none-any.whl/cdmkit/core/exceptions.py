class CDMKitException(Exception):
    """
    Base exception to rule them all
    """

    def __init__(self, message=None, cause=None):
        super(CDMKitException, self).__init__()
        self.message = message
        self.cause = cause

    def __str__(self):
        return '\nException: ' + repr(self) + \
                '\nMessage: ' + str(self.message) + \
                '\nCause: ' + str(self.cause)


class StartUpException(CDMKitException):
    """
    Exception for the first step of CDM Kit run
    """

    pass


class JobException(CDMKitException):
    """
    Exception for the second step of CDM Kit run
    """

    pass


class ConfigException(StartUpException):
    """
    Exception for any problems with configuration files
    """

    pass


class CLIArgsException(StartUpException):
    """
    Exception for any problems with CLI arguments
    """

    pass


class JobInitException(JobException):
    """
    Exception for any problems with Job initialization
    """

    pass


class JobExecException(JobException):
    """
    Exception for any problems with Job execution
    """

    pass


class JobReportException(JobException):
    """
    Exception for any problems with Job reports
    """

    pass


class ParseException(JobInitException):
    """
    Exception for any problems with scripts parsing
    """

    pass


class WorkflowGraphGeneratorException(JobInitException):
    """
    Exception for any problems with workflow graph generating
    """

    pass
