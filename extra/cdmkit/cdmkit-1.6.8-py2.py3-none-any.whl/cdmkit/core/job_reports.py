"""
Temporary module for job-related stuff.

These are not tied to a particular DBMS so they're placed
in a common module. A subject to refactoring, actually,
because having things divided by job would be a better idea.
"""

import json
import datetime
import os
import shutil

from cdmkit import __version__
from cdmkit.core import enum
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core.exceptions import JobReportException


class QAStepInfo:
    """QA Step Container."""

    @staticmethod
    def from_statement(qa_statement, script_name=None):
        """Create QAStepInfo object from QA statement.

        Args:
            qa_statement (str): annotated QA query.
            script_name (str): filename for the script that contains given query

        Returns:
            QAStepInfo: a DTO for QA query results.

        """
        qa_info = QAStepInfo()
        for line in qa_statement.split('\n'):
            if line.lstrip().startswith('---'):
                tag = line.split(':')[0].strip()
                value = ':'.join(line.split(':')[1:]).strip()
                if 'table' in tag:
                    qa_info.table = value
                elif 'column' in tag:
                    qa_info.column = value
                elif 'rule_id' in tag or 'unit_id' in tag:
                    qa_info.rule_id = value
                elif 'comment' in tag:
                    qa_info.comment = value
                elif 'severity' in tag:
                    qa_info.severity = value.lower()

        qa_info.statement = qa_statement
        if script_name:
            qa_info.script = script_name
        return qa_info

    def to_json(self):
        return {
            "table": self.table,
            "column": self.column,
            "rule_id": self.rule_id,
            "comment": self.comment,
            "result": self.result,
            "statement": self.statement,
            "severity": self.severity,
            "script": self.script
        }

    table = ''
    column = ''
    rule_id = ''
    comment = ''
    statement = ''
    severity = 'error'
    script = ''
    result = None


class ColumnStatsBase:
    """Basic table column statistics information."""

    def __init__(self, column_name, column_type, data_sample, nulls_count=None, distincs_count=None):
        self.column_name = column_name
        self.column_type = column_type
        self.data_sample = data_sample
        self.nulls_count = nulls_count
        self.distincs_count = distincs_count

    def to_json(self):
        return {
            "column_name": self.column_name,
            "column_type": self.column_type,
            "data_sample": self.data_sample,
            "nulls_count": self.nulls_count,
            "distincs_count": self.distincs_count
        }


class SourceColumnStats(ColumnStatsBase):
    class SourceColumnMappedVocabs:
        def __init__(self, vocabulary_id, distincts, distincts_rate):
            self.vocabulary_id = vocabulary_id
            self.distincts = distincts
            self.distincts_rate = distincts_rate

        def to_json(self):
            return {
                "vocabulary_id": self.vocabulary_id,
                "distincts": self.distincts,
                "distincts_rate": self.distincts_rate
            }

    # maybe consider remaking all these stats generators with telescopic constructor with builder pattern?

    def __init__(self, column_name, column_type, data_sample,
                 nulls_count=None, distincs_count=None, data_type=0, is_skipped=False):
        ColumnStatsBase.__init__(self, column_name, column_type, data_sample, nulls_count, distincs_count)
        self.data_type = data_type
        self.is_skipped = is_skipped
        self.mapped_vocabs = list()

    def to_json(self):
        return {
            "column_name": self.column_name,
            "column_type": self.column_type,
            "data_type": self.data_type,
            "data_sample": self.data_sample,
            "nulls_count": self.nulls_count,
            "distincs_count": self.distincs_count,
            "mapped_vocabs": [x.to_json() for x in self.mapped_vocabs],
            "skipped": self.is_skipped
        }


class CDMDataStats:
    """Container class for CDM data statistics."""

    class RuleSubsetStats:
        def __init__(self, count=None, rule_id=None, column_stats=None, custom_stats=None):
            self.rule_id = rule_id
            self.count = count
            self.column_stats = column_stats or list()
            self.custom_stats = custom_stats or list()

        def to_json(self):
            return {
                "rule_id": self.rule_id,
                "count": self.count,
                "columns": [x.to_json() for x in self.column_stats],
                "custom_stats": self.custom_stats
            }

        def __deepcopy__(self, memo):
            return type(self)(count=self.count, rule_id=self.rule_id, column_stats=self.column_stats, custom_stats=self.custom_stats)

    TableType = enum(
        "TableType",
        ["Source", "CDM", "Vocabulary"]
    )

    class TableStats:
        """Container class for CDM table statistics."""

        def __init__(self, table_name, stats=None, data_sample=None,
                     custom_stats=None, rules=None, mapping_samples=None):
            self.table_name = table_name
            self.stats = stats
            self.data_sample = data_sample
            self.custom_stats = custom_stats or list()
            self.rules = rules or list()
            self.mapping_samples = mapping_samples or list()

        def to_json(self):
            return {
                "table": self.table_name,
                "stats": self.stats.to_json(),
                "custom_stats": self.custom_stats,
                "rules": [x.to_json() for x in self.rules],
                "data_sample": self.data_sample,
                "mapping_samples": [x.to_json() for x in self.mapping_samples]
            }

    def __init__(self, dataset_name=None, created_date=None):
        self.created_date = created_date
        self.dataset_name = dataset_name
        self.table_stats = list()
        self.vocabs = list()

    def to_json(self):
        return {
            "created_date": str(self.created_date),
            "tables": [x.to_json() for x in self.table_stats],
            "vocabs": self.vocabs
        }


class SourceDataStats:
    """Container class for source data statistics."""

    class SourceTableStats:
        """Container class for source table statistics."""

        def __init__(self, table_name, count=None, stats=None, custom_stats=None):
            self.table_name = table_name
            self.count = count
            self.stats = stats
            self.custom_stats = custom_stats or list()

        def to_json(self):
            return {
                "table": self.table_name,
                "count": self.count,
                "stats": [x.to_json() for x in self.stats] if self.stats is not None else [],
                "custom_stats": self.custom_stats
            }

    def __init__(self, dataset_name=None, created_date=None):
        self.created_date = created_date
        self.dataset_name = dataset_name
        self.table_stats = list()

    def to_json(self):
        return {
            "created_date": str(self.created_date),
            "tables": [x.to_json() for x in self.table_stats]
        }


def write_report(report_path, report_data, mode = "w", add_metadata = True):
    if add_metadata:
        report = {
            "_meta": {
                "cdmkit_version": __version__,
                "create_date": str(datetime.datetime.now())
            },
            "report": report_data # if isinstance(report_data, dict) else report_data
        }
    else:
        report = report_data

    if os.path.exists(report_path):
        root_ext = os.path.splitext(report_path)
        shutil.copyfile(
            report_path,
            '{}_{}{}'.format(root_ext[0], str(datetime.datetime.now().strftime('%y%m%d_%H%M%S_%f')), root_ext[1])
        )

    try:
        with open(report_path, mode) as report_temp_file:
            json.dump(report, report_temp_file, indent=4)
    except (ValueError, OSError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise JobReportException(cause=exc)