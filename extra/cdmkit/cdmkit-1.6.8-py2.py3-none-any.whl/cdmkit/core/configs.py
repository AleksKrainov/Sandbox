import json
from os import path
from cdmkit.core.exceptions import ConfigException

try:
    import configparser
except ImportError:
    import ConfigParser as configparser

# ======= Master configuration for ETL env ==========================

_to_list = lambda x: [x, ] if not isinstance(x, list) else x


class ETLConf(object):
    """Master configuration file for CDMKit envs."""

    REQUIRED_SECTIONS = {"db": dict, "schemas": dict}
    OPTIONAL_SECTIONS = ("params", "ext_params")
    JOB_SECTIONS = (
        "load", "ddl", "run",
        "verify", "qa", "srcstats",
        "stats", "unload",
        "patients_history", "coverage_report",
        "custom_voc",
    )
    DEFAULTS = {
        "params": dict(),
        "ext_params": list()
    }

    def __init__(self, conf_data):
        no_errors = self.validate(conf_data)
        if not no_errors:
            raise ValueError("Invalid etlconf configuration")
        for req_section in self.REQUIRED_SECTIONS:
            setattr(self, req_section, conf_data[req_section])
        for opt_section in self.OPTIONAL_SECTIONS:
            setattr(self, opt_section, conf_data.get(opt_section, self.DEFAULTS[opt_section]))
        for job_section in self.JOB_SECTIONS:
            setattr(self, job_section, _to_list(conf_data.get(job_section, list())))

    def validate(self, loaded):
        return all(
            [rk in loaded.keys() for rk in self.REQUIRED_SECTIONS]
            + [isinstance(loaded.get(rk, rt()), rt) for rk, rt in self.REQUIRED_SECTIONS.items()]
        )

    def job_is_unconfigured(self, job):
        return getattr(self, job) == list()

    @classmethod
    def from_file(cls, filepath):
        with open(filepath, "r") as conf_file:
            loaded = json.load(conf_file)
        return cls(loaded)

    @classmethod
    def from_json(cls, json_string):
        loaded = json.loads(json_string)
        return cls(loaded)


# ======= Job-specific configuration ================================

class Config:
    """Configuration files adapter."""

    renamed_attrs = dict()

    def __init__(self, conf):
        with open(conf) as conf_file:
            self.__dict__ = self.handle_deprecations(json.load(conf_file))

    @classmethod
    def from_dict(cls, config_dict):
        conf = cls.__new__(cls)
        conf.__dict__ = cls.handle_deprecations(conf, config_dict)
        return conf

    def handle_deprecations(self, data):
        if not self.renamed_attrs:
            return data
        clean = dict()
        for attr, value in data.items():
            if isinstance(value, dict):
                updated_value = self.handle_deprecations(value)
            elif isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
                updated_value = [self.handle_deprecations(x) for x in value]
            else:
                updated_value = value
            clean[self.renamed_attrs.get(attr, attr)] = updated_value
        return clean


class SourceConfig(Config):
    """Source files configuration file."""

    renamed_attrs = {
        "delimeter": "delimiter",
        "s3_root": "files_location",
        "tableSchema": "fields",
    }

    def __init__(self, conf):
        with open(conf) as conf_file:
            self.name = path.split(conf)[-1]
            self.source_batches = [self.handle_deprecations(x) for x in json.load(conf_file)]


class UnloadConfig(Config):
    renamed_attrs = {
        "delimeter": "delimiter",
        "folder_name": "folder",
        "s3_root": "files_location",
        "cdm_tables": "tables",
    }


class CDMTablesConfig(Config):
    """CDM tables configuration file."""
    renamed_attrs = {
        "delimeter": "delimiter",
        "s3_root": "files_location",
        "tableSchema": "fields",
        "source_tables": "tables",
        "units": "rules",
        "unit": "rule",
    }


class QAConfig(Config):
    """QA configuration file."""
    pass


class QACustomConfig(Config):
    """QA config generated from CLI args."""
    def __init__(self, scripts=None):
        self.scripts = list()
        for script in (scripts or list()):
            self.scripts.append({'script': script})


class WorkflowConfig(Config):
    """Workflow configuration file."""
    scripts_selection_range = None
    infer_doc_info = True

    def __init__(self, conf):
        with open(conf) as conf_file:
            self.workflow_batches = json.load(conf_file)

    def __add__(self, other):
        self.workflow_batches += other.workflow_batches
        return self


class WorkflowCustomConfig(Config):
    """Workflow generated from etl_run params."""
    scripts_selection_range = None
    infer_doc_info = True

    def __init__(self, scripts=None, folders=None):
        # NB: folders are processed in etl_run, not here
        self.workflow_batches = list()
        for folder in (folders or list()):
            self.workflow_batches.append({'folder': folder})
        for script in (scripts or list()):
            self.workflow_batches.append({'script': script})


class WorkflowReceivedConfig(Config):
    """Workflow received configuration file."""
    scripts_selection_range = None
    infer_doc_info = False

    def __init__(self, conf):
        self.workflow_batches = list()
        for batch in conf:
            self.workflow_batches.append(batch)


class StatsConfigBase(Config):

    def __init__(self, data):
        if data.get('pages') is not None:
            raise Exception("'pages' configuration key is deprecated, replace with 'tables'")
        data = self.handle_deprecations(data)
        for param in self.DEFAULTS:
            setattr(self, param, data.get(param, self.DEFAULTS[param]))

    renamed_attrs = {
        "generate_unit_stats": "generate_stats_by_rule",
    }
    DEFAULTS = {
        'dataset_name': None,
        'schema': None,
        "generate_stats_by_rule": False,
        "generate_mapping_samples": False,
        "generate_table_data_sample": False,
        "generate_custom_stats_by_rule": False,
        "table_data_sample_rows": 10,
        "column_data_sample_rows": 10,
        "tables": []
    }


class StatsConfig(StatsConfigBase):
    def __init__(self, conf):
        with open(conf) as conf_file:
            data = json.load(conf_file)
        super(StatsConfig, self).__init__(data)


class StatsReceivedConfig(StatsConfigBase):
    def __init__(self, conf):
        data = json.loads(conf)
        super(StatsReceivedConfig, self).__init__(data)


class CustomVocConfig(Config):
    def __init__(self, conf):
        super(CustomVocConfig, self).__init__(conf)
        self.ddl_conf_files = list()
        self.workflow = None
        self.ignore_level = 'warning'
        self.empty_old = False
        self.empty_new = False


class ForeignKeyRef:
    schema_tag = None
    table_name = None
    field_name = None

    def __init__(self, val):
        assert val.count('.') < 3, "too many ref parts"
        if val.count('.') == 2:
            self.schema_tag, self.table_name, self.field_name = val.strip('@').split('.')
        elif val.count('.') == 1 and val.startswith('@'):
            self.schema_tag, self.table_name = val.strip('@').split('.')
        elif val.count('.') == 1 and not val.startswith('@'):
            self.table_name, self.field_name = val.split('.')
        else:
            self.table_name = val


# ======= Internal tool configuration ===============================

class SparkConfig:
    """
    Spark session settings configuration
    """

    __settings = []

    def __init__(self, conf, config_name = None):
        if not path.exists(conf):
            return

        config = configparser.ConfigParser()
        config.optionxform = lambda x: x  # prevent lowercase keys
        config.read(conf)

        # If config section name has been passed it should be represented
        if config_name:
            try:
                self.__settings = config.items(config_name)
            except configparser.NoSectionError:
                raise ConfigException("Config section {} hasn't been found".format(config_name))
        # Otherwise keep old logic for compatibility
        else:
            try:
                self.__settings = config.items('CUSTOM')
            except configparser.NoSectionError:
                self.__settings = config.items('DEFAULT')

    def get_settings(self):
        return self.__settings
