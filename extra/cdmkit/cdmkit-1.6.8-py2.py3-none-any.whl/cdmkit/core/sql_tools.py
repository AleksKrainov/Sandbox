import re

_SEP_PLACEHOLDER = "!SEMICOLON!"
_DOC_PLACEHOLDER = "!DOC_TAG!"

SPARK = "SPARK"
REDSHIFT = "REDSHIFT"
ATHENA = "ATHENA"
POSTGRES = "POSTGRES"
__EngineList = [SPARK, REDSHIFT, ATHENA, POSTGRES]


def apply_schemas(script, schemas):
    """Replace schema tags in SQL with values from configuration.

    Args:
        script (str): SQL code with schema params.
        schemas (dict): 'schemas' section of ETLConf.

    Returns:
        str: SQL code with schema values in place.

    """
    DEPREC = {
        # old notation used in IQVIA ETL projects
        '#SR_SCHEMA_NAME#': '@source_schema',
        '#sr_schema_name#': '@source_schema',
        '#ETL_SCHEMA_NAME#': '@cdm_schema',
        '#etl_schema_name#': '@cdm_schema',
        '#FINAL_SCHEMA_NAME#': '@target_schema',
        '#final_schema_name#': '@target_schema',
    }
    for old_tag, new_tag in DEPREC.items():
        script = script.replace(old_tag, new_tag)
    schema_map = [("@" + k if not k.startswith("@") else k, v) for k, v in schemas.items()]
    # replace longer schema tags first to avoid partial substitution
    for tag, val in sorted(schema_map, reverse=True):
        script = script.replace(tag, val)
    return script


def apply_params(script, params):
    """Replace parameters in SQL with values from configuration.

    Args:
        script (str): SQL code with custom params.
        params (dict): 'params' section of ETLConf.

    Returns:
        str: SQL code with parameter values in place.

    """
    for param_key, param_val in sorted(params.items(), reverse=True):
        # Just a temporary workaround until we need list vars somewhere else
        if isinstance(param_val, list):
            continue
        script = script.replace(param_key, param_val)
    return script


def resolve_if_macros(script):
    if_blocks = re.finditer(
        r'(--@IF\s)(\S+\s?(=|IN)\s?(\S+|\(.*?\)))(\s*\n)(.*?)(--@ELSE\s*?\n+.*?)?(\s*--@ENDIF)',
        script,
        re.DOTALL
    )
    # group 2 is the condition itself, group 6 is block of code if true
    # group 7 is block of code if false (may not be present)
    # parameters have to be already replaced at this step
    for if_block in if_blocks:
        sep = 'IN' if 'IN' in str(if_block.group(2)) else '='
        condition = str(if_block.group(2)).split(sep)
        actual_value = condition[0].rstrip()
        expected_value = condition[1].lstrip()
        if sep == 'IN':
            expected_value = [v.strip() for v in expected_value[1:-1].split(',')]
            check_result = actual_value in expected_value
        else:
            check_result = actual_value == expected_value

        if check_result and if_block.group(7) is not None:
            script = script.replace(str(if_block.group(7)), '')
        elif not check_result:
            script = script.replace(str(if_block.group(6)), '')
    return script


def only_comments_in(statement):
    """Check if SQL chunk contains only comments and empty space.

    Args:
        statement (str): A single SQL statement.

    Returns:
        bool: True if `statement` has no real SQL to execute, False otherwise.

    """
    # single-line comments, starting with '--' and possibly ending with newline
    # OR multi-line comments (DOTALL applies here)
    # OR empty lines (lookbehind to leave one \n instead of empty line)
    return strip_comments(statement) == ''


def strip_comments(statement):
    """Remove commented lines from the SQL statement.

    Args:
        statement (str): A single SQL statement.

    Returns:
        str: SQL statement with comment lines stripped.

    """
    garbage = re.compile(r"(\s*--[^\n]*\n?)|(\/\*.*?\*\/)|((?<=\n)\s*\n)", re.DOTALL)
    stripped = re.sub(garbage, ' ', statement).strip()
    return stripped


def _replace_semicolon(sql_code):
    return _replace_symbols(sql_code, [';'], _SEP_PLACEHOLDER)

def _replace_doctag(sql_code):
    """
    Wrapper for calling replace_symbol function for doc_tag tags inside comment on placeholder
    """
    return _replace_symbols(sql_code, ['!*/', '/*!'], _DOC_PLACEHOLDER)

def _replace_symbols(sql_code, symbols, placeholder):
    replaced = ""
    escaped = False
    sq_value = False  # literal string value in single quotes ('TL; DR')
    dq_value = False  # literal string value in double quotes ("let's break;")
    sline_comment = False
    mline_comment = False
    reset = False
    previous = ""
    for sym in sql_code:
        if previous[-1:] == "\\" and (sq_value or dq_value):
            escaped = True
        if sym == "'" and not (dq_value or sline_comment or mline_comment or escaped):
            reset = sq_value
            sq_value = not sq_value
        if sym == '"' and not (sq_value or sline_comment or mline_comment or escaped):
            reset = dq_value
            dq_value = not dq_value
        if ((sym == "-" and previous == "-") or previous[-2:] == '--') and not (sq_value or dq_value):
            sline_comment = True
            reset = True
        if sym == "\n" and sline_comment:
            sline_comment = False
            reset = True
        if sym == "*" and previous[-1:] == "/" and not (mline_comment or sline_comment):
            mline_comment = True
            reset = True
        if sym == "/" and previous[-1:] == "*" and mline_comment and not sline_comment:
            mline_comment = False

        if any([sq_value, dq_value, sline_comment, mline_comment]):
            if (previous in symbols) or (previous + sym in symbols):
                replaced += placeholder
                previous = ''
            elif sym in symbols:
                replaced += (previous if len(previous) > 0 else '') + placeholder
                previous = ''
            elif reset:
                replaced += (previous if len(previous) > 0 else '') + sym
                previous = ''
                reset = False
            else:
                previous += sym
        elif sym == ' ' or reset:
            if previous in symbols and any([sq_value, dq_value, sline_comment, mline_comment]):
                replaced += placeholder + sym
            else:
                replaced += (previous if len(previous) > 0 else '') + sym
            previous = ''
            reset = False
        else:
            previous += sym

        escaped = False

    return replaced + previous

def split_into_queries(script, ensure_newline=True, keep_empty=False):
    """Split SQL code into separate queries.
    Possible ';' inside string values are taken into account.

    Args:
        script (str): SQL code.
        ensure_newline (bool): end each query with single newline. Defaults to True.
        keep_empty (bool): keep whitespace-only parts after split. Defaults to False.

    Returns:
        list: the list of SQL queries.

    """
    end = "\n" if ensure_newline else ""
    return list(filter(
        lambda x: keep_empty or len(x.strip()) > 0,
        [q.replace(_SEP_PLACEHOLDER, ";").strip() + end for q in _replace_semicolon(script).split(";")]
    ))


def replace_identity(script, engine):
    """
    Replace @IDENTITY macros for autoincremental field
    
    For engines which don't support auto-incremental fields (e.g. spark) it will be replaced with ids generator

    Args:
        script(str): sql script with @IDENTITY macros
        engine(EngineList): which will run query. It must be one of engine from ENGINE_LIST
    Returns:
        script without @IDENTITY macros
    """
    
    assert engine in __EngineList, "Unknown dialect: '{}'".format(engine)

    if engine == SPARK:
        script = script.replace("@IDENTITY", "monotonically_increasing_id()+1")
    elif engine == REDSHIFT:
        script = re.sub("@IDENTITY\s+(AS [a-z_]+\s?)?,", "", script, 0, re.I)
    elif engine == ATHENA:
        script = script.replace("@IDENTITY", "ROW_NUMBER() OVER()")
    if engine == POSTGRES:
        # script = script.replace("@IDENTITY", "nextval('')")  # requires name in '{schema}.{table}_{col}_seq' format
        script = re.sub("@IDENTITY\s+(AS [a-z_]+\s?)?,", "", script, 0, re.I)

    return script
