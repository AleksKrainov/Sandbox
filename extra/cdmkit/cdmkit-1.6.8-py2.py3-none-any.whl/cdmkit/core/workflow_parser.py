import re
from os import path
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core.utils import unfolderize

from sqlparse import parse
from sqlparse.sql import Identifier, IdentifierList, Where
from sqlparse.tokens import Keyword, DML, DDL, CTE

REGEX_CLEANUP = {
    (r'STORED\s+AS\s+([A-Z]+)\s?\n?', ''),
    (r'USING\s+([A-Z]+)\s?\n?', ''),
    (r'TBLPROPERTIES\s*\(.*?\)', ''),
}


def parse_workflow(etl_conf, workflow, etl_home):
    """Read all script files from workflow and parse the SQL queries to get target-source links.
    Args:
        etl_conf: configuration from the project etlconf file
        workflow: the list of scripts from the workflow.conf file
        etl_home: path to project directory
    Returns:
        workflow_dict: dictionary of workflow queries, tables & their sources
    TODO: Parse SQL some more to extract links between fields & anything else we might be interested in
    """
    etl_print('Attempting to parse SQL scripts into inferred workflow graph', ETLMessageType.Running)

    params = etl_conf.params
    workflow_scripts = unfolderize(etl_home, workflow.workflow_batches)
    script_statements = {}
    workflow_dict = dict(queries={}, links={})

    for script in workflow_scripts:
        if 'script' not in script.keys():
            continue
        with open(path.join(etl_home, 'src', script['script']), 'r') as script_file:
            sql_code = script_file.read()

        for param, value in params.items():
            if isinstance(value, str):
                sql_code = sql_code.replace(param, value)
        for regex in REGEX_CLEANUP:
            sql_code = re.sub(regex[0], regex[1], sql_code, flags=re.IGNORECASE)

        try:
            parsed = parse(sql_code)
        except ValueError:
            etl_print('Could not parse {}, skipping workflow inference'.format(script), ETLMessageType.Warning)
            return {}

        script_statements[script['script']] = [sql for sql in parsed if sql.get_type() in ('CREATE', 'INSERT')]

    for script in script_statements:
        for i, sql in enumerate(script_statements[script]):
            table_name = _get_table_name(sql)
            cte_sources = _get_sources_cte(sql)
            from_sources = _get_sources_from(sql)
            real_sources = [table for table in from_sources if table not in cte_sources]
            for table in filter(lambda x: x in cte_sources, from_sources):
                real_sources.extend(cte_sources[table])
            workflow_dict['queries'].setdefault(script, {})[i] = sql.value
            workflow_dict['links'].setdefault(table_name, {}).update({table: (script, i) for table in real_sources})

    etl_print('', ETLMessageType.Ok)
    return workflow_dict


def _get_fqn_from_token(token):
    sch_name = token.get_parent_name()
    tbl_name = token.get_real_name()
    name = tbl_name if sch_name is None else '.'.join((sch_name, tbl_name))
    return name


def _get_table_name(sql):
    """Go through the tokens of the parsed SQL, pick the first name found after CREATE or INSERT keywords
        Args:
            sql (Token): parsed SQL token(s) from sqlparse
        Returns:
            name (str): name of the target table
    """
    name = None
    seen_create_insert = False
    for token in sql.tokens:
        if token.ttype in (DDL, DML) and token.value.upper() in ('CREATE', 'INSERT'):
            seen_create_insert = True
        if isinstance(token, Identifier) and seen_create_insert:
            name = _get_fqn_from_token(token)
            break
    return name


def _get_sources_cte(sql):
    """Go through the tokens of the CTE part of the SQL, get source tables of a single CTE or multiple CTEs
        Args:
            sql (Token): parsed SQL token(s) from sqlparse
        Returns:
            sources (list[str]): list of source table names
    """
    sources = {}
    cte_part = _extract_cte_part(sql)
    if isinstance(cte_part, Identifier):
        alias, source_tables = _extract_sources_cte(cte_part)
        sources[alias] = source_tables
    elif isinstance(cte_part, IdentifierList):
        for cte in filter(lambda x: x.is_group, cte_part):
            alias, source_tables = _extract_sources_cte(cte)
            if alias:
                sources[alias] = source_tables
    return sources


def _get_sources_from(token_stream):
    """Go through the tokens of parsed SQL, get source tables after FROM keyword.
        Ignore sources in a special case of LEFT JOIN some_table t WHERE t.some_field IS NULL:
            such structure is often used to check for duplicates
            and is the most common cause of recursion is the workflow graph.
        Args:
            token_stream (generator): SQL tokens starting from the FROM keyword
        Returns:
            table_sources (list[str]): list of source table names
    """
    table_sources = []
    from_seen = False
    leftjoin_seen = False
    leftjoin_sources = {}
    suspicious_alias_list = []
    for token in token_stream:
        if token.ttype is Keyword:
            if token.value.upper() == 'FROM':
                from_seen = True
            elif token.value.upper() in ('LEFT JOIN', 'RIGHT JOIN', 'LEFT OUTER JOIN',
                                         'RIGHT OUTER JOIN', 'ANTI JOIN'):
                leftjoin_seen = True
            elif token.value.upper() in ('UNION', 'GROUP BY', 'ORDER BY'):
                from_seen = False
        elif isinstance(token, Where):
            from_seen = False
            suspicious_alias_list.extend(_alias_isnull(token))
        if from_seen and _is_subselect(token):
            for group in filter(lambda x: x.is_group, token):
                table_sources.extend(_get_sources_from(group))
            if leftjoin_seen:
                leftjoin_seen = False
        elif from_seen and isinstance(token, Identifier):
            prev_token = token_stream.token_prev(token_stream.token_index(token))
            if not (prev_token[1].ttype is Keyword and (
                    prev_token[1].value.upper() == 'FROM' or 'JOIN' in prev_token[1].value.upper())):
                continue
            if leftjoin_seen:
                leftjoin_sources[token.get_alias()] = _get_fqn_from_token(token)
                leftjoin_seen = False
            else:
                table_sources.append(_get_fqn_from_token(token))
    table_sources += [table for alias, table in leftjoin_sources.items() if alias not in suspicious_alias_list]
    return table_sources


def _extract_cte_part(sql):
    """Go through the tokens of the parsed SQL, pick the first group found after WITH keyword
        Args:
            sql (Token): parsed SQL token(s) from sqlparse
        Returns:
            token (Token): CTE group of tokens
    """
    cte_seen = False
    for token in sql.tokens:
        if cte_seen and token.is_group:
            return token
        elif token.ttype is CTE and token.value.upper() == 'WITH':
            cte_seen = True


def _extract_sources_cte(cte_group):
    """Go through the tokens of the CTE part of the SQL, get source tables list from the first token group
        Args:
            cte_group (Token): parsed SQL token(s) from sqlparse
        Returns:
            cte_alias (str): alias used for CTE
            sources (list[str]): list of source table names
    """
    cte_alias = cte_group.get_name()
    sources = []
    for token in cte_group:
        if token.is_group:
            sources = _get_sources_from(token)
    return cte_alias, sources


def _is_subselect(token):
    """Check if token is a subquery"""
    if not token.is_group:
        return False
    for group in filter(lambda x: x.is_group, token.tokens):
        for item in group.tokens:
            if item.ttype is DML and item.value.upper() == 'SELECT':
                return True
    return False


def _alias_isnull(where):
    """Go through the tokens of the WHERE part of the SQL, get aliases of tables in `field IS NULL` filters.
        Args:
            where (Token): parsed SQL token(s) from sqlparse
        Returns:
            found_alias (list[str]): list of table aliases
    """
    found_alias = []
    for token in where:
        if isinstance(token, Identifier):
            next_token = where.token_next(where.token_index(token))[1]
            if next_token.ttype is Keyword and next_token.value.upper() == 'IS':
                next_next_token = where.token_next(where.token_index(next_token))[1]
                if next_next_token.ttype is Keyword and next_next_token.value.upper() == 'NULL':
                    found_alias.append(token._get_first_name())
    return found_alias
