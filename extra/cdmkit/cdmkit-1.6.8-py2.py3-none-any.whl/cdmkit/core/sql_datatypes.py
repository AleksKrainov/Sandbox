"""Handle discrepancies in SQL data types.
"""

__all__ = ["SQLiteDataTypes", "PostgreSQLDataTypes", "SparkDataTypes", "LegacyPostgreSQLDataTypes"]


class BaseTypeTranslator:
    """SQL datatype translation interface."""

    DATA_TYPES = {
        # each type has at least "t" attribute with target datatype
        "string": {
            "t": "varchar",
            # param section. If not present, this means native datatype doesn't support this param.
            "length": {"default": None, "max": 255}
            # default: None means that param section can be omitted (e.g.just "varchar").
        },
        "bigint":       {"t": "bigint"},
        "int":          {"t": "int"},
        "float":        {"t": "float"},
        "double":       {"t": "double"},
        "decimal":      {"t": "decimal"},
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "int"},
        "identity":     {"t": "bigint identity"},
        "event_date":   {"t": "date"},
    }

    @classmethod
    def to_native(cls, t, length=None, precision=None, scale=None):
        """Translate internal SQL datatype into native dialect.

        Args:
            t (str): Reference datatype.
            length (int): Maximum length for "string" type. Ignored if not supported by DBMS. Defaults to None.
            precision (int): Precision for "decimal" type. Defaults to None.
            scale (int): Scale for "decimal" type. Must be less or equal to `precision`. Defaults to None.

        Returns:
            str: Datatype string in DB-native dialect.

        Raises:
            KeyError: if `t` is not a correct reference type.
            ValueError: if `length`, `precision` or `scale` have incorrect values.

        """
        try:
            translation = cls.DATA_TYPES[t]
        except KeyError:
            raise KeyError("Class {} cannot translate type '{}'".format(cls, t))
        params = ""  # no parameters by default
        length_rules = translation.get("length")  # supports 'length' parameter
        if length_rules is not None:
            if length is None:
                params = "(" + str(length_rules["default"]) + ")" if length_rules.get("default") is not None else ""
            elif str(length) != "MAX" and length_rules["max"] < length:
                raise ValueError(
                    "Datatype '{}' length value {} exceeds the max={} for {} DB type"
                    .format(t, length, length_rules["max"], cls)
                )
            else:
                params = "(" + str(length) + ")"
        elif length is None and length_rules is not None and length_rules["default"] is not None:
            params = "(" + str(length_rules["default"]) + ")"
        if precision or scale:
            p, s = translation.get("precision"), translation.get("scale")
            if p is None or s is None:
                pass  # no support for precision/scale params
            else:
                pv = precision if precision is not None else p["default"]
                sv = scale if scale is not None else s["default"]
                # in ideal world, defaults are set correctly, so these checks won't fire
                if pv not in range(p["min"], p["max"]+1):
                    raise ValueError(
                        "Datatype '{}' precision value {} is not in ({},{}) range for {} DB type"
                        .format(t, precision, p["min"], p["max"], cls)
                    )
                elif sv not in range(s["min"], s["max"]+1):
                    raise ValueError(
                        "Datatype '{}' scale value {} is not in ({},{}) range for {} DB type"
                        .format(t, scale, s["min"], s["max"], cls)
                    )
                elif sv not in range(s["min"], pv+1):
                    raise ValueError(
                        "Datatype '{}' scale value {} must be <= precision {}"
                        .format(t, scale, s["min"], pv)
                    )
                else:
                    params = "({},{})".format(pv, sv)
        return translation["t"] + params


# === Implementations for currently supported DB systems ============


class SQLiteDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string":       {"t": "text"},
        "bigint":       {"t": "integer"},
        "int":          {"t": "integer"},
        "float":        {"t": "real"},
        "double":       {"t": "real"},
        "decimal":      {"t": "real"},
        "date":         {"t": "text"},
        "timestamp":    {"t": "text"},
        "boolean":      {"t": "integer"},
        # Generic types
        "concept_id":   {"t": "integer"},
        "identity":     {"t": "integer primary key"},
        "event_date":   {"t": "date"},
    }


class PostgreSQLDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string": {
            "t": "varchar",
            "length": {"default": None, "max": 65535}  # DB sets 256 without params
        },
        "bigint":       {"t": "bigint"},
        "int":          {"t": "int"},
        "float":        {"t": "real"},
        "double":       {"t": "double precision"},
        "decimal": {
            "t": "decimal",
            "precision":    {"default": 18, "max": 1000, "min": 0},
            "scale":        {"default": 0, "max": 1000, "min": 0},
        },
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "int"},
        "identity":     {"t": "bigint generated by default as identity primary key"},
        "event_date": {"t": "date"},
    }


class LegacyPostgreSQLDataTypes(BaseTypeTranslator):
    """For Postgres 9x and earlier."""
    DATA_TYPES = {
        "string": {
            "t": "varchar",
            "length": {"default": None, "max": 65535}  # DB sets 256 without params
        },
        "bigint":       {"t": "bigint"},
        "int":          {"t": "int"},
        "float":        {"t": "real"},
        "double":       {"t": "double precision"},
        "decimal": {
            "t": "decimal",
            "precision":    {"default": 18, "max": 1000, "min": 0},
            "scale":        {"default": 0, "max": 1000, "min": 0},
        },
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "int"},
        "identity":     {"t": "bigserial primary key"},
        "event_date":   {"t": "date"},
    }


class SparkDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string":       {"t": "string"},
        "bigint":       {"t": "long"},
        "int":          {"t": "integer"},
        "float":        {"t": "float"},
        "double":       {"t": "double"},
        "decimal": {
            "t": "decimal",
            "precision":    {"default": 10, "max": 38, "min": 0},
            "scale":        {"default": 0, "max": 38, "min": 0},
        },
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "integer"},
        "identity":     {"t": "long"},
        "event_date":   {"t": "date"},
        # legacy typing scheme with pyspark class names
        "StringType":       {"t": "string"},
        "LongType":         {"t": "long"},
        "IntegerType":      {"t": "integer"},
        "FloatType":        {"t": "float"},
        "DoubleType":       {"t": "double"},
        "DecimalType":      {"t": "decimal"},
        "DateType":         {"t": "date"},
        "TimestampType":    {"t": "timestamp"},
        "BooleanType":      {"t": "boolean"},
    }


class AthenaDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string":       {"t": "varchar"},
        "bigint":       {"t": "bigint"},
        "int":          {"t": "int"},
        "float":        {"t": "double"},
        "double":       {"t": "double"},
        "decimal": {
            "t": "decimal",
            "precision":    {"default": 10, "max": 38, "min": 0},
            "scale":        {"default": 0, "max": 38, "min": 0},
        },
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "int"},
        "identity":     {"t": "bigint"},
        "event_date":   {"t": "date"},
    }


class BigQueryDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string":       {"t": "string"},
        "bigint":       {"t": "int64"},
        "int":          {"t": "int64"},
        "float":        {"t": "float64"},
        "double":       {"t": "float64"},
        "decimal":      {"t": "float64"},
        "date":         {"t": "date"},
        "timestamp":    {"t": "datetime"},
        "boolean":      {"t": "bool"},
        # Generic types
        "concept_id":   {"t": "int64"},
        "identity":     {"t": "int64"},
        "event_date":   {"t": "date"},
    }


class SqlServerDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string": {
            "t": "varchar",
            "length": {"default": 255, "max": 65535}  # DB sets 256 without params
        },
        "bigint": {"t": "bigint"},
        "int": {"t": "int"},
        "float": {"t": "float"},
        "double": {"t": "float"},
        "decimal": {
            "t": "decimal",
            "precision": {"default": 18, "max": 1000, "min": 0},
            "scale": {"default": 0, "max": 1000, "min": 0},
        },
        "date": {"t": "date"},
        "timestamp": {"t": "datetime"},
        "boolean": {"t": "bit"},
        # Generic types
        "concept_id": {"t": "int"},
        "identity": {"t": "bigint identity(1,1)"},
        "event_date": {"t": "date"},
    }


class SnowflakeDataTypes(BaseTypeTranslator):
    DATA_TYPES = {
        "string": {
            "t": "varchar",
            "length": {"default": None, "max": 16777216}  # max is default
        },
        "bigint":       {"t": "bigint"},
        "int":          {"t": "int"},
        "float":        {"t": "float"},
        "double":       {"t": "double"},
        "decimal": {
            "t": "number",
            "precision":    {"default": 38, "max": 38, "min": 0},
            "scale":        {"default": 0, "max": 37, "min": 0},
        },
        "date":         {"t": "date"},
        "timestamp":    {"t": "timestamp"},
        "boolean":      {"t": "boolean"},
        # Generic types
        "concept_id":   {"t": "int"},
        "identity":     {"t": "bigint"},
        "event_date":   {"t": "date"},
    }
