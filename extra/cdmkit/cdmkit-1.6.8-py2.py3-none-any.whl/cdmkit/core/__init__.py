
def enum(typename, field_names):
    """Limited reimplementation of native Enum, which is not supported in Py2.

    Args:
        typename (str): The name of new Enum-like type.
        field_names (list): List of str enum options.

    Returns:
        object: Enum-like object.

    """
    d = dict((reversed(nv) for nv in enumerate(field_names)), __slots__=())
    return type(typename, (object,), d)()


try:
    from cdmkit.core.output_colored import etl_print
    from cdmkit.core.output_colored import ETLMessageType
except ImportError:
    from cdmkit.core.output import etl_print
    from cdmkit.core.output import ETLMessageType
