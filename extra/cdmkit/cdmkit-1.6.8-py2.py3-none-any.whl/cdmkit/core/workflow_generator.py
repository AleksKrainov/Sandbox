import json
import os
import re

from collections import OrderedDict

from cdmkit.core import exceptions as E
from cdmkit.core.utils import unfolderize, apply_selection_range, merge_dicts
from cdmkit.core.sql_tools import (
    only_comments_in,
    split_into_queries,
    _replace_doctag as replace_doctag,
    strip_comments
)

class CodeParser:
    section_tags_list = ['insertgroup', 'endgroup', 'docpage']
    insert_tags_list = ['insert']

    @staticmethod
    def parse_script(script, params):
        statements_list = split_into_queries(script)
        statements_list = CodeParser.unfold_for(statements_list, params)
        result_list = list()
        for sttm in statements_list:
            statement = replace_doctag(sttm)

            sections = CodeParser.fetch_section_tags(statement)
            for section in sections['sections']:
                result_list.append(section)

            statement = sections['rest']

            if statement != '':
                tag = CodeParser.fetch_insert_tags(statement)
                doc_section = None
                if tag:
                    start_idx = statement.find('/*!')
                    end_idx = statement.find('!*/')
                    if start_idx != -1 and end_idx != -1:
                        doc_section = statement[start_idx + 3:end_idx]
                        statement = statement[end_idx + 3:]

                statement = statement.strip()
                if not only_comments_in(statement):
                    result_list.append({
                        'type': 'sql',
                        'content': statement,
                        'doc_section': doc_section
                    })

        return result_list

    @staticmethod
    def fetch_table_name(table):
        if '.' not in table:
            return table

        return table.split('.')[1]

    @staticmethod
    def fetch_section_tags(statement):
        doc_comments_list = statement.split('!*/')
        sections = list()
        rest = list()
        for doc_comment in doc_comments_list:
            section_tag_found = False
            for tag in CodeParser.section_tags_list:
                if '@' + tag in doc_comment:
                    section_tag_found = True
                    sections.append({
                        'type': tag,
                        'content': doc_comment.split('/*!')[1].strip(),
                    })

            if not section_tag_found:
                rest.append(doc_comment)

        return {
            'sections': sections,
            'rest': ('!*/').join(rest)
        }

    @staticmethod
    def fetch_insert_tags(statement):
        for tag in CodeParser.insert_tags_list:
            if '@' + tag in statement:
                return tag

        return None

    @staticmethod
    def table_node_class(table_name):
        table_name = table_name.lower()

        looks_like_source_table = any([
            table_name.startswith('@source_schema'),
            table_name.startswith('#sr_schema_name#')
        ])
        if looks_like_source_table:
            return 'source_table'

        if table_name.startswith('@voc_schema'):
            return 'voc_table'

        looks_like_cdm_table = any([
            table_name.startswith('@target_schema'),
            table_name.startswith('#final_schema_name#'),
        ])
        if looks_like_cdm_table:
            return 'cdm_table'

        return 'proxy_table'

    @staticmethod
    def unfold_for(statements, variables):
        unfolded_statements = list()

        # group 1 is the iterator variable
        # group 2 is the list variable from params
        # group 3 is the sql itself
        for_re = re.compile(r'--@FOR (.*?) IN (.*?)\s+--@FOR_BEGIN\s+(.+?)--@FOR_END', re.DOTALL)

        for raw_statement in statements:
            if not for_re.search(raw_statement):
                unfolded_statements.append(raw_statement)
                continue

            for_cycles = for_re.finditer(raw_statement)

            # TODO: THINK ABOUT SEMICOLON AND WHY --@FOR_END SHOULD BE AFTER IT?
            for for_cycle in for_cycles:
                iter_var = for_cycle.group(1)
                var_list_id = for_cycle.group(2)
                sql = for_cycle.group(3)

                iter_var_dict_re = re.compile(r'{}\[(.*?)\]'.format(iter_var))

                for var in variables.get(var_list_id, list()):
                    if not iter_var_dict_re.search(sql):
                        parsed_sql = sql.replace(iter_var, var)
                    else:
                        if not isinstance(var, dict):
                            raise E.ParseException('Found dict var references in the code, yet no dicts in params given')

                        # group 1 is the dict key
                        parsed_sql = iter_var_dict_re.sub(lambda x: var.get(x.group(1), 'NULL'), sql)

                    unfolded_statements.append(parsed_sql)

        return unfolded_statements


class WorkflowGenerator(object):
    def __init__(self, etl_conf, workflow_conf, etl_home):
        """Generate workflow based on configuration received from workflow.conf file.

        Args:
            etl_conf (core.etl_configs.ETLConf): the configuration for current env.
            workflow_conf (core.etl_configs.WorkflowCustomConfig): workflow definition referenced in `etl_conf`.
            etl_home (str): the root directory of current CDMKit project.

        """
        self.etl_conf = etl_conf
        self.conf = workflow_conf
        self.etl_home = etl_home
        # replace 'folder' tags with 'script's (if any)
        self.conf.workflow_batches = unfolderize(self.etl_home, self.conf.workflow_batches)
        # remove scripts out of given range (if range is present)
        apply_selection_range(self.conf)
        # collect all params (regular & from additional files)
        self.params = self.get_params()
        # collect SQL source code
        self.sql_code_list = self.get_scripts_source_code()

    def run(self):
        preprocess_result = self._preprocess(self.sql_code_list)
        process_result = self._process(preprocess_result)
        return process_result

    def get_scripts_source_code(self):
        flow = list()
        for item in self.conf.workflow_batches:
            if 'automation' in item.keys():
                flow.append({
                    'type': 'callable',
                    'call': [
                        'bash',
                        item['automation']
                    ] + item['args']
                })
                continue
            script_path = os.path.join(self.etl_home, 'src', item['script'])
            with open(script_path, 'r') as script_file:
                sql_code = script_file.read()
                flow.append({
                    'type': 'sql',
                    'script': item['script'],
                    'sql': sql_code
                })
        return flow

    def get_params(self):
        paths = [os.path.join(self.etl_home, 'conf', filename) for filename in self.etl_conf.ext_params]
        ext_param_sets = list()
        for file in paths:
            with open(file, 'r') as f:
                ext_params = json.load(f)
                ext_param_sets.append(ext_params)
        return merge_dicts(self.etl_conf.params, *ext_param_sets)

    def _preprocess(self, sql_code_list):
        preprocess_result = list()
        for script in sql_code_list:
            if script['type'] == 'callable':
                preprocess_result.append(script)
                continue
            preprocess_result.append({
                "type": script['type'],
                "script": script['script'],
                "statements": CodeParser.parse_script(script['sql'], self.params)
            })
        return preprocess_result

    def _process(self, preprocessed_scripts):
        statements_list = list()
        workflow_graph = list()
        current_script = None
        current_group = None
        page_id_counter = 0

        current_page = None
        # may raise StopIteration, which means only bash scripts in workflow.
        first_non_callable = next(
            (s for s in preprocessed_scripts
             if s['type'] != 'callable')
        )
        if first_non_callable['statements'][0]['type'] != 'docpage':
            current_page = {
                'page': 'Default',
                'id': str(page_id_counter),
                'graph': {
                    'nodes': list(),
                    'links': list()
                }
            }

        insert_group_id_counter = 0
        for script in preprocessed_scripts:
            if script['type'] == 'callable':
                statements_list.append(script)
                continue
            statement_id_counter = 0
            current_script = script['script']
            current_script_statements_list = list()
            for statement in script['statements']:
                if statement['type'] == 'sql':
                    doc_info = dict()
                    doc_warnings = list()
                    sql = statement['content']
                    script_id = script['script'].replace("/", ".") + '.' + str(statement_id_counter)
                    if statement['doc_section']:
                        provided_doc_info = self._fetch_doc_info(statement['doc_section'])
                        inferred_doc_info = self._infer_doc_info(statement) if self.conf.infer_doc_info is True else {}
                        doc_info = {
                            "summary": provided_doc_info["summary"],
                            "table": inferred_doc_info.get('target_table') or provided_doc_info.get('table'),
                            "source_table": list(set().union(provided_doc_info.get('source_table', list()),
                                                             inferred_doc_info.get('source_tables', list())))
                        }
                        doc_warnings = check_insert_doc_info(provided_doc_info, inferred_doc_info)

                        graph_insert_node = {
                            'node_class': 'insert',
                            'id': script_id,
                            'summary': doc_info["summary"],
                            'table': doc_info["table"],
                            'source_table': doc_info["source_table"],
                            'sql': statement['content']
                        }

                        if current_group:
                            current_group['child_nodes'].append(graph_insert_node)
                        else:
                            current_page['graph']['nodes'].append(graph_insert_node)

                    current_script_statements_list.append({
                        'id': script_id,
                        'doc_info': doc_info,
                        'sql': sql,
                        'doc_warnings': doc_warnings
                    })
                    statement_id_counter += 1
                elif statement['type'] == 'insertgroup':
                    doc_info = self._fetch_doc_info(statement['content'])
                    current_group = {
                        'node_class': 'insert_group',
                        'id': 'insertgroup.' + str(insert_group_id_counter),
                        'summary': doc_info['summary'],
                        'table': doc_info['table'],
                        'source_table': doc_info['source_table'],
                        'child_nodes': list()
                    }
                    insert_group_id_counter += 1
                elif statement['type'] == 'endgroup':
                    current_page['graph']['nodes'].append(current_group)
                    current_group = None

                elif statement['type'] == 'docpage':
                    if current_page:
                        links = self._generate_links(current_page['graph']['nodes'])
                        current_page['graph']['links'] = links
                        table_nodes = self._generate_table_nodes(current_page['graph']['nodes'])
                        current_page['graph']['nodes'].extend(table_nodes)
                        workflow_graph.append(current_page)

                    current_page = {
                        'page': self._fetch_doc_value(statement['content'], 'pagename'),
                        'id': str(page_id_counter),
                        'graph': {
                            'nodes': list(),
                            'links': list()
                        }
                    }
                    page_id_counter += 1

            statements_list.append({
                'script': current_script,
                'statements': current_script_statements_list
            })

        if current_page:
            links = self._generate_links(current_page['graph']['nodes'])
            current_page['graph']['links'] = links
            table_nodes = self._generate_table_nodes(current_page['graph']['nodes'])
            current_page['graph']['nodes'].extend(table_nodes)
            workflow_graph.append(current_page)

        default_page_is_empty = all((
            workflow_graph[0]['page'] == "Default",
            workflow_graph[0]['graph']['nodes'] == list(),
            workflow_graph[0]['graph']['links'] == list()
        ))
        if default_page_is_empty:
            workflow_graph.pop(0)

        return {
            "workflow": statements_list,
            "workflow_graph": workflow_graph
        }

    @staticmethod
    def _generate_table_nodes(insert_nodes):
        table_nodes = dict()
        for node in insert_nodes:
            if node['table'] is None:
                continue
            try:
                table_nodes[node['table']] = {
                    'node_class': CodeParser.table_node_class(node['table']),
                    'id': node['table'],
                    'table': CodeParser.fetch_table_name(node['table']),
                    'table_name': node['table']
                }

                for source_table in node['source_table']:
                    table_nodes[source_table] = {
                        'node_class': CodeParser.table_node_class(source_table),
                        'id': source_table,
                        'table': CodeParser.fetch_table_name(source_table),
                        'table_name': source_table
                    }
            except Exception as e:
                print(str(e))
                # print(json.dumps(node, indent=4))

        return table_nodes.values()

    def _generate_links(self, insert_nodes):
        links = list()
        for node in insert_nodes:
            if node['node_class'] == 'insert_group':
                for child_node in node['child_nodes']:
                    links.extend(self._generate_node_links(child_node))
            else:
                links.extend(self._generate_node_links(node))

        return links

    @staticmethod
    def _generate_node_links(node):
        links = list()
        links.append({
            'source': node['id'],
            'target': node['table']
        })

        for source_table in node['source_table']:
            links.append({
                'source': source_table,
                'target': node['id'],
            })

        return links

    def _fetch_doc_info(self, comments_text):
        doc_info = dict()
        required_tags = ('summary',)
        if self.conf.infer_doc_info is False:
            required_tags += ('table', 'source_table')

        tags_positions = list()

        tags = re.findall(r"\@\s*\w*:",comments_text,re.MULTILINE)

        for tag in tags:
            tags_positions.append(comments_text.find(tag))

        doc_comments = list()
        end_pos = len(comments_text)

        for start_pos in reversed(tags_positions):
            comment_section = comments_text[start_pos + 1:end_pos]
            doc_comments.append(comment_section.strip())
            end_pos = start_pos

        for doc_comment in doc_comments:
            if doc_comment.startswith('table:'):
                doc_info['table'] = self._fetch_doc_value(doc_comment, 'table').split('\n')[0].lower()
            elif doc_comment.startswith('source_table:'):
                src_table_string = self._fetch_doc_value(doc_comment, 'source_table').lower().replace('\n', ',')
                doc_info['source_table'] = [tbl_name.strip().lower()
                                            for tbl_name in src_table_string.split(',')
                                            if tbl_name.strip() != '' and ' ' not in tbl_name.strip()]
            elif doc_comment.startswith('summary:'):
                doc_info['summary'] = self._fetch_doc_value(doc_comment, 'summary')

        for tag in required_tags:
            if tag not in doc_info:
                print("Warning: required tag '{0}' is missing in annotation {1}".format(tag, comments_text.rstrip()))
                doc_info[tag] = 'none'
                if tag in ('table', 'source_table'):
                    # not quite elegant, but at least offers a solution
                    print("Hint: try running without '--no-inference' flag.\n")

        return doc_info

    @staticmethod
    def _infer_doc_info(query):
        # TODO: --@F tag doesn't work properly with ctas and insert re, fix it
        exclude_tag = '--#F'
        excluded_tables = list()

        # group 2 - target table, group 5 - source table, both must be stripped
        ctas_re = re.compile(r"(?<=CREATE TABLE\s)\s*(@.*?\..*?\s).*?(?<=(SELECT))(.*?)(?<=FROM\s).*?(@\w*?\.\w*\s?)",
                             re.DOTALL | re.IGNORECASE)

        # group 2 - target table, group 5 - source table, both must be stripped
        insert_re = re.compile(r"(?<=INSERT INTO\s)\s*(@.*?\.*?\s).*?(?<=(SELECT))(.*?)(?<=FROM\s).*?(@\w*?\.\w*\s?)",
                               re.DOTALL | re.IGNORECASE)

        # group 1 - source join table, must be stripped, group 2 - alias
        joins_re = re.compile(r"(?<=JOIN\s).*?(@\w+\.\w+\s?)(.*?)\s+", re.DOTALL | re.IGNORECASE)

        placeholder = "!@$~"    # prevent exclude_tag being removed as SQL comment
        statement = query['content'].replace(exclude_tag, placeholder)
        statement = strip_comments(statement).replace(placeholder, exclude_tag)
        doc_info = OrderedDict()
        doc_info['source_tables'] = list()
        doc_info['filter_tables'] = list()

        match = ctas_re.search(statement) or insert_re.search(statement)

        if match is None:
            doc_info['cannot_infer'] = True
            return doc_info

        doc_info['target_table'] = match.group(1).strip().lower()

        if exclude_tag not in match.group(0):
            doc_info['source_tables'].append(match.group(4).strip().lower())

        joins = joins_re.finditer(statement)

        for join in joins:
            if exclude_tag in join.group(0):
                excluded_tables.append(join.group(1).strip().lower())
                continue
            elif '{}.'.format(join.group(2)) not in match.group(0) and join.group(2) != '':
                doc_info['filter_tables'].append(join.group(1).strip().lower())
            else:
                doc_info['source_tables'].append(join.group(1).strip().lower())

        doc_info['source_tables'] = list(set(doc_info['source_tables']) - set(excluded_tables))
        if excluded_tables:
            doc_info['excluded_tables'] = excluded_tables

        return doc_info

    @staticmethod
    def _fetch_doc_value(doc_comment, tag):
        return doc_comment.split(tag + ':')[1].strip()


def check_insert_doc_info(provided, inferred):
    warnings = list()
    if not inferred:
        return warnings

    # empty values
    if provided['summary'].strip() == '':
        warnings.append("Empty 'summary' section")
    if 'table' in provided and provided['table'].strip() == '':
        warnings.append("Empty 'table' section")
    empty_src_ts = provided.get('source_table', list()).count('')
    if empty_src_ts:
        warnings.append("{} whitespace-only values in 'source_table' section".format(empty_src_ts))
    if inferred.get('cannot_infer') is True:
        warnings.append("Cannot infer query doc info, check syntax")
        # early return - makes no sense to check the tables
        return warnings

    # table names mismatch
    should_guess_all_tbls = not ('table' in provided or 'source_table' in provided)
    for t in set(provided.get('source_table', list())) - set(inferred['source_tables']):
        if t in inferred['filter_tables']:
            warnings.append("Filtering/proxy source table in annotation: '{}'".format(t))
        else:
            warnings.append("Extra source table: '{}'".format(t))
    if not should_guess_all_tbls:
        if provided.get('table', 'X') != inferred.get('target_table', 'Y'):
            warnings.append("Target table mismatch: got '{}', inferred '{}'".format(provided.get('table'),
                                                                                    inferred.get('target_table')))
        for t in set(inferred['source_tables']) - set(provided.get('source_table', list())):
            warnings.append("Missing source table: '{}'".format(t))

    return warnings
