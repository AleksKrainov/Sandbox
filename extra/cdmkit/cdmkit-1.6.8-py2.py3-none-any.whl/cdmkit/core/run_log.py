import datetime
import operator


class RunningAction(object):
    def __init__(self, action, **kwargs):
        self.action = action
        self.args = dict(**kwargs)
        self.error = None

    def __enter__(self):
        self.started = datetime.datetime.now()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.finished = datetime.datetime.now()
        self.took = (self.finished - self.started).total_seconds()
        if exc_val:
            self.error = str(exc_val)

    def serialize(self):
        return {
            'action': self.action,
            'args': self.args,
            'started_at': str(self.started),
            'finished_at': str(self.finished),
            'duration_s': self.took,
            'error': self.error,
        }


class RunLog(object):
    def __init__(self):
        self.events = list()

    def running(self, action, **kwargs):
        current_action = RunningAction(action, **kwargs)
        self.events.append(current_action)
        return current_action

    def serialize(self):
        return [x.serialize() for x in sorted(self.events, key=operator.attrgetter("started"))]
