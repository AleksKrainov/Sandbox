import io
import json
import os
import re
from pathlib import Path

from cdmkit.core import configs, sql_datatypes
from cdmkit.core import exceptions as E
from cdmkit.core.sql_tools import strip_comments


class BaseConnection:
    """
    An interface for Connection classes.
    Inherit from it to create new type of database connection.
    """
    # TODO: organize these in some smarter way
    ddl_before_load = False
    ddl_declare_nullable = {True: 'NOT NULL', False: 'NULL'}
    ddl_external_tables = False
    quotes = '""'
    s3_location = ''
    default_storage_format = ''
    top_query = ''
    limit_query = 'LIMIT {num}'
    extract_year_query = 'YEAR({column})'
    count_not_zero_query = 'COUNT({column})>0'
    length_query = 'LENGTH({column})'
    dateadd_query = "DATEADD('{interval}', {increment}, {column})"
    substr_func = "SUBSTRING({column}, {start}, {length})"

    def select(self, query, **kwargs):
        raise NotImplementedError

    def select_dict(self, query):
        raise NotImplementedError

    def select_scalar(self, query, as_type=None):
        raise NotImplementedError

    def execute(self, *queries, **kwargs):
        raise NotImplementedError

    def close(self):
        raise NotImplementedError

    def create_schema(self, name, overwrite=False):
        """Create database schema.

        'schema' is mostly a PostgreSQL term, other DBMS use different
        names for the concept. Here, 'schema' is understood as a namespace
        which allows to organize DB objects into logical groups.

        Args:
            name (str): Schema name.
            overwrite (bool): If True, the schema is dropped with all objects before being created. Defaults to False.

        """
        pass

    def is_table_exists(self, schema, table):
        raise NotImplementedError

    def get_columns_list(self, schema, table, rule_id=None):
        raise NotImplementedError

    def get_table_list(self, schema):
        raise NotImplementedError

    def truncate_table(self, schema, table):
        raise NotImplementedError

    def drop_table(self, schema, table):
        raise NotImplementedError

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        raise NotImplementedError

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        raise NotImplementedError

    def server_version(self):
        raise NotImplementedError

    def quoted(self, x):
        if x is None:
            return ''
        return self.quotes[0] + x + self.quotes[1]

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        return sql_statement


class SparkConnection(BaseConnection):

    # spark_conf_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), '../conf/spark_settings.ini')
    spark_conf_file = os.path.join(os.environ["CDMKIT_HOME"], 'conf', 'spark_settings.ini')
    quotes = '``'

    def __init__(self, conn_details, **kwargs):
        from pyspark.sql import SparkSession
        from pyspark.conf import SparkConf

        job_name = kwargs.get('appname', 'unknown_job')
        appname = '{s}.{a}'.format(s=conn_details.get('schema'), a=job_name)
        settings = configs.SparkConfig(self.spark_conf_file, conn_details.get('config', None)).get_settings()
        spark_conf = SparkConf()
        spark_conf.setAll(settings)

        spark = SparkSession.builder.appName(appname).config(conf=spark_conf).enableHiveSupport().getOrCreate()
        self.conn = spark
        self.types = sql_datatypes.SparkDataTypes
        self.dialect = 'spark'

    def select(self, query, **kwargs):
        result_df = self.conn.sql(query)
        return result_df.toJSON()

    def select_dict(self, query):
        raise NotImplementedError

    def select_scalar(self, query, as_type=None):
        result = self.conn.sql(query).head()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        # Spark does not support transactions -> ignore kwarg
        for query in queries:
            self.conn.sql(query)

    def close(self):
        pass

    def create_schema(self, name, overwrite=False):
        if overwrite is True:
            self.conn.sql("DROP DATABASE IF EXISTS {} CASCADE".format(name))
            self.conn.sql("CREATE DATABASE " + name)
        else:
            self.conn.sql("CREATE DATABASE IF NOT EXISTS " + name)

    def is_table_exists(self, schema, table):
        raise NotImplementedError

    def get_columns_list(self, schema, table, rule_id=None):
        raise NotImplementedError

    def get_table_list(self, schema):
        table_df = self.conn.sql('SHOW TABLES IN {}'.format(schema)).select("tableName")
        return [x.tableName for x in table_df.collect()]

    def truncate_table(self, schema, table):
        raise NotImplementedError

    def drop_table(self, schema, table):
        raise NotImplementedError

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        raise NotImplementedError

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        raise NotImplementedError

    def server_version(self):
        return self.conn.version


class PostgreConnection(BaseConnection):
    quotes = '""'
    extract_year_query = 'EXTRACT(YEAR FROM {column})'
    dateadd_query = "{column} + INTERVAL '{increment} {interval}'"
    ddl_before_load = True

    def __init__(self, conn_details, **kwargs):
        import psycopg2
        self.conn = psycopg2.connect(
            host=conn_details["host"],
            port=conn_details["port"],
            dbname=conn_details["dbname"],
            user=conn_details["user"],
            password=conn_details["password"],
        )
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.PostgreSQLDataTypes
        db_version = self.server_version()
        is_legacy_pg = not("Redshift" in db_version or db_version.startswith("PostgreSQL 1"))
        if is_legacy_pg:
            self.types = sql_datatypes.LegacyPostgreSQLDataTypes
        self.dialect = 'postgres'

    def select(self, query, **kwargs):
        as_transaction = kwargs.get("as_transaction", True)
        # we might want to run queries like CREATE DATABASE or VACUUM outside a transaction
        if as_transaction is False:
            self.conn.autocommit = True
        cur = self.conn.cursor()
        try:
            cur.execute(query)
        except Exception as e:
            self.conn.rollback()
            self.conn.autocommit = False
            raise e
        result = cur.fetchall()
        cur.close()
        if as_transaction is True:
            self.conn.commit()
        else:
            # be polite and turn autocommit off again
            self.conn.autocommit = False
        return result

    def select_dict(self, query):
        import psycopg2.extras
        cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return [dict(x) for x in result]

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        as_transaction = kwargs.get("as_transaction", True)
        # we might want to run queries like CREATE DATABASE or VACUUM outside a transaction
        if as_transaction is False:
            self.conn.autocommit = True

        # execute a set of queries, commit at the end or rollback on exception
        for q in queries:
            try:
                self.cur.execute(q)
            except Exception as e:
                self.conn.rollback()
                self.conn.autocommit = False
                raise e
        if as_transaction is True:
            self.conn.commit()
        else:
            # be polite and turn autocommit off again
            self.conn.autocommit = False

    def close(self):
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        if overwrite is True:
            self.cur.execute("DROP SCHEMA IF EXISTS {} CASCADE".format(name))
            self.cur.execute("CREATE SCHEMA " + name)
        else:
            self.cur.execute("CREATE SCHEMA IF NOT EXISTS " + name)

    def is_table_exists(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("""SELECT EXISTS (
                        SELECT 1 FROM pg_catalog.pg_class c
                        JOIN   pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                        WHERE  n.nspname = '{schema}'
                        AND    c.relname = '{table}'
                     ) as is_exists""".format(schema=schema, table=table))
        result = cur.fetchone()[0]
        cur.close()
        return result

    def get_columns_list(self, schema, table, rule_id=None):
        q = """
                SELECT DISTINCT attname AS name, format_type(atttypid, atttypmod) AS type, attnum
                 FROM pg_attribute
                 WHERE attrelid = '{schema}.{table}'::regclass
                 AND attnum > 0 ORDER BY attnum
            """.format(schema=schema, table=table)
        with self.conn.cursor() as cur:
            cur.execute(q)
            res_rows = cur.fetchall()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        cur = self.conn.cursor()
        cur.execute("""SELECT c.relname AS table_name FROM pg_catalog.pg_class c
                        JOIN   pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                        WHERE  n.nspname = '{schema}'""".format(schema=schema))
        result = cur.fetchall()
        cur.close()
        return [res[0].lower() for res in result]

    def truncate_table(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("TRUNCATE TABLE {schema}.{table}".format(schema=schema, table=table))
        cur.close()

    def drop_table(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("DROP TABLE IF EXISTS {schema}.{table}".format(schema=schema, table=table))
        cur.close()

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        """
         Load file to database table.

         Args:
             s3_key: S3 lookup key (=mask). Ex: 's3n://dataset_1/source_data/patients.'
             schema_name: source_schema specified in etlconf
             table_name: table name
             fields: 'fields' from source_data.conf
             sep: separator character
             header (bool): ignore first row as header
             dateformat: date formatting string. Ex. 'MM/DD/YYYY' -> '01/30/2012'
                 (see http://docs.aws.amazon.com/redshift/latest/dg/r_DATEFORMAT_and_TIMEFORMAT_strings.html)
             timeformat: timestamp formatting string. Ex. 'MM.DD.YYYY HH:MI:SS' -> '03.31.2003 10:26:01'
             compression: one of ["bzip2", "gzip", "lzop"]
             encoding: one of ["utf8", "utf16", "utf16le", "utf16be"]
             invalid_char: single ASCII char to replace non-valid chars
             blank_as_null: use 'BLANKASNULL' param (bool)
             empty_as_null: use 'EMPTYASNULL' param (bool)
             ignore_blank: use 'IGNOREBLANKLINES' param (bool)
             remove_quotes: use 'REMOVEQUOTES' param (bool)
             trim_blanks: use 'TRIMBLANKS' param (bool)
             generate_util_cols (bool): populate utility fields. Defaults to False.

         Raises:
             Exception if load process has failed
         """
        delimiter = "\n    DELIMITER '{}'".format(sep)
        additionals = list()
        if header:
            additionals.append("HEADER".format(header))
        if encoding:
            additionals.append("ENCODING '{}'".format(encoding.upper()))
        if quote_char:
            additionals.append("QUOTE '{}'".format(quote_char))
        if escape_char:
            additionals.append("ESCAPE '{}'".format(escape_char))
        if empty_as_null:
            additionals.append("FORCE_NULL ({fields})".format(
                fields=',\n    '.join([self.quoted(f['field']) for f in fields])
            ))

        if timeformat:
            re_timeformmat = re.search('^([yMd\-\/\.]+)([T ]+HH:mm:ss(\.SSS)?)?$', timeformat) or re.search('^([yMd\-\/\.]+)([T ]+HHmmss(\.SSS)?)?$', timeformat)
            if re_timeformmat:
                date_from_timeformat = re_timeformmat.group(1)
                if dateformat and dateformat != date_from_timeformat:
                    raise E.JobExecException("Postgres doesn't support different formats for date and timestamp")
                elif not dateformat:
                    dateformat = date_from_timeformat
            else:
                raise E.JobExecException("Not supported timeformat '{}'".format(timeformat))

        if dateformat:
            if dateformat in ['yyyyMMdd', 'yyyy-MM-dd', 'yyyy.MM.dd', 'yyyy/MM/dd']:
                self.execute("SET DATESTYLE TO 'ISO, YMD';")
            elif dateformat in ['MM-dd-yyyy', 'MM.dd.yyyy', 'MM/dd/yyyy']:
                self.execute("SET DATESTYLE TO 'ISO, MDY';")
            elif dateformat in ['dd-MM-yyyy', 'dd.MM.yyyy', 'dd/MM/yyyy']:
                self.execute("SET DATESTYLE TO 'ISO, DMY';")
            else:
                raise E.JobExecException("Not supported dateformat '{}'".format(dateformat))

        self.execute("TRUNCATE TABLE {schema}.{table};".format(schema=schema_name, table=table_name))
        if generate_util_cols:
            self.execute(*self._set_util_fields_defaults(schema_name, table_name))

        copy_query = """COPY {schema}.{table} ({fields}) FROM STDIN
                        WITH (FORMAT CSV, {delimiter}, {additionals});""".format(
            schema=schema_name, table=table_name,
            fields=',\n    '.join([self.quoted(f['field']) for f in fields]),
            file=file, delimiter=delimiter,
            additionals=', '.join(additionals)
        )
        with self.conn.cursor() as cur:
            with open(file, 'r', encoding=encoding or 'utf-8') as in_file:
                cur.copy_expert(sql=copy_query, file=in_file)

        self.execute("ANALYZE {schema}.{table};".format(schema=schema_name, table=table_name))
        if generate_util_cols:
            self.execute(*self._unset_util_fields_defaults(schema_name, table_name))

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        delim = ", DELIMITER E'{}',".format(delimiter)
        additionals = list()
        if header:
            additionals.append("HEADER")
        if quote:
            additionals.append("QUOTE '{}'".format(quote))
        if quote_all:
            additionals.append("FORCE_QUOTE *")
        if escape:
            additionals.append("ESCAPE '{}'".format(escape))

        cols = '*'
        if exclude_columns:
            cols = [self.quoted(col['name'])
                    for col in self.get_columns_list(schema, table_name)
                    if col['name'] not in exclude_columns]

        self.execute("SET DATESTYLE TO 'ISO, YMD'")
        copy_query = """COPY (SELECT {cols} FROM {schema}.{table})\n
                        TO STDOUT\n(FORMAT CSV {delimiter} {additionals})""".format(
                cols=', '.join(cols),
                schema=schema, table=table_name,
                file=path, delimiter=delim,
                additionals=', '.join(additionals)
        )

        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        except PermissionError as e:
            raise E.JobExecException("Table unload failed", cause=e)

        with self.conn.cursor() as cur:
            with open(path, 'w', encoding='utf8') as out_file:
                cur.copy_expert(sql=copy_query, file=out_file)

    def server_version(self):
        self.cur.execute("SELECT version()")
        return self.cur.fetchone()[0]

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        # sql_statement = re.sub("@IDENTITY\s+(AS [a-z_]+\s?)?,", "", sql_statement, 0, re.I)
        return sql_statement

    def _get_table_column_with_identity(self, schema, table):
        columns = self.select("""
        select column_name,
               case
                    when is_identity = 'YES' then 1  -- v10+
                    else 0
               end      as identity_list
          from information_schema.columns
         where table_schema = '{}' and table_name = '{}'
         order by ordinal_position
        """.format(schema, table))
        # https://stackoverflow.com/a/20880247
        should_be_quoted = lambda x: not (x.isascii() and x.islower())
        return [
            (self.quoted(column_name) if should_be_quoted(column_name) else column_name, is_identity)
            for column_name, is_identity in columns
        ]

    @staticmethod
    def _set_util_fields_defaults(schema_name, table_name):
        """Generate SQL to set default values for utility fields during data load."""
        qs = (
            "ALTER TABLE {schema}.{table} ALTER COLUMN load_table_id SET DEFAULT '{table}'",
            "DROP SEQUENCE IF EXISTS {schema}.{table}__load_row_id_seq",
            "CREATE SEQUENCE {schema}.{table}__load_row_id_seq",
            "ALTER TABLE {schema}.{table} ALTER COLUMN load_row_id SET DEFAULT nextval('{schema}.{table}__load_row_id_seq')"
        )
        return [q.format(schema=schema_name, table=table_name) for q in qs]

    @staticmethod
    def _unset_util_fields_defaults(schema_name, table_name):
        """Generate SQL to drop default values for utility fields during data load."""
        qs = (
            "ALTER TABLE {schema}.{table} ALTER COLUMN load_table_id DROP DEFAULT",
            "ALTER TABLE {schema}.{table} ALTER COLUMN load_row_id DROP DEFAULT",
            "DROP SEQUENCE IF EXISTS {schema}.{table}__load_row_id_seq"
        )
        return [q.format(schema=schema_name, table=table_name) for q in qs]


class RedshiftConnection(PostgreConnection):

    def __init__(self, conn_details, **kwargs):
        aws_keys = {
            'aws_access_key_id': conn_details.pop('aws_access_key_id', '<missing>'),
            'aws_secret_access_key': conn_details.pop('aws_secret_access_key', '<missing>'),
        }
        super(RedshiftConnection, self).__init__(conn_details)
        self.dialect = "redshift"
        self.keys = aws_keys

    def get_columns_list(self, schema, table, rule_id=None):
        # svv_columns covers both managed and external tbls
        q = """
            SELECT column_name, data_type, ordinal_position
            FROM svv_columns
            WHERE table_schema = %(schema)s AND table_name = %(table)s
            ORDER BY ordinal_position ASC
            """
        with self.conn.cursor() as cur:
            cur.execute(q, {"schema": schema, "table": table})
            res_rows = cur.fetchall()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        q = """
            SELECT a.table_name
            FROM svv_all_tables a
            WHERE a.schema_name = %(schema)s
            """
        with self.conn.cursor() as cur:
            cur.execute(q, {"schema": schema})
            res_rows = cur.fetchall()
        return [row[0].lower() for row in res_rows]

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        """
         Load file to database table.

         Args:
             s3_key: S3 lookup key (=mask). Ex: 's3n://dataset_1/source_data/patients.'
             schema_name: source_schema specified in etlconf
             table_name: table name
             fields: 'fields' from source_data.conf
             sep: separator character
             header (bool): ignore first row as header
             dateformat: date formatting string. Ex. 'MM/DD/YYYY' -> '01/30/2012'
                 (see http://docs.aws.amazon.com/redshift/latest/dg/r_DATEFORMAT_and_TIMEFORMAT_strings.html)
             timeformat: timestamp formatting string. Ex. 'MM.DD.YYYY HH:MI:SS' -> '03.31.2003 10:26:01'
             compression: one of ["bzip2", "gzip", "lzop"]
             encoding: one of ["utf8", "utf16", "utf16le", "utf16be"]
             invalid_char: single ASCII char to replace non-valid chars
             blank_as_null: use 'BLANKASNULL' param (bool)
             empty_as_null: use 'EMPTYASNULL' param (bool)
             ignore_blank: use 'IGNOREBLANKLINES' param (bool)
             remove_quotes: use 'REMOVEQUOTES' param (bool)
             trim_blanks: use 'TRIMBLANKS' param (bool)
             generate_util_cols (bool): populate utility fields. Defaults to False.

         Raises:
             Exception if load process has failed
         """
        s3_part = "'{s3_key}'\n CREDENTIALS 'aws_access_key_id={s3_access};aws_secret_access_key={s3_secret}'".format(
                    s3_key=file, s3_access=self.keys['aws_access_key_id'], s3_secret=self.keys['aws_secret_access_key'])
        delimiter = "\n    DELIMITER '{}'".format(sep)
        additionals = list()
        if header:
            additionals.append("IGNOREHEADER 1")
        if dateformat:
            additionals.append("DATEFORMAT '{}'".format(dateformat))
        else:
            additionals.append("DATEFORMAT 'auto'")
        if timeformat:
            additionals.append("TIMEFORMAT '{}'".format(timeformat))
        if compression:
            additionals.append(compression.upper())
        if encoding:
            additionals.append("ENCODING '{}'".format(encoding.upper()))
        if invalid_char:
            additionals.append("ACCEPTINVCHARS '{}'".format(invalid_char.upper()))
        if blank_as_null:
            additionals.append("BLANKASNULL")
        if empty_as_null:
            additionals.append("EMPTYASNULL")
        if ignore_blank:
            additionals.append("IGNOREBLANKLINES")
        if remove_quotes:
            additionals.append("REMOVEQUOTES")
        if trim_blanks:
            additionals.append("TRIMBLANKS")

        query_lst = []

        fields = ',\n    '.join([f['field'] for f in fields])
        query_lst.append("TRUNCATE TABLE {schema}.{table};".format(schema=schema_name, table=table_name))
        query_lst.append(
            "COPY {schema}.{table}\n(\n    {fields}\n)\nFROM {s3_part}{delimiter}\n{additionals}\nCOMPUPDATE ON\n;".format(
                schema=schema_name, table=table_name,
                fields=fields, s3_part=s3_part, delimiter=delimiter,
                additionals='\n'.join(additionals)
            )
        )
        query_lst.append("ANALYZE {schema}.{table};".format(schema=schema_name, table=table_name))

        self.execute(*query_lst)

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        """
        Unload data from database table to Amazon S3.

        Args:
            table_name: table name
            s3_file: S3 file key.
            delimiter: separator character
            files_number: <int> n - DEPRECATED
            exclude_columns: <list[str]> - list of column names
            compression: one of ["bzip2", "gzip"]
            add_quotes: use 'ADDQUOTES' param (bool)
            allow_overwrite: use 'ALLOWOVERWRITE' param (bool)
            parallel: set 'PARALLEL ON' (bool)
            max_file_size: default is 6.2 GB.
                (see docs.aws.amazon.com/redshift/latest/dg/r_UNLOAD.html)

        Raises:
            JobExecException: if unload process has failed
        """
        # construct unload statement
        unload_fields = list(filter(
            lambda x: x['name'] not in (exclude_columns or list()),
            self.get_columns_list(schema, table_name)))
        fields = ',\n    '.join([f['name'] for f in unload_fields])
        select = "SELECT\n    {fields}\nFROM\n    {schema}.{table}".format(fields=fields,
                                                                           schema=schema,
                                                                           table=table_name)
        delimiter = "\n    DELIMITER '{}'".format(delimiter)
        s3_part = "'{s3_key}'\n CREDENTIALS 'aws_access_key_id={s3_access};aws_secret_access_key={s3_secret}'".format(
                  s3_key=path, s3_access=self.keys['aws_access_key_id'], s3_secret=self.keys['aws_secret_access_key'])
        additionals = list()

        if compression:
            additionals.append(compression.upper())
        if add_quotes:
            additionals.append("ADDQUOTES")
        if allow_overwrite:
            additionals.append("ALLOWOVERWRITE")
        if parallel is False:
            additionals.append("PARALLEL OFF")
        if max_file_size:
            additionals.append("MAXFILESIZE {}".format(max_file_size.upper()))
        query = "UNLOAD \n('\n    {select}\n')\nTO {s3_part}{delimiter}\n    {additionals}\n;".format(
                select=select, s3_part=s3_part, delimiter=delimiter, additionals='\n    '.join(additionals))
        # execute
        self.execute(query)

    def _get_table_column_with_identity(self, schema, table):
        # based on RedshiftDatabaseMetaData.java (https://github.com/aws/amazon-redshift-jdbc-driver)
        columns = self.select("""
        SELECT
            column_name,
            CASE
                WHEN left(column_default, 16) = 'default_identity' THEN 1
                WHEN left(column_default, 10) = '"identity"' THEN 1
                ELSE 0
            END AS is_identity
        FROM svv_columns
        WHERE table_schema = '{}' and table_name = '{}'
        ORDER BY ordinal_position
        """.format(schema, table))
        return columns


class AthenaConnection(BaseConnection):
    ddl_declare_nullable = {True: '', False: ''}
    ddl_external_tables = True
    # quotes = '""'
    s3_location = "LOCATION '{s3}/{schema}/{table}'"
    default_storage_format = 'PARQUET'
    dateadd_query = "DATE_ADD('{interval}', {increment}, {column})"

    def __init__(self, conn_details, **kwargs):
        import pyathena
        import boto3
        self.s3 = boto3.resource('s3',
                                 aws_access_key_id=conn_details['aws_access_key_id'],
                                 aws_secret_access_key=conn_details['aws_secret_access_key'])
        self.conn = pyathena.connect(**conn_details)
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.AthenaDataTypes
        self.dialect = 'athena'
        self.keys = {
            'aws_access_key_id': conn_details['aws_access_key_id'],
            'aws_secret_access_key': conn_details['aws_secret_access_key'],
        }

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_dict(self, query):
        import pyathena.cursor
        cur = self.conn.cursor(cursor=pyathena.cursor.DictCursor)
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return [dict(x) for x in result]

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        physical_removal = kwargs.get("physical_removal", True)

        for q in queries:
            try:
                query_cleans_data = re.search(
                    r"^((drop|truncate)\s+table\s+)(if\s+exists\s+)?([a-z_0-9\"`]+)[.]([a-z_0-9\"`]+)",
                    strip_comments(q.lower())
                )
                if query_cleans_data and physical_removal:
                    schema, table = query_cleans_data.group(4), query_cleans_data.group(5)
                    if query_cleans_data.group(1).lower().startswith('drop'):
                        self.drop_table(schema, table)
                    elif query_cleans_data.group(1).lower().startswith('truncate'):
                        self.truncate_table(schema, table)
                else:
                    self.cur.execute(q)
            except Exception as e:
                raise e

    def close(self):
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        if overwrite:
            self.cur.execute("DROP DATABASE IF EXISTS {} CASCADE".format(name))
            self.cur.execute("CREATE DATABASE " + name)
        else:
            self.cur.execute("CREATE DATABASE IF NOT EXISTS " + name)

    def is_table_exists(self, schema, table):
        with self.conn.cursor() as cur:
            cur.execute("""SELECT EXISTS (
                            SELECT 1 FROM information_schema.tables c
                            WHERE  table_schema = '{schema}'
                            AND    table_name  = '{table}'
                        ) as is_exists""".format(schema=schema, table=table))

            result = cur.fetchone()[0]
        return result

    def get_columns_list(self, schema, table, rule_id=None):
        q = """
                SELECT DISTINCT column_name AS name, data_type AS type, ordinal_position AS attnum
                FROM information_schema.columns
                WHERE table_schema = '{schema}' AND table_name = '{table}'
                ORDER BY ordinal_position
            """.format(schema=schema, table=table)
        with self.conn.cursor() as cur:
            cur.execute(q)
            res_rows = cur.fetchall()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        cur = self.conn.cursor()
        cur.execute("""SELECT table_name FROM information_schema.tables
                        WHERE  table_schema = '{schema}'""".format(schema=schema))
        result = cur.fetchall()
        cur.close()
        return [res[0].lower() for res in result]

    def truncate_table(self, schema, table):
        if self.is_table_exists(schema, table):
            path = self._get_table_location(schema, table)
            self._clean_s3_data(path)

    def drop_table(self, schema, table):
        if self.is_table_exists(schema, table):
            path = self._get_table_location(schema, table)
            self._clean_s3_data(path)
            cur = self.conn.cursor()
            cur.execute("DROP TABLE IF EXISTS {schema}.{table}".format(schema=schema, table=table))
            cur.close()

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        """
        Load file to database table. Steps:
            1. Upload the local file to S3 if necessary
            2. Create tmp table on top of the loaded file
            3. Create target table using Parquet format
            4. Drop tmp table (keep the original file if the the source is from s3)

        Args:
            s3_path: Path on s3 where file is placed
            schema_name: source_schema specified in etlconf
            table_name: table name
            fields: 'fields' from source_data.conf
            sep: separator character
            header: <bool> - ignore first row as headers
            timeformat: timestamp formatting string. Ex. 'MM.DD.YYYY HH:MI:SS' -> '03.31.2003 10:26:01'
            dateformat: date formatting string. Ex. '%m/%d/%Y' -> '01/30/2012'
            blank_as_null: use 'BLANKASNULL' param (bool)
            generate_util_cols (bool): populate utility fields. Defaults to False.
        Raises:
            Exception if load process has failed
        """
        if re.match(r'((^file:///.*)|(^[a-zA-Z]:\\.*)|(^/))', file):  # anyone still using drive A:, we've got you covered
            file = self._load_local_file_to_s3(file, data_location)
            drop_tmp_file = True
        else:
            drop_tmp_file = False

        columns = []
        for f in fields:
            field_type = self.types.DATA_TYPES[f['type']]['t']
            # changing time/date format is a very questionable decision
            # TODO: rethink this
            if field_type == 'timestamp':
                field_format = timeformat.replace('yyyy', '%Y').replace('MM', '%m')\
                                         .replace('dd', '%d') if '%' not in timeformat else timeformat
            elif field_type == 'date':
                field_format = dateformat.replace('yyyy', '%Y').replace('MM', '%m')\
                                         .replace('dd', '%d') if '%' not in dateformat else dateformat
            elif field_type == 'string':
                field_type = 'varchar'  # Non-string data types cannot be cast to string in Athena

            if field_type in ('timestamp', 'date'):
                columns.append(
                    "CAST(date_parse(NULLIF(\"{field}\", ''), '{field_format}') AS {type}) AS \"{field}\""
                    .format(field=f['field'], field_format=field_format, type=field_type)
                )
            else:
                columns.append(
                    "CAST(NULLIF(\"{field}\", '') AS {type}) AS \"{field}\"".format(field=f['field'], type=field_type)
                )

        # Temporary table is created over file for loading. So that the file mustn't be dropped.
        drop_tmp_stm = 'DROP TABLE IF EXISTS {schema}.tmp_{table_name}'.format(schema=schema_name, table_name=table_name)
        self.execute(drop_tmp_stm, physical_removal=False)

        queries_to_run = [
            """
                CREATE EXTERNAL TABLE {schema}.tmp_{table_name} (
                   {fields}
                )
                ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
                WITH SERDEPROPERTIES (
                  'separatorChar' = '{sep}'
                  {header}
                )
                LOCATION '{s3}'
            """.format(
                schema=schema_name,
                table_name=table_name,
                fields=',\n   '.join([f['field'] + ' string' for f in fields]),
                sep=sep,
                s3=file,
                header=',"skip.header.line.count"="1"' if header else ''
            ),
            """
                DROP TABLE IF EXISTS {schema}.{table_name}
            """.format(schema=schema_name, table_name=table_name),
            """
                CREATE TABLE {schema}.{table_name} WITH (format='PARQUET', external_location='{location}') AS
                SELECT
                    {fields},
                    '{table_name}'          AS load_table_id,
                    ROW_NUMBER() OVER()     AS load_row_id
                FROM {schema}.tmp_{table_name}
            """.format(
                schema=schema_name,
                table_name=table_name,
                fields=',\n   '.join(columns),
                location="{}/{}/{}".format(data_location, schema_name, table_name)
            )
        ]

        self.execute(*queries_to_run)
        self.execute(drop_tmp_stm, physical_removal=drop_tmp_file)

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        self._clean_s3_data(path + '/*')
        file_format = 'TEXTFILE' if target_format.upper() == 'CSV' else target_format.upper()

        if file_format.upper() != 'TEXTFILE':
            # Using Athena UNLOAD query to unload Parquet/ORC/Avro files
            unload_fields = ['"' + field['name'] + '"' for field in filter(
                lambda x: x['name'] not in exclude_columns,
                self.get_columns_list(schema, table_name))]

            unload_query = """
                              UNLOAD (SELECT {unload_fields} FROM {schema}.{table})
                              TO '{location}'
                              WITH ({properties})
                           """
            properties = ["format='{}'".format(file_format)]
            if compression:
                properties.append("compression='{}'".format(compression))

            self.execute(unload_query.format(
                unload_fields=', '.join(unload_fields),
                schema=schema,
                table=table_name,
                location=path,
                properties=', '.join(properties)
            ))
        else:
            # Athena's native CSV unload is extremely limited.
            # Using Pandas to preserve my sanity.
            from csv import QUOTE_MINIMAL, QUOTE_ALL
            from pyathena.pandas.cursor import PandasCursor

            output_location = path + '/' + path.split('/')[-1] + '.csv'
            if compression == 'gzip':
                output_location += '.gz'
            elif compression is not None:
                output_location += '.' + compression
            quoting = QUOTE_ALL if quote_all else QUOTE_MINIMAL

            cur = self.conn.cursor(cursor=PandasCursor)
            df = cur.execute("SELECT * FROM {schema}.{table}".format(schema=schema, table=table_name)).as_pandas()
            df = df[df.columns[~df.columns.isin(exclude_columns)]]
            df.to_csv(output_location, index=False, header=header, sep=delimiter, compression=compression,
                      date_format=date_format, quoting=quoting, quotechar=quote, escapechar=escape, na_rep=null_value,
                      storage_options={
                          'key': self.keys['aws_access_key_id'],
                          'secret': self.keys['aws_secret_access_key'],
                      })

    def server_version(self):
        # Athena doesn't expose its version through SQL, only for workgroups.
        # Presto/Trino version can be retrieved using:
        #   SELECT node_version FROM system.runtime.nodes
        # but it raises 'Queries of this type are not supported' in Athena.
        return ''

    def quoted(self, x):
        return x

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        sql_statement = sql_statement.replace("@IDENTITY", "ROW_NUMBER() OVER()")

        # Add explicit S3 location to CREATE TABLE statement if it doesn't have it
        ddl_statement = re.match(r'CREATE TABLE (@?[a-zA-Z_0-9]+.[a-zA-Z_0-9]+)\s*\n?\((.*?)\)',
                                 sql_statement, re.DOTALL)
        if not ddl_statement or re.search(r'[LOCATION|location]\s+[\'|\"][\S]+[\'|\"]', sql_statement):
            return sql_statement
        schema, table = ddl_statement.group(1).split('.')
        return "{}\nLOCATION '{}/{}/{}/'".format(sql_statement, etl_conf.db['data_location'], schema, table)

    def _clean_s3_data(self, path):
        if path:
            path_search = re.search('s3://([a-z\d.-]+)/(.*/)', path)
            bucket = self.s3.Bucket(path_search.group(1))
            bucket.objects.filter(Prefix=path_search.group(2)).delete()

    def _move_object(self, src_bucket, src_path, object_name):
        bucket = self.s3.Bucket(src_bucket)

        for obj in bucket.objects.filter(Prefix=src_path):
            source = {
                "Bucket": src_bucket,
                "Key": obj.key
            }
            self.s3.meta.client.copy(source, src_bucket, object_name)

            self._clean_s3_data("s3://{}/{}".format(src_bucket, src_path))

    def _create_folder(self, path, folder_name):
        dist_path = "{path}/{folder}".format(path=path, folder=folder_name)

        key = self.s3.get_key(dist_path)
        if key is None:
            self.s3.new_key(key)

    def _get_table_location(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("""SELECT DISTINCT REGEXP_EXTRACT(\"$path\", 's3://(.*\/)+') AS loc
                        FROM {schema}.{table}""".format(schema=schema, table=table))
        result = cur.fetchone()
        cur.close()
        if result:
            return result[0]

    def _load_local_file_to_s3(self, file_path, data_location):
        if not data_location.endswith('/'):
            data_location += '/'
        s3_path = "{}tmp_load/{}".format(data_location,
                                          re.search(".*(\\\\|/)([a-zA-Z_0-9.-]+[.][a-zA-Z]+)", file_path).group(2))

        self._upload_file_to_s3(file_path, s3_path)

        return "{}tmp_load/".format(data_location)

    def _upload_file_to_s3(self, file_path, s3_path):
        path_search = re.search('s3://([a-z\d.-]+)/(.*)', s3_path)
        file_path = re.search("((file://)|([A-Z]:))(((/[^/])+)|((\\\[^\\\]+)+))", file_path).group(0)
        bucket = self.s3.Bucket(path_search.group(1))
        bucket.upload_file(file_path, path_search.group(2))


class SQLServerConnection(BaseConnection):
    ddl_before_load = True
    quotes = '""'
    top_query = 'TOP {num}'
    limit_query = ''
    extract_year_query = 'DATEPART(year, {column})'
    count_not_zero_query = 'IIF(COUNT({column})>0, 1, 0)'
    length_query = 'DATALENGTH({column})'
    dateadd_query = "DATEADD({interval}, {increment}, {column})"

    def __init__(self, conn_details, **kwargs):
        import pyodbc
        conn_string = 'Driver={{{driver}}};Server={host};'\
                      'Database={database};Trusted_Connection=yes;'.format(driver=conn_details['driver'],
                                                                           host=conn_details['host'],
                                                                           database=conn_details['dbname'])
        if conn_details.get('user'):
            conn_string += 'UID={user};'.format(user=conn_details.get('user'))
        if conn_details.get('password'):
            conn_string += 'PWD={pwd};'.format(pwd=conn_details.get('password'))
        self.conn = pyodbc.connect(conn_string)
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.SqlServerDataTypes
        self.dialect = 'sqlserver'

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_dict(self, query):
        cur = self.conn.cursor()
        cur.execute(query)
        result = [{d[0]: v for (d, v) in zip(row.cursor_description, row)} for row in cur.fetchall()]
        return result

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        as_transaction = kwargs.get("as_transaction", True)
        # we might want to run queries like CREATE DATABASE or VACUUM outside a transaction
        if as_transaction is False:
            self.conn.autocommit = True

        # execute a set of queries, commit at the end or rollback on exception
        for q in queries:
            try:
                self.cur.execute(q)
            except Exception as e:
                self.conn.rollback()
                self.conn.autocommit = False
                raise e
        if as_transaction is True:
            self.conn.commit()
        else:
            # be polite and turn autocommit off again
            self.conn.autocommit = False

    def close(self):
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        if overwrite is True:
            self.cur.execute("IF EXISTS (SELECT * FROM sys.schemas WHERE name = '{name}') "
                             "EXEC('DROP SCHEMA {name} CASCADE')".format(name=name))
            self.cur.execute("CREATE SCHEMA " + name)
        else:
            self.cur.execute("IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = '{name}') "
                             "EXEC('CREATE SCHEMA {name}')".format(name=name))

    def is_table_exists(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("""SELECT EXISTS (
                        SELECT 1 FROM sys.tables t
                        WHERE  schema_name(t.schema_id) = '{schema}'
                        AND    t.table_name = '{table}'
                     ) as is_exists""".format(schema=schema, table=table))
        result = cur.fetchone()[0]
        cur.close()
        return result

    def get_columns_list(self, schema, table, rule_id=None):
        q = """
            SELECT COLUMN_NAME, DATA_TYPE, ORDINAL_POSITION
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table}'
            ORDER BY 3
            """.format(schema=schema, table=table)
        with self.conn.cursor() as cur:
            cur.execute(q)
            res_rows = cur.fetchall()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        cur = self.conn.cursor()
        cur.execute("""SELECT t.name as table_name
                    FROM sys.tables t
                    WHERE schema_name(t.schema_id) = '{schema}'""".format(schema=schema))
        result = cur.fetchall()
        cur.close()
        return [res[0].lower() for res in result]

    def truncate_table(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("TRUNCATE TABLE {schema}.{table}".format(schema=schema, table=table))
        cur.close()

    def drop_table(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("DROP TABLE IF EXISTS {schema}.{table}".format(schema=schema, table=table))
        cur.close()

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        """
         Load file to database table.

         Args:
             file: path to local file
             schema_name: source_schema specified in etlconf
             table_name: table name
             fields: 'fields' from source_data.conf
             sep: separator character
             header: <int> n - ignore first n rows as headers
             dateformat: date formatting string. Ex. 'MM/DD/YYYY' -> '01/30/2012'
             timeformat: timestamp formatting string. Ex. 'MM.DD.YYYY HH:MI:SS' -> '03.31.2003 10:26:01'
             compression: one of ["bzip2", "gzip", "lzop"]
             encoding: one of ["utf8", "utf16", "utf16le", "utf16be"]
             invalid_char: single ASCII char to replace non-valid chars
             blank_as_null: use 'BLANKASNULL' param (bool)
             empty_as_null: use 'EMPTYASNULL' param (bool)
             ignore_blank: use 'IGNOREBLANKLINES' param (bool)
             remove_quotes: use 'REMOVEQUOTES' param (bool)
             trim_blanks: use 'TRIMBLANKS' param (bool)
             generate_util_cols (bool): populate utility fields. Defaults to False.

         Raises:
             Exception if load process has failed
         """
        additionals = [
            "DATAFILETYPE = 'char'",
            "FORMAT = 'CSV'",
            "FIELDTERMINATOR = '{}'".format(sep),
            "ROWTERMINATOR = '\n'",
            "TABLOCK"
        ]
        if header:
            additionals.append("FIRSTROW = {}".format(header + 1))
        if empty_as_null:
            additionals.append("KEEPNULLS")
        if quote_char:
            additionals.append("FIELDQUOTE = '{}'".format(quote_char))

        query_lst = []

        if dateformat:
            query_lst.append("SET DATEFORMAT {}".format(dateformat))

        query_lst.append("TRUNCATE TABLE {schema}.{table}".format(schema=schema_name, table=table_name))
        query_lst.append(
            "BULK INSERT {schema}.{table}\n"
            "FROM '{data_file}'\n"
            "WITH ({additionals})".format(schema=schema_name, table=table_name,
                                          data_file=file, additionals=', '.join(additionals))
        )

        self.execute(*query_lst)

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        if target_format.upper() != 'CSV':
            # TODO: support other formats maybe?
            raise NotImplementedError
        else:
            from csv import QUOTE_MINIMAL, QUOTE_ALL
            from pandas import read_sql_query

            os.makedirs(path, exist_ok=True)
            output_location = path + '/' + path.split('/')[-1] + '.csv'
            if compression == 'gzip':
                output_location += '.gz'
            elif compression is not None:
                output_location += '.' + compression
            quoting = QUOTE_ALL if quote_all else QUOTE_MINIMAL

            df = read_sql_query("SELECT * FROM {schema}.{table}".format(schema=schema, table=table_name), self.conn)
            df = df[df.columns[~df.columns.isin(exclude_columns)]]
            df.to_csv(output_location, index=False, header=header, sep=delimiter, compression=compression,
                      date_format=date_format, quoting=quoting, quotechar=quote, escapechar=escape, na_rep=null_value)

    def server_version(self):
        self.cur.execute("SELECT @@VERSION")
        return self.cur.fetchone()[0]

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        sql_statement = re.sub("@IDENTITY\s+(AS [a-z_]+\s?)?,", "", sql_statement, 0, re.I)

        # Turn `CREATE TABLE AS` statement into `SELECT cols INTO table` format
        ctas_statement = re.match(r'(CREATE TABLE\s+(@?[a-zA-Z_0-9]+.[a-zA-Z_0-9]+)\s*\n?(.*?))SELECT(.*?)FROM\s',
                                  sql_statement, re.DOTALL)
        if not ctas_statement:
            return sql_statement

        return sql_statement.replace(ctas_statement.group(1), '')\
                            .replace(ctas_statement.group(4),
                                     ctas_statement.group(4) + 'INTO ' + ctas_statement.group(2) + '\n', 1)


class BigQueryConnection(BaseConnection):
    quotes = '``'
    ddl_declare_nullable = {True: 'NOT NULL', False: ''}
    extract_year_query = 'EXTRACT(YEAR FROM {column})'


    def __init__(self, conn_details, **kwargs):
        from google.cloud import bigquery
        from google.cloud.bigquery import dbapi
        if conn_details.get('credentials_file'):
            # Use provided service account credentials
            from google.oauth2 import service_account
            self.credentials = service_account.Credentials.from_service_account_file(conn_details.get('credentials_file'))
        else:
            # Use application default credentials
            self.credentials = None
        self._client = bigquery.Client(credentials=self.credentials)
        self.conn = dbapi.Connection(self._client)
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.BigQueryDataTypes
        self.dialect = 'bigquery'

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_dict(self, query):
        # DB API cursor has no description/DictCursor
        # hope that Client.query() is a valid replacement
        rows = self._client.query(query).result()
        return [dict(x) for x in rows]

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        cur = self.conn.cursor()
        for q in queries:
            cur.execute(q)
        cur.close()

    def close(self):
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        cur = self.conn.cursor()
        if overwrite is True:
            cur.execute("DROP SCHEMA IF EXISTS {name} CASCADE".format(name=name))
            cur.execute("CREATE SCHEMA " + name)
        else:
            cur.execute("CREATE SCHEMA IF NOT EXISTS {name}".format(name=name))
        cur.close()

    def is_table_exists(self, schema, table):
        return table.lower() in self.get_table_list(schema)

    def get_columns_list(self, schema, table, rule_id=None):
        q = """
            SELECT COLUMN_NAME, DATA_TYPE, ORDINAL_POSITION
            FROM {schema}.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = '{table}'
            ORDER BY 3
            """.format(schema=schema, table=table)
        cur = self.conn.cursor()
        cur.execute(q)
        res_rows = cur.fetchall()
        cur.close()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        cur = self.conn.cursor()
        cur.execute("""SELECT table_name FROM {schema}.INFORMATION_SCHEMA.TABLES""".format(schema=schema))
        result = cur.fetchall()
        cur.close()
        return [res[0].lower() for res in result]

    def truncate_table(self, schema, table):
        if self.is_table_exists(schema, table):
            self.execute("TRUNCATE TABLE {s}.{t}".format(s=schema, t=table))

    def drop_table(self, schema, table):
        self.execute("DROP TABLE IF EXISTS {s}.{t}".format(s=schema, t=table))

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        import pandas as pd
        header_rows = 0 if header else None
        quoting = 0 if remove_quotes else 3
        types = {'string': 'str', 'concept_id': 'Int64', 'int': 'Int64', 'double': 'float', 'bool': 'bool'}
        df = pd.read_csv(file, sep=sep, header=header_rows, quoting=quoting, quotechar=quote_char,
                         escapechar=escape_char, encoding=encoding, na_filter=False,
                         parse_dates=[field['field'] for field in fields if field['type'] == 'date'],
                         names=[field['field'] for field in fields],
                         dtype={field['field']: types.get(field['type'], 'str') for field in fields})
        table_schema = [
            {'name': field['field'], 'type': self.types.DATA_TYPES[field['type']]['t'].upper()}
            for field in fields
        ]
        df.to_gbq(destination_table='{}.{}'.format(schema_name, table_name), if_exists='replace',
                  table_schema=table_schema, progress_bar=False, credentials=self.credentials)

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        # TODO: implement
        raise NotImplementedError

    def server_version(self):
        # managed service, does not expose version
        return ''

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        sql_statement = re.sub(r'UNION(?!\sALL)', 'UNION DISTINCT', sql_statement, 0, flags=re.IGNORECASE)
        return sql_statement


class ImpalaConnection(BaseConnection):
    quotes = '``'
    dateadd_query = 'DATE_ADD({column}, {increment})'

    def __init__(self, conn_details, **kwargs):
        import jaydebeapi

        conn_string = 'jdbc:impala://{host}:{port}/;{extra_params}'.format(host=conn_details['host'],
                                                                           port=conn_details['port'],
                                                                           extra_params=conn_details['extra_params'])
        credentials = {'UID': conn_details['user'], 'PWD': conn_details['pwd']}
        self.conn = jaydebeapi.connect('com.cloudera.impala.jdbc.DataSource',
                                       conn_string, credentials, conn_details['driver_path'])
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.BigQueryDataTypes
        self.dialect = 'impala'

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_dict(self, query):
        cur = self.conn.cursor()
        cur.execute(query)
        cols = [col[0] for col in cur.description]
        result = [{d: v for (d, v) in zip(cols, row)} for row in cur.fetchall()]
        return result

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        cur = self.conn.cursor()
        for q in queries:
            cur.execute(q)
        cur.close()

    def close(self):
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        cur = self.conn.cursor()
        if overwrite is True:
            cur.execute("DROP DATABASE IF EXISTS {name} CASCADE".format(name=name))
            cur.execute("CREATE DATABASE " + name)
        else:
            cur.execute("CREATE DATABASE IF NOT EXISTS {name}".format(name=name))
        cur.close()

    def is_table_exists(self, schema, table):
        return table.lower() in self.get_table_list(schema)

    def get_columns_list(self, schema, table, rule_id=None):
        q = """DESCRIBE {schema}.{table}""".format(schema=schema, table=table)
        cur = self.conn.cursor()
        cur.execute(q)
        res_rows = cur.fetchall()
        cur.close()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        cur = self.conn.cursor()
        cur.execute("""SHOW TABLES IN {schema}""".format(schema=schema))
        result = cur.fetchall()
        cur.close()
        return [res[0].lower() for res in result]

    def truncate_table(self, schema, table):
        if self.is_table_exists(schema, table):
            self.execute("TRUNCATE TABLE {s}.{t}".format(s=schema, t=table))

    def drop_table(self, schema, table):
        self.execute("DROP TABLE IF EXISTS {s}.{t}".format(s=schema, t=table))

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        import pandas as pd
        header_rows = 0 if header else None
        quoting = 0 if remove_quotes else 3
        types = {'string': 'str', 'concept_id': 'Int64', 'int': 'Int64', 'double': 'float', 'bool': 'bool'}
        df = pd.read_csv(file, sep=sep, header=header_rows, quoting=quoting, quotechar=quote_char, encoding=encoding,
                         parse_dates=[field['field'] for field in fields if field['type'] == 'date'],
                         names=[field['field'] for field in fields],
                         dtype={field['field']: types.get(field['type'], 'str') for field in fields})
        table_schema = [
            {'name': field['field'], 'type': self.types.DATA_TYPES[field['type']]['t'].upper()}
            for field in fields
        ]
        df.to_gbq(destination_table='{}.{}'.format(schema_name, table_name), if_exists='replace',
                  table_schema=table_schema, progress_bar=False, credentials=self.credentials)

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        # TODO: implement
        raise NotImplementedError

    def server_version(self):
        return self.select_scalar("SELECT version()")

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        return sql_statement


class SnowflakeConnection(BaseConnection):
    ddl_before_load = True
    ddl_declare_nullable = {True: 'NOT NULL', False: 'NULL'}
    ddl_external_tables = False
    quotes = '""'
    s3_location = ''
    default_storage_format = ''
    top_query = ''
    limit_query = 'LIMIT {num}'
    extract_year_query = 'YEAR({column})'
    count_not_zero_query = 'COUNT({column})>0'
    length_query = 'LENGTH({column})'
    dateadd_query = "DATEADD({interval}, {increment}, {column})"

    def __init__(self, conn_details, **kwargs):
        import snowflake.connector
        # TODO: proper args mapping
        self.conn = snowflake.connector.connect(
            account=conn_details.get("account"),
            user=conn_details.get("user"),
            password=conn_details.get("password"),
            database=conn_details.get("dbname"),
            role=conn_details.get("role"),
            warehouse=conn_details.get("warehouse"),
            authenticator=conn_details.get("auth_method", "externalbrowser"),
        )
        self.cur = self.conn.cursor()
        self.types = sql_datatypes.SnowflakeDataTypes
        self.dialect = 'snowflake'

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_dict(self, query):
        cur = self.conn.cursor(snowflake.connector.DictCursor)
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return [dict(x) for x in result]

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        cur = self.conn.cursor()
        for q in queries:
            cur.execute(q)
        cur.close()

    def close(self):
        self.cur.close()
        self.conn.close()

    def create_schema(self, name, overwrite=False):
        cur = self.conn.cursor()
        if overwrite is True:
            cur.execute("CREATE OR REPLACE SCHEMA {name}".format(name=name))
        else:
            cur.execute("CREATE SCHEMA IF NOT EXISTS {name}".format(name=name))
        cur.close()

    def is_table_exists(self, schema, table):
        cur = self.conn.cursor()
        cur.execute("""
            SELECT EXISTS (
                SELECT * FROM information_schema.tables
                WHERE table_schema = '{schema}' AND table_name = '{table}'
            )
            """.format(schema=schema.upper(), table=table.upper())
        )
        result = cur.fetchone()[0]
        cur.close()
        return result

    def get_columns_list(self, schema, table, rule_id=None):
        q = """ SELECT lower(column_name), lower(data_type), ordinal_position
                FROM information_schema.columns
                WHERE table_schema = '{schema}' AND table_name = '{table}'
                ORDER BY ordinal_position ASC
            """.format(schema=schema.upper(), table=table.upper())
        with self.conn.cursor() as cur:
            cur.execute(q)
            res_rows = cur.fetchall()
        column_names = [{"name": str(row[0]), "type": str(row[1])} for row in res_rows]
        return column_names

    def get_table_list(self, schema):
        q = """ SELECT lower(table_name)
                FROM information_schema.columns
                WHERE table_schema = '{schema}'
            """.format(schema=schema.upper())
        with self.conn.cursor() as cur:
            cur.execute(q)
            res_rows = cur.fetchall()
        table_names = [str(row[0]) for row in res_rows]
        return table_names

    def truncate_table(self, schema, table):
        if self.is_table_exists(schema, table):
            with self.conn.cursor() as cur:
                cur.execute("TRUNCATE TABLE {s}.{t}".format(s=schema, t=table))

    def drop_table(self, schema, table):
        with self.conn.cursor() as cur:
            cur.execute("DROP TABLE IF EXISTS {s}.{t}".format(s=schema, t=table))

    def load_file(self, file, schema_name, table_name, fields=None, sep=',', header=None, dateformat=None,
                  timeformat=None, compression=None, encoding=None, invalid_char=None, blank_as_null=False,
                  empty_as_null=False, ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, data_location=None, generate_util_cols=False):
        # TODO: implement
        raise NotImplementedError

    def unload_file(self, table_name, path, target_format=None, delimiter=',', header=None, files_number=None,
                    exclude_columns=None, compression=None, add_quotes=None, allow_overwrite=False, parallel=True,
                    max_file_size='', schema=None, date_format=None, quote_all=False, quote='"', escape='\\',
                    null_value=None):
        # TODO: implement
        raise NotImplementedError

    def server_version(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT current_version()")
            res = cur.fetchone()
        return res[0]

    def quoted(self, x):
        # TODO: Snowflake uses upper case by default
        # quoted lowercase identifiers are not found
        return x

    @staticmethod
    def adjust_sql_statement(sql_statement, etl_conf):
        return sql_statement


class SQLiteConnection(BaseConnection):
    def __init__(self, conn_details, **kwargs):
        import sqlite3
        self.conn = sqlite3.connect(conn_details.get('database'))
        self.types = sql_datatypes.SQLiteDataTypes

    def select(self, query, **kwargs):
        cur = self.conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        return result

    def select_scalar(self, query, as_type=None):
        with self.conn.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()[0]
        if as_type is not None:
            result = as_type(result)
        return result

    def execute(self, *queries, **kwargs):
        as_transaction = kwargs.get("as_transaction", True)
        # execute a set of queries, commit at the end or rollback on exception
        cur = self.conn.cursor()
        for q in queries:
            try:
                cur.execute(q)
                if as_transaction is False:
                    # non-atomic -> commit after each query
                    self.conn.commit()
            except Exception as e:
                self.conn.rollback()
                raise e
        if as_transaction is True:
            # atomic -> commit once at the end
            self.conn.commit()
        cur.close()

    def close(self):
        self.conn.close()

    def server_version(self):
        import sqlite3
        return sqlite3.sqlite_version


class ConnectionBuilder(object):
    """Factory class which creates Connection instances.
    Saved connections are stored in {accentor_home}/conf/connections.conf.

    NB: if you created a new connection type, don't forget to add it to _SUPPORTED_DBMS dict.

    Attributes:
        known_connections (dict): DB credentials sets, saved into configuration file.

    """

    _SUPPORTED_DBMS = {
        'sqlite':       SQLiteConnection,
        'postgre':      PostgreConnection,
        'postgres':     PostgreConnection,
        'redshift':     RedshiftConnection,
        'athena':       AthenaConnection,
        'bigquery':     BigQueryConnection,
        'sqlserver':    SQLServerConnection,
        'impala':       ImpalaConnection,
        'snowflake':    SnowflakeConnection,
        'spark':        SparkConnection
    }

    def __init__(self):
        with open(os.path.join(os.environ["CDMKIT_HOME"], 'conf', 'connections.conf'), 'r') as f:
            self.known_connections = json.load(f)

    def get_connection(self, dbms, conn_details={}, **kwargs):
        """Create a connection instance, choosing type by `dbms`.

        Args:
            dbms (str): One of supported DB systems.
            conn_details (dict): Connection credentials. Defaults to {}.
            **kwargs: Extra connection parameters.

        Returns:
            type: Connection instance.

        """
        conn_type = self._SUPPORTED_DBMS.get(dbms, None)
        if not conn_type:
            raise E.JobInitException('DBMS "{}" not supported.'.format(dbms))
        return conn_type(conn_details, **kwargs)

    def get_connection_by_name(self, conn_name, **kwargs):
        """Shortcut method. Try to get saved connection by its name.

        Args:
            conn_name (str): Name of the set of connection credentials.
            **kwargs: Extra connection parameters.

        Returns:
            type: Connection instance.

        """
        conn_details = self.known_connections.get(conn_name)
        if not conn_details:
            raise E.JobInitException('No connection named "{}" was found.'.format(conn_name))
        dbms = conn_details.pop('dbms')
        return self.get_connection(dbms, conn_details, **kwargs)

    def get_connection_by_etlconf(self, etl_conf, **kwargs):
        """Shortcut method. Try to get connection by configuration file.

        Args:
            etl_conf (:class:`configs.ETLConf`): CDMKit env configuration.
            **kwargs: Extra connection parameters.

        Returns:
            type: Connection instance.

        """
        conn_name = etl_conf.db.get('connection_name')
        if conn_name:
            session = self.get_connection_by_name(conn_name, **kwargs)
        else:
            dbms = etl_conf.db.pop('dbms')
            session = self.get_connection(dbms, conn_details=etl_conf.db, **kwargs)
        return session
