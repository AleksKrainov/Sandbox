"""Generate CDM statistics
"""

import argparse
import json
import os
import sys
import traceback

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E

try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_stats_report(temp_dir, run_id, stats, failed=False):
    etl_print('Writing intermediate cdmstats report', ETLMessageType.Running)
    report_temp_path = os.path.join(
        temp_dir,
        'cdmstats_{run_id}.{ext}'.format(
            run_id=run_id,
            ext="json" if not failed else "failed"
        )
    )

    try:
        with open(report_temp_path, 'w') as report_temp_file:
            json.dump(stats, report_temp_file, indent=4)
    except (ValueError, OSError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise E.JobReportException(cause=exc)
    etl_print('', ETLMessageType.Ok)


def merge_reports(old, new):
    if old is None:
        return new
    return {
        "tables": old["tables"] + new["tables"],
        "vocabs": old["vocabs"] + new["vocabs"],
        "created_date": new["created_date"]
    }


# ======= Start ===============================================================

etl_print('Job cdmstats.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-s", dest="cdm_stats_conf_file", required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("--rule-col", dest="rule_col_name", type=str)
parser.add_argument("-t", dest="tables", type=lambda x: x.split(","), default=None)

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False
)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to cdmstats.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
cdm_stats_conf_file = parsed.cdm_stats_conf_file
run_id = parsed.run_id
notebook_run = parsed.notebook_run
tables = parsed.tables

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

etl_conf = configs.ETLConf.from_file(os.path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'stats')

try:
    cdm_stats_conf_path = os.path.join(etl_home, 'conf', cdm_stats_conf_file)
    cdm_stats_conf = configs.StatsConfig(cdm_stats_conf_path)
except (OSError, ValueError, IOError) as e:
    FAILED_TO_READ_CONF = 'Failed to read configuration file "{filename}"\n{exception}'.format(
        filename=cdm_stats_conf_path,
        exception=str(e)
    )
    etl_print(FAILED_TO_READ_CONF, ETLMessageType.Error)
    sys.exit(1)

# ======= 3. Check if there's a report from failed run ========================

temp_dir = os.path.join(etl_home, "temp", os.path.splitext(etl_conf_file)[0])
errfile_path = os.path.join(temp_dir, 'cdmstats_{run_id}.failed'.format(run_id=run_id))

# Read currently existing cdm_stats report and exclude jobs that already done
if os.path.exists(errfile_path):
    with open(errfile_path) as errfile:
        previous_stats = json.load(errfile)
        if "report" in previous_stats:
            already_done = [x["table"] for x in previous_stats["report"]["tables"]]
        else:
            already_done = [x["table"] for x in previous_stats["tables"]]

    cdm_stats_conf.tables = [
        table_conf for table_conf in cdm_stats_conf.tables
        if table_conf["table"] not in already_done
    ]
else:
    previous_stats = None

# Run job only for given tables
if tables:
    for t in tables:
        if t not in [t['table'] for t in cdm_stats_conf.tables]:
            etl_print('{} doesn\'t include table {}'.format(cdm_stats_conf_file, t), ETLMessageType.Error)
    cdm_stats_conf.tables = [
        table_conf for table_conf in cdm_stats_conf.tables
        if table_conf["table"] in tables
    ]
# ======= 4. Set up database session and runner ===============================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="cdmstats")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.CDMStatsGenerator(session, etl_conf, cdm_stats_conf)
else:
    runner = sql_core.CDMStatsGenerator(session, etl_conf, cdm_stats_conf)

if parsed.rule_col_name:
    runner.RULE_COL = parsed.rule_col_name
# ======= 5. Run job ==========================================================

JOB_FAILED = 'Job cdmstats.py failed\n{exception}'
try:
    runner.run()
except E.JobExecException as e:
    etl_print(JOB_FAILED.format(exception=str(e)), ETLMessageType.Error)
    traceback.print_exc(file=sys.stdout)
    write_stats_report(
        temp_dir, run_id,
        merge_reports(previous_stats, runner.stats.to_json()),
        failed=True
    )
    sys.exit(1)

# ======= 6. Write job report =================================================
try:
    write_stats_report(
        temp_dir, run_id,
        merge_reports(previous_stats, runner.stats.to_json())
    )
except (E.JobReportException, AttributeError) as e:
    etl_print(JOB_FAILED.format(exception=str(e)), ETLMessageType.Error)
    traceback.print_exc(file=sys.stdout)
    sys.exit(1)

if os.path.exists(errfile_path):
    os.remove(errfile_path)

# ======= 7. Create run log ===================================================

if run_id is None:
    etl_print(
        'Run report is not created. Missing -r parameter',
        ETLMessageType.Warning
    )
else:
    try:
        write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'cdmstats')
    except (E.JobReportException, AttributeError) as e:
        etl_print(
            'Run report is not created\n' + str(e),
            ETLMessageType.Warning
        )

if notebook_run: return_code = 0

etl_print('Job cdmstats.py finished')

# ======= End ================================================================
