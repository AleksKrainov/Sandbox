from subprocess import call
import sys

print('command_runner.py started')
run_command = ' '.join(sys.argv[1:])
print('Running "{0}"'.format(run_command))

call(run_command, shell=True)

print('command_runner.py finished')