-- -------------------------------------------------------------------
-- @2021, Odysseus Data Services, Inc. All rights reserved
-- OMOP CDM Conversion v5.3.1
-- Dataset Name
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: Eras
!*/

DROP TABLE IF EXISTS @target_schema.tmp_target_condition PURGE;
/*!
    @insert
    @table: @target_schema.tmp_target_condition
    @source_table: @target_schema.cdm_condition_occurrence
    @summary:
    Defining spans of time when the
    Person is assumed to have a given
    condition.
!*/
CREATE TABLE @target_schema.tmp_target_condition
AS SELECT
    co.condition_occurrence_id                                              AS condition_occurrence_id,
    co.person_id                                                            AS person_id,
    co.condition_concept_id                                                 AS condition_concept_id,
    co.condition_start_date                                                 AS condition_start_date,
    COALESCE( co.condition_end_date,
              CAST (DATE_ADD (co.condition_start_date, 1) AS timestamp))    AS condition_end_date
    -- Depending on the needs of data, include more filters in cteConditionTarget
    -- For example
    -- - to exclude unmapped condition_concept_id's (i.e. condition_concept_id = 0)
          -- from being included in same era
    -- - to set condition_era_end_date to same condition_era_start_date
          -- or condition_era_start_date + INTERVAL '1 day', when condition_end_date IS NULL
FROM
    @target_schema.cdm_condition_occurrence co
WHERE
    co.condition_concept_id != 0
;

DROP TABLE IF EXISTS @target_schema.tmp_dates_un_condition PURGE;
CREATE TABLE @target_schema.tmp_dates_un_condition
    AS SELECT
        person_id                               AS person_id,
        condition_concept_id                    AS condition_concept_id,
        CAST(condition_start_date AS timestamp) AS event_date,
        -1                                      AS event_type,
        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                condition_concept_id
            ORDER BY
                condition_start_date)               AS start_ordinal
    FROM
        @target_schema.tmp_target_condition
UNION ALL
    SELECT
        person_id                                             AS person_id,
        condition_concept_id                                  AS condition_concept_id,
        CAST( DATE_ADD (condition_end_date, 30) AS timestamp) AS event_date,
        1                                                     AS event_type,
        NULL                                                  AS start_ordinal
    FROM
        @target_schema.tmp_target_condition
;

DROP TABLE IF EXISTS @target_schema.tmp_dates_rows_condition PURGE;
CREATE TABLE @target_schema.tmp_dates_rows_condition
AS SELECT
    person_id                       AS person_id,
    condition_concept_id            AS condition_concept_id,
    event_date                      AS event_date,
    event_type                      AS event_type,
    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            condition_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)   AS start_ordinal,
        -- this pulls the current START down from the prior rows
        -- so that the NULLs from the END DATES will contain a value we can compare with
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            condition_concept_id
        ORDER BY
            event_date,
            event_type)             AS overall_ord
        -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
FROM
    @target_schema.tmp_dates_un_condition
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_condition PURGE;
CREATE TABLE @target_schema.tmp_enddates_condition
AS SELECT
    person_id                                       AS person_id,
    condition_concept_id                            AS condition_concept_id,
    CAST (DATE_SUB (event_date, 30) AS timestamp)   AS end_date  -- unpad the end date
FROM
    @target_schema.tmp_dates_rows_condition e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
;

DROP TABLE IF EXISTS @target_schema.tmp_conditionends PURGE;
CREATE TABLE @target_schema.tmp_conditionends
AS SELECT
    c.person_id                             AS person_id,
    c.condition_concept_id                  AS condition_concept_id,
    c.condition_start_date                  AS condition_start_date,
    CAST (MIN (e.end_date) AS timestamp)    AS era_end_date
FROM
    @target_schema.tmp_target_condition c
JOIN
    @target_schema.tmp_enddates_condition e
        ON  c.person_id            = e.person_id
        AND c.condition_concept_id = e.condition_concept_id
        AND e.end_date             >= c.condition_start_date
GROUP BY
    c.condition_occurrence_id,
    c.person_id,
    c.condition_concept_id,
    c.condition_start_date
;

-- -------------------------------------------------------------------
-- Load Table: Condition_era
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_condition_era;
/*!
    @insert
    @table: @target_schema.cdm_condition_era
    @source_table: @target_schema.tmp_target_condition
    @summary: It is derived from the records in
    the CONDITION_OCCURRENCE table using
    a standardized algorithm.
    30 days window is allowed.
!*/
INSERT INTO @target_schema.cdm_condition_era
SELECT
    monotonically_increasing_id()                   AS condition_era_id,
    person_id                                       AS person_id,
    condition_concept_id                            AS condition_concept_id,
    CAST (MIN (condition_start_date) AS timestamp)  AS condition_era_start_date,
    era_end_date                                    AS condition_era_end_date,
    COUNT(*)                                        AS condition_occurrence_count,
-- --
    'CDM.condition_occurrence.<condition_era>'      AS rule_id,
    NULL                                            AS load_table_id,
    NULL                                            AS load_row_id
FROM
    @target_schema.tmp_conditionends
GROUP BY
    person_id,
    condition_concept_id,
    era_end_date
ORDER BY
    person_id,
    condition_concept_id
;

ANALYZE TABLE @target_schema.cdm_condition_era COMPUTE STATISTICS;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_conditionends        PURGE;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_condition   PURGE;
DROP TABLE IF EXISTS @target_schema.tmp_dates_rows_condition PURGE;
DROP TABLE IF EXISTS @target_schema.tmp_dates_un_condition   PURGE;
DROP TABLE IF EXISTS @target_schema.tmp_target_condition     PURGE;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
