-- -------------------------------------------------------------------
-- @2021, Odysseus Data Services, Inc. All rights reserved
-- OMOP CDM Conversion v5.3.1
-- Dataset Name
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Load Table: cdm_source
-- -------------------------------------------------------------------

TRUNCATE TABLE @target_schema.cdm_cdm_source;

INSERT INTO @target_schema.cdm_cdm_source
SELECT
    'The Dataset Full Name'                         AS cdm_source_name,
    'The Dataset Abbreviation'                      AS cdm_source_abbreviation,
    'Odysseus Data Services, Inc.'                  AS cdm_holder,
    'The Description of The Dataset'
                                                    AS source_description,
    'https://dataset.org/docs/if/open'
                                                    AS source_documentation_reference,
    'https://github.com/if/exists/and/open'
                                                    AS cdm_etl_reference,
    '@cutoff_date'                                  AS source_release_date,
    current_date                                    AS cdm_release_date,
    'v5.3.1'                                        AS cdm_version,
    v.vocabulary_version                            AS vocabulary_version,
-- --
    NULL                                            AS rule_id,
    NULL                                            AS load_table_id,
    NULL                                            AS load_row_id
FROM
    @voc_schema.voc_vocabulary v
WHERE
    v.vocabulary_id = 'None'
;

-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
