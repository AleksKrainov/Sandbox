import json
import argparse
import sys
from os import path
try:
    import openpyxl as op
except ImportError:
    print('You must have openpyxl module installed of at least version 2.6.3')
    sys.exit(1)


class GroupRuleParser:

    def __init__(self):
        self.filename      = 'fields_lk.xlsx'
        self.worksheet     = 'grouped_rules'
        self.group_by      = None
        self.excluded_rows = list()
        self.output_file   = 'grouped_rules.json'
        self.grouped_rules = dict() 

    def _get_rule_name(self, row):
        if self.group_by is None:
            return '@' + path.split(self.output_file)[1].split('.')[0] or 'grouped_rule'
        else:
            return '@' + '_'.join([str(row[idx - 1].value) for idx in self.group_by]) # since we work with excel let's give the user some consistency    
    
    def _process_cell_value(self, string):
        # you can add any sort of processing here
        return string
    
    def parse_grouped_rules(self):
    
        self.grouped_rules = dict()
        wb = op.load_workbook(filename=self.filename)
        ws = wb[self.worksheet]
    
        field_names = list()
        
        # we need to extract field names from the header
        for column in range(1, ws.max_column + 1): # the damn ranges in excel have 1-based index
            field_names.append(ws.cell(1, column).value)
        
        for row in ws.iter_rows(min_row=2): # 2 is the row after the header
            if row[0].row in self.excluded_rows:
                continue
            
            current_rule = self._get_rule_name(row)
            if not isinstance(self.grouped_rules.get(current_rule), list):
                self.grouped_rules[current_rule] = list()
        
            row_dict = dict()
            for col_idx in range(0, ws.max_column):
                if row[col_idx].value is not None:
                    val = self._process_cell_value(str(row[col_idx].value))
                    row_dict[field_names[col_idx]] = val
    
            self.grouped_rules[current_rule].append(row_dict)
    
        return self.grouped_rules
    
    def dump_rules(self):
        with open(self.output_file, 'w') as f:
            f.write(json.dumps(self.grouped_rules, indent=4))


def main(args):
    desc_str = """
    Excel parser for grouped rules. 
    By default looks for a file fields_lk.xlsx in the working directory with a worksheet named grouped_rules.
    You can also specify a processing function for the cell values inside the script (process_cell_value function)
    """
    arg_parser = argparse.ArgumentParser(
        description=desc_str,
        usage="python adds_to_spec_parser.py PATH [options]"
    )
    
    arg_parser.add_argument('path', nargs='?', default='./fields_lk.xlsx', type=str, 
                            help='Path to Excel file where the grouped rules are stored')
    arg_parser.add_argument('-g', '--group-by', nargs='*', dest='group_by', default=None, type=int, 
                            help='Column numbers for the grouped rule name (@output_file name if none specified)')
    arg_parser.add_argument('-ws', '--worksheet', nargs='?', dest='worksheet', default='grouped_rules',
                            help='Name of the worksheet where the grouped rules are described')
    arg_parser.add_argument('-of', '--output-file', nargs='?', dest='output_file', default='grouped_rules.json',
                            help='Path to where the result should be saved (grouped_rules.json if none specified)')
    arg_parser.add_argument('-ex', '--exclude', nargs='*', dest='excluded_rows', default=list(), type=int,
                            help='List of row indexes that you do not need (1-based)')
    parsed_args = arg_parser.parse_args(args)
    
    rule_parser = GroupRuleParser()
    rule_parser.filename      = parsed_args.path
    rule_parser.worksheet     = parsed_args.worksheet
    rule_parser.group_by      = parsed_args.group_by
    rule_parser.excluded_rows = parsed_args.excluded_rows
    rule_parser.output_file   = parsed_args.output_file
    
    rule_parser.parse_grouped_rules()
    rule_parser.dump_rules()

if __name__ == '__main__':
    main(sys.argv[1:])
