
-- ------------------------------------------------------------------
-- select distinct vocs, which need for custom_mappings
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_code_list;

CREATE TABLE @cdm_schema.tmp_code_list
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
-- old stage
AS SELECT
    concept_code                AS concept_code,
    vocabulary_id               AS vocabulary_id
FROM @old_stage_schema.cdm_concept_stage_old
UNION
SELECT
    concept_code_1              AS concept_code,
    vocabulary_id_1             AS vocabulary_id
FROM @old_stage_schema.cdm_concept_relationship_stage_old
UNION
SELECT
    concept_code_2              AS concept_code,
    vocabulary_id_2             AS vocabulary_id
FROM @old_stage_schema.cdm_concept_relationship_stage_old
UNION
SELECT
    ancestor_concept_code       AS concept_code,
    ancestor_vocabulary_id      AS vocabulary_id
FROM @old_stage_schema.cdm_concept_ancestor_stage_old
UNION
SELECT
    descendant_concept_code     AS concept_code,
    descendant_vocabulary_id    AS vocabulary_id
FROM @old_stage_schema.cdm_concept_ancestor_stage_old
-- new stage
UNION
SELECT
    concept_code                AS concept_code,
    vocabulary_id               AS vocabulary_id
FROM @new_stage_schema.cdm_concept_stage_new
UNION
SELECT
    concept_code_1              AS concept_code,
    vocabulary_id_1             AS vocabulary_id
FROM @new_stage_schema.cdm_concept_relationship_stage_new
UNION
SELECT
    concept_code_2              AS concept_code,
    vocabulary_id_2             AS vocabulary_id
FROM @new_stage_schema.cdm_concept_relationship_stage_new
UNION
SELECT
    ancestor_concept_code       AS concept_code,
    ancestor_vocabulary_id      AS vocabulary_id
FROM @new_stage_schema.cdm_concept_ancestor_stage_new
UNION
SELECT
    descendant_concept_code     AS concept_code,
    descendant_vocabulary_id    AS vocabulary_id
FROM @new_stage_schema.cdm_concept_ancestor_stage_new
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_code_list COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- select only needed rows in vocabulary
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_voc_vocabulary;

CREATE TABLE @cdm_schema.tmp_voc_vocabulary
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT voc.*
FROM
    @omop_voc_schema.voc_vocabulary voc
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_code_list cl
        WHERE cl.vocabulary_id = voc.vocabulary_id
    )
    OR EXISTS
    (
        SELECT 1
        FROM @old_stage_schema.lk_vocabulary_match vm
        WHERE vm.vocabulary_id = voc.vocabulary_id
    )
    OR vocabulary_id = 'None'
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_voc_vocabulary COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- select only needed rows in concept
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept;

CREATE TABLE @cdm_schema.tmp_voc_concept
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT vc.*
FROM
    @omop_voc_schema.voc_concept vc
INNER JOIN
    @cdm_schema.tmp_code_list cl
        ON cl.concept_code = vc.concept_code
WHERE
    (
        cl.vocabulary_id = vc.vocabulary_id
        OR vc.vocabulary_id IN
            (
                SELECT vm.vocabulary_id
                FROM @old_stage_schema.lk_vocabulary_match vm
                WHERE vm.unmapped_vocabulary_id = cl.vocabulary_id
            )
    )
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_voc_concept COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- select only needed rows in concept_relationship
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept_relationship;

CREATE TABLE @cdm_schema.tmp_voc_concept_relationship
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT vcr.*
FROM
    @omop_voc_schema.voc_concept_relationship vcr
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept vc1
        WHERE vc1.concept_id = vcr.concept_id_1
    )
    OR EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept vc2
        WHERE vc2.concept_id = vcr.concept_id_2
    )
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_voc_concept_relationship COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- select only needed rows in concept_ancestor
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept_ancestor;

CREATE TABLE @cdm_schema.tmp_voc_concept_ancestor
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT vca.*
FROM
    @omop_voc_schema.voc_concept_ancestor vca
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept vc
        WHERE vc.concept_id = vca.ancestor_concept_id
    )
    OR EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept vc
        WHERE vc.concept_id = vca.descendant_concept_id
    )
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_voc_concept_ancestor COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- Drop Temporary Tables
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_code_list;
