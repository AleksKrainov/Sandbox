
-- ------------------------------------------------------------------
-- vocabulary_stage
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_vocabulary_stage;

CREATE TABLE @cdm_schema.tmp_vocabulary_stage
(
--@IF dbms IN (spark, athena)
    vocabulary_id           STRING,
    vocabulary_name         STRING,
    vocabulary_reference    STRING,
    vocabulary_version      STRING,
    vocabulary_concept_id   INT
--@ENDIF
--@IF dbms IN (redshift, postgres, snowflake)
    vocabulary_id           VARCHAR,
    vocabulary_name         VARCHAR,
    vocabulary_reference    VARCHAR,
    vocabulary_version      VARCHAR,
    vocabulary_concept_id   INT
--@ENDIF
--@IF dbms = sqlserver
-- TODO: this is becoming painful and we need to rethink this
    vocabulary_id           VARCHAR(100),
    vocabulary_name         VARCHAR(255),
    vocabulary_reference    VARCHAR(255),
    vocabulary_version      VARCHAR(255),
    vocabulary_concept_id   INT
--@ENDIF
)
--@IF dbms IN (spark, athena)
STORED AS PARQUET
--@ENDIF
;


-- Copy old vocabulary_stage, which not exists in voc_vocabulary
-- and update fields if exists in new stage
-- and not exists in voc_vocabulary
INSERT INTO @cdm_schema.tmp_vocabulary_stage
SELECT
    vso.vocabulary_id                   AS vocabulary_id,
    COALESCE(vsn.vocabulary_name
           , vso.vocabulary_name)       AS vocabulary_name,
    COALESCE(vsn.vocabulary_reference
           , vso.vocabulary_reference
           , 'OMOP generated')          AS vocabulary_reference,
    COALESCE(vsn.vocabulary_version
           , vso.vocabulary_version)    AS vocabulary_version,
    vso.vocabulary_concept_id           AS vocabulary_concept_id
FROM
    @old_stage_schema.cdm_vocabulary_stage_old vso
LEFT JOIN
    @new_stage_schema.cdm_vocabulary_stage_new vsn
        ON vsn.vocabulary_id = vso.vocabulary_id
WHERE
    vso.vocabulary_id != 'CDM None'
    AND NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_vocabulary voc
        WHERE   voc.vocabulary_id = vso.vocabulary_id
            AND voc.vocabulary_id != 'None'
    )
;


-- Copy new vocabulary_stage, which not exists in old voc_vocabulary
-- and not exists in voc_vocabulary;
INSERT INTO @cdm_schema.tmp_vocabulary_stage
SELECT DISTINCT
    vsn.vocabulary_id,
    vsn.vocabulary_name,
    vsn.vocabulary_reference,
    vsn.vocabulary_version,
    vsn.vocabulary_concept_id
FROM @new_stage_schema.cdm_vocabulary_stage_new vsn
WHERE
    vsn.vocabulary_id != 'CDM None'
    AND NOT EXISTS
    (
        SELECT 1
        FROM @old_stage_schema.cdm_vocabulary_stage_old vso
        WHERE vso.vocabulary_id = vsn.vocabulary_id
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_vocabulary voc
        WHERE   voc.vocabulary_id = vsn.vocabulary_id
            AND voc.vocabulary_id != 'None'
    )
;

-- Update vocabulary_stage from vocabulary
-- for vocabulary_id = 'CDM None'
INSERT INTO @cdm_schema.tmp_vocabulary_stage
SELECT
    'CDM None'                      AS vocabulary_id,
    vocabulary_name                 AS vocabulary_name,
    vocabulary_reference            AS vocabulary_reference,
    vocabulary_version              AS vocabulary_version,
    vocabulary_concept_id           AS vocabulary_concept_id
FROM
    @cdm_schema.tmp_voc_vocabulary
WHERE
    vocabulary_id = 'None'
;

-- ------------------------------------------------------------------
-- Temporary Table: tmp_concept_exclude
-- code found in standart vocs and should be exclude from stage vocs
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_exclude;

CREATE TABLE @cdm_schema.tmp_concept_exclude
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT
    cs.concept_code,
    cs.vocabulary_id
FROM
    (
        SELECT
            concept_code,
            vocabulary_id
        FROM @old_stage_schema.cdm_concept_stage_old
        UNION
        SELECT
            concept_code,
            vocabulary_id
        FROM @new_stage_schema.cdm_concept_stage_new
    ) cs
INNER JOIN
    @cdm_schema.tmp_voc_concept vc
        ON vc.concept_code = cs.concept_code
WHERE
    vc.vocabulary_id IN
        (
            SELECT vocabulary_id
            FROM @old_stage_schema.lk_vocabulary_match vm
            WHERE vm.unmapped_vocabulary_id = cs.vocabulary_id
        )
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_concept_exclude COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- concept_stage
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_stage;

CREATE TABLE @cdm_schema.tmp_concept_stage
(
--@IF dbms IN (spark, athena)
    source_table        STRING,
    concept_id          INTEGER,
    concept_name        STRING,
    domain_id           STRING,
    vocabulary_id       STRING,
    concept_class_id    STRING,
    standard_concept    STRING,
    concept_code        STRING,
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      STRING
--@ENDIF
--@IF dbms IN (redshift, postgres, snowflake)
    source_table        VARCHAR,
    concept_id          INTEGER,
    concept_name        VARCHAR,
    domain_id           VARCHAR,
    vocabulary_id       VARCHAR,
    concept_class_id    VARCHAR,
    standard_concept    VARCHAR,
    concept_code        VARCHAR,
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      VARCHAR
--@ENDIF
--@IF dbms = sqlserver
    source_table        VARCHAR(100),
    concept_id          INTEGER,
    concept_name        VARCHAR(MAX),
    domain_id           VARCHAR(20),
    vocabulary_id       VARCHAR(100),
    concept_class_id    VARCHAR(20),
    standard_concept    CHAR(1),
    concept_code        VARCHAR(MAX),
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      CHAR(1)
--@ENDIF
)
--@IF dbms IN (spark, athena)
STORED AS PARQUET
--@ENDIF
;


-- Copy old concept_stage, which not exists in voc_concept
-- and update fields if exists in new stage
INSERT INTO @cdm_schema.tmp_concept_stage
SELECT DISTINCT
    CASE
        WHEN csn.concept_code IS NOT NULL
        THEN 'new'
        ELSE 'old'
    END                                                     AS source_table,
    CASE
        WHEN COALESCE(csn.concept_id, 0) = -1
        THEN csn.concept_id
        WHEN    csn.concept_code IS NOT NULL
            AND cso.concept_id = -1
        THEN NULL
        ELSE cso.concept_id
    END                                                     AS concept_id,
    COALESCE(csn.concept_name, cso.concept_name)            AS concept_name,
    COALESCE(csn.domain_id, cso.domain_id)                  AS domain_id,
    cso.vocabulary_id                                       AS vocabulary_id,
    COALESCE(csn.concept_class_id, cso.concept_class_id)    AS concept_class_id,
    CASE
        WHEN csn.concept_code IS NOT NULL
        THEN csn.standard_concept
        ELSE cso.standard_concept
    END                                                     AS standard_concept,
    cso.concept_code                                        AS concept_code,
    COALESCE(csn.valid_start_date, cso.valid_start_date)    AS valid_start_date,
    COALESCE(csn.valid_end_date, cso.valid_end_date)        AS valid_end_date,
    CASE
        WHEN csn.concept_code IS NOT NULL
        THEN csn.invalid_reason
        ELSE cso.invalid_reason
    END                                                     AS invalid_reason
FROM
    @old_stage_schema.cdm_concept_stage_old cso
LEFT JOIN
    @new_stage_schema.cdm_concept_stage_new csn
        ON  csn.concept_code = cso.concept_code
        AND csn.vocabulary_id = cso.vocabulary_id
WHERE
    NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_exclude ce
        WHERE   ce.concept_code = cso.concept_code
            AND ce.vocabulary_id = cso.vocabulary_id
    )
    AND cso.vocabulary_id != 'Vocabulary'
;


-- Copy new concept_stage, which not exists in old concept_stage
-- and not exists in voc_concept
INSERT INTO @cdm_schema.tmp_concept_stage
SELECT DISTINCT
    'new'               AS source_table,
    csn.concept_id,
    csn.concept_name,
    csn.domain_id,
    csn.vocabulary_id,
    csn.concept_class_id,
    csn.standard_concept,
    csn.concept_code,
    csn.valid_start_date,
    csn.valid_end_date,
    csn.invalid_reason
FROM @new_stage_schema.cdm_concept_stage_new csn
WHERE
    NOT EXISTS
    (
        SELECT 1
        FROM @old_stage_schema.cdm_concept_stage_old cso
        WHERE   cso.concept_code = csn.concept_code
            AND cso.vocabulary_id = csn.vocabulary_id
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_exclude ce
        WHERE   ce.concept_code = csn.concept_code
            AND ce.vocabulary_id = csn.vocabulary_id
    )
    AND csn.vocabulary_id != 'Vocabulary'
;


-- Add custom vocabulary to tmp_concept_stage table
INSERT INTO @cdm_schema.tmp_concept_stage
SELECT
    'voc'                       AS source_table,
    vocabulary_concept_id       AS concept_id,
    vocabulary_id               AS concept_name,
    'Metadata'                  AS domain_id,
    'Vocabulary'                AS vocabulary_id,
    'Vocabulary'                AS concept_class_id,
    NULL                        AS standard_concept,
    'OMOP generated'            AS concept_code,
    CAST('1970-01-01' AS DATE)  AS valid_start_date,
    CAST('2099-12-31' AS DATE)  AS valid_end_date,
    NULL                        AS invalid_reason
FROM
    @cdm_schema.tmp_vocabulary_stage
WHERE
    vocabulary_id NOT IN ('None', 'CDM None')
;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_concept_stage COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- Temporary Table: tmp_concept_relationship_stage
-- collect rows for concept_relationship_stage
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_relationship_stage;

CREATE TABLE @cdm_schema.tmp_concept_relationship_stage
(
--@IF dbms IN (spark, athena)
    concept_id_1        INTEGER,
    concept_id_2        INTEGER,
    concept_code_1      STRING,
    concept_code_2      STRING,
    vocabulary_id_1     STRING,
    vocabulary_id_2     STRING,
    relationship_id     STRING,
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      STRING
--@ENDIF
--@IF dbms IN (redshift, postgres, snowflake)
    concept_id_1        INTEGER,
    concept_id_2        INTEGER,
    concept_code_1      VARCHAR,
    concept_code_2      VARCHAR,
    vocabulary_id_1     VARCHAR,
    vocabulary_id_2     VARCHAR,
    relationship_id     VARCHAR,
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      VARCHAR
--@ENDIF
--@IF dbms = sqlserver
    concept_id_1        INTEGER,
    concept_id_2        INTEGER,
    concept_code_1      VARCHAR(MAX),
    concept_code_2      VARCHAR(MAX),
    vocabulary_id_1     VARCHAR(100),
    vocabulary_id_2     VARCHAR(100),
    relationship_id     VARCHAR(20),
    valid_start_date    DATE,
    valid_end_date      DATE,
    invalid_reason      CHAR(1)
--@ENDIF
)
--@IF dbms IN (spark, athena)
STORED AS PARQUET
--@ENDIF
;


-- new: relationships for custom codes
INSERT INTO @cdm_schema.tmp_concept_relationship_stage
SELECT DISTINCT
    crsn.concept_id_1,
    crsn.concept_id_2,
    crsn.concept_code_1,
    crsn.concept_code_2,
    crsn.vocabulary_id_1,
    crsn.vocabulary_id_2,
    crsn.relationship_id,
    crsn.valid_start_date,
    crsn.valid_end_date,
    crsn.invalid_reason
FROM
    @new_stage_schema.cdm_concept_relationship_stage_new crsn
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_stage tcs
        WHERE
            tcs.source_table = 'new'
            AND COALESCE(tcs.concept_id, 0) != -1           -- not junk
            AND
            (       tcs.concept_code = crsn.concept_code_1
                AND tcs.vocabulary_id = crsn.vocabulary_id_1
            OR      tcs.concept_code = crsn.concept_code_2
                AND tcs.vocabulary_id = crsn.vocabulary_id_2
            )
    )
;


-- old: relationships for custom codes
INSERT INTO @cdm_schema.tmp_concept_relationship_stage
SELECT DISTINCT
    crso.concept_id_1,
    crso.concept_id_2,
    crso.concept_code_1,
    crso.concept_code_2,
    crso.vocabulary_id_1,
    crso.vocabulary_id_2,
    crso.relationship_id,
    crso.valid_start_date,
    crso.valid_end_date,
    crso.invalid_reason
FROM
    @old_stage_schema.cdm_concept_relationship_stage_old crso
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_stage tcs
        WHERE
            tcs.source_table = 'old'
            AND COALESCE(tcs.concept_id, 0) != -1           -- not junk
            AND
            (       tcs.concept_code = crso.concept_code_1
                AND tcs.vocabulary_id = crso.vocabulary_id_1
            OR      tcs.concept_code = crso.concept_code_2
                AND tcs.vocabulary_id = crso.vocabulary_id_2
            )
    )
;


-- new: relationships for codes from standard vocabularies
INSERT INTO @cdm_schema.tmp_concept_relationship_stage
SELECT DISTINCT
    vc1.concept_id              AS concept_id_1,
    vc2.concept_id              AS concept_id_2,
    crsn.concept_code_1         AS concept_code_1,
    crsn.concept_code_2         AS concept_code_2,
    crsn.vocabulary_id_1        AS vocabulary_id_1,
    crsn.vocabulary_id_2        AS vocabulary_id_2,
    crsn.relationship_id        AS relationship_id,
    crsn.valid_start_date       AS valid_start_date,
    crsn.valid_end_date         AS valid_end_date,
    CASE
        WHEN crsn.relationship_id IN ('Maps to', 'Maps to value')
        THEN vc2.invalid_reason
        ELSE crsn.invalid_reason
    END                         AS invalid_reason
FROM
    @new_stage_schema.cdm_concept_relationship_stage_new crsn
INNER JOIN
    @cdm_schema.tmp_voc_concept vc1
        ON  vc1.concept_code = crsn.concept_code_1
        AND vc1.vocabulary_id = crsn.vocabulary_id_1
INNER JOIN
    @cdm_schema.tmp_voc_concept vc2
        ON  vc2.concept_code = crsn.concept_code_2
        AND vc2.vocabulary_id = crsn.vocabulary_id_2
WHERE
    -- no relationship in standard vocabularies
    NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept_relationship cr
        WHERE
            cr.relationship_id = crsn.relationship_id
            AND cr.concept_id_1 = vc1.concept_id
            AND cr.concept_id_2 = vc2.concept_id
    )
;


-- old: relationships for codes from standard vocabularies
INSERT INTO @cdm_schema.tmp_concept_relationship_stage
SELECT DISTINCT
    vc1.concept_id              AS concept_id_1,
    vc2.concept_id              AS concept_id_2,
    crso.concept_code_1         AS concept_code_1,
    crso.concept_code_2         AS concept_code_2,
    crso.vocabulary_id_1        AS vocabulary_id_1,
    crso.vocabulary_id_2        AS vocabulary_id_2,
    crso.relationship_id        AS relationship_id,
    crso.valid_start_date       AS valid_start_date,
    crso.valid_end_date         AS valid_end_date,
    CASE
        WHEN crso.relationship_id IN ('Maps to', 'Maps to value')
        THEN vc2.invalid_reason
        ELSE crso.invalid_reason
    END                         AS invalid_reason
FROM
    @old_stage_schema.cdm_concept_relationship_stage_old crso
INNER JOIN
    @cdm_schema.tmp_voc_concept vc1
        ON  vc1.concept_code = crso.concept_code_1
        AND vc1.vocabulary_id = crso.vocabulary_id_1
INNER JOIN
    @cdm_schema.tmp_voc_concept vc2
        ON  vc2.concept_code = crso.concept_code_2
        AND vc2.vocabulary_id = crso.vocabulary_id_2
WHERE
    -- no relationship in standard vocabularies
    NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept_relationship cr
        WHERE
            cr.relationship_id = crso.relationship_id
            AND cr.concept_id_1 = vc1.concept_id
            AND cr.concept_id_2 = vc2.concept_id
    )
;

-- ------------------------------------------------------------------
-- Temporary Table: tmp_concept_ancestor_stage
-- collect rows for concept_ancestor_stage
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_ancestor_stage;

CREATE TABLE @cdm_schema.tmp_concept_ancestor_stage
(
--@IF dbms IN (spark, athena)
    ancestor_concept_id         INT,
    descendant_concept_id       INT,
    ancestor_concept_code       STRING,
    descendant_concept_code     STRING,
    ancestor_vocabulary_id      STRING,
    descendant_vocabulary_id    STRING,
    min_levels_of_separation    INTEGER,
    max_levels_of_separation    INTEGER
--@ENDIF
--@IF dbms IN (redshift, postgres, snowflake)
    ancestor_concept_id         INT,
    descendant_concept_id       INT,
    ancestor_concept_code       VARCHAR,
    descendant_concept_code     VARCHAR,
    ancestor_vocabulary_id      VARCHAR,
    descendant_vocabulary_id    VARCHAR,
    min_levels_of_separation    INTEGER,
    max_levels_of_separation    INTEGER
--@ENDIF
--@IF dbms = sqlserver
    ancestor_concept_id         INT,
    descendant_concept_id       INT,
    ancestor_concept_code       VARCHAR(100),
    descendant_concept_code     VARCHAR(100),
    ancestor_vocabulary_id      VARCHAR(100),
    descendant_vocabulary_id    VARCHAR(100),
    min_levels_of_separation    INTEGER,
    max_levels_of_separation    INTEGER
--@ENDIF
)
--@IF dbms IN (spark, athena)
STORED AS PARQUET
--@ENDIF
;


-- new: rows for custom codes
INSERT INTO @cdm_schema.tmp_concept_ancestor_stage
SELECT DISTINCT
    casn.ancestor_concept_id,
    casn.descendant_concept_id,
    casn.ancestor_concept_code,
    casn.descendant_concept_code,
    casn.ancestor_vocabulary_id,
    casn.descendant_vocabulary_id,
    casn.min_levels_of_separation,
    casn.max_levels_of_separation
FROM
    @new_stage_schema.cdm_concept_ancestor_stage_new casn
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_stage tcs
        WHERE
            tcs.source_table = 'new'
            AND COALESCE(tcs.concept_id, 0) != -1           -- not junk
            AND
            (       tcs.concept_code = casn.ancestor_concept_code
                AND tcs.vocabulary_id = casn.ancestor_vocabulary_id
            OR      tcs.concept_code = casn.descendant_concept_code
                AND tcs.vocabulary_id = casn.descendant_vocabulary_id
            )
    )
;


-- old: rows for custom codes
INSERT INTO @cdm_schema.tmp_concept_ancestor_stage
SELECT DISTINCT
    caso.ancestor_concept_id,
    caso.descendant_concept_id,
    caso.ancestor_concept_code,
    caso.descendant_concept_code,
    caso.ancestor_vocabulary_id,
    caso.descendant_vocabulary_id,
    caso.min_levels_of_separation,
    caso.max_levels_of_separation
FROM
    @old_stage_schema.cdm_concept_ancestor_stage_old caso
WHERE
    EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_concept_stage tcs
        WHERE
            tcs.source_table = 'old'
            AND COALESCE(tcs.concept_id, 0) != -1           -- not junk
            AND
            (       tcs.concept_code = caso.ancestor_concept_code
                AND tcs.vocabulary_id = caso.ancestor_vocabulary_id
            OR      tcs.concept_code = caso.descendant_concept_code
                AND tcs.vocabulary_id = caso.descendant_vocabulary_id
            )
    )
;


-- new: rows for codes from standard vocabularies
INSERT INTO @cdm_schema.tmp_concept_ancestor_stage
SELECT DISTINCT
    vc1.concept_id                  AS ancestor_concept_id,
    vc2.concept_id                  AS descendant_concept_id,
    casn.ancestor_concept_code      AS ancestor_concept_code,
    casn.descendant_concept_code    AS descendant_concept_code,
    casn.ancestor_vocabulary_id     AS ancestor_vocabulary_id,
    casn.descendant_vocabulary_id   AS descendant_vocabulary_id,
    casn.min_levels_of_separation   AS min_levels_of_separation,
    casn.max_levels_of_separation   AS max_levels_of_separation
FROM
    @new_stage_schema.cdm_concept_ancestor_stage_new casn
INNER JOIN
    @cdm_schema.tmp_voc_concept vc1
        ON  vc1.concept_code = casn.ancestor_concept_code
        AND vc1.vocabulary_id = casn.ancestor_vocabulary_id
INNER JOIN
    @cdm_schema.tmp_voc_concept vc2
        ON  vc2.concept_code = casn.descendant_concept_code
        AND vc2.vocabulary_id = casn.descendant_vocabulary_id
WHERE
    -- no rows in standard vocabularies
    NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept_ancestor ca
        WHERE
            ca.ancestor_concept_id = vc1.concept_id
            AND ca.descendant_concept_id = vc2.concept_id
    )
;


-- old: rows for codes from standard vocabularies
INSERT INTO @cdm_schema.tmp_concept_ancestor_stage
SELECT DISTINCT
    vc1.concept_id                  AS ancestor_concept_id,
    vc2.concept_id                  AS descendant_concept_id,
    caso.ancestor_concept_code      AS ancestor_concept_code,
    caso.descendant_concept_code    AS descendant_concept_code,
    caso.ancestor_vocabulary_id     AS ancestor_vocabulary_id,
    caso.descendant_vocabulary_id   AS descendant_vocabulary_id,
    caso.min_levels_of_separation   AS min_levels_of_separation,
    caso.max_levels_of_separation   AS max_levels_of_separation
FROM
    @old_stage_schema.cdm_concept_ancestor_stage_old caso
INNER JOIN
    @cdm_schema.tmp_voc_concept vc1
        ON  vc1.concept_code = caso.ancestor_concept_code
        AND vc1.vocabulary_id = caso.ancestor_vocabulary_id
INNER JOIN
    @cdm_schema.tmp_voc_concept vc2
        ON  vc2.concept_code = caso.descendant_concept_code
        AND vc2.vocabulary_id = caso.descendant_vocabulary_id
WHERE
    -- no row in standard vocabularies
    NOT EXISTS
    (
        SELECT 1
        FROM @cdm_schema.tmp_voc_concept_ancestor ca
        WHERE
            ca.ancestor_concept_id = vc1.concept_id
            AND ca.descendant_concept_id = vc2.concept_id
    )
;

-- ------------------------------------------------------------------
-- concept_stage
-- ------------------------------------------------------------------

TRUNCATE TABLE @final_stage_schema.cdm_concept_stage;

-- Create temporary table for max 2bil concept_id
DROP TABLE IF EXISTS @cdm_schema.tmp_max_2bil_concept_id;

CREATE TABLE @cdm_schema.tmp_max_2bil_concept_id
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT MAX(concept_id)      AS concept_id
FROM
(
    SELECT MAX(concept_id)  AS concept_id
    FROM @old_stage_schema.cdm_concept_stage_old
    UNION
    SELECT MAX(concept_id)  AS concept_id
    FROM @new_stage_schema.cdm_concept_stage_new
    UNION
    SELECT MAX(concept_id)  AS concept_id
    FROM @cdm_schema.tmp_concept_stage
) s
WHERE s.concept_id > 2000000000;

--@IF dbms=spark
ANALYZE TABLE @cdm_schema.tmp_max_2bil_concept_id COMPUTE STATISTICS
--@ENDIF
;
-- codes with concept_id
INSERT INTO @final_stage_schema.cdm_concept_stage
SELECT DISTINCT
    concept_id,
    concept_name,
    domain_id,
    vocabulary_id,
    concept_class_id,
    standard_concept,
    concept_code,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM
    @cdm_schema.tmp_concept_stage
WHERE
    concept_id IS NOT NULL
;


-- generate concept_id for codes without concept_id
INSERT INTO @final_stage_schema.cdm_concept_stage
SELECT DISTINCT
    COALESCE(
        (
            SELECT concept_id
            FROM @cdm_schema.tmp_max_2bil_concept_id
        ), 2000000000
    ) + CAST(
        ROW_NUMBER() OVER(
            ORDER BY
                vocabulary_id,
                concept_code,
                concept_name
            )
        AS INTEGER
    )                               AS concept_id,
    concept_name                    AS concept_name,
    domain_id                       AS domain_id,
    vocabulary_id                   AS vocabulary_id,
    concept_class_id                AS concept_class_id,
    standard_concept                AS standard_concept,
    concept_code                    AS concept_code,
    valid_start_date                AS valid_start_date,
    valid_end_date                  AS valid_end_date,
    invalid_reason                  AS invalid_reason
FROM
    @cdm_schema.tmp_concept_stage cs
WHERE
    concept_id IS NULL
;

--@IF dbms=spark
ANALYZE TABLE @final_stage_schema.cdm_concept_stage COMPUTE STATISTICS
--@ENDIF
;

DROP TABLE IF EXISTS @cdm_schema.tmp_max_2bil_concept_id;

-- ------------------------------------------------------------------
-- concept_relationship_stage
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_full;

CREATE TABLE @cdm_schema.tmp_concept_full
--@IF dbms=spark
STORED AS PARQUET
--@ENDIF
--@IF dbms=athena
WITH (format='PARQUET')
--@ENDIF
AS SELECT
    concept_id,
    concept_code,
    vocabulary_id,
    standard_concept,
    invalid_reason
FROM @cdm_schema.tmp_voc_concept
UNION
SELECT
    concept_id,
    concept_code,
    vocabulary_id,
    standard_concept,
    invalid_reason
FROM @final_stage_schema.cdm_concept_stage
;

TRUNCATE TABLE @final_stage_schema.cdm_concept_relationship_stage;

INSERT INTO @final_stage_schema.cdm_concept_relationship_stage
SELECT DISTINCT
    vc1.concept_id                  AS concept_id_1,
    vc2.concept_id                  AS concept_id_2,
    tcrs.concept_code_1             AS concept_code_1,
    tcrs.concept_code_2             AS concept_code_2,
    tcrs.vocabulary_id_1            AS vocabulary_id_1,
    tcrs.vocabulary_id_2            AS vocabulary_id_2,
    tcrs.relationship_id            AS relationship_id,
    tcrs.valid_start_date           AS valid_start_date,
    tcrs.valid_end_date             AS valid_end_date,
    CASE
        WHEN    tcrs.relationship_id IN ('Maps to', 'Maps to value')
            AND COALESCE(vc2.standard_concept, '') != 'S'
        THEN 'D'
        WHEN    tcrs.relationship_id IN ('Mapped from', 'Value mapped from')
            AND COALESCE(vc1.standard_concept, '') != 'S'
        THEN 'D'
        ELSE tcrs.invalid_reason
    END                         AS invalid_reason
FROM
    @cdm_schema.tmp_concept_relationship_stage tcrs
LEFT JOIN
    @cdm_schema.tmp_concept_full vc1
        ON  vc1.concept_code = tcrs.concept_code_1
        AND vc1.vocabulary_id = tcrs.vocabulary_id_1
LEFT JOIN
    @cdm_schema.tmp_concept_full vc2
        ON  vc2.concept_code = tcrs.concept_code_2
        AND vc2.vocabulary_id = tcrs.vocabulary_id_2
;


-- ------------------------------------------------------------------
-- concept_ancestor_stage
-- ------------------------------------------------------------------

TRUNCATE TABLE @final_stage_schema.cdm_concept_ancestor_stage;

INSERT INTO @final_stage_schema.cdm_concept_ancestor_stage
SELECT DISTINCT
    vc1.concept_id                      AS ancestor_concept_id,
    vc2.concept_id                      AS descendant_concept_id,
    tcrs.ancestor_concept_code          AS ancestor_concept_code,
    tcrs.descendant_concept_code        AS descendant_concept_code,
    tcrs.ancestor_vocabulary_id         AS ancestor_vocabulary_id,
    tcrs.descendant_vocabulary_id       AS descendant_vocabulary_id,
    tcrs.min_levels_of_separation       AS min_levels_of_separation,
    tcrs.max_levels_of_separation       AS max_levels_of_separation
FROM
    @cdm_schema.tmp_concept_ancestor_stage tcrs
LEFT JOIN
    @cdm_schema.tmp_concept_full vc1
        ON  vc1.concept_code = tcrs.ancestor_concept_code
        AND vc1.vocabulary_id = tcrs.ancestor_vocabulary_id
LEFT JOIN
    @cdm_schema.tmp_concept_full vc2
        ON  vc2.concept_code = tcrs.descendant_concept_code
        AND vc2.vocabulary_id = tcrs.descendant_vocabulary_id
;

-- ------------------------------------------------------------------
-- cdm_vocabulary_stage: Update vocabulary_concept_id
-- ------------------------------------------------------------------

TRUNCATE TABLE @final_stage_schema.cdm_vocabulary_stage;

INSERT INTO @final_stage_schema.cdm_vocabulary_stage
SELECT DISTINCT
    tvs.vocabulary_id                       AS vocabulary_id,
    tvs.vocabulary_name                     AS vocabulary_name,
    tvs.vocabulary_reference                AS vocabulary_reference,
    tvs.vocabulary_version                  AS vocabulary_version,
    COALESCE( cs.concept_id
            , tvs.vocabulary_concept_id
            , 44819096)                     AS vocabulary_concept_id
FROM
    @cdm_schema.tmp_vocabulary_stage tvs
LEFT JOIN
    @final_stage_schema.cdm_concept_stage cs
        ON  cs.concept_name = tvs.vocabulary_id
        AND cs.vocabulary_id = 'Vocabulary'
;

-- ------------------------------------------------------------------
-- Drop Temporary Tables
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_concept_exclude;
DROP TABLE IF EXISTS @cdm_schema.tmp_vocabulary_stage;
DROP TABLE IF EXISTS @cdm_schema.tmp_concept_stage;
DROP TABLE IF EXISTS @cdm_schema.tmp_concept_relationship_stage;
DROP TABLE IF EXISTS @cdm_schema.tmp_concept_ancestor_stage;
DROP TABLE IF EXISTS @cdm_schema.tmp_max_2bil_concept_id;