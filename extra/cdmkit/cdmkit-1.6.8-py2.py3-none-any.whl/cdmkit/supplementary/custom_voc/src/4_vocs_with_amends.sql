
-- ------------------------------------------------------------------
-- concept
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_concept;

INSERT INTO @custom_voc_schema.voc_concept
SELECT
    concept_id,
    concept_name,
    domain_id,
    vocabulary_id,
    concept_class_id,
    standard_concept,
    concept_code,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM
    @omop_voc_schema.voc_concept
;

INSERT INTO @custom_voc_schema.voc_concept
SELECT 
    concept_id,
    concept_name,
    domain_id,
    vocabulary_id,
    concept_class_id,
    standard_concept,
    concept_code,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM @amend_schema.cdm_concept_amend
--TODO
WHERE
    concept_id IS NOT NULL
;

-- ------------------------------------------------------------------
-- concept_relationship
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_concept_relationship;

INSERT INTO @custom_voc_schema.voc_concept_relationship
SELECT
    concept_id_1,
    concept_id_2,
    relationship_id,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM
    @omop_voc_schema.voc_concept_relationship
;

INSERT INTO @custom_voc_schema.voc_concept_relationship
SELECT 
    concept_id_1,
    concept_id_2,
    relationship_id,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM @amend_schema.cdm_concept_relationship_amend
--TODO
WHERE
    concept_id_1 IS NOT NULL
    AND concept_id_2 IS NOT NULL
;

-- ------------------------------------------------------------------
-- concept_ancestor
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_concept_ancestor;

INSERT INTO @custom_voc_schema.voc_concept_ancestor
SELECT
    ancestor_concept_id,
    descendant_concept_id,
    min_levels_of_separation,
    max_levels_of_separation
FROM
    @omop_voc_schema.voc_concept_ancestor
;

INSERT INTO @custom_voc_schema.voc_concept_ancestor
SELECT 
    ancestor_concept_id,
    descendant_concept_id,
    min_levels_of_separation,
    max_levels_of_separation
FROM @amend_schema.cdm_concept_ancestor_amend
--TODO
WHERE
    ancestor_concept_id IS NOT NULL
    AND descendant_concept_id IS NOT NULL
;

-- ------------------------------------------------------------------
-- concept_synonym
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_concept_synonym;

INSERT INTO @custom_voc_schema.voc_concept_synonym
SELECT
    concept_id,
    concept_synonym_name,
    language_concept_id
FROM
    @omop_voc_schema.voc_concept_synonym
;

INSERT INTO @custom_voc_schema.voc_concept_synonym
SELECT 
    concept_id,
    concept_synonym_name,
    language_concept_id
FROM @amend_schema.cdm_concept_synonym_amend
--TODO
WHERE
    concept_id IS NOT NULL
;

-- ------------------------------------------------------------------
-- vocabulary
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_vocabulary;

INSERT INTO @custom_voc_schema.voc_vocabulary
SELECT
    vocabulary_id,
    vocabulary_name,
    vocabulary_reference,
    vocabulary_version,
    vocabulary_concept_id
FROM
    @omop_voc_schema.voc_vocabulary
;

INSERT INTO @custom_voc_schema.voc_vocabulary
SELECT 
    vocabulary_id,
    vocabulary_name,
    vocabulary_reference,
    vocabulary_version,
    vocabulary_concept_id
FROM 
    @amend_schema.cdm_vocabulary_amend
;

-- ------------------------------------------------------------------
-- concept_class
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_concept_class;

INSERT INTO @custom_voc_schema.voc_concept_class
SELECT
    concept_class_id,
    concept_class_name,
    concept_class_concept_id
FROM
    @omop_voc_schema.voc_concept_class
;

-- ------------------------------------------------------------------
-- domain
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_domain;

INSERT INTO @custom_voc_schema.voc_domain
SELECT
    domain_id,
    domain_name,
    domain_concept_id
FROM
    @omop_voc_schema.voc_domain
;

-- ------------------------------------------------------------------
-- drug_strength
-- ------------------------------------------------------------------

TRUNCATE TABLE @custom_voc_schema.voc_drug_strength;

INSERT INTO @custom_voc_schema.voc_drug_strength
SELECT
    drug_concept_id,
    ingredient_concept_id,
    amount_value,
    amount_unit_concept_id,
    numerator_value,
    numerator_unit_concept_id,
    denominator_value,
    denominator_unit_concept_id,
    box_size,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM
    @omop_voc_schema.voc_drug_strength
;

-- ------------------------------------------------------------------
-- relationship
-- ------------------------------------------------------------------
TRUNCATE TABLE @custom_voc_schema.voc_relationship;

INSERT INTO @custom_voc_schema.voc_relationship
SELECT
    relationship_id,
    relationship_name,
    is_hierarchical,
    defines_ancestry,
    reverse_relationship_id,
    relationship_concept_id
FROM
    @omop_voc_schema.voc_relationship
;
