
-- ------------------------------------------------------------------
-- Generate relationships
-- ------------------------------------------------------------------

TRUNCATE TABLE @amend_schema.cdm_concept_amend;
TRUNCATE TABLE @amend_schema.cdm_concept_relationship_amend;
TRUNCATE TABLE @amend_schema.cdm_concept_ancestor_amend;
TRUNCATE TABLE @amend_schema.cdm_concept_synonym_amend;
TRUNCATE TABLE @amend_schema.cdm_vocabulary_amend;

-- ------------------------------------------------------------------
-- cdm_concept_amend
-- ------------------------------------------------------------------

INSERT INTO @amend_schema.cdm_concept_amend
SELECT
    concept_id,
    COALESCE(concept_name, concept_code),
    domain_id,
    vocabulary_id,
    concept_class_id,
    standard_concept,
    concept_code,
    valid_start_date,
    valid_end_date,
    invalid_reason
FROM
    @final_stage_schema.cdm_concept_stage
WHERE
    concept_id != -1
;

--@IF dbms=spark
ANALYZE TABLE @amend_schema.cdm_concept_amend COMPUTE STATISTICS
--@ENDIF
;

-- ------------------------------------------------------------------
-- cdm_concept_relationship_amend
-- ------------------------------------------------------------------

-- from concept_relationship_stage
INSERT INTO @amend_schema.cdm_concept_relationship_amend
SELECT
    concept_id_1                    AS concept_id_1,
    concept_id_2                    AS concept_id_2,
    relationship_id                 AS relationship_id,
    valid_start_date                AS valid_start_date,
    valid_end_date                  AS valid_end_date,
    invalid_reason                  AS invalid_reason
FROM
    @final_stage_schema.cdm_concept_relationship_stage
WHERE
    invalid_reason IS NULL
    AND concept_id_1 IS NOT NULL
    AND concept_id_2 IS NOT NULL
;


-- relationship 'Maps to' for standard concepts
INSERT INTO @amend_schema.cdm_concept_relationship_amend
SELECT
    ca.concept_id                   AS concept_id_1,
    ca.concept_id                   AS concept_id_2,
    'Maps to'                       AS relationship_id,
    CAST('1970-01-01' AS DATE)      AS valid_start_date,
    CAST('2099-12-31' AS DATE)      AS valid_end_date,
    NULL                            AS invalid_reason
FROM
    @amend_schema.cdm_concept_amend ca
WHERE
    COALESCE(ca.standard_concept, '') = 'S'
    AND NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_relationship_amend cra
            WHERE   cra.relationship_id = 'Maps to'
                AND cra.concept_id_1 = ca.concept_id
                AND cra.concept_id_2 = ca.concept_id
        )
;


-- reverse_relationship
INSERT INTO @amend_schema.cdm_concept_relationship_amend
SELECT
    cra.concept_id_2                AS concept_id_1,
    cra.concept_id_1                AS concept_id_2,
    vr.reverse_relationship_id      AS relationship_id,
    cra.valid_start_date            AS valid_start_date,
    cra.valid_end_date              AS valid_end_date,
    cra.invalid_reason              AS invalid_reason
FROM
    @amend_schema.cdm_concept_relationship_amend cra
INNER JOIN
    @omop_voc_schema.voc_relationship vr
        ON vr.relationship_id = cra.relationship_id
WHERE
    NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_relationship_amend cra2
            WHERE   cra2.relationship_id = vr.reverse_relationship_id
                AND cra2.concept_id_1 = cra.concept_id_2
                AND cra2.concept_id_2 = cra.concept_id_1
        )
;


-- ------------------------------------------------------------------
-- cdm_concept_ancestor_amend
-- ------------------------------------------------------------------

-- from concept_ancestor_stage
INSERT INTO @amend_schema.cdm_concept_ancestor_amend
SELECT
    ancestor_concept_id             AS ancestor_concept_id,
    descendant_concept_id           AS descendant_concept_id,
    min_levels_of_separation        AS min_levels_of_separation,
    max_levels_of_separation        AS max_levels_of_separation
FROM
    @final_stage_schema.cdm_concept_ancestor_stage
WHERE
    ancestor_concept_id IS NOT NULL
    AND descendant_concept_id IS NOT NULL
;


-- ancestor to itself for standard concepts
INSERT INTO @amend_schema.cdm_concept_ancestor_amend
SELECT
    ca.concept_id                   AS ancestor_concept_id,
    ca.concept_id                   AS descendant_concept_id,
    0                               AS min_levels_of_separation,
    0                               AS max_levels_of_separation
FROM
    @amend_schema.cdm_concept_amend ca
WHERE
    COALESCE(ca.standard_concept, '') IN ('C', 'S') -- TODO: CHECK MAYBE NOT
    AND NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_ancestor_amend caa
            WHERE   caa.ancestor_concept_id = ca.concept_id
                AND caa.descendant_concept_id = ca.concept_id
        )
;


-- ancestor from concept_relationship_stage for 'Is a'
INSERT INTO @amend_schema.cdm_concept_ancestor_amend
SELECT
    cra.concept_id_2            AS ancestor_concept_id,
    cra.concept_id_1            AS descendant_concept_id,
    1                           AS min_levels_of_separation,
    1                           AS max_levels_of_separation
FROM
    @amend_schema.cdm_concept_relationship_amend cra
WHERE
    cra.relationship_id = 'Is a'
    AND NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_ancestor_amend caa
            WHERE   caa.ancestor_concept_id = cra.concept_id_2
                AND caa.descendant_concept_id = cra.concept_id_1
        )
;


-- ancestor to itself for all descendant concepts with levels_of_separation = 0
INSERT INTO @amend_schema.cdm_concept_ancestor_amend
SELECT
    caa.descendant_concept_id   AS ancestor_concept_id,
    caa.descendant_concept_id   AS descendant_concept_id,
    0                           AS min_levels_of_separation,
    0                           AS max_levels_of_separation
FROM
    @amend_schema.cdm_concept_ancestor_amend caa
WHERE
    NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_ancestor_amend caa2
            WHERE   caa2.ancestor_concept_id = caa.descendant_concept_id
                AND caa2.descendant_concept_id = caa.descendant_concept_id
        )
    AND NOT EXISTS
        (
            SELECT 1
            FROM @cdm_schema.tmp_voc_concept_ancestor vca  -- TODO: check whether I should use sliced table
            WHERE   vca.ancestor_concept_id = caa.descendant_concept_id
                AND vca.descendant_concept_id = caa.descendant_concept_id
        )
;


-- ancestors for all sequence of ancestor
INSERT INTO @amend_schema.cdm_concept_ancestor_amend
SELECT
    vca.ancestor_concept_id                 AS ancestor_concept_id,
    caa.descendant_concept_id               AS descendant_concept_id,
    vca.min_levels_of_separation + 1        AS min_levels_of_separation,
    vca.max_levels_of_separation + 1        AS max_levels_of_separation
FROM
    @amend_schema.cdm_concept_ancestor_amend caa
INNER JOIN
    @omop_voc_schema.voc_concept_ancestor vca 
        ON vca.descendant_concept_id = caa.ancestor_concept_id
WHERE
    NOT EXISTS
        (
            SELECT 1
            FROM @amend_schema.cdm_concept_ancestor_amend caa2
            WHERE   caa2.ancestor_concept_id = vca.ancestor_concept_id
                AND caa2.descendant_concept_id = caa.descendant_concept_id
        )
;


-- ------------------------------------------------------------------
-- cdm_concept_synonym_amend
-- ------------------------------------------------------------------

INSERT INTO @amend_schema.cdm_concept_synonym_amend
SELECT
    concept_id                              AS concept_id,
    COALESCE(concept_name
           , concept_code)                  AS concept_synonym_name,
    4180186                                 AS language_concept_id       -- 'English language'
FROM
    @final_stage_schema.cdm_concept_stage
WHERE
    concept_id != -1
    AND concept_name IS NOT NULL
    AND concept_id IS NOT NULL
;


-- ------------------------------------------------------------------
-- cdm_vocabulary_amend
-- ------------------------------------------------------------------

INSERT INTO @amend_schema.cdm_vocabulary_amend
SELECT
    vocabulary_id           AS vocabulary_id,
    vocabulary_name         AS vocabulary_name,
    vocabulary_reference    AS vocabulary_reference,
    vocabulary_version      AS vocabulary_version,
    vocabulary_concept_id   AS vocabulary_concept_id
FROM
    @final_stage_schema.cdm_vocabulary_stage
WHERE
    vocabulary_id NOT IN ('None', 'CDM None')
;


-- ------------------------------------------------------------------
-- Drop Temporary Tables
-- ------------------------------------------------------------------

DROP TABLE IF EXISTS @cdm_schema.tmp_voc_vocabulary;
DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept;
DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept_relationship;
DROP TABLE IF EXISTS @cdm_schema.tmp_voc_concept_ancestor;