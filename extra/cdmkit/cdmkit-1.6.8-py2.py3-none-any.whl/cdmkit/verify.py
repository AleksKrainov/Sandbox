"""Run etl convertion step
"""

import argparse
import json
import os
import sys

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E

try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_verify_report(temp_dir, run_id, results, failed=False):
    etl_print('Writing intermediate verify report', ETLMessageType.Running)
    report_temp_path = os.path.join(
        temp_dir,
        'verify_{run_id}.{ext}'.format(
            run_id=run_id,
            ext="json" if not failed else "failed"
        )
    )
    try:
        with open(report_temp_path, 'w') as report_temp_file:
            json.dump(results, report_temp_file, indent=4)
    except (ValueError, OSError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise E.JobReportException(cause=exc)
    etl_print('', ETLMessageType.Ok)


def merge_reports(old, new):
    if old is None:
        return new
    return {
        "tables": old["tables"] + new["tables"],
        "created_date": new["created_date"]
    }


# ======= Start ===============================================================

etl_print('Job verify.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-s", dest="cdm_tables_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("-sw", dest="skip_warnings", action='store_true')
parser.add_argument("--rule-col", dest="rule_col_name", type=str)
parser.add_argument("-t", dest="tables", type=lambda x: x.split(","), default=None)

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False
)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to verify.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
cdm_tables_conf_file = parsed.cdm_tables_conf_file
run_id = parsed.run_id
notebook_run = parsed.notebook_run
skip_warnings = parsed.skip_warnings
tables = parsed.tables

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

etl_conf = configs.ETLConf.from_file(os.path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'verify')

try:
    cdm_tables_conf_path = os.path.join(etl_home, 'conf', cdm_tables_conf_file)
    cdm_tables_conf = configs.CDMTablesConfig(cdm_tables_conf_path)
except (OSError, ValueError, IOError) as e:
    etl_print(
        'Failed to read configuration file "{filename}"\n{exception}'.format(
            filename=cdm_tables_conf_file,
            exception=str(e)
        ),
        ETLMessageType.Error
    )
    sys.exit(1)

# ======= 3. Check if there's a report from failed run ========================

temp_dir = os.path.join(etl_home, "temp", os.path.splitext(etl_conf_file)[0])
errfile_path = os.path.join(temp_dir, 'verify_{run_id}.failed'.format(run_id=run_id))

if os.path.exists(errfile_path):
    with open(errfile_path) as errfile:
        previous_report = json.load(errfile)
        already_done = [x["table"] for x in previous_report["tables"]]
    cdm_tables_conf.tables = [
        table_conf for table_conf in cdm_tables_conf.tables
        if table_conf["table"] not in already_done
    ]
else:
    previous_report = None

# Run job only for given tables
if tables:
    for t in tables:
        if t not in [t['table'] for t in cdm_tables_conf.tables]:
            etl_print('{} doesn\'t include table {}'.format(cdm_tables_conf_file, t), ETLMessageType.Error)
    cdm_tables_conf.tables = [
        table_conf for table_conf in cdm_tables_conf.tables
        if table_conf["table"] in tables
    ]
# ======= 4. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="verify")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.CDMVerifier(session, etl_conf, cdm_tables_conf, skip_warnings)
else:
    runner = sql_core.CDMVerifier(session, etl_conf, cdm_tables_conf, skip_warnings)

if parsed.rule_col_name:
    runner.RULE_COL = parsed.rule_col_name
# ======= 5. Run job ==========================================================
try:
    runner.run()
except (E.JobExecException, ValueError) as e:
    etl_print(
        'Job verify.py failed\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    write_verify_report(
        temp_dir, run_id,
        merge_reports(previous_report, runner.report),
        failed=True
    )
    sys.exit(1)

# ======= 6. Write job report =================================================

write_verify_report(
    temp_dir, run_id,
    merge_reports(previous_report, runner.report)
)
if os.path.exists(errfile_path):
    os.remove(errfile_path)

# ======= 7. Create run log ===================================================

try:
    write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'verify')
except (E.JobReportException, AttributeError) as e:
    etl_print(
        'Run report is not created\n' + str(e),
        ETLMessageType.Warning
    )

if notebook_run: return_code = 0

etl_print('Job verify.py finished')

# ======= End ================================================================
