import argparse
import json
import sys
from os import path

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E
try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_report(etl_home, etl_conf_file, run_info, fail_info):
    conf = path.splitext(etl_conf_file)[0]
    report_path = path.join(etl_home, 'temp', conf, 'run_workflow_results.json')
    with open(report_path, 'w') as report_file:
        json.dump({
            'run_info': run_info,
            'fail_info': fail_info
        }, report_file, indent=4)


# ======= Start ===============================================================

etl_print('Job started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-s", dest="script_file", type=str, required=True)
parser.add_argument("-n", dest="count_necessity", action="store_false")
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("--rule-col", dest="rule_col_name", type=str)

# ======= 1. Parse command line args ==========================================

try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to the job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
script_file = parsed.script_file
count_necessity = parsed.count_necessity
notebook_run = parsed.notebook_run

# ======= 2. Load configuration files =========================================

create_log_file(etl_home, etl_conf_file, 'run_workflow', script_file)
conf = path.splitext(etl_conf_file)[0]
etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
workflow_conf_path = path.join(etl_home, 'temp', conf, 'run_workflow.json')

try:
    etl_print('Reading workflow file {file}'.format(file=workflow_conf_path))
    with open(workflow_conf_path, 'r') as workflow_conf_file:
        workflow_conf = json.load(workflow_conf_file)
except (OSError, ValueError, IOError) as e:
    print(
        'Failed to read configuration file "{filename}"\n{exception}'
        .format(filename=workflow_conf_path, exception=str(e))
    )
    sys.exit(1)

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="run_workflow")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.WorkflowRunner(session, etl_conf, count_necessity)
else:
    runner = sql_core.WorkflowRunner(session, etl_conf, count_necessity)

# ======= 4. Run job ==========================================================

return_code = 0
try:
    runner.run(workflow_conf)
except E.JobExecException as e:
    etl_print(
        'Job failed\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    return_code = 1
except Exception as e:
    etl_print(
        'Unexpected error! Details:\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    return_code = 1
finally:
    # === 5. Write job report anyway ==========================================
    etl_print('Writing report file')
    write_report(etl_home, etl_conf_file, runner.run_info, runner.fail_info)
    write_run_report(etl_home, etl_conf_file, parsed.run_id, runner.run_log.serialize(), 'run_workflow')
    etl_print('Job finished')
    sys.exit(return_code)

# ======= End ================================================================
