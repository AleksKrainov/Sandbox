"""Generate source statistics
"""

import argparse
import json
import sys
from os import path

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E

try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_stats_report(etl_home, etl_conf_file, stats, run_id):
    etl_print('Writing intermediate srcstats report', ETLMessageType.Running)
    report_file_path = '{home}/temp/{conf}/srcstats_{run_id}.json'.format(
        home=etl_home,
        conf=path.splitext(etl_conf_file)[0],
        run_id=run_id
    )

    try:
        with open(report_file_path, 'wt') as report_file:
            json.dump(stats.to_json(), report_file, indent=4)
    except (ValueError, OSError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise E.JobReportException(cause=exc)

    etl_print('', ETLMessageType.Ok)


# ======= Start ==============================================================

etl_print('Job srcstats.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-s", dest="src_stats_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("--rule-col", dest="rule_col_name", type=str)
parser.add_argument("-t", dest="tables", type=lambda x: x.split(","), default=None)

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False
)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to srcstats.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
src_stats_conf_file = parsed.src_stats_conf_file
run_id = parsed.run_id
notebook_run = parsed.notebook_run
tables = parsed.tables

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'srcstats')

try:
    src_stats_conf_path = path.join(etl_home, 'conf', src_stats_conf_file)
    src_stats_conf = configs.StatsConfig(src_stats_conf_path)
except (OSError, ValueError, IOError) as e:
    etl_print(
        'Failed to read configuration file "{filename}"\n{exception}'
        .format(
            filename=src_stats_conf_path,
            exception=str(e)),
        ETLMessageType.Error
    )
    sys.exit(1)

# Run job only for given tables
if tables:
    for t in tables:
        if t not in [t['table'] for t in src_stats_conf.tables]:
            etl_print('{} doesn\'t include table {}'.format(src_stats_conf_file, t), ETLMessageType.Error)
    src_stats_conf.tables = [
        table_conf for table_conf in src_stats_conf.tables
        if table_conf["table"] in tables
    ]
# ======= 3. Set up database session and runner ===============================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="srcstats")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.SourceDataStatsGenerator(session, etl_conf, src_stats_conf)
else:
    runner = sql_core.SourceDataStatsGenerator(session, etl_conf, src_stats_conf)

# ======= 4. Run job ==========================================================
try:
    runner.run()
except Exception as e:
    etl_print('Job srcstats.py failed\n{exception}'.format(exception=str(e)), ETLMessageType.Error)
    sys.exit(1)

# ======= 5. Write job report =================================================

try:
    write_stats_report(etl_home, etl_conf_file, runner.stats, run_id)
except (E.JobReportException, AttributeError) as e:
    etl_print('Job srcstats.py failed\n{exception}'.format(
        exception=str(e)),
        ETLMessageType.Error
    )
    sys.exit(1)

# ======= 6. Create run log ===================================================

if run_id is None:
    etl_print(
        'Run report is not created. Missing -r parameter',
        ETLMessageType.Warning
    )
else:
    try:
        write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'srcstats')
    except (E.JobReportException, AttributeError) as e:
        etl_print(
            'Run report is not created\n' + str(e),
            ETLMessageType.Warning
        )

if notebook_run: return_code = 0

etl_print('Job srcstats.py finished')

# ======= End ================================================================
