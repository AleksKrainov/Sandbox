# -------------------------------------------------------------------
# @2015-2021, Odysseus Data Services, Inc. All rights reserved
# CDMKit Toolkit
# -------------------------------------------------------------------
from collections import OrderedDict
from copy import deepcopy
import datetime
import functools
import json
import os
import pkg_resources
import shutil
import subprocess
import sys

from cdmkit.cli_args import CmdArgsParser
from cdmkit.core import (
    etl_print, ETLMessageType,
    utils,
    configs,
    workflow_generator
)
from cdmkit.core import exceptions as E
from cdmkit.core.job_reports import write_report
from cdmkit import __version__ as CDMKIT_VERSION


class EtlRunner(object):
    """
    Runs conversion jobs by calling subprocess with 'spark-submit' or python 2.
    """
    orchestration_home = None
    etl_home = None
    files_list = ''

    def __init__(self, args):
        self.run_id = datetime.datetime.now().strftime('%m%d%H%M%S%f')
        self.installation_path = os.path.dirname(os.path.realpath(__file__))
        self.orchestration_home = args.accentor_home
        self.job_params = args.job_params
        self.stderr = args.stderr
        self.args = args

        PROJECT_LEVEL_JOBS = (
            'new_project', 'import_project', 'delete_project',
            'setup'
        )
        if args.job not in PROJECT_LEVEL_JOBS:
            self.etl_home = os.path.normpath(args.project_conf['home'])
            # in case etlconf already exists
            if args.job != 'new_env':
                self.etl_conf_name = args.etl_conf_name
                self.load_etl_conf()
                self.get_submit_string()
                self.__create_out_dirs()
                self.files_list = utils.collect_files(self)
                self.default_spark_master = self.etl_conf.db.get('master') or 'yarn'

    def run(self):
        """Runs the conversion step, specified by self.args.job."""
        JOBS_TO_RUN = {
            'setup':            self.setup,
            'new_project':      self.new_project,
            'import_project':   self.import_project,
            'new_env':          self.new_environment,
            'update_env':       self.update_config,
            'delete_project':   self.delete_project,
            'delete_env':       self.delete_env,
            'build_graph':      self.build_graph,
            'load':             self.__submit_load_jobs,
            'ddl':              self.__submit_ddl_job,
            'verify':           self.__submit_verify_job,
            'qa':               self.__submit_qa_jobs,
            'srcstats':         self.__submit_src_stats_job,
            'cdmstats':         self.__submit_cdm_stats_job,
            'unload':           self.__submit_unload_job,
            'cmd':              self.__submit_command_runner,
            'run':              self.__submit_run_workflow,
            'patients_history': self.__submit_patients_history,
            'coverage_report':  self.__submit_coverage_report,
            'custom_voc':       self.__submit_custom_voc_merge_job
        }
        return JOBS_TO_RUN[self.args.job]()

    def setup(self):
        if not os.path.exists(self.args.cdmkit_home):
            etl_print("Creating CDMKIT_HOME directory '{}'...".format(self.args.cdmkit_home))
            os.makedirs(self.args.cdmkit_home)
        else:
            etl_print("Using existing CDMKIT_HOME directory '{}'...".format(self.args.cdmkit_home))
        if not os.path.exists(os.path.join(self.args.cdmkit_home, 'conf')):
            os.makedirs(os.path.join(self.args.cdmkit_home, 'conf'))
        for tn in ('accentor.conf', 'projects.conf', 'connections.conf', 'spark_settings.ini'):
            if not os.path.exists(os.path.join(self.args.cdmkit_home, 'conf', tn)):
                shutil.copyfile(
                    pkg_resources.resource_filename('cdmkit', 'templates/' + tn),
                    os.path.join(self.args.cdmkit_home, 'conf', tn)
                )
        if not os.path.exists(self.args.projects_home):
            etl_print("Creating CDMKIT_PROJECTS_HOME directory '{}'...".format(self.args.projects_home))
            os.makedirs(self.args.projects_home)
        else:
            etl_print("Using existing CDMKIT_PROJECTS_HOME directory '{}'...".format(self.args.projects_home))
        etl_print("Writing configuration changes to file..")
        with open(os.path.join(self.args.cdmkit_home, 'conf', 'accentor.conf'), 'r') as conf_file:
            conf = json.load(conf_file)
        conf['accentor_home'] = self.args.cdmkit_home
        conf['projects_home'] = self.args.projects_home
        with open(os.path.join(self.args.cdmkit_home, 'conf', 'accentor.conf'), 'w') as conf_file:
            json.dump(conf, conf_file)
        etl_print("Done.")
        if "CDMKIT_HOME" not in os.environ or "CDMKIT_PROJECTS_HOME" not in os.environ:
            etl_print("Make sure to set the following variables:", ETLMessageType.Warning)
            print("CDMKIT_HOME=" + self.args.cdmkit_home)
            print("CDMKIT_PROJECTS_HOME=" + self.args.projects_home)
        return 0

    def new_project(self):
        """
        Create new project folder in etl_home.

        :returns: 0 if created successfully
        """
        # check if project already in projects.conf
        if self.args.project in self.args.projects_conf:
            etl_print(
                "Project '{}' already exists.".format(self.args.project),
                ETLMessageType.Error)
            return 1

        etl_print(
            'Creating new project', ETLMessageType.Running, log=False
        )
        # create project folder in etl_home
        project_folder_path = os.path.join(self.args.projects_home, self.args.project)
        dirs = [
            os.path.join(project_folder_path, 'conf'),  # config folder
            os.path.join(project_folder_path, 'qa'),    # qa scripts
            os.path.join(project_folder_path, 'src')    # source sql scripts
        ]
        for d in dirs:
            # exist_ok fails on Py2 so assume folders do not exist
            os.makedirs(d)

        # copy etlconf template
        shutil.copyfile(
            pkg_resources.resource_filename('cdmkit', 'templates/template.etlconf'),
            os.path.join(project_folder_path, 'conf', 'EDIT_ME.etlconf')
        )

        project_id = None
        # update projects.conf
        self.args.projects_conf[self.args.project] = {
            "id": project_id,
            "home": project_folder_path,
            "environments": {}
        }
        projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'w') as projects_conf_file:
            json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        etl_print('', ETLMessageType.Ok, log=False)
        etl_print(
            "New project '{proj}' is created."
            .format(proj=self.args.project),
            log=False
        )
        return 0

    def import_project(self):
        """
        Finds project folder in projects_home,
        verifies its inner structure, saves project in projects.conf.
        :returns: 0 if imported successfully
        """
        etl_print(
            'Importing project', ETLMessageType.Running, log=False
        )

        # check if present in projects.conf
        if self.args.project in self.args.projects_conf:
            etl_print('', ETLMessageType.Failed, log=False)
            raise E.JobInitException(
                'Project "{proj}" already exists. Choose different name or delete it.'
                .format(proj=self.args.project))

        # verify structure
        project_folder_path = os.path.join(self.args.projects_home, self.args.project)
        verifier = utils.ProjectStructureVerifier(project_folder_path)
        errors = verifier.check_project(check_etlconfs=self.args.check_etlconfs)
        if errors:
            # strategy: show errors as warnings
            etl_print('', ETLMessageType.Ok, log=False)
            for err in errors:
                etl_print(err, ETLMessageType.Warning)

        # add project record
        project_id = None
        self.args.projects_conf[self.args.project] = {
            "id": project_id,
            "home": project_folder_path,
            "environments": {}
        }
        projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'w') as projects_conf_file:
            json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        # add environments
        for env, content in verifier.get_environments():
            env_id = None
            # update projects.conf
            self.args.projects_conf[self.args.project]['environments'][env] = {
                "id": env_id,
                "conf": env + '.etlconf',
                "env_type": "dev"
            }
            projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
            with open(projects_conf_path, 'w') as projects_conf_file:
                json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        etl_print('', ETLMessageType.Ok, log=False)
        etl_print(
            "Project '{proj}' imported successfully."
            .format(proj=self.args.project), log=False
        )

        return 0

    def new_environment(self):
        """
        Create new environment based on etl_home/{project}/conf/{name}.etlconf.
        :returns: 0 if created successfully
        """
        # check if environment already exists
        if self.args.environment in self.args.project_conf['environments']:
            raise E.JobInitException('Environment "{env}" already exists.'.format(env=self.args.environment))

        if not os.path.exists(pkg_resources.resource_filename('cdmkit', 'templates/ddl_cdm_v{}.conf'.format(self.args.cdm_version))):
            raise E.CLIArgsException('Template for cdm_tables of v{} does not exist'.format(self.args.cdm_version))

        etl_print(
            'Creating new environment', ETLMessageType.Running, log=False
        )

        # find new etlconf file
        new_etlconf_name = self.args.environment + '.etlconf'
        new_etlconf_path = os.path.join(self.etl_home, 'conf', new_etlconf_name)
        try:
            self.etl_conf = configs.ETLConf.from_file(new_etlconf_path)
        except IOError:
            etl_print('', ETLMessageType.Failed, log=False)
            raise E.ConfigException('Etlconf "{}" not found ({}).'.format(new_etlconf_name, new_etlconf_path))

        env_id = None
        # update projects.conf
        ref_copy = deepcopy(self.args.projects_conf[self.args.project]['environments'])
        self.args.projects_conf[self.args.project]['environments'][self.args.environment] = {
            "id": env_id,
            "conf": new_etlconf_name,
            "env_type": "dev"
        }
        projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'w') as projects_conf_file:
            json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        # create output folders
        self.etl_conf_name = new_etlconf_name
        self.__create_out_dirs()
        etl_print('', ETLMessageType.Ok, log=False)

        exclude = list()
        # copy conf templates if specified file don't exist
        try:
            utils.copy_conf_templates(self, exclude)
        except Exception:
            self.args.projects_conf[self.args.project]['environments'] = ref_copy
            with open(projects_conf_path, 'w') as projects_conf_file:
                json.dump(self.args.projects_conf, projects_conf_file, indent=4)
            raise E.JobInitException("Failed to copy configuration templates. Aborting 'new_env'..")

        etl_print(
            "New environment '{proj}.{env}' is created."
            .format(proj=self.args.project, env=self.args.environment),
            log=False
        )
        return 0

    def delete_project(self):
        etl_print(
            'Deleting project', ETLMessageType.Running, log=False
        )

        # update projects.conf
        project_conf = self.args.projects_conf.pop(self.args.project)
        projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'w') as projects_conf_file:
            json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        # if --clean-files was passed, clean the folder itself
        rm_errors = list()  # CDMK-314
        if self.args.clean_files is True:
            shutil.rmtree(project_conf['home'], onerror=lambda _, path, exc: rm_errors.append((path, str(exc[1]))))

        etl_print('', ETLMessageType.Ok, log=False)
        for path, exc in rm_errors:
            etl_print('Cannot delete {}: {}'.format(path, exc), ETLMessageType.Warning)
        etl_print(
            "Project '{proj}' has been deleted."
            .format(proj=self.args.project)
        )
        return 0

    def delete_env(self):
        etl_print(
            'Deleting environment', ETLMessageType.Running, log=False
        )

        # update projects.conf
        env_info = self.args.projects_conf[self.args.project]['environments'].pop(self.args.environment)
        projects_conf_path = os.path.join(self.args.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'w') as projects_conf_file:
            json.dump(self.args.projects_conf, projects_conf_file, indent=4)

        # if --clean-files was passed, clean env folders from disk
        if self.args.clean_files is True:
            self.etl_conf_name = env_info['conf']
            self.__delete_out_dirs()

        etl_print('', ETLMessageType.Ok, log=False)
        etl_print(
            "Environment '{proj}.{env}' has been deleted."
            .format(proj=self.args.project, env=self.args.environment)
        )
        return 0

    def build_graph(self):
        workflow_graph_path = os.path.join(self.etl_home,
                                           'reports',
                                           self.args.environment,
                                           'workflow_graph.json')
        confs = list()
        for conf_ref in self.etl_conf.run:
            try:
                workflow_conf_path = os.path.join(
                    self.etl_home, 'conf',
                    conf_ref['conf']
                )
                workflow_conf = configs.WorkflowConfig(workflow_conf_path)
                confs.append(workflow_conf)
            except (ValueError, KeyError, OSError, IOError) as e:
                raise E.ConfigException(
                    'Failed to read configuration file "{filename}"\n{exception}'
                    .format(
                        filename=workflow_conf_path,
                        exception=str(e)
                    )
                )
        workflow_conf = functools.reduce(lambda a, x: a + x, confs)
        workflow_conf.infer_doc_info = self.args.infer_doc_info

        try:
            from cdmkit.core.workflow_parser import parse_workflow
        except ImportError:
            etl_print('Skipping experimental workflow inference: sqlparse package is not found',
                      ETLMessageType.Warning)
        else:
            inferred_workflow = parse_workflow(self.etl_conf, workflow_conf, self.etl_home)
            workflow_inferred_path = os.path.join(self.etl_home, 'reports',
                                                self.args.environment, 'workflow_inferred_graph.json')
            with open(workflow_inferred_path, 'w') as workflow_inferred_file:
                json.dump(
                    inferred_workflow,
                    workflow_inferred_file,
                    indent=4
                )

        etl_print('Generating workflow graph', ETLMessageType.Running)
        generator = workflow_generator.WorkflowGenerator(self.etl_conf, workflow_conf, self.etl_home)
        try:
            process_results = generator.run()
        except E.JobExecException as e:
            etl_print('', ETLMessageType.Failed)
            etl_print(str(e))

        with open(workflow_graph_path, 'w') as workflow_graph_file:
            json.dump(
                process_results['workflow_graph'],
                workflow_graph_file,
                indent=4
            )

        etl_print('', ETLMessageType.Ok)

        # warnings about workflow annotations
        for s in process_results['workflow']:
            if 'statements' not in s.keys():
                continue
            for q in s['statements']:
                for w in q['doc_warnings']:
                    etl_print("'{}': {}".format(q['id'], w), ETLMessageType.Warning)
        return 0

    def load_etl_conf(self):
        etl_conf_path = os.path.join(self.etl_home, 'conf', self.etl_conf_name)
        try:
            self.etl_conf = configs.ETLConf.from_file(etl_conf_path)
        except (ValueError, FileNotFoundError) as e:
            raise E.ConfigException(
                "Failed to load '{filename}' configuration file."
                .format(filename=self.etl_conf_name),
                cause=e
            )

    def update_config(self):
        """
        Update <environment>.etlconf file

        :returns: 0 if all changes are made
        """
        etl_print(
            'Updating project configuration file', ETLMessageType.Running, log=False
        )

        with open(os.path.join(self.etl_home, 'conf', self.etl_conf_name), 'r') as conf_file:
            conf = json.load(conf_file)

        # 1. Update schema names
        if self.args.schemas is not None:
            if "schemas" not in conf:
                conf["schemas"] = dict()
            json_object = conf["schemas"]
            for s in self.args.schemas:
                etl_schema = s.split("=")[0]
                schema_name = s.split("=")[1]
                json_object.update({etl_schema: schema_name})

        # 2. Update general parameters
        if self.args.params is not None:
            if "params" not in conf:
                conf["params"] = dict()
            json_object = conf["params"]
            for s in self.args.params:
                param_name = s.split("=")[0]
                param_value = s.split("=")[1]
                json_object.update({param_name: param_value})

        # 3. Update job section parameters
        etlconf_job_sections = (
            "load", "srcstats", "ddl", "custom_voc",
            "run", "verify", "qa", "stats", "unload"
        )
        for job_section in etlconf_job_sections:
            fnames = getattr(self.args, job_section)
            if fnames is not None:
                conf[job_section] = list()
                json_object = conf[job_section]
                for file_name in fnames:
                    job_file = {"conf": file_name}
                    if job_file not in json_object:
                        json_object.append(job_file)

        with open(os.path.join(self.etl_home, 'conf', self.etl_conf_name), 'w') as conf_file:
            json.dump(conf, conf_file, indent=4)
        etl_print('', ETLMessageType.Ok)
        return 0

    def get_submit_string(self):
        """
        Check connection type and get the right SUBMIT_STRING.
        If connection_name is present, get details from connections.conf,
        otherwise use details straight from etlconf file.
        """
        conn_name = self.etl_conf.db.get('connection_name')
        if conn_name:
            with open(os.path.join(self.orchestration_home, 'conf', 'connections.conf'), 'r') as conn_file:
                connections = json.load(conn_file)
                conn_details = connections.get(conn_name)
        else:
            conn_details = self.etl_conf.db

        # no details -> no connection
        if not conn_details:
            raise E.ConfigException("Haven't found connection details.")

        dbms = conn_details['dbms']
        if dbms == 'spark':
            bin = conn_details.get('exec', 'spark-submit')
            spark_conf_path = os.path.join(self.orchestration_home, "conf", "spark_settings.ini")
            spark_settings = configs.SparkConfig(spark_conf_path, conn_details.get('config', None)).get_settings()
            bin_args = ["--master {master_mode}"] + [
                "--conf '{}={}'".format(param, value)
                for param, value in spark_settings
                if param in utils.DRIVER_JVM_PARAMS
            ]
            # NOTE: '--files {self.files_list}' removed due to filename collisions (CDMK-96).
        else:
            bin = conn_details.get('exec', 'python')
            bin_args = []
        self.SUBMIT_STRING = " ".join(
            [bin] + bin_args + [utils.JOB_RUNNER_TMPL] + utils.JOB_ARGS_TMPL
        )

    def __create_out_dirs(self):
        dirs = [
            os.path.join('log', os.path.splitext(self.etl_conf_name)[0]),
            os.path.join('temp', os.path.splitext(self.etl_conf_name)[0]),
            os.path.join('reports', os.path.splitext(self.etl_conf_name)[0]),
            os.path.join('reports', os.path.splitext(self.etl_conf_name)[0], 'run_log')
        ]

        for out_dir in dirs:
            if not os.path.exists(os.path.join(self.etl_home, out_dir)):
                os.makedirs(os.path.join(self.etl_home, out_dir))

    def __delete_out_dirs(self):
        dirs = [
            os.path.join('log', os.path.splitext(self.etl_conf_name)[0]),
            os.path.join('temp', os.path.splitext(self.etl_conf_name)[0]),
            os.path.join('reports', os.path.splitext(self.etl_conf_name)[0]),
        ]

        for out_dir in dirs:
            if os.path.exists(os.path.join(self.etl_home, out_dir)):
                shutil.rmtree(os.path.join(self.etl_home, out_dir))

    def _start_job_subprocess(self, submit_string):  # pragma: no cover
        try:
            rcode = subprocess.check_call(submit_string,
                                          shell=True,
                                          stdout=None,
                                          stderr=self.stderr)
        except subprocess.CalledProcessError as e:
            # error during job run
            rcode = e.returncode
        return rcode

    def _run_module(self, module_name, submit_id=None, add_params=None):
        import importlib
        # Databricks Notebooks run inside pre-existing Spark session, so running spark-submit is not an option
        # Solution: re-work CDMKit completely to support Notebooks in a nice, sensible & native manner
        # Or just import CDMKit scripts as modules, that works too I guess
        # Choo choo goes the crazy train

        # keep format aligned with self.SUBMIT_STRING
        run_id = self.run_id + ('' if submit_id is None else ('_' + str(submit_id)))
        # Add usual arguments for the job we want to run
        sys.argv = [module_name, '-h', self.etl_home, '-e', self.etl_conf_name, '-r', run_id, '-d']
        if add_params:
            sys.argv.extend(add_params)
        # Remove module if it exists so could re-import it for maximum damage. Required for workflow & qa jobs
        full_module_name = "cdmkit." + module_name
        if full_module_name in sys.modules:
            del sys.modules[full_module_name]
        rcode = 0   # assume successful run by default
        try:
            module = importlib.import_module(full_module_name, package="cdmkit")
            # rcode = module.return_code
        except SystemExit as e:
            if e.code != 0:
                rcode = e.code
                etl_print("Failed to run {} module, rcode={}".format(full_module_name, str(e)), ETLMessageType.Error)

        # Pretend it's a real actual genuine process and return the code
        return rcode

    def __submit_load_jobs(self):
        """
        Submit Data load jobs
        :returns: 0 if all jobs finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("load"):
            raise E.ConfigException(
                "Missing configuration for load job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, source_data_conf in enumerate(self.etl_conf.load):
            # submit job
            add_params = ['-s', source_data_conf["conf"], '-cs', self.args.create_schema]
            if self.args.cdp_compatible:
                add_params.append('-cdp')

            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=source_data_conf.get('master') or self.default_spark_master,
                runner='load.py',
                submit_id=str(submit_id),
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..\n' + submit_string, log=False)
            if self.args.notebook_run:
                return_code = self._run_module(module_name='load', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}.'.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(source_data_conf['conf'])
                self.__write_status_report('load', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to load data. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(source_data_conf['conf'])

            if self.args.gen_config:
                # generate srcstats configuration file
                source_data_conf_path = os.path.join(self.etl_home, "conf", source_data_conf["conf"])
                source_conf = configs.SourceConfig(source_data_conf_path)
                for i, batch in enumerate(source_conf.source_batches):
                    template = OrderedDict()
                    template['schema'] = batch.get("schema", "source_schema")
                    template['tables'] = [
                        {
                            "table": source_table['table'],
                            "custom_stats": []
                        }
                        for source_table in batch['source_tables']
                    ]
                    template_path = os.path.join(
                        self.etl_home, 'conf',
                        'AUTO_srcstats_{}_{}.conf'.format(os.path.splitext(source_data_conf["conf"])[0], i)
                    )
                    with open(template_path, 'w') as out:
                        json.dump(template, out, indent=4)

        self.__write_status_report('load', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))
        return 0

    def __submit_ddl_job(self):
        """
        Submit Data load jobs
        :returns: 0 if all jobs finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("ddl"):
            raise E.ConfigException(
                "Missing configuration for ddl job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, job_conf in enumerate(self.etl_conf.ddl):
            add_params = ['-s', job_conf['conf']] + self.job_params + ['-cs', self.args.create_schema]
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=job_conf.get('master') or self.default_spark_master,
                runner='ddl.py',
                submit_id=submit_id,
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..\n' + str(submit_string))
            if self.args.notebook_run:
                return_code = self._run_module(module_name='ddl', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}. '.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(job_conf['conf'])
                self.__write_status_report('ddl', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to run ddl job. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(job_conf['conf'])

        self.__write_status_report('ddl', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))
        return 0

    def __submit_run_workflow(self):
        if self.etl_conf.job_is_unconfigured("run"):
            raise E.ConfigException(
                "Missing configuration for run job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        conf = self.args.environment
        workflow_conf_path = None
        ALLOWED_ATTEMPTS = 2
        scripts_from_cmd = False
        scripts_selection_range = None

        confs = list()
        start_dt = datetime.datetime.now()
        # option 1 - manual task with command line params
        if self.args.scripts is not None or self.args.folders is not None:
            scripts_from_cmd = True
            confs.append(
                configs.WorkflowCustomConfig(
                    scripts=self.args.scripts,
                    folders=self.args.folders
                ))
        # option 2 - manual task without params -> use conf file
        else:
            for conf_ref in self.etl_conf.run:
                try:
                    workflow_conf_path = os.path.join(
                        self.etl_home, 'conf', conf_ref['conf']
                    )
                    confs.append(configs.WorkflowConfig(workflow_conf_path))
                except (ValueError, KeyError, OSError, IOError) as e:
                    raise E.ConfigException(
                        'Failed to read configuration file "{filename}"'
                        .format(filename=workflow_conf_path),
                        cause=e
                    )
        workflow_conf = functools.reduce(lambda a, x: a + x, confs)

        # apply a range script selection (if given)
        if self.args.stop is not None and not os.path.exists(os.path.join(self.etl_home, 'src', self.args.stop)):
            raise E.CLIArgsException('You have chosen a stop script that does not exist')
        if not scripts_from_cmd:
            scripts_selection_range = {
                'start': self.args.start,
                'stop': self.args.stop
            }

        workflow_conf.scripts_selection_range = scripts_selection_range
        workflow_conf.infer_doc_info = self.args.infer_doc_info

        # ========================================================
        try:
            from cdmkit.core.workflow_parser import parse_workflow
        except ImportError:
            etl_print('Skipping experimental workflow inference: sqlparse package is not found',
                      ETLMessageType.Warning)
        else:
            inferred_workflow = parse_workflow(self.etl_conf, workflow_conf, self.etl_home)
            workflow_inferred_path = os.path.join(self.etl_home, 'reports', conf, 'workflow_inferred_graph.json')
            with open(workflow_inferred_path, 'w') as workflow_inferred_file:
                json.dump(
                    inferred_workflow,
                    workflow_inferred_file,
                    indent=4
                )

        etl_print('Generating workflow graph', ETLMessageType.Running)

        generator = workflow_generator.WorkflowGenerator(self.etl_conf, workflow_conf, self.etl_home)
        try:
            process_results = generator.run()
        except E.JobExecException as e:
            etl_print('', ETLMessageType.Failed)
            etl_print(str(e))

        workflow_graph_path = os.path.join(
            self.etl_home, 'reports',
            conf, 'workflow_graph.json'
        )
        with open(workflow_graph_path, 'w') as workflow_graph_file:
            json.dump(
                process_results['workflow_graph'],
                workflow_graph_file,
                indent=4
            )
        etl_print('', ETLMessageType.Ok)
        # ========================================================
        # Delete temporary files once, if needed.
        # 'reset' only affects the first attempt, that is,
        # in case of job failure during the following ETL run
        # it will retry from the failed statement, not from the very beginning.
        if self.args.reset is True:
            tmp_file_paths = filter(
                os.path.exists,
                map(lambda tf: os.path.join(self.etl_home, 'temp', conf, tf),
                    ("run_workflow.json", "run_workflow_results.json"))
            )
            etl_print('Removing temporary workflow files', ETLMessageType.Running)
            for tmp_fpath in tmp_file_paths:
                os.remove(tmp_fpath)
            self.files_list = utils.collect_files(self)
            etl_print('', ETLMessageType.Ok)

        # ========================================================

        # run workflow
        workflow = process_results['workflow']
        failed_statement_id = self.__get_failed_statement()
        workflow_counts_path = os.path.join(
            self.etl_home, 'reports',
            conf, 'workflow_graph_counts.json'
        )
        if failed_statement_id is not None and os.path.exists(workflow_counts_path):
            # run after failure - try to append to previous run
            with open(workflow_counts_path, 'r') as workflow_graph_counts_file:
                workflow_counts = json.load(workflow_graph_counts_file)
        else:
            # new run - new counts
            workflow_counts = dict()
            with open(workflow_counts_path, 'w') as workflow_graph_counts_file:
                json.dump(workflow_counts, workflow_graph_counts_file, indent=4)

        attempt_num = 1
        # failover loop
        while attempt_num <= ALLOWED_ATTEMPTS:
            if failed_statement_id is not None:
                # cut workflow - collect the failed one and all following
                workflow = self.__seek_statement(workflow, failed_statement_id)
            # get scripts that must be executed
            if attempt_num == 1:
                wf_scripts = [w['script'] for w in workflow if "script" in w.keys()]
            # run workflow until something fails (hopefully not)
            new_failed_statement_id = self.__run_workflow(workflow, workflow_counts)
            if new_failed_statement_id is None:
                # we're all good!
                break
            if new_failed_statement_id == failed_statement_id:
                # this statement has failed on previous attempt too
                attempt_num += 1
            else:
                # this statement hasn't failed before, give it another shot
                failed_statement_id = new_failed_statement_id
                attempt_num = 2
            if attempt_num <= ALLOWED_ATTEMPTS:
                etl_print(
                    'Taking {attempt} attempt to run {statement_id}'.format(
                        statement_id=failed_statement_id,
                        attempt=attempt_num), ETLMessageType.Warning
                )
            else:
                etl_print(
                    'Statement {} failed more than {} times.'
                    .format(failed_statement_id, ALLOWED_ATTEMPTS),
                    ETLMessageType.Error
                )

                # save failed status
                failed_script = failed_statement_id[:failed_statement_id.rfind('.')].replace('.', '/', failed_statement_id.count('.')-2)
                failed_script_index = wf_scripts.index(failed_script)
                job_details = ''
                if failed_script_index > 0:
                    job_details += 'Run successfully: {}. '.format(', '.join(wf_scripts[:failed_script_index]))
                job_details += 'Failed to run: {}. '.format(failed_script)
                if failed_script_index+1 < len(wf_scripts):
                    job_details += 'No run: {}.'.format(', '.join(wf_scripts[failed_script_index+1:]))
                self.__write_status_report('run_workflow', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                return 1

        self.__write_status_report('run_workflow', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(wf_scripts)))
        return 0

    def __run_workflow(self, statements, workflow_counts):
        for submit_id, script in enumerate(statements):
            if script.get('type') == 'callable':
                # if this is an automation script, just run it and proceed
                etl_print(
                    'Running automation task {script}'
                    .format(script=script['call'][1]),
                    ETLMessageType.Running
                )
                try:
                    return_code = subprocess.call(script['call'], shell=False)
                except Exception as e:
                    etl_print('', ETLMessageType.Failed)
                    etl_print(str(e), ETLMessageType.Error)
                    sys.exit(1)
                etl_print('', ETLMessageType.Ok)
                continue
            etl_print(
                'Submitting run job for script {script}'
                .format(script=script['script'])
            )
            workflow_path = os.path.join(
                self.etl_home, 'temp',
                self.args.environment,
                'run_workflow.json'
            )
            with open(workflow_path, 'w') as workflow_file:
                json.dump(script['statements'], workflow_file, indent=4)

            add_params = ['-s', script['script']] + self.job_params
            if self.args.notebook_run:
                return_code = self._run_module(module_name='run_workflow', submit_id=submit_id, add_params=add_params)
            else:
                submit_string = self.SUBMIT_STRING.format(
                    self=self,
                    master_mode=self.default_spark_master,
                    runner='run_workflow.py',
                    submit_id=str(submit_id),
                    add_params=' '.join(add_params)
                )
                return_code = self._start_job_subprocess(submit_string)
                if return_code == 127:
                    raise E.JobInitException(
                        "Cannot start job subprocess. Check executable that is used to spawn a job ('{}')"
                        .format(submit_string.split()[0])
                    )

            run_results_path = os.path.join(
                self.etl_home, 'temp',
                self.args.environment,
                'run_workflow_results.json'
            )
            with open(run_results_path, 'r') as run_results_file:
                run_results = json.load(run_results_file)

            workflow_counts.update(run_results['run_info'])
            workflow_graph_counts_path = os.path.join(
                self.etl_home, 'reports',
                self.args.environment,
                'workflow_graph_counts.json'
            )
            with open(workflow_graph_counts_path, 'w') as workflow_graph_counts_file:
                json.dump(workflow_counts, workflow_graph_counts_file, indent=4)

            if return_code != 0:
                return self.__get_failed_statement()

        return None

    def __get_failed_statement(self):
        run_workflow_results_path = os.path.join(
            self.etl_home, 'temp',
            self.args.environment, 'run_workflow_results.json'
        )
        if not os.path.exists(run_workflow_results_path):
            return None

        with open(run_workflow_results_path, 'r') as workflow_results_file:
            previous_run_results = json.load(workflow_results_file)

        if 'fail_info' not in previous_run_results:
            return None

        return previous_run_results['fail_info'].get('statement_id')

    def __seek_statement(self, scripts, statement_id):
        failed_script = statement_id[:statement_id.rfind('.')].replace('.', '/', statement_id.count('.')-2)
        statement_found = False
        result = list()
        for script in scripts:
            if statement_found:
                result.append(script)
            else:
                result_statements = list()
                if 'statements' not in script:
                    continue
                for statement in script['statements']:
                    if statement['id'] == statement_id:
                        statement_found = True
                    if statement_found:
                        result_statements.append(statement)
                if statement_found:
                    result.append({
                        'script': script['script'],
                        'statements': result_statements
                    })

        if not result:
            etl_print("Workflow is empty. The script {} is no longer in the workflow configuration file.\n"
                      "Possible workarounds:\n"
                      "    - rerun job from the very beginning using --reset option;\n"
                      "    - run job from a specific script using --start <scriptname> option."
                      .format(failed_script), ETLMessageType.Warning)

        return result

    def __submit_verify_job(self):
        """
        Submit CDM tables unit testing job
        :returns: 0 if job is finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("verify"):
            raise E.ConfigException(
                "Missing configuration for verify job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        final_report_path = os.path.join(
            self.etl_home, 'reports', self.args.environment, "unit_testing.json"
        )

        if self.args.update_report:
            if not self.args.tables:
                etl_print('Unable to start verify job with --update-report option. No tables passed', ETLMessageType.Error)
                sys.exit(1)
            if not os.path.exists(final_report_path):
                etl_print('Unable to start verify job with --update-report option. The last report was not found', ETLMessageType.Error)
                sys.exit(1)

        # check if previous run failed; if yes, reuse run_id and start from failed conf
        temp_dir = os.path.join(self.etl_home, "temp", self.args.environment)
        errfile = next(
            (f for f in os.listdir(temp_dir) if f.startswith("verify_") and f.endswith(".failed")),
            None)
        start_id = 0
        if errfile is not None:
            if self.args.reset:
                os.remove(os.path.join(temp_dir, errfile))
                self.files_list = utils.collect_files(self)
            else:
                _, self.run_id, _id = os.path.splitext(errfile)[0].split("_")
                start_id = int(_id)

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, job_conf in enumerate(self.etl_conf.verify[start_id:], start_id):
            add_params = ['-s', job_conf['conf']] + self.job_params
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=job_conf.get('master') or self.default_spark_master,
                runner='verify.py',
                submit_id=submit_id,
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..\n' + submit_string, log=False)
            if self.args.notebook_run:
                return_code = self._run_module(module_name='verify', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}.'.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(job_conf['conf'])
                self.__write_status_report('verify', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to run verify job. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(job_conf['conf'])

        etl_print('Collecting full verify report', ETLMessageType.Running)
        report = self.__multi_config_reports("verify", self.etl_conf.verify)
        etl_print('', ETLMessageType.Ok)

        if self.args.update_report:
            etl_print('Updating report', message_type=ETLMessageType.Running)
            with open(final_report_path) as file:
                last_report = json.load(file)
            report = self.__update_report(last_report['report'], report)
        else:
            etl_print('Writing report', message_type=ETLMessageType.Running)

        write_report(final_report_path, report)
        self.__write_status_report('verify', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))
        etl_print('', ETLMessageType.Ok)

        return 0

    def __submit_qa_jobs(self):
        """
        Submit QA jobs
        :returns: 0 if all jobs finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("qa"):
            raise E.ConfigException(
                "Missing configuration for qa job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        qa_report_path = os.path.join(
            self.etl_home, 'reports', self.args.environment, "qa.json"
        )

        if self.args.update_report:
            if not self.args.scripts:
                etl_print('Unable to start qa job with --update-report option. No scripts passed', ETLMessageType.Error)
                sys.exit(1)
            if not os.path.exists(qa_report_path):
                etl_print('Unable to start qa job with --update-report option. The last report was not found', ETLMessageType.Error)
                sys.exit(1)

        start_dt = datetime.datetime.now()
        # clean temporary reports from previous QA run
        temp_dir = os.path.join(self.etl_home, 'temp', self.args.environment)
        qa_temp = map(
            lambda f: os.path.join(temp_dir, f),
            filter(lambda qa: qa.startswith("qa_") and qa.endswith(".json"),
                   os.listdir(temp_dir)))
        for stale_report in qa_temp:
            os.remove(stale_report)
        # remove deleted temp reports from files_list
        self.files_list = utils.collect_files(self)

        exec_status = dict()
        qa_report = list()
        submit_id = 0
        for conf_ref in self.etl_conf.qa:
            # option 1 - manual task with command line params
            if self.args.scripts is not None:
                qa_conf = configs.QACustomConfig(scripts=self.args.scripts)
            # option 2 - manual task without params -> use conf file
            else:
                try:
                    qa_conf_path = os.path.join(self.etl_home, 'conf', conf_ref['conf'])
                    qa_conf = configs.Config(qa_conf_path)
                except (ValueError, KeyError, OSError, IOError) as e:
                    raise E.ConfigException(
                        'Failed to read configuration file "{filename}"'.format(filename=qa_conf_path),
                        cause=e
                    )

            for script in qa_conf.scripts:
                submit_id += 1
                add_params = ['-s', script['script']] + self.job_params
                submit_string = self.SUBMIT_STRING.format(
                    self=self,
                    master_mode=self.default_spark_master,
                    runner='qa.py',
                    submit_id=submit_id,
                    add_params=' '.join(add_params)
                )
                etl_print("Submitting job (script '{}')..".format(script['script']))
                if self.args.notebook_run:
                    rcode = self._run_module(module_name='qa', submit_id=submit_id, add_params=add_params)
                else:
                    rcode = self._start_job_subprocess(submit_string)

                if rcode in (0, 121):
                    # 121 == executed with errors
                    qa_tmp_path = os.path.join(
                        temp_dir,
                        "qa" + utils.format_script_name(script['script']) + ".json"
                    )

                    try:
                        with open(qa_tmp_path, 'r') as tmp:
                            qa_report.append({
                                "config": conf_ref["conf"],
                                "report": json.load(tmp)
                            })
                    except (OSError, TypeError, IOError) as exc:
                        etl_print('', ETLMessageType.Failed)
                        raise E.JobReportException(cause=exc)

                exec_status[script['script']] = rcode

        if self.args.update_report:
            etl_print('Updating report', message_type=ETLMessageType.Running)
            with open(qa_report_path) as file:
                last_qa_report = json.load(file)
            qa_report = self.__update_qa_report(last_qa_report['report'], qa_report)
        else:
            etl_print('Writing report', message_type=ETLMessageType.Running)

        write_report(qa_report_path, qa_report)

        # save status
        run_scripts = [s for s, c in exec_status.items() if c == 0]
        failed_scripts = [s for s, c in exec_status.items() if c != 0]
        job_details = ''
        if len(run_scripts) > 0:
            job_details += 'Run successfully: {}. '.format(', '.join(run_scripts))
        if len(failed_scripts) > 0:
            job_details += 'Failed to run: {}.'.format(', '.join(failed_scripts))
        self.__write_status_report('qa', 'Failed' if len(failed_scripts) > 0 else 'Done', str(start_dt), str(datetime.datetime.now()), job_details)

        etl_print('', message_type=ETLMessageType.Ok)

        if len(failed_scripts) > 0:
            etl_print(
                "The following scripts executed with errors: " + ", ".join(failed_scripts),
                ETLMessageType.Warning)

        return 0

    def __submit_src_stats_job(self):
        """
        Submit source statistics generation job
        :returns: 0 if job is finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("srcstats"):
            raise E.ConfigException(
                "Missing configuration for srcstats job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        final_report_path = os.path.join(
            self.etl_home, 'reports', self.args.environment, "srcstats.json"
        )

        if self.args.update_report:
            if not self.args.tables:
                etl_print('Unable to start srcstats job with --update-report option. No tables passed', ETLMessageType.Error)
                sys.exit(1)
            if not os.path.exists(final_report_path):
                etl_print('Unable to start srcstats job with --update-report option. The last report was not found', ETLMessageType.Error)
                sys.exit(1)

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, job_conf in enumerate(self.etl_conf.srcstats):
            add_params = ['-s', job_conf["conf"]] + self.job_params
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=self.default_spark_master,
                runner='srcstats.py',
                submit_id=submit_id,
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..\n' + submit_string, log=False)
            if self.args.notebook_run:
                return_code = self._run_module(module_name='srcstats', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}.'.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(job_conf['conf'])
                self.__write_status_report('srcstats', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to run stats job. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(job_conf["conf"])

        etl_print('Collecting full srcstats report', ETLMessageType.Running)
        #Collecting of results of job in separate loop for supporting job restarting
        report = self.__multi_config_reports("srcstats", self.etl_conf.srcstats)
        etl_print('', ETLMessageType.Ok)

        if self.args.update_report:
            etl_print('Updating report', message_type=ETLMessageType.Running)
            with open(final_report_path) as file:
                last_report = json.load(file)
            report = self.__update_report(last_report['report'], report)
        else:
            etl_print('Writing report', message_type=ETLMessageType.Running)

        write_report(final_report_path, report)
        self.__write_status_report('srcstats', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))
        etl_print('', message_type=ETLMessageType.Ok)

        return 0

    def __submit_cdm_stats_job(self):
        """
        Submit CDM statistics generation job
        :returns: 0 if job is finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("stats"):
            raise E.ConfigException(
                "Missing configuration for cdmstats job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        # check if previous run failed; if yes, reuse run_id and start from failed conf
        temp_dir = os.path.join(self.etl_home, "temp", self.args.environment)
        errfile = next(
            (f for f in os.listdir(temp_dir) if f.startswith("cdmstats_") and f.endswith(".failed")),
            None)

        final_report_path = os.path.join(
            self.etl_home, 'reports', self.args.environment, "cdmstats.json"
        )

        if self.args.update_report:
            if not self.args.tables:
                etl_print('Unable to start cdmstats job with --update-report option. No tables passed', ETLMessageType.Error)
                sys.exit(1)
            if not os.path.exists(final_report_path):
                etl_print('Unable to start cdmstats job with --update-report option. The last report was not found', ETLMessageType.Error)
                sys.exit(1)

        start_id = 0
        if errfile is not None:
            if self.args.reset:
                os.remove(os.path.join(temp_dir, errfile))
                self.files_list = utils.collect_files(self)
            else:
                _, self.run_id, _id = os.path.splitext(errfile)[0].split("_")
                start_id = int(_id)

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, job_conf in enumerate(self.etl_conf.stats[start_id:], start_id):
            add_params = ['-s', job_conf["conf"]] + self.job_params
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=job_conf.get('master') or self.default_spark_master,
                runner='cdmstats.py',
                submit_id=submit_id,
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..\n' + submit_string, log=False)
            if self.args.notebook_run:
                return_code = self._run_module(module_name='cdmstats', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)

            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}.'.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(job_conf['conf'])
                self.__write_status_report('cdmstats', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to run stats job. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(job_conf['conf'])

        etl_print('Collecting full cdmstats report', ETLMessageType.Running)
        #Collecting of results of job in separate loop for supporting job restarting
        report = self.__multi_config_reports("cdmstats", self.etl_conf.stats)
        etl_print('', ETLMessageType.Ok)     

        if self.args.update_report:
            etl_print('Updating report', message_type=ETLMessageType.Running)
            with open(final_report_path) as file:
                last_report = json.load(file)
            report = self.__update_report(last_report['report'], report)
        else:
            etl_print('Writing report', message_type=ETLMessageType.Running)

        write_report(final_report_path, report)
        self.__write_status_report('cdmstats', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))
        etl_print('', message_type=ETLMessageType.Ok)

        return 0

    def __multi_config_reports(self, job_name, jobs):
        temp_dir = os.path.join(self.etl_home, "temp", self.args.environment)
        report = list()

        for id, job_conf in enumerate(jobs):
            temp_report_path = os.path.join(
                temp_dir,
                "{job}_{run_id}_{submit_id}.json".format(
                    job=job_name,
                    run_id=self.run_id,
                    submit_id=id
                )
            )

            try:
                with open(temp_report_path, "r") as trf:
                    temp_report = json.load(trf)

                if 'vocabs' in temp_report:
                    report.append({
                        "config": job_conf["conf"],
                        "tables": temp_report["tables"],
                        "vocabs": temp_report["vocabs"]
                    })
                else:
                    report.append({
                        "config": job_conf["conf"],
                        "tables": temp_report["tables"]
                    })                    
            except FileNotFoundError:
                raise E.JobReportException("File with index {} not found. Please re-start {} job with reset flag".format(id, job_name))

        return report

    def __submit_unload_job(self):
        """
        Submit Data unload jobs
        :returns: 0 if all jobs finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("unload"):
            raise E.ConfigException(
                "Missing configuration for unload job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )

        start_dt = datetime.datetime.now()
        run_jobs = []
        for submit_id, job_conf in enumerate(self.etl_conf.unload):
            add_params = ['-s', job_conf['conf']]
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=job_conf.get('master') or self.default_spark_master,
                runner='unload.py',
                submit_id=submit_id,
                add_params=' '.join(add_params)
            )
            etl_print('Submitting job..', log=False)
            if self.args.notebook_run:
                return_code = self._run_module(module_name='unload', submit_id=submit_id, add_params=add_params)
            else:
                return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                # save failed status
                job_details = ''
                if len(run_jobs) > 0:
                    job_details = 'Run successfully: {}.'.format(', '.join(run_jobs))
                job_details += 'Failed to run: {}.'.format(job_conf['conf'])
                self.__write_status_report('unload', 'Failed', str(start_dt), str(datetime.datetime.now()), job_details)

                raise E.JobException(
                    'Failed to unload data. Error code is {rcode}'
                    .format(rcode=return_code)
                )
            run_jobs.append(job_conf["conf"])

        self.__write_status_report('unload', 'Done', str(start_dt), str(datetime.datetime.now()), 'Run successfully: {}.'.format(', '.join(run_jobs)))

        return 0

    def __submit_command_runner(self):
        """
        Submit shell comand
        :returns: command return code
        """
        submit_string = self.SUBMIT_STRING.format(
            self=self,
            master_mode=self.default_spark_master,
            runner='command_runner.py',
            add_params='',
            submit_id=0
        )
        return_code = self._start_job_subprocess(submit_string)
        return return_code

    def __submit_patients_history(self):
        """
        Submit Patients History job
        :returns: 0 if finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("patients_history"):
            raise E.ConfigException(
                "Missing configuration for patients_history job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )
        submit_string = self.SUBMIT_STRING.format(
            self=self,
            master_mode=self.default_spark_master,
            runner='patients_history.py',
            submit_id=0,
            add_params=''
        )
        etl_print('Submitting job..', log=False)
        return_code = self._start_job_subprocess(submit_string)
        if return_code != 0:
            raise E.JobException(
                'Failed to generate sample patients history. '
                'Error code is {rcode}'.format(rcode=return_code)
            )
        return return_code

    def __submit_coverage_report(self):
        """
        Submit Source to CDM codes mapping job
        :returns: 0 if finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("coverage_report"):
            raise E.ConfigException(
                "Missing configuration for coverage_report job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )
        for submit_id, job_conf in enumerate(self.etl_conf.coverage_report):
            submit_string = self.SUBMIT_STRING.format(
                self=self,
                master_mode=job_conf.get('master') or self.default_spark_master,
                runner='coverage_report.py',
                submit_id=submit_id,
                add_params='-s ' + job_conf['conf'] + self.job_params
            )
            etl_print('Submitting job..\n' + submit_string, log=False)
            return_code = self._start_job_subprocess(submit_string)
            if return_code != 0:
                raise E.JobException(
                    'Failed to generate Source Data Coverage report. '
                    'Error code is {rcode}'.format(rcode=return_code)
                )
        return 0

    def __submit_custom_voc_merge_job(self):
        """
        Submit Merging of custom and OMOP vocabularies job
        :returns: 0 if finished successfully. Otherwise - 1
        """
        if self.etl_conf.job_is_unconfigured("custom_voc"):
            raise E.ConfigException(
                "Missing configuration for custom_voc job in '{conf}' file."
                .format(conf=self.etl_conf_name)
            )
        custom_voc_conf_name = self.etl_conf.custom_voc[0]['conf']
        other_params = ['-s', custom_voc_conf_name] + self.job_params + ['-cs', self.args.create_schema]
        if self.args.stats_only:
            other_params.append('--stats-only')
        submit_string = self.SUBMIT_STRING.format(
            self=self,
            master_mode=self.etl_conf.custom_voc[0].get('master') or self.default_spark_master,
            runner='custom_voc.py',
            submit_id=0,
            add_params=' '.join(other_params)
        )

        custom_voc_conf_path = os.path.join(self.etl_home, "conf", custom_voc_conf_name)
        custom_voc_conf = configs.CustomVocConfig(custom_voc_conf_path)
        omop_voc_schema = custom_voc_conf.schemas["omop_voc_schema"]
        custom_voc_schema = custom_voc_conf.schemas["custom_voc_schema"]
        if omop_voc_schema == custom_voc_schema:
            raise E.ConfigException(
                "Schema names 'omop_voc_schema' and 'custom_voc_schema' in '{conf}' file should have different values."
                .format(conf=custom_voc_conf_name)
            )

        workflow_list = [
            {"script": "1_cut_vocabularies.sql"},
            {"script": "2_create_stage.sql"},
            {"script": "3_create_amends.sql"}
        ]
        if self.args.merge_with_voc:
            workflow_list.append({"script": "4_vocs_with_amends.sql"})
        supp_path = pkg_resources.resource_filename('cdmkit', 'supplementary/custom_voc/')
        workflow_conf = configs.WorkflowReceivedConfig(workflow_list)
        try:
            workflow = workflow_generator.WorkflowGenerator(self.etl_conf, workflow_conf, supp_path).run()
        except E.JobExecException as e:
            etl_print('', ETLMessageType.Failed)
            etl_print(str(e))

        ddl_conf_paths = [
            os.path.join(supp_path, ddl)
            for ddl in ['amend_ddl.conf', 'merged_stage_ddl.conf', 'old_stage_ddl.conf', 'new_stage_ddl.conf', "final_voc_ddl.conf"]
        ]

        custom_map_tmp = {
            "workflow": workflow['workflow'],
            "ddl_conf_files": ddl_conf_paths,
            "ignore_level": self.args.ignore_level,
            "empty_old": self.args.empty_old,
            "empty_new": self.args.empty_new
        }
        temp_conf_path = os.path.join(self.etl_home, 'temp', self.args.environment, 'custom_voc.json')
        with open(temp_conf_path, 'w') as tmp_conf:
            tmp_conf.write(json.dumps(custom_map_tmp, indent=4))

        etl_print('Submitting job..', log=False)
        if self.args.notebook_run:
            return_code = self._run_module(module_name='custom_voc', add_params=other_params)
        else:
            return_code = self._start_job_subprocess(submit_string)

        return return_code

    def __create_status_report(self, path):
        """Create status.json file if it doesn't exist"""
        jobs = [
            'load',
            'srcstats',
            'ddl',
            'run_workflow',
            'verify',
            'qa',
            'cdmstats',
            'unload'
        ]
        status_report = OrderedDict()
        for j in jobs:
            status_report[j] = {'status': 'Never executed'}
        with open(path, 'w') as status_report_file:
            json.dump(status_report, status_report_file, indent=4)

    def __write_status_report(self, job_name, status, start_dt, end_dt, details):
        """Save status of executed job"""
        report_path = os.path.join(self.etl_home, 'reports', self.args.environment, 'status.json')
        if not os.path.exists(report_path):
            self.__create_status_report(report_path)
        with open(report_path, 'r') as report_file:
            status_report = json.load(report_file, object_pairs_hook=OrderedDict)

        status_report[job_name] = OrderedDict([('status', status), ('start_datetime', start_dt), ('end_datetime', end_dt), ('details', details)])
        with open(report_path, 'w') as report_file:
            json.dump(status_report, report_file, indent=4)

    def __update_report(self, report_old, report_new):
        for rn in report_new:
            is_new_config = True
            for ro in report_old:
                if ro['config'] == rn['config']:
                    is_new_config = False
                    for rnt in rn['tables']:
                        replaced = False
                        for i, rot in enumerate(ro['tables']):
                            if rnt['table'] == rot['table']:
                                replaced = True
                                ro['tables'][i] = rnt
                                break
                        if not replaced:
                            ro['tables'].append(rnt)
            if is_new_config:
                report_old.append(rn)
        return report_old

    def __update_qa_report(self, report_old, report_new):
        executed_scripts = set([test['script'] for ro in report_new for test in ro['report']])
        for ro in report_old:
            if ro['report'][0]['script'] in executed_scripts:
                report_old.remove(ro)
        for rn in report_new:
            report_old.append(rn)

        return report_old

# === MAIN ====================================================================

def run(args):
    start_time = datetime.datetime.now()

    if not any(x in args for x in ('-h', '--help', '--version')):
        etl_print('Starting CDMKit v{}'.format(CDMKIT_VERSION),
                  message_type=ETLMessageType.Titles, log=False)
        etl_print('Reading configuration files.',
                  ETLMessageType.Running, log=False)
    try:
        args_parser = CmdArgsParser()
        args_parser.parse_cmdargs(args)
    except E.CLIArgsException as e:
        etl_print('', ETLMessageType.Failed)
        etl_print('Failed to read CLI args:\n{exception}'
                  .format(exception=str(e)), ETLMessageType.Error)
        args_parser.parser.print_usage()
        return 2

    runner = None
    try:
        runner = EtlRunner(args_parser)
    except Exception as e:
        etl_print('', ETLMessageType.Failed)
        etl_print('Failed to initialize ETL runner:\n{exception}'
                  .format(exception=str(e)), ETLMessageType.Error)
        return 1

    etl_print('', ETLMessageType.Ok)

    try:
        job_result = runner.run()
    except (E.ConfigException, E.JobException) as e:
        job_result = 1
        etl_print('CDMKit failed. ' + str(e), ETLMessageType.Error)
    finally:
        run_time = datetime.datetime.now() - start_time
        etl_print('Run time: ' + str(run_time))

    if job_result == 0:
        etl_print('CDMKit successfully finished',
                  message_type=ETLMessageType.Titles)
    return job_result


def main():
    sys.exit(run(args=sys.argv))


if __name__ == "__main__":
    main()
