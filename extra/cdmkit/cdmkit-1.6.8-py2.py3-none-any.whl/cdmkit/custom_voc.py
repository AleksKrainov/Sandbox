import argparse
import json
import sys
from os import path

from cdmkit.core.utils import create_log_file, write_run_report
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core.exceptions import *
try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_stats_report(etl_home, etl_conf_file, stats):
    conf = path.splitext(etl_conf_file)[0]
    etl_print('Writing custom voc stats report', ETLMessageType.Running)
    report_path = path.join(etl_home, 'reports', conf, 'custom_voc_stats.json')
    try:
        with open(report_path, 'w') as report_file:
            json.dump(stats, report_file, indent=4)
    except (OSError, ValueError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise JobReportException(cause=exc)
    etl_print('', ETLMessageType.Ok)


# ======= Start ===============================================================

etl_print('Job custom_voc.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-s", dest="custom_voc_conf_file", type=str, required=True)
parser.add_argument("-cs", dest="create_schema", type=str)
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("--rule-col", dest="rule_col_name", type=str)
parser.add_argument("--stats-only", dest="stats_only", action='store_true')

# ======= 1. Parse command line args ==========================================

try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to custom_voc.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

run_id = parsed.run_id
etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
custom_voc_conf_file = parsed.custom_voc_conf_file
should_create_schema = parsed.create_schema != "no"
should_overwrite_schema = parsed.create_schema == "overwrite"
stats_only = parsed.stats_only

# ======= 2. Load configuration files =========================================

create_log_file(etl_home, etl_conf_file, 'custom_voc', custom_voc_conf_file)
conf = path.splitext(etl_conf_file)[0]
etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
custom_voc_conf_path = path.join(etl_home, 'conf', custom_voc_conf_file)
tmp_custom_voc_conf = path.join(etl_home, 'temp', conf, 'custom_voc.json')

try:
    etl_print('Reading custom_voc file {file}'.format(file=custom_voc_conf_path))
    custom_voc_conf = configs.CustomVocConfig(custom_voc_conf_path)
    with open(tmp_custom_voc_conf, 'r') as tmp_conf_file:
        tmp_conf = json.load(tmp_conf_file)
    for k, val in tmp_conf.items():
        setattr(custom_voc_conf, k, val)
except (OSError, ValueError, IOError) as e:
    print(
        'Failed to read configuration file "{filename}"\n{exception}'
        .format(filename=custom_voc_conf_path, exception=str(e))
    )
    sys.exit(1)

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="custom_voc")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.CustomVocMerger(session, etl_conf, custom_voc_conf)
else:
    runner = sql_core.CustomVocMerger(session, etl_conf, custom_voc_conf)

if should_create_schema:
    schema_tags = set(custom_voc_conf.schemas.values())
    schema_names = {etl_conf.schemas[s_tag] for s_tag in schema_tags}
    for s_name in schema_names:
        session.create_schema(s_name, overwrite=should_overwrite_schema)
# ======= 4. Run job ==========================================================

return_code = 0

if not stats_only:
    try:
        runner.run()
    except JobExecException as e:
        etl_print(
            'Job custom_voc failed\n{exception}'.format(exception=str(e)),
            ETLMessageType.Error
        )
        return_code = 1


# ======= 5. Collect statistics ===============================================

if isinstance(session, connections.SparkConnection):
    stats_runner = spark_core.CustomVocStatsGenerator(session, etl_conf)
else:
    stats_runner = sql_core.CustomVocStatsGenerator(session, etl_conf)
etl_print('Generating statistics for custom vocabularies tables', ETLMessageType.Running)
stats_runner.run()
etl_print('', ETLMessageType.Ok)
write_stats_report(etl_home, etl_conf_file, stats_runner.stats)

# ======= 6. Create run log ===================================================

try:
    write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'custom_voc')
except (E.JobReportException, AttributeError) as e:
    etl_print(
        'Run report is not created\n' + str(e),
        ETLMessageType.Warning
    )

etl_print('Job custom_voc finished')
sys.exit(return_code)

# ======= End ================================================================
