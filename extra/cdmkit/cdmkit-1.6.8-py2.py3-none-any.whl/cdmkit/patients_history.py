import argparse
import json
import sys
from os import path

from cdmkit.core.utils import create_log_file
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E
from cdmkit.core import job_reports

try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


def write_report(etl_home, etl_conf_file, stats):
    conf = path.splitext(etl_conf_file)[0]
    report_path = path.join(etl_home, 'reports', conf, 'patients_history.json')

    job_reports.write_report(report_path, stats)


# ======= Start ===============================================================

etl_print('Job patients_history.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-f", dest="row_id", action="store_false")  # sic!

# ======= 1. Parse command line args ==========================================

try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to patients_history.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
row_id = parsed.row_id

# ======= 2. Load configuration files =========================================

create_log_file(etl_home, etl_conf_file, 'patients_history')
conf = path.splitext(etl_conf_file)[0]
etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
patients_history_conf_path = path.join(etl_home, 'conf', 'patients_history.conf')

try:
    etl_print(
        'Reading patients history configuration file {file}'
        .format(file=patients_history_conf_path)
    )
    patients_history_conf = configs.Config(patients_history_conf_path)
except (OSError, ValueError, IOError) as e:
    print(
        'Failed to read patients history configuration file "{filename}"\n{exc}'
        .format(filename=patients_history_conf_path, exc=str(e))
    )
    sys.exit(1)

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="patients_history")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.SamplePatientsHistoryGenerator(session, etl_conf, patients_history_conf)
else:
    runner = sql_core.SamplePatientsHistoryGenerator(session, etl_conf, patients_history_conf)

# ======= 4. Run job ==========================================================

try:
    runner.run()
except E.JobExecException as e:
    etl_print(
        'Job patients_history failed\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    exit(1)

# ======= 5. Write job report =================================================

etl_print('Writing report file')
write_report(etl_home, etl_conf_file, runner.stats)

etl_print('Job patients_history finished')

# ======= End ================================================================
