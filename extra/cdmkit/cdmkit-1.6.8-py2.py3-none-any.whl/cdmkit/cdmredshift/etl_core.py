import datetime
import itertools
import json
import logging
import os
import re
import sys
import traceback
from copy import deepcopy

from cdmkit.core import configs, etl_print, ETLMessageType, utils
from cdmkit.core.job_reports import (
    QAStepInfo,
    ColumnStatsBase, SourceColumnStats,
    CDMDataStats, SourceDataStats,
)
from cdmkit.core.sql_tools import (
    apply_schemas, apply_params, resolve_if_macros, only_comments_in, strip_comments,
    split_into_queries, replace_identity, REDSHIFT, ATHENA, POSTGRES
)
from cdmkit.core.run_log import RunLog
from cdmkit.core import exceptions as E


# Python 2 + Unicode = trouble
if sys.version_info[0] == 2:
    str = unicode


class StatsAdapter:
    def __init__(self, session, schema, dirty_schema=None):
        self.__session = session
        self.__schema = schema
        self.__dirty_schema = dirty_schema

    def get_table_count(self, table):
        query = "SELECT COUNT(*) FROM {schema}.{table}".format(schema=self.__schema,
                                                               table=self.__session.quoted(table))
        result = self.__session.select_scalar(query, as_type=int)
        return result

    def get_distincts_count(self, table, column):
        query = "SELECT COUNT(DISTINCT {column_name}) FROM {schema_name}.{table_name}".format(
            column_name=column, schema_name=self.__session.quoted(self.__schema), table_name=self.__session.quoted(table)
        )
        result = self.__session.select_scalar(query, as_type=int)
        return result

    def get_nulls_count(self, table, column):
        query = "SELECT COUNT(*) FROM {schema_name}.{table_name} WHERE {column_name} IS NULL".format(
            column_name=column, schema_name=self.__session.quoted(self.__schema), table_name=self.__session.quoted(table)
        )
        result = self.__session.select_scalar(query, as_type=int)
        return result

    def get_top_values(self, table, column, rule_id=None, sample_limit=30, is_grouping=True):
        schema = self.__schema if rule_id is None else self.__dirty_schema
        query_start = (
            "SELECT {top} {column_name} as value, {count} as cnt"
            " FROM {schema_name}.{table_name}".format(top=self.__session.top_query.format(num=sample_limit),
                                                      column_name=self.__session.quoted(column),
                                                      schema_name=schema,
                                                      table_name=self.__session.quoted(table),
                                                      count="COUNT(*)" if is_grouping else "1")
        )
        query_rule = self._make_rule_filter(rule_id, start="WHERE")
        query_group = (
            " GROUP BY {column_name}"
            " ORDER BY cnt DESC".format(column_name=self.__session.quoted(column))
        )
        query_end = " {limit}".format(limit=self.__session.limit_query.format(num=sample_limit))

        query = query_start + query_rule + (query_group if is_grouping else "") + query_end
        res_rows = self.__session.select(query)
        data_sample = [
            {"value": str(row[0]) if row[0] is not None else None, "count": row[1]} for row in res_rows
        ]
        return data_sample

    def generate_table_data_sample(self, table_name, sample_limit):
        """
        Take first sample_limit rows from table.
        :param table_name: name of the table
        :param sample_limit: how many rows to take
        :return: table rows as list of dicts
        """
        result = list()
        rows = self.__session.select_dict(
            "SELECT {top} * FROM {schema_name}.{table_name} {limit}".format(
                top=self.__session.top_query.format(num=sample_limit),
                schema_name=self.__schema,
                table_name=self.__session.quoted(table_name),
                limit=self.__session.limit_query.format(num=sample_limit),
            )
        )
        for ds in rows:
            result.append(
                {key: str(value) for key, value in ds.items()}
            )
        return result

    def _make_rule_filter(self, rule_id, start=None, end=None):
        if rule_id is None and start is None and end is None:
            fltr = ""
        elif rule_id is None:
            fltr = "1=1"
        elif rule_id == "None":
            fltr = "{} IS NULL".format(self.RULE_COL)
        else:
            fltr = "{} = '{}'".format(self.RULE_COL, rule_id)
        return "" if not fltr else ' ' + ' '.join([x for x in (start, fltr, end) if x is not None]) + ' '


class CDMStatsGenerator:
    """CDM Statistics generator."""

    RULE_COL = "rule_id"

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.CDMStatsConfig`): job configuration object
        """
        self.__session = session
        self.__conf = conf
        self.__etl_conf = etl_conf
        self.stats = CDMDataStats()

        # TODO: purge cdm_schema, use target instead in all projects
        self.__target_schema = etl_conf.schemas.get('target_schema') or etl_conf.schemas['cdm_schema']
        self.__etl_schema = etl_conf.schemas.get('target_schema') or etl_conf.schemas['cdm_schema']
        self.__voc_schema = etl_conf.schemas.get('voc_schema') or etl_conf.schemas['target_schema']

        self.__stats_adapter = StatsAdapter(
            session,
            self.__target_schema,
            self.__etl_schema
        )
        self.run_log = RunLog()

    def run(self):
        """Generate CDM stats."""
        self.stats.created_date = datetime.datetime.now()
        self.__stats_adapter.RULE_COL = self.RULE_COL
        for table in self.__conf.tables:
            etl_print(
                'Generating stats for table "{table}"'
                .format(table=table['table']))
            try:
                with self.run_log.running("table_stats", table=table['table']):
                    table_stats = self.generate_table_stats(table)
                    if table_stats.stats.count > 0:
                        self.stats.vocabs = list(set(self.fetch_vocabularies(table_stats.table_name) + self.stats.vocabs))
            except Exception as e:
                raise E.JobExecException(cause=e)
            self.stats.table_stats.append(table_stats)

    def generate_table_stats(self, table_conf):
        """Generate stats for a single CDM table.

        Args:
            table_conf: stats configuration for the table

        Returns:
            :class:`CDMDataStats.TableStats`
        """
        table_stats = CDMDataStats.TableStats(table_conf['table'])
        with self.run_log.running("rule_stats", table=table_conf["table"], rule_id=None):
            table_name = utils.locate_table(self.__session, self.__target_schema, table_stats.table_name).split('.')[1]
            table_stats.stats = self.__generate_rule_stats(table_name)

        if table_stats.stats.count == 0:
            return table_stats

        if self.__conf.generate_table_data_sample:
            table_stats.data_sample = self.__stats_adapter.generate_table_data_sample(
                table_name, self.__conf.table_data_sample_rows
            )
        if 'custom_stats' in table_conf:
            custom_stats_list = list()
            custom_stats_conf = deepcopy(table_conf['custom_stats'])
            for stat in custom_stats_conf:
                etl_print(
                    "Generating custom stat '{stat_type}'".format(
                        stat_type=stat['type']),
                    ETLMessageType.Running
                )
                stat['data'] = self.__generate_custom_stats(table_name, stat)
                custom_stats_list.append(stat)
                etl_print('', ETLMessageType.Ok)

            table_stats.custom_stats = custom_stats_list

        rule_ids = self.collect_table_rules(table_conf['table'])
        rules_list = list()

        for rule_id in rule_ids:
            if len(rule_ids) == 1:
                # skip when single rule_id in whole table (CDMK-252)
                stats_copy = deepcopy(table_stats.stats)
                stats_copy.rule_id = rule_id
                rules_list.append(stats_copy)
                break
            etl_print(
                'Generating stats for "{rule_id}" rule'
                .format(rule_id=rule_id)
            )
            with self.run_log.running("rule_stats", table=table_conf["table"], rule_id=rule_id):
                rule_stats = self.__generate_rule_stats(table_name, rule_id=rule_id)

            if 'custom_stats' in table_conf and \
               table_conf.get('generate_custom_stats_by_rule', self.__conf.generate_custom_stats_by_rule) is True:
                rule_custom_stats = list()
                rule_custom_stats_conf = deepcopy(table_conf['custom_stats'])
                for stat in rule_custom_stats_conf:
                    etl_print(
                        "Generating custom stat '{stat_type}' ('{rule_id}' rule)".format(
                            stat_type=stat['type'], rule_id=rule_id),
                        ETLMessageType.Running
                    )
                    stat['data'] = self.__generate_custom_stats(table_name, stat, rule_id)
                    rule_custom_stats.append(stat)
                    etl_print('', ETLMessageType.Ok)
                rule_stats.custom_stats = rule_custom_stats
            rules_list.append(rule_stats)

        table_stats.rules = rules_list
        return table_stats

    def __generate_rule_stats(self, table_name, rule_id=None):
        """Count table-level basic statistics.

        Operates on all records by default, but if rule_id is present, operates on a subset.

        Args:
            table_name (str): table name, without schema
            rule_id (:obj:`str`, optional): business rule name

        Returns:
            :class:`CDMDataStats.RuleSubsetStats`
        """
        rule_stats = CDMDataStats.RuleSubsetStats()
        rule_stats.count = self.__get_table_count(table_name, rule_id)
        rule_stats.rule_id = rule_id
        if rule_id is None or self.__conf.generate_stats_by_rule is True:
            rule_stats.column_stats = self.__generate_column_stats(table_name, rule_id, rule_stats.count)
        return rule_stats

    def __generate_column_stats(self, table, rule_id=None, table_count=0):
        """Calculate basic column-level statistics.

        Args:
            table (str): table name, without schema
            rule_id (:obj:`str`, optional): business rule name
            table_count (int): number of records in the table. Defaults to 0.

        Returns:
            list: array of ColumnStatsBase objects
        """

        column_stats = list()
        columns = self.__session.get_columns_list(self.__target_schema if rule_id is None else self.__etl_schema, table)

        for column in columns:
            top_values = []
            nulls = 0
            distincts = 0

            if table_count > 0:
                distincts = self.__get_distincts_count(table, column['name'], rule_id)
                nulls = self.__get_nulls_count(table, column['name'], rule_id)
                top_values = self.__stats_adapter.get_top_values(table, column['name'], rule_id, self.__conf.column_data_sample_rows, distincts!=table_count)
                if column['name'].endswith('_concept_id'):
                    concept_names = self.__translate_concept_ids(*[v['value'] for v in top_values if v['value'] is not None])
                    top_values = [
                        {
                            'value': v['value'],
                            'name': concept_names.get(int(v['value'])) if v['value'] is not None else None,
                            'count': v['count']
                        }
                        for v in top_values
                    ]

            column_stats.append(ColumnStatsBase(column['name'], column['type'], top_values, nulls, distincts))

        return column_stats

    def __generate_custom_stats(self, table, stat, rule_id=None):
        """Calculate custom statistics.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration
        """
        CUSTOM_STATS = {
            'pie': self.__generate_custom_stats_pie,
            'mapping_rate': self.__generate_custom_stats_mapping_rate,
            'top_values': self.__generate_custom_stats_top_values,
            'top_mapped_concepts': self.__generate_custom_stats_top_mapped_concepts,
            'top_unmapped_concepts': self.__generate_custom_stats_top_unmapped_concepts,
            'foreign_keys_rate': self.__generate_custom_stats_foreign_key_rate,
            'distribution': self.__generate_custom_stats_distribution,
            'first_last_values': self.__generate_custom_stats_boundary_values
        }
        return CUSTOM_STATS[stat['type']](table, stat, rule_id)

    def __generate_custom_stats_pie(self, table, stat, rule_id):
        """Collect distinct values distribution for pie chart.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            list: custom stat data
        """
        val_counts = self.__session.select(
            "SELECT {top} {column_name}, COUNT(*) as cnt FROM {schema_name}.{table_name}{rules} GROUP BY {column_name} {limit}"
            .format(top=self.__session.top_query.format(num=100),
                    column_name=self.__session.quoted(stat['column']),
                    schema_name=self.__target_schema,
                    table_name=table,
                    rules=self._make_rule_filter(rule_id, start="WHERE"),
                    limit=self.__session.limit_query.format(num=100))
        )

        value_names = dict()
        if stat.get('is_concept') is True:
            value_names = self.__translate_concept_ids(*[v[0] for v in val_counts if v[0] is not None])

        data = list()
        for val_count in val_counts:
            value = val_count[0]
            if stat.get('is_concept') is True and value is not None:
                value = value_names.get(value)

            data.append({
                'value': value,
                'count': val_count[1]
            })

        return data

    def __generate_custom_stats_mapping_rate(self, table, stat, rule_id):
        """Calculate mapping rate for a concept_id field.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            dict: custom stat data
        """
        # ### RECORDS ####
        # 1) Unmapped - have concept_id == 0
        q_unmapped = (
            "SELECT COUNT(*) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{column_name} = 0 AND {source_column} IS NOT NULL"
            .format(
                column_name=self.__session.quoted(stat['column']),
                source_column=self.__session.quoted(stat['source_column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        unmapped_count = self.__session.select_scalar(q_unmapped, as_type=int)

        # 2) Amendment concepts - have concept_id > 2 billion
        q_amended = (
            "SELECT COUNT(*) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{column_name} > 2000000000 AND {source_column} IS NOT NULL"
            .format(
                column_name=self.__session.quoted(stat['column']),
                source_column=self.__session.quoted(stat['source_column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        amended_count = self.__session.select_scalar(q_amended, as_type=int)

        table_count = self.__get_table_count(table, rule_id=rule_id)
        # 3) Concepts mapped to standard vocs - all the rest
        mapped_count = table_count - unmapped_count - amended_count

        # ### CODES ####
        # The story is almost the same, but we collect mapped and amended,
        # thus considering the rest unmapped.
        q_distinct_codes = (
            "SELECT COUNT(DISTINCT({column_name})) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{column_name} IS NOT NULL"
            .format(
                column_name=self.__session.quoted(stat['source_column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        distinct_codes = self.__session.select_scalar(q_distinct_codes, as_type=int)

        q_mapped_count_codes = (
            "SELECT COUNT(*) FROM"
            " (SELECT COUNT(*) c"
            "  FROM {schema_name}.{table_name}"
            "  WHERE {rls}{source_column} IS NOT NULL"
            "  GROUP BY {source_column}"
            "  HAVING MAX({concept_column}) != 0"
            "  AND MAX({concept_column}) < 2000000000) AS a"
            .format(
                source_column=self.__session.quoted(stat['source_column']),
                concept_column=self.__session.quoted(stat['column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        mapped_count_codes = self.__session.select_scalar(q_mapped_count_codes, as_type=int)

        q_amended_count_codes = (
            "SELECT COUNT(*) FROM"
            " (SELECT COUNT(*) c"
            "  FROM {schema_name}.{table_name}"
            "  WHERE {rls}{source_column} IS NOT NULL"
            "  GROUP BY {source_column}"
            "  HAVING MIN({concept_column}) > 2000000000) AS a"
            .format(
                source_column=self.__session.quoted(stat['source_column']),
                concept_column=self.__session.quoted(stat['column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        amended_count_codes = self.__session.select_scalar(q_amended_count_codes, as_type=int)

        unmapped_count_codes = distinct_codes - mapped_count_codes - amended_count_codes

        data = {
            "records": [
                {
                    'value': 'mapped',
                    'count': mapped_count
                },
                {
                    'value': 'amended',
                    'count': amended_count
                },
                {
                    'value': 'unmapped',
                    'count': unmapped_count
                }
            ],
            "codes": [
                {
                    'value': 'mapped',
                    'count': mapped_count_codes
                },
                {
                    'value': 'amended',
                    'count': amended_count_codes
                },
                {
                    'value': 'unmapped',
                    'count': unmapped_count_codes
                }
            ]
        }
        return data

    def __generate_custom_stats_top_mapped_concepts(self, table, stat, rule_id):
        """Collect top N mapped concepts with concept names.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            list: custom stat data
        """
        data = list()
        q_string = (
            "SELECT {top}{column_name}, COUNT(*) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{column_name} != 0"
            " GROUP BY {column_name}"
            " ORDER BY cnt DESC"
            " {limit}"
            .format(
                top=self.__session.top_query.format(num=stat['num']),
                column_name=self.__session.quoted(stat['column']),
                schema_name=self.__target_schema,
                table_name=table,
                limit=self.__session.limit_query.format(num=stat['num']),
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        val_counts_mapped = self.__session.select(q_string)

        value_names = self.__translate_concept_ids(*[v[0] for v in val_counts_mapped if v[0] is not None])

        for val in val_counts_mapped:
            data.append({
                'value': value_names.get(val[0]),
                'count': val[1]
            })

        return data

    def __generate_custom_stats_top_unmapped_concepts(self, table, stat, rule_id):
        """Collect top N unmapped source codes.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            list: custom stat data
        """
        data = list()
        q_string = (
            "SELECT {top} {column_name}, COUNT(*) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{concept_column_name} = 0"
            " GROUP BY {column_name}"
            " ORDER BY cnt DESC {limit}"
            .format(top=self.__session.top_query.format(num=stat['num']),
                    column_name=self.__session.quoted(stat['column']),
                    concept_column_name=self.__session.quoted(stat['concept_column']),
                    schema_name=self.__target_schema,
                    table_name=table,
                    limit=self.__session.limit_query.format(num=stat['num']),
                    rls=self._make_rule_filter(rule_id, end="AND"))
        )
        val_counts_unmapped = self.__session.select(q_string)

        for val in val_counts_unmapped:
            data.append({
                'value': str(val[0]),
                'count': val[1]
            })

        return data

    def __generate_custom_stats_top_values(self, table, stat, rule_id):
        """Collect top N mapped concepts with concept names.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            list: custom stat data
        """
        data = list()
        q_string = (
            "SELECT {top}{column_name}, COUNT(*) as cnt"
            " FROM {schema_name}.{table_name}"
            " WHERE {rls}{column_name} IS NOT NULL"
            " GROUP BY {column_name}"
            " ORDER BY cnt DESC"
            " {limit}"
            .format(
                top=self.__session.top_query.format(num=stat['num']),
                column_name=self.__session.quoted(stat['column']),
                schema_name=self.__target_schema,
                table_name=table,
                limit=self.__session.limit_query.format(num=stat['num']),
                rls=self._make_rule_filter(rule_id, end="AND"))
        )
        val_counts = self.__session.select(q_string)

        for val in val_counts:
            data.append({
                'value': str(val[0]),
                'count': val[1]
            })

        return data

    def __generate_custom_stats_foreign_key_rate(self, table, stat, rule_id):
        """Calculate the percentage of values from foreign column present in current field.

        Referenced field might contain duplicates.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            dict: custom stat data
        """
        distincts_count = self.__session.select_scalar(
            "SELECT COUNT(DISTINCT({column_name})) as cnt FROM {schema_name}.{table_name}{rls}"
            .format(
                column_name=self.__session.quoted(stat['column']),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, start="WHERE"))
        )
        fk_ref = configs.ForeignKeyRef(stat['target_table'])
        fk_schema_name = self.__target_schema if not fk_ref.schema_tag else self.__etl_conf.schemas[fk_ref.schema_tag]
        ref_table_count = self.__session.select_scalar(
            "SELECT COUNT(DISTINCT({column_name})) as cnt FROM {table}"
            .format(
                column_name=self.__session.quoted(fk_ref.field_name) or self.__session.quoted(stat['column']),
                table=utils.locate_table(self.__session, fk_schema_name, fk_ref.table_name)
            )
        )

        data = {
            'mapped': distincts_count,
            'unmapped': ref_table_count - distincts_count
        }

        return data

    def __generate_custom_stats_distribution(self, table, stat, rule_id):
        """Prepare data for Distribution custom stat.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            list: custom stat data
        """
        data = list()
        selector = "{column}"
        if stat.get('extract_year'):
            selector = self.__session.extract_year_query
        query = """
            SELECT {selector} as val, COUNT(*) as cnt
             FROM {schema_name}.{table_name}{rls}
            GROUP BY {selector} ORDER BY {selector}
            """.format(
                selector=selector.format(column=self.__session.quoted(stat['column'])),
                schema_name=self.__target_schema,
                table_name=table,
                rls=self._make_rule_filter(rule_id, start="WHERE"))
        val_counts_mapped = self.__session.select(query)
        for val in val_counts_mapped:
            data.append({
                'value': str(val[0]),
                'count': val[1]
            })

        return data

    def __generate_custom_stats_boundary_values(self, table, stat, rule_id):
        """Prepare data for Top/Bottom Values custom stat.

        Args:
            table (str): table name, without schema
            stat (dict): custom stat configuration

        Returns:
            dict: extracted values, by key ('first_values', 'last_values').
        """
        values_amount = 10

        if 'num' in stat:
            values_amount = stat['num']

        data = {
            'first_values': [],
            'last_values': []
        }

        first_values = self.__session.select(
            "SELECT DISTINCT {top}{column_name} "
            "FROM {schema_name}.{table_name}{rls} "
            "ORDER BY {column_name} "
            "{limit}"
            .format(column_name=self.__session.quoted(stat['column']),
                    schema_name=self.__target_schema, table_name=table,
                    top=self.__session.top_query.format(num=values_amount),
                    limit=self.__session.limit_query.format(num=values_amount),
                    rls=self._make_rule_filter(rule_id, start="WHERE"))
        )
        last_values = self.__session.select(
            "SELECT DISTINCT {top}{column_name} "
            "FROM {schema_name}.{table_name}{rls} "
            "ORDER BY {column_name} DESC "
            "{limit}"
            .format(column_name=self.__session.quoted(stat['column']),
                    schema_name=self.__target_schema, table_name=table,
                    top=self.__session.top_query.format(num=values_amount),
                    limit=self.__session.limit_query.format(num=values_amount),
                    rls=self._make_rule_filter(rule_id, start="WHERE"))
        )

        for row_1, row_2 in zip(first_values, last_values):
            data['first_values'].append(str(row_1[0]))
            data['last_values'].append(str(row_2[0]))

        return data

    def __translate_concept_ids(self, *concept_ids):
        """
        Tries to fetch human-readable form for list of concept_id
        if they are present in OMOP Standardized Vocabularies.

        Returns:
            dict: "concept_id": "concept_name"
        """
        if not concept_ids:
            return dict()
        concept_table = utils.locate_table(self.__session, self.__voc_schema, 'concept')
        query = (
            "SELECT concept_id, concept_name"
            " FROM {concept_table}"
            " WHERE concept_id IN ({concept_values})"
            .format(
                concept_table=concept_table,
                concept_values=",".join(str(x) for x in concept_ids)
                )
        )
        res_rows = self.__session.select(query)
        res = [{r[0]: r[1]} for r in res_rows]
        result = {k: v for d in res for k, v in d.items()}

        return result

    def __get_table_count(self, table, rule_id=None):
        schema_to_use = self.__target_schema if rule_id is None else self.__etl_schema
        full_table_name = utils.locate_table(self.__session, schema_to_use, table)
        query = "SELECT COUNT(*) FROM {t} {rls}".format(t=full_table_name, rls=self._make_rule_filter(rule_id, start="WHERE"))
        return self.__session.select_scalar(query, as_type=int)

    def __get_distincts_count(self, table, column, rule_id=None):
        schema_to_use = self.__target_schema if rule_id is None else self.__etl_schema
        full_table_name = utils.locate_table(self.__session, schema_to_use, table)
        query = (
            "SELECT COUNT(DISTINCT {column_name})"
            " FROM {full_table_name} {rls}"
            .format(
                column_name=self.__session.quoted(column),
                full_table_name=full_table_name,
                rls=self._make_rule_filter(rule_id, start="WHERE")
            )
        )
        return self.__session.select_scalar(query, as_type=int)

    def __get_nulls_count(self, table, column, rule_id=None):
        schema_to_use = self.__target_schema if rule_id is None else self.__etl_schema
        full_table_name = utils.locate_table(self.__session, schema_to_use, table)
        query = (
            "SELECT COUNT(*)"
            " FROM {full_table_name}"
            " WHERE {rls} {column_name} IS NULL"
            .format(
                column_name=self.__session.quoted(column),
                full_table_name=full_table_name,
                rls=self._make_rule_filter(rule_id, end="AND")
            )
        )
        return self.__session.select_scalar(query, as_type=int)

    def collect_table_rules(self, table_name):
        """Collect distinct rule_id values from table.

        If table does not contain 'rule_id' field -> return empty list.
        If table does not contain 'rule_id' other than NULL -> return empty list.

        Pay attention that rules are not present in 'target_schema',
        therefore we use corresponding table from 'cdm_schema' with '_f' postfix.

        Args:
            table_name (str): table name without schema

        Returns:
            list: list of string rule ids or empty list
        """
        full_table_name = utils.locate_table(self.__session, self.__etl_schema, table_name)
        if self.RULE_COL not in [c['name'] for c in self.__session.get_columns_list(*full_table_name.split('.'))]:
            return list()
        query = "SELECT DISTINCT({}) FROM {};".format(self.RULE_COL, full_table_name)
        rules = [str(row[0]) for row in self.__session.select(query)]
        if rules == ["None"]:
            # NULL is the only value -> column is present, but no rules
            return list()
        return rules

    def _make_rule_filter(self, rule_id, start=None, end=None):
        # helper func to ease rule_id filtering in methods
        if rule_id is None and start is None and end is None:
            fltr = ""
        elif rule_id is None:
            fltr = "1=1"
        elif rule_id == "None":
            fltr = "{} IS NULL".format(self.RULE_COL)
        else:
            fltr = "{} = '{}'".format(self.RULE_COL, rule_id)
        return "" if not fltr else ' ' + ' '.join([x for x in (start, fltr, end) if x is not None]) + ' '

    def fetch_vocabularies(self, table_name):
        """Fetch all vocabularies are used in provided table

        Args:
            table_name (str): Table for what vocabularies must be extracted
        Returns:
            [List]: List of vocabularies are used in provided table
        """
        concept_table = utils.locate_table(self.__session, self.__voc_schema, 'concept')
        table = utils.locate_table(self.__session, self.__etl_schema, table_name)
        query = (
            "SELECT DISTINCT c.vocabulary_id"
            " FROM {table} as src"
            " INNER JOIN {concept} as c"
            " ON c.concept_id = src.{column}"
            " WHERE {column} != 0"
        )
        vocabularies = set()
        columns = self.__session.get_columns_list(table.split('.')[0], table.split('.')[1])

        for column in [c['name'] for c in columns]:
            if "_concept_id" in column and "_type_concept_id" not in column:
                qf = query.format(table=table, concept=concept_table, column=column)
                vocabularies.update([row[0] for row in self.__session.select(qf)])

        return list(vocabularies)


class SourceDataStatsGenerator:
    """Source Data Statistics generator."""
    default_schema_tag = "source_schema"

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.StatsConfig`): job configuration object
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.stats = SourceDataStats()
        schema_tag = getattr(self.__conf, "schema") or self.default_schema_tag
        self.__schema = self.__etl_conf.schemas[schema_tag]
        self.__stats_adapter = StatsAdapter(session, self.__etl_conf.schemas[schema_tag])
        self.run_log = RunLog()

    def run(self):
        """Generate source data stats."""
        self.stats.created_date = datetime.datetime.now()

        should_autodiscover = len(self.__conf.tables) == 0
        if should_autodiscover:
            tables = self.get_source_tables(self.__schema)
            if len(tables) == 0:
                raise ValueError("No tables are found in '{}' schema.".format(self.__schema))
        else:
            self.check_if_tables_exists(self.__conf.tables)
            tables = self.__conf.tables

        for table in tables:
            etl_print(
                'Generating source stats for table "{table}"'
                .format(table=table['table']))
            with self.run_log.running("srcstats_table", table=table["table"]):
                table_stats = self.generate_table_stats(table)
                self.stats.table_stats.append(table_stats)

    def get_source_tables(self, schema):
        """Get all tables from source schema in conf-like format.

        Args:
            schema: String which represent schema where table is kept

        Returns:
            List of source tables
        """
        etl_print("Getting all tables from the source schema")
        return [
            {"table": table}
            for table in self.__session.get_table_list(schema)
        ]

    def check_if_tables_exists(self, tables):
        etl_print("Check if all tables exists")

        has_an_error = False
        tables_in_schema = self.__session.get_table_list(self.__schema)
        for table in tables:
            if table['table'].lower() not in tables_in_schema:
                has_an_error = True
                etl_print("Table {} has not been found.".format(table['table']), ETLMessageType.Error)

        if has_an_error:
            raise ValueError("Some of the tables have not been found. Please check table names")

    def generate_table_stats(self, table_conf):
        """Generate stats for a single table.

        Args:
            table_conf: stats configuration for the table

        Returns:
            :class:`SourceDataStats.SourceTableStats`
        """
        table_name = table_conf["table"]
        table_stats = SourceDataStats.SourceTableStats(table_name)
        table_stats.count = self.__stats_adapter.get_table_count(table_name)
        table_stats.stats = self.__generate_column_stats(
            table=table_name,
            limit=self.__conf.column_data_sample_rows,
            table_count=table_stats.count
        )

        if self.__conf.generate_table_data_sample:
            table_stats.data_sample = self.__stats_adapter.generate_table_data_sample(table_name, 10)

        return table_stats

    def __generate_column_stats(self, table, limit, table_count):
        """Calculate basic column-level statistics.

        Args:
            table (str): table name, without schema

        Returns:
            list: array of SourceColumnStats objects
        """
        column_stats = list()
        columns = self.__session.get_columns_list(self.__schema, table)
        for column in columns:
            etl_print(
                'Generating source stats for column "{col}".'.format(col=column['name']),
                ETLMessageType.Running
            )
            distincts_count = self.__stats_adapter.get_distincts_count(table, column['name'])
            nulls_count = self.__stats_adapter.get_nulls_count(table, column['name'])
            top_values = self.__stats_adapter.get_top_values(
                table=table,
                column=column['name'],
                sample_limit=limit,
                is_grouping=(distincts_count!=table_count)
            )

            col_stats = SourceColumnStats(column['name'], column['type'], top_values, nulls_count, distincts_count)
            column_stats.append(col_stats)
            etl_print('', ETLMessageType.Ok)

        return column_stats


class SamplePatientsHistoryGenerator:
    SAMPLE_ROW_COUNT = 5

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.Config`): job configuration object
        """
        self.__session = session
        self.__conf = conf
        self.__etl_conf = etl_conf
        self.stats = list()
        self.__stats_adapter = StatsAdapter(session, self.__etl_conf.schemas["target_schema"])

    def run(self):
        """Collect patient records."""
        pat_records = self.__get_patients_sample()

        for patient in pat_records:
            patient_rec = dict()
            patient_rec['key'] = patient
            patient_rec['source_records'] = self.__get_source_patient_records(patient)
            patient_rec['cdm_records'] = self.__get_cdm_patient_records(patient)

            self.stats.append(patient_rec)

    def __get_patients_sample(self):
        sample_limit = self.__conf.patient_ids['num']
        rows = self.__session.select_dict(
            "SELECT {top} {columns} FROM {schema_name}.{table_name} {limit}".format(
                top=self.__session.top_query.format(num=sample_limit),
                columns=','.join(self.__conf.source_patient_key),
                schema_name=self.__etl_conf.schemas["source_schema"],
                table_name=self.__conf.source_patient_table,
                limit=self.__session.limit_query.format(num=sample_limit),
            )
        )
        return [
            {key: str(value) for key, value in row.items()}
            for row in rows
        ]

    def __get_cdm_patient(self, source_patient):
        qualification = self.__conf.source_cdm_join_rule
        for column in source_patient:
            qualification = qualification.replace(column, source_patient[column])
        schema_name = self.__etl_conf.schemas["target_schema"]
        query = "SELECT person_id FROM {full_table_name} WHERE {qual}".format(
                full_table_name=utils.locate_table(self.__session, schema_name, "person"),
                qual=qualification)
        result = self.__session.select_scalar(query, as_type=int)
        return result

    def __get_source_patient_records(self, patient):
        records = dict()
        for table in self.__conf.source_tables:
            qualification = ' AND '.join([field + " = '" + patient[field] + "'" for field in self.__conf.source_patient_key])
            query = "SELECT * FROM {schema_name}.{table_name} WHERE {qual}".format(
                schema_name=self.__etl_conf.schemas["source_schema"],
                table_name=table['table'],
                qual=qualification)

            try:
                rows = self.__session.select_dict(query)
                records[table['table']] = [
                    {key: str(value) for key, value in row.items()}
                    for row in rows
                ]
            except Exception:
                print(table['table'] + ' FAILED')

        return records

    def __get_cdm_patient_records(self, patient):
        records = dict()
        person_id = self.__get_cdm_patient(patient)

        schema_name = self.__etl_conf.schemas["target_schema"]
        for table in self.__conf.cdm_tables:
            query = "SELECT * FROM {full_table_name} WHERE person_id = {person}".format(
                full_table_name=utils.locate_table(self.__session, schema_name, table["table"]),
                person=person_id)

            try:
                rows = self.__session.select_dict(query)
                records[table['table']] = [
                    {key: str(value) for key, value in row.items()}
                    for row in rows
                ]
            except Exception:
                print(table['table'] + ' FAILED')

        return records


class WorkflowRunner(object):
    """Runs ETL workflow and collects execution details."""

    def __init__(self, session, etl_conf, should_count=True):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            should_count (bool): collect number of records in affected tables. Defaults to True.
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.run_info = dict()
        self.fail_info = dict()
        self.should_count = should_count
        self.params = etl_conf.params
        self.run_log = RunLog()

    def run(self, workflow):
        """Run all SQL queries."""
        for statement in workflow:
            start_time = datetime.datetime.now()

            try:
                with self.run_log.running("run_sql_statement", statement_id=statement['id']):
                    self.run_sql_statement(statement['sql'])
            except Exception as e:
                self.fail_info = {
                    'statement_id': statement['id'],
                    'error': str(e)
                }
                raise E.JobExecException(cause=e)

            end_time = datetime.datetime.now()

            if statement.get('doc_info') and self.should_count:
                self.run_info[statement['id']] = {
                    'run_time': str(end_time - start_time),
                    'count': self._get_table_count(statement['doc_info']['table']) if self.__session.cur.rowcount == -1 else self.__session.cur.rowcount
                }

        if self.should_count:
            self._collect_tables_info(workflow)

    def run_sql_statement(self, sql_statement):
        """Run single SQL statement against database.

        Args:
            sql_statement (str): SQL statement without semicolon.

        """
        if sql_statement.replace('*', '').replace('-', '').strip() == '':
            return

        query_cleans_data = re.search(
            r"^((drop|truncate)\s+table\s+)(if\s+exists\s+)?(@?[a-z_0-9]+)[.]([a-z_0-9]+)",
            strip_comments(sql_statement.lower())
        )

        if query_cleans_data:
            schema = query_cleans_data.group(4)
            table = query_cleans_data.group(5)
            # Fetch count for tmp_ table before it is dropped
            if table.startswith('tmp_') and self.should_count:
                self.run_info[schema + '.' + table] = {
                    'run_time': None,
                    'count': self._get_table_count(schema + '.' + table)
                }

        sql_statement = self.__session.adjust_sql_statement(sql_statement, self.__etl_conf)
        sql_statement = apply_schemas(sql_statement, self.__etl_conf.schemas)
        if '@db.dbms' in self.__etl_conf.params and 'db.dbms' in sql_statement:
            etl_print("Macros 'db.dbms' will be skipped. There is a regular parameter with the same name.", ETLMessageType.Warning)
        else:
            sql_statement = sql_statement.replace('db.dbms', self.__session.dialect)
        sql_statement = apply_params(sql_statement, self.params)
        sql_statement = resolve_if_macros(sql_statement)
        sql_statement = self._handle_identity_macros(sql_statement)

        etl_print('\n{sql}'.format(sql=sql_statement))
        if only_comments_in(sql_statement):
            etl_print("Nothing to do, skipping..")
            return
        etl_print('Running SQL statement', ETLMessageType.Running)

        as_transaction = "--@NONTRANSACT" not in sql_statement

        try:
            self.__session.execute(sql_statement, as_transaction=as_transaction)
        except Exception as e:
            etl_print('', ETLMessageType.Failed)
            raise E.JobExecException(cause=e)

        etl_print('', ETLMessageType.Ok)

    def _get_table_count(self, table_name, zero_on_fail=False):
        """Get number of records in specified table.

        Args:
            table_name (str): Table reference, with schema variable ('@some_schema.some_table') or not ('real_schema.some_table').
            zero_on_fail (bool): When True, 0 is returned instead of None when table doesn't exist. Defaults to False.

        Returns:
            int: Number of records. None is returned by default on failure.

        """
        real_name = apply_schemas(table_name, self.__etl_conf.schemas)
        try:
            res = self.__session.select("SELECT COUNT(*) FROM {tbl}".format(tbl=real_name), as_transaction=False)
            count = int(res[0][0])
        except Exception:
            # table does not exist
            etl_print("Failed to fetch '{}' table count".format(real_name), ETLMessageType.Warning)
            count = 0 if zero_on_fail else None
        return count

    def _collect_tables_info(self, workflow):
        # collect meaningful annotations
        annotations = (w['doc_info'] for w in workflow if (w.get('doc_info') or {}) != {})
        # ensure each table is listed once
        tables_to_count = set(
            itertools.chain.from_iterable((
                a["source_table"] + [a["table"]]
                for a in annotations
            ))
        )
        for table in tables_to_count:
            with self.run_log.running("get_table_count", table_name=table):
                table_count = self._get_table_count(table)
            if table_count is not None:
                self.run_info[table] = {
                    'run_time': None,
                    'count': table_count
                }

    def _handle_identity_macros(self, sql_statement):
        if '@IDENTITY' in sql_statement.upper():
            if self.__session.dialect in ('redshift', 'postgres') and self._is_insert(sql_statement):
                insert_part = self._extract_insert_part(sql_statement)

                columns = insert_part[3].replace('(', '').replace(')', '')

                if len(columns.strip()) == 0:
                    #List of columns already hasn't been provided by developer.
                    actual_list_of_columns = self.__session._get_table_column_with_identity(insert_part[1], insert_part[2])
                    sql_statement = self._add_column_list(actual_list_of_columns, insert_part)

            sql_dialect = self.__session.dialect.upper()
            sql_statement = replace_identity(sql_statement, sql_dialect)

        return sql_statement

    def _is_insert(self, statement):
        """
        Validate that statement is INSERT, raise an error otherwise

        Arg:
          statement (str) -> String contains sql statement
        """
        is_insert = re.match(
            r"insert\s+into\s+[a-z_0-9@#]+[.]{1}[a-z_0-9]+[\na-z_0-9, ()\"'@.+*\-\\<>=]+",
            strip_comments(statement),
            re.I
        )

        if not is_insert:
            raise E.ParseException("SQL statement with @IDENTITY macros must be insert!")

        return True

    def _extract_insert_part(self, statement):
        """Split SQL INSERT statement into the following groups:

        Group 0: "insert into" keywords
        Group 1: schema name
        Group 2: table name
        Group 3: list of columns for insert like (column1, ... columnN)
        Group 4: all CTEs
        Group 5: "select" keyword
        Group 6: rest of the query

        Args:
            statement (str): SQL INSERT statement

        Returns:
            tuple: parts of the INSERT
        """
        extracted_parts = re.findall(
            r"""(insert\s+into\s+)
                ([a-z_0-9]+)[.]{1}([a-z_0-9]+)  # schema_name.table_name
                \s*
                ([(][\n a-z_0-9,"]+[)])?        # fields list, optional
                (\s+with\s+[a-z_]+\s+as\s+[(][\s\S]+?[)]\s*[,]?)*  # CTEs, optional
                \s+
                (select){1}
                ([\s\S]+)                       # main part of the query
                """,
            statement,
            re.I | re.VERBOSE
        )

        if len(extracted_parts) == 0:
            raise E.ParseException("Couldn't parse insert statement. Please validate your code or contact cdmkit developers")
        else:
            groups = extracted_parts[0]

        return groups

    def _add_column_list(self, actual_list_of_columns, insert_part, include_identity=False):
        """
        Add list of column to insert sql statement

        Args:
            actual_list_of_columns - real list of table's column. Each element must be tuple where
            first part is column name, and second part is flag that determines the identifier column or not
            insert_part - tuple of parts of insert statement
            include_identity - if it is true, identity column also will be include in column list
        """
        colnames = list()
        for colname, is_identity in actual_list_of_columns:
            if is_identity == 0 or include_identity:
                colnames.append(colname)
        list_of_columns = "({})".format(",".join(colnames))

        sql_statement = "{insert}{schema}.{table}{columns}{cte} {select}{rest}".format(
            insert=insert_part[0],
            schema=insert_part[1],
            table=insert_part[2],
            columns=list_of_columns,
            cte=insert_part[4],
            select=insert_part[5],
            rest=insert_part[6]
        )

        return sql_statement


class CDMVerifier:
    """CDM tables unit testing adapter."""

    RULE_COL = "rule_id"

    def __init__(self, session, etl_conf, conf, skip_warnings=False):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.CDMTablesConfig`): job configuration object
        """
        self.__session = session
        self.__cdm_conf = conf
        self.__etl_conf = etl_conf
        self._concept_table = None
        self._date_tables = None
        self.__skip_warnings = skip_warnings or self.__cdm_conf.__dict__.get('skip_warnings')
        self.report = dict()
        self.run_log = RunLog()

    def run(self):
        """Run CDM tables unit testing.

        Returns:
            dict: Unit testing report.

        """
        self.report['created_date'] = str(datetime.datetime.now())
        self.report['tables'] = self.__cdm_conf.tables
        if self.__skip_warnings:
            etl_print("Skipping low severity checks")

        failed_tables = list()
        for table in self.report['tables']:
            etl_print(
                'Verifying table "{tbl}"'.format(tbl=table['table']),
                ETLMessageType.Running)
            with self.run_log.running("verify_table", table=table['table']):
                errors = self._test_table(table)
                scores = {k: len(list(g)) for k, g in itertools.groupby(errors, lambda x: x[0])}
            if not errors:
                etl_print('', ETLMessageType.Ok)
                table['result'] = 'Passed'
                continue
            if scores.get("no_data") is not None and len(scores) == 1:
                etl_print('', ETLMessageType.Ok)
                table['result'] = 'No data'
            elif scores.get("error"):
                etl_print('', ETLMessageType.Failed)
                table['result'] = 'Failed'
                failed_tables.append(table['table'])
            else:
                etl_print('', ETLMessageType.Ok)
                etl_print(
                    "Table '{}' has no errors but {} warnings".format(table['table'], scores["warning"]),
                    ETLMessageType.Warning)
                table['result'] = 'Warning'
            table['result_details'] = [self._format_err_msg(*e) for e in errors]

        if not failed_tables:
            etl_print('Unit testing passed')
        else:
            etl_print(
                'Unit testing failed for tables: {}'.format(', '.join(failed_tables)),
                ETLMessageType.Error)
        return self.report

    def _test_table(self, table_def):
        """Wrapper func for single table testing."""
        schema_tag = getattr(self.__cdm_conf, "schema", self.default_schema_tag)
        table_full_name = utils.locate_table(self.__session, self.__etl_conf.schemas[schema_tag], table_def['table'])

        errors = list()
        has_records = self.__session.select_scalar(
            'SELECT {count_not_zero} FROM {table}'.format(
                count_not_zero=self.__session.count_not_zero_query.format(column='*'),
                table=table_full_name),
            as_type=bool
        )
        if has_records is False:
            errors.append(("no_data", "No data in the whole table '{}'".format(table_def['table'])))
            return errors
        errors.extend(self.__check_rec_uniqueness(table_def, table_full_name))
        errors.extend(self.__check_rec_constraints(table_def, table_full_name))
        errors.extend(self.__check_col_constraints(table_def, table_full_name))

        if not self.__skip_warnings and table_def.get('rules') is not None:
            errors.extend(self.__check_rule_coverage(table_def, table_full_name))

        for rule_def in table_def.get('rules', list()):
            if not isinstance(rule_def['rule'], list):
                rule_def['rule'] = [rule_def['rule']]
            has_records = self.__session.select_scalar(
                "SELECT {count_not_zero} FROM {t} WHERE {rc} in ('{rls}')".format(
                                            count_not_zero=self.__session.count_not_zero_query.format(column='*'),
                                            t=table_full_name,
                                            rc=self.RULE_COL,
                                            rls="','".join(rule_def['rule'])
                ),
                as_type=bool
            )
            if has_records is False:
                errors.append(
                    (
                        "warning",
                        "No data for rule '{rls}' in '{t}'"
                        .format(t=table_def['table'], rls="','".join(rule_def['rule']))
                    )
                )
                continue
            errors.extend(self.__check_rec_uniqueness(rule_def, table_full_name))
            errors.extend(self.__check_rec_constraints(rule_def, table_full_name))
            errors.extend(self.__check_col_constraints(rule_def, table_full_name))
        return errors

    @staticmethod
    def _format_err_msg(severity, msg):
        return "{0}: {1}".format(severity.capitalize(), msg)

    @property
    def concept_table(self):
        if self._concept_table is None:
            self._concept_table = utils.locate_table(self.__session, self.__etl_conf.schemas['voc_schema'], 'concept')
        return self._concept_table

    @property
    def date_tables(self):
        if self._date_tables is None:
            self._date_tables = dict()
            for t in ("person", "death", "visit_occurrence"):
                self._date_tables[t] = utils.locate_table(self.__session, self.__etl_conf.schemas['target_schema'], t)
        return self._date_tables

    def __check_rec_uniqueness(self, table_def, table_name):
        """Look for duplicates by fields defined in `table_def.unique`.

        Args:
            table_def (dict): A chunk of `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        errors = list()
        if table_def.get("unique"):
            rules = table_def.get('rule')
            rules_string = '1=1'
            if rules:
                rules_string = "{rule_cond}".format(rule_cond=self._get_rule_id_filter(rules)).strip(" and ")
            full_count = self.__session.select_scalar(
                "SELECT COUNT(*) FROM {tbl} WHERE {rls};".format(tbl=table_name, rls=rules_string),
                as_type=int
            )
            cols = ', '.join(table_def["unique"])
            unique_count = self.__session.select_scalar(
                "SELECT COUNT(*) FROM (SELECT DISTINCT {cols} FROM {tbl} WHERE {rls}) AS a;"
                .format(tbl=table_name, cols=cols, rls=rules_string)
            )
            if full_count != unique_count:
                table_def['violated'] = ['unique']
                error_message = "Duplicates{rls} by fields [{unique}]".format(
                    rls="" if not rules else " (rule '{}')".format("', '".join(rules)),
                    unique=', '.join(table_def["unique"])
                )
                errors.append(("warning", error_message))
        return errors

    def __check_rec_constraints(self, table_def, table_name):
        """Check record level constraints, like "required" and "length".

        Args:
            table_def (dict): A chunk of `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        all_checks = dict()
        errors = list()
        for field_def in table_def['fields']:
            field_checks = list()
            field_def['violated'] = list()
            if field_def.get("required"):
                field_checks.append((
                    "required",
                    '{field} is null'.format(field=self.__session.quoted(field_def['field'])),
                    "error"
                ))
            if field_def.get("value"):
                legacy = field_def.get("value") == ["Null"]
                if field_def.get("value") == [None] or legacy:
                    field_checks.append((
                        "value",
                        '{field} is not null'.format(field=self.__session.quoted(field_def['field'])),
                        "error"
                    ))
                else:
                    field_checks.append((
                        "value",
                        "CAST({field} AS {string_type}) not in ('{value_list}')".format(
                            field=self.__session.quoted(field_def['field']),
                            string_type=self.__session.types.to_native('string'),
                            value_list="','".join(field_def.get("value"))),
                        "error"
                    ))
            if not self.__skip_warnings:
                if field_def.get("length") is not None:
                    field_checks.append((
                        "length",
                        '{length} > {max_length}'.format(
                            length=self.__session.length_query.format(column=self.__session.quoted(field_def['field'])),
                            max_length=field_def.get("length")),
                        "warning"
                    ))
                if field_def.get("range", [None, None]) != [None, None]:
                    field_checks.append((
                        "range",
                        (
                                ('' if field_def['range'][0] is None else '{field} < {range[0]}')
                                + ('' if any([x is None for x in field_def['range']]) else ' OR ')
                                + ('' if field_def['range'][1] is None else '{field} > {range[1]}')
                        ).format(field=self.__session.quoted(field_def['field']), range=field_def['range']),
                        "warning"
                    ))
            all_checks[field_def['field']] = field_checks
        check_string = ' OR '.join([cond for _, cond, _ in itertools.chain(*all_checks.values())])
        if not check_string:
            return errors

        rules = table_def.get('rule')
        if rules:
            check_string = " {rule_cond}".format(rule_cond=self._get_rule_id_filter(rules)) + "(" + check_string + ")"

        query = "SELECT {count_not_zero} FROM {table_name} WHERE {check_string}"
        params = {
            'count_not_zero': self.__session.count_not_zero_query.format(column='*'),
            'table_name': table_name,
            'check_string': check_string
        }
        general_test_passed = not self.__session.select_scalar(query.format(**params), as_type=bool)
        if general_test_passed:
            return errors

        for field_def in table_def['fields']:
            for test_name, check_cond, severity in all_checks[field_def["field"]]:
                if rules:
                    check_cond = " {rule_cond}".format(rule_cond=self._get_rule_id_filter(rules)) + check_cond
                params = {
                    'count_not_zero': self.__session.count_not_zero_query.format(column='*'),
                    'table_name': table_name,
                    'check_string': check_cond
                }
                condition_test_failed = self.__session.select_scalar(query.format(**params), as_type=bool)
                if condition_test_failed:
                    field_def['violated'].append(test_name)
                    error_message = '{fld}{rls} - {cnd}'.format(
                        fld=field_def["field"], cnd=test_name,
                        rls="" if not rules else " (rule '{}')".format("', '".join(rules))
                    )
                    errors.append((severity, error_message))

        return errors

    def __check_col_constraints(self, table_def, table_name):
        """Check columns level constraints, like "identity".

        Args:
            table_def (dict): A chunk of `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        errors = list()
        rules = table_def.get('rule')

        for field_def in table_def["fields"]:
            if field_def.get("type") == 'identity':
                errors.extend(self.__check_field_identity(field_def, table_name))
            if field_def.get("type") == 'event_date' and not self.__skip_warnings:
                errors.extend(self.__check_event_dates(field_def, table_name))
            if field_def.get("foreign_key"):
                errors.extend(self.__check_foreign_keys(field_def, table_name, rules))
            if field_def.get("type") == 'concept_id':
                errors.extend(self.__check_concept_id(field_def, table_name, rules))
                errors.extend(self.__check_concept_id_type(field_def, table_name, rules))

        return errors

    def __check_field_identity(self, field_def, table_name):
        """Check identity field (no duplicates).

        Args:
            field_def (dict): Field config from `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        errors = list()
        col_count = self.__session.select_scalar("SELECT COUNT(*) FROM {}".format(table_name))
        col_distinct_count = self.__session.select_scalar(
            "SELECT COUNT(DISTINCT({col})) FROM {tbl}"
            .format(col=self.__session.quoted(field_def['field']), tbl=table_name)
        )
        test_result = col_distinct_count == col_count
        if test_result is False:
            field_def['violated'].append('type')
            errors.append((
                "error",
                '{} - identity data type'.format(field_def['field'])
            ))
        return errors

    def __check_foreign_keys(self, field_def, table_name, rules):
        """Check referential integrity.

        There can be several foreign keys specified, which means that
        values from checked column should be present in ANY of foreign keys.

        Args:
            field_def (dict): Field config from `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.
            rules (list): Array of rule_id values.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        def get_fk_subquery(field_def, string_type):
            fk_selects = list()
            if not isinstance(field_def['foreign_key'], list):
                field_def['foreign_key'] = [field_def['foreign_key']]

            for fk_field in field_def['foreign_key']:
                params = fk_field.split('.')
                # replace schema tag with actual schema name
                params[0] = self.__etl_conf.schemas[self._which_schema(params[0])]

                orig_table_name = params[1]
                verified_ftable_name = utils.locate_table(self.__session, params[0], orig_table_name)
                params2 = [verified_ftable_name, params[2], string_type]
                # mind the order
                fk_selects.append("SELECT DISTINCT(CAST({1} AS {2})) FROM {0}".format(*params2))
            return " UNION ".join(fk_selects)

        errors = list()
        field_name = field_def['field']

        condition_zero_value = ''
        if field_def.get("allow_zero"):
            condition_zero_value = field_name + ' !=0 and '

        # checking constraints
        query = "SELECT COUNT(DISTINCT({field})) FROM {table} WHERE {conditions}"
        params = {
            'field': self.__session.quoted(field_name),
            'table': table_name,
            'conditions': condition_zero_value + self._get_rule_id_filter(rules) + field_name + ' is not null'
        }
        col_distinct_count = self.__session.select_scalar(query.format(**params))

        # checking foreign keys as well as constraints
        fk_query = "SELECT COUNT(DISTINCT({field})) FROM {table} WHERE {conditions} AND CAST({field} AS {string_type}) IN ({subquery})"
        fk_params = {
            'field': self.__session.quoted(field_name),
            'table': table_name,
            'conditions': condition_zero_value + self._get_rule_id_filter(rules) + field_name + ' is not null',
            'string_type': self.__session.types.to_native('string'),
            'subquery': get_fk_subquery(field_def, self.__session.types.to_native('string'))
        }
        fk_distinct_count = self.__session.select_scalar(fk_query.format(**fk_params))

        foreign_key_test_passed = fk_distinct_count == col_distinct_count

        if foreign_key_test_passed is False:
            error_message = '{fld}{rls} - foreign key constraints'.format(
                fld=field_name,
                rls="" if not rules else " (rule '{}')".format("', '".join(rules))
            )
            logging.info(error_message)
            field_def['violated'].append('foreign_key')
            errors.append(("error", error_message))

        return errors

    def __check_concept_id(self, field_def, table_name, rules):
        """Check concept_id specific stuff (vocs, domains etc).

        Args:
            field_def (dict): Field config from `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.
            rules (list): Array of rule_id values.

        Returns:
            list: Errors, if test has failed; empty if test has passed.

        """
        errors = list()
        condition_list = list()

        if field_def.get("domain"):
            condition_list.append((
                "domain",
                "voc.domain_id NOT IN ('{domain_list}')"
                .format(domain_list="','".join(field_def["domain"])),
                "error"
            ))
        if field_def.get("vocabulary"):
            condition_list.append((
                "vocabulary",
                "voc.vocabulary_id NOT IN ('{vocabulary_list}')"
                .format(vocabulary_list="','".join(field_def["vocabulary"])),
                "error"
            ))
        if field_def.get("is_standard"):
            condition_list.append((
                "is_standard",
                "voc.standard_concept IS NULL OR voc.standard_concept != 'S' OR voc.invalid_reason IS NOT NULL",
                "error"
            ))
        if field_def.get("allow_zero") is False:
            condition_list.append((
                "allow_zero",
                "{} = 0".format(self.__session.quoted(field_def['field'])),
                "error"
            ))
        if not condition_list:
            return errors

        # checking concepts as well as constraints
        for condition, constraint, severity in condition_list:
            fk_query = (
                "SELECT {count_not_zero}"
                " FROM {table} as a"
                " INNER JOIN {concept_table} as voc"
                " ON a.{field} = voc.concept_id"
                " WHERE {allow_zero}"
                " AND {conditions};")
            fk_params = {
                'count_not_zero': self.__session.count_not_zero_query.format(column=field_def['field']),
                'field': self.__session.quoted(field_def['field']), 'table': table_name,
                'concept_table': self.concept_table,
                'conditions': self._get_rule_id_filter(rules) + constraint,
                'allow_zero': "{} != 0".format(self.__session.quoted(field_def['field'])) if field_def.get("allow_zero") is True else "1 = 1"
            }
            test_failed = self.__session.select_scalar(fk_query.format(**fk_params), as_type=bool)
            if test_failed is True:
                error_message = '{fld}{rls} - {cnd}'.format(
                    fld=field_def['field'], cnd=condition,
                    rls="" if not rules else " (rule '{}')".format("', '".join(rules))
                )
                logging.info(error_message)
                errors.append((severity, error_message))
                field_def['violated'].append(condition)

        return errors

    def __check_concept_id_type(self, field_def, table_name, rules):
        """Check that all values are actually concept_ids present in vocabulary.

        Args:
            field_def (dict): Field config from `cdm_tables.conf`.
            table_name (str): Fully-qualified table name.
            rules (list): Array of rule_id values.

        Returns:
            list: Test result as a single-item list ([True] if passed).

        """
        errors = list()
        fk_query = (
            "SELECT {count_not_zero}"
            " FROM {table} as a"
            " LEFT JOIN {concept_table} as voc"
            " ON a.{field} = voc.concept_id"
            " WHERE {conditions};")
        fk_params = {
            'count_not_zero': self.__session.count_not_zero_query.format(column=field_def['field']),
            'field': self.__session.quoted(field_def['field']), 'table': table_name,
            'concept_table': self.concept_table,
            'conditions': self._get_rule_id_filter(rules) + "voc.concept_id IS NULL"
        }
        test_failed = self.__session.select_scalar(fk_query.format(**fk_params), as_type=bool)

        if test_failed is True:
            error_message = '{fld}{rls} - {cnd}'.format(
                fld=field_def['field'], cnd="concept_id",
                rls="" if not rules else " (rule '{}')".format("', '".join(rules))
            )
            logging.info(error_message)
            errors.append(("error", error_message))
            field_def['violated'].append("concept_id")

        return errors

    def __check_event_dates(self, field_def, table_name):
        """
        Check event dates against OMOP constraints and common sense
        Checks:
            - year of event date should be >= patient's year of birth
            - event data should be <= patient's death date + N days (default 60)
            - event date should be inside either observation period or payer plan period
            - event date should be inside start and end dates of a corresponding visit_occurrence

        """
        # Default number of days is defined by Themis
        num_days = self.__cdm_conf.__dict__.get('days_allowed_after_death') or 60
        errors = list()

        check_queries = {
            'year of event < year of birth':
                """
                    SELECT {count_not_zero}
                    FROM {table} e
                    INNER JOIN {person_table} p
                      ON e.person_id = p.person_id
                    WHERE {extract_year} < p.year_of_birth
                """.format(
                    count_not_zero=self.__session.count_not_zero_query.format(column='*'),
                    table=table_name,
                    person_table=self.date_tables['person'],
                    extract_year=self.__session.extract_year_query.format(column='e.' + self.__session.quoted(field_def['field'])),
                )
        }
        if field_def['field'] != 'death_date':
            check_queries['event date > death date + {num} days'.format(num=num_days)] = \
                    """
                        SELECT {count_not_zero}
                        FROM {table} e
                        INNER JOIN {death_table} d
                          ON e.person_id = d.person_id
                        WHERE e.{field} > {date_add}
                    """.format(
                        count_not_zero=self.__session.count_not_zero_query.format(column='*'),
                        table=table_name,
                        death_table=self.date_tables['death'],
                        field=field_def['field'],
                        date_add=self.__session.dateadd_query.format(interval='day',
                                                                          increment=num_days,
                                                                          column='d.death_date')
                    )
        if field_def.get('inside_visit_dates'):
            check_queries['event date outside related visit occurrence dates'] = \
                    """
                        SELECT {count_not_zero}
                        FROM {table} e
                        INNER JOIN {visit_table} v
                          ON e.visit_occurrence_id = v.visit_occurrence_id
                        WHERE e.{field} NOT BETWEEN v.visit_start_date AND v.visit_end_date
                    """.format(
                        count_not_zero=self.__session.count_not_zero_query.format(column='*'),
                        table=table_name,
                        visit_table=self.date_tables['visit_occurrence'],
                        field=field_def['field']
                    )

        for check, query in check_queries.items():
            test_failed = self.__session.select_scalar(query, as_type=bool)
            if test_failed is True:
                field_def['violated'].append(check)
                error_message = '{fld} - {cnd}'.format(fld=field_def['field'], cnd=check)
                errors.append(('warning', error_message))

        return errors

    def __check_rule_coverage(self, table_def, table_name):
        """Check that all rules present in target table have some coverage in unit test config"""
        errors = list()
        rules_in_conf = list()
        rules_in_table = [str(row[0]) for row in self.__session.select('SELECT DISTINCT {} FROM {}'
                                                                       .format(self.RULE_COL, table_name))]
        for rule_def in table_def['rules']:
            rules_in_conf.extend(rule_def['rule'])

        rules_not_in_conf = ', '.join([i for i in rules_in_table if i not in rules_in_conf])

        if rules_not_in_conf:
            errors = [('warning', 'Rules potentially not covered by unit tests: ' + rules_not_in_conf)]

        return errors

    @staticmethod
    def _which_schema(schema_tag):
        """To be removed.
        Workaround for supporting both old and new schema tags.
        :param schema_tag: tag to check (str)
        :returns: schema type (str)
        """
        SCHEMA_TAGS = {
            "@source_schema": "source_schema",
            '#sr_schema_name#': "source_schema",
            "@voc_schema": "voc_schema",
            "@cdm_schema": "cdm_schema",
            '#etl_schema_name#': "cdm_schema",
            "@target_schema": "target_schema",
        }
        return SCHEMA_TAGS.get(schema_tag.lower())

    def _get_rule_id_filter(self, rules):
        if not rules:
            return ""
        return (
            "{self.RULE_COL} in ('{rules}') and "
            .format(self=self, rules="','".join(rules))
            )

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"


class SourceDataLoader(object):
    """Source data load adapter."""

    def __init__(self, session, etl_conf):
        """Initialize job runner.

        Args:
            session (:class:`cdmkit.core.connections.RedshiftConnection`): Connection wrapper, with open DB session.
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object.

        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.run_log = RunLog()

    def run(self, source_batches, cdp_compatible=False):
        """Triggers a job.

        Args:
            source_batches (list): a list of data configurations from SourceConfig.
            cdp_compatible (boolean): unused (not applicable for non-Spark jobs)

        Returns:
            list: record counts for every loaded table.

        """
        source_batch_counts = []
        for batch in source_batches:
            batch_counts = self.load_source_batch(batch)
            source_batch_counts.append(batch_counts)

        return source_batch_counts

    def load_source_batch(self, batch):
        """Load source files batch.

        Args:
            batch (dict): configuration section from source_data.conf

        Returns:
            list: record counts for every loaded table.

        """
        tables_counts = []

        files_location = batch.get("files_location") or batch["s3_root"]
        generate_util_cols = batch.get("generate_util_columns", False)
        if self.__session.ddl_before_load:
            ddl_conf = configs.CDMTablesConfig.from_dict(batch)
            ddl_creator = CDMDDLCreator(self.__session, self.__etl_conf, row_id=generate_util_cols, cdm_schema_conf=ddl_conf, tables=None)
            ddl_creator.run()
        for source_table in batch["source_tables"]:
            s3_key = os.path.join(self.norm_path(files_location), source_table["path"])
            schema_name = self.__etl_conf.schemas[batch.get("schema", "source_schema")]
            self.__session.create_schema(schema_name)
            table_name = source_table["table"]
            fields = source_table["fields"]
            try:
                with self.run_log.running("load_table", table_name=table_name, source_file_path=s3_key):
                    table_count = self.load_file(
                        s3_key,
                        schema_name=schema_name,
                        table_name=table_name,
                        fields=fields,
                        sep=source_table["delimiter"],
                        header=source_table.get("header", True),
                        dateformat=source_table.get("dateformat") or batch.get("dateformat"),
                        timeformat=source_table.get("timestampformat") or batch.get("timestampformat"),
                        compression=source_table.get("compression"),
                        encoding=source_table.get("encoding"),
                        invalid_char=source_table.get("invalid_char"),
                        blank_as_null=source_table.get("blank_as_null") or batch.get("blank_as_null"),
                        empty_as_null=source_table.get("empty_as_null") or batch.get("empty_as_null"),
                        ignore_blank=source_table.get("ignore_blank"),
                        remove_quotes=source_table.get("remove_quotes"),
                        trim_blanks=source_table.get("trim_blanks"),
                        quote_char=source_table.get("quote_char") or batch.get("quote_char"),
                        escape_char=source_table.get("escape_char") or batch.get("escape_char"),
                        generate_util_cols=source_table.get("generate_util_columns", generate_util_cols),
                    )
                    tables_counts.append(table_count)
            except Exception as e:
                logging.error(
                    "Failed to load table {name}. {exc}"
                    .format(name=table_name, exc=traceback.format_exc())
                )
                raise E.JobExecException(cause=e)

        return tables_counts

    def load_file(self, s3_key, schema_name, table_name, fields=None,
                  sep=',', header=None, dateformat=None, timeformat=None, compression=None,
                  encoding=None, invalid_char=None, blank_as_null=False, empty_as_null=False,
                  ignore_blank=False, remove_quotes=False, trim_blanks=False, quote_char=None,
                  escape_char=None, generate_util_cols=False):
        table_count = self.indicate_start(table_name, s3_key)
        self.__session.load_file(file=s3_key, schema_name=schema_name, table_name=table_name, fields=fields,
                                 sep=sep, header=header, dateformat=dateformat, timeformat=timeformat,
                                 compression=compression, encoding=encoding, invalid_char=invalid_char,
                                 blank_as_null=blank_as_null, empty_as_null=empty_as_null, ignore_blank=ignore_blank,
                                 remove_quotes=remove_quotes, trim_blanks=trim_blanks, quote_char=quote_char,
                                 escape_char=escape_char, data_location=self.__etl_conf.db.get('data_location'),
                                 generate_util_cols=generate_util_cols)
        table_count = self.indicate_finish(schema_name, table_name, table_count)
        return table_count

    @staticmethod
    def norm_path(filepath):
        if os.name == "nt" and os.path.splitdrive(filepath)[0] != '':
            # normalize only local Windows paths
            return os.path.normpath(filepath)
        else:
            return filepath

    @staticmethod
    def indicate_start(table_name, source_path):
        table_count = dict()
        table_count["table"] = table_name
        table_count["source_file"] = source_path

        logging.info("Loading " + source_path)
        etl_print("Loading table '{}'".format(table_name), ETLMessageType.Running)

        return table_count

    def indicate_finish(self, schema, table_name, table_count):
        table_count["count"] = self.__session.select_scalar(
            "SELECT COUNT(*) FROM {}.{}".format(schema, self.__session.quoted(table_name)),
            as_type=int
        )
        etl_print('', ETLMessageType.Ok)
        return table_count


class CDMUnloader(object):
    """CDM data unload adapter."""

    def __init__(self, session, etl_conf, conf):
        """Initialize job runner.

        Args:
            session: Database session
            etl_conf (:class:`cdmkit.core.configs.ETLConf`): .etlconf configuration object
            conf (:class:`cdmkit.core.configs.UnloadConfig`): job configuration object
        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.run_log = RunLog()

    def run(self):
        """Export data from target tables."""
        for folder_conf in self.__conf.folders:
            self.unload_folder(self.__conf.files_location, folder_conf)

    def unload_folder(self, files_location, folder_conf):
        schema = self.__etl_conf.schemas.get(folder_conf.get('schema', 'target_schema'))
        for table in folder_conf["tables"]:
            cdm_file = '/'.join([files_location, folder_conf["folder"], table["path"]])
            # override on table level or use folder-level defaults
            delimiter = table.get('delimiter', folder_conf.get("delimiter", ","))
            files_number = table.get('files_number', folder_conf.get("files_number", 1))
            exclude_columns = table.get('exclude_columns', folder_conf.get("exclude_columns", []))

            self.__indicate_start(table['table'])
            self.__session.unload_file(table_name=table['table'],
                                       path=cdm_file,
                                       target_format=folder_conf.get('target_format', 'parquet'),
                                       delimiter=delimiter,
                                       header=folder_conf.get('header', True),
                                       files_number=files_number,
                                       exclude_columns=exclude_columns,
                                       compression=folder_conf.get('compression'),
                                       add_quotes=table.get('add_quotes'),
                                       allow_overwrite=table.get('allow_overwrite'),
                                       parallel=table.get('parallel'),
                                       max_file_size=table.get('max_file_size'),
                                       schema=schema,
                                       date_format=folder_conf.get('dateformat'),
                                       quote_all=folder_conf.get('quote_all', False),
                                       quote=folder_conf.get('quote', '"'),
                                       escape=folder_conf.get('escape', '\\'),
                                       null_value=folder_conf.get('null_value')
                                       )
            self.__indicate_finish()

    @staticmethod
    def __indicate_start(table_name):
        etl_print("Unloading table '{}'".format(table_name), ETLMessageType.Running)

    @staticmethod
    def __indicate_finish():
        etl_print('', ETLMessageType.Ok)


class CDMDDLCreator:
    """Creates and executes DDL statements for CDM tables."""

    RULE_COL = "rule_id"

    @property
    def util_fields(self):
        return [
            {"field": self.RULE_COL, "type": "string", "length": 100},
            {"field": "load_table_id", "type": "string", "length": 50},
            {"field": "load_row_id", "type": "bigint"}
        ]

    def __init__(self, session, etl_conf, row_id, cdm_schema_conf, tables):
        """Create runner instance.

        Args:
            session (:class:`core.etl_connections.SparkConnection`): Connection wrapper, with open DB session.
            etl_conf (:class:`core.etl_configs.Config`): .etlconf configuration object.
            row_id (bool): Whether to add utility fields or not (True by default).
            cdm_schema_conf (:class:`core.etl_configs.CDMTablesConfig`): Job configuration.
            tables (list): Run job only for specified tables, if present. A list of (str) table names.

        Returns:
            type: Description of returned object.

        """
        self.__session = session
        self.__etl_conf = etl_conf
        self.__cdm_schema_conf = cdm_schema_conf
        self.__row_id = row_id
        self.__tables = tables
        self.__typo_checker = utils.CDMTablesTypoChecker()
        self.run_log = RunLog()

    def run(self):
        ddl_statements = list()
        if self.__tables is None:
            for table in self.__cdm_schema_conf.tables:
                ddl_statements.append(self.generate_ddl_table(table))
        else:
            for table in self.__cdm_schema_conf.tables:
                if self.__is_table_excluded(table['table']):
                    continue
                ddl_statements.append(self.generate_ddl_table(table))

        # execute all generated SQL
        for table, drop, create in ddl_statements:
            with self.run_log.running("create_table", table_name=table):
                etl_print("Creating table '{}'...".format(table), ETLMessageType.Running)
                self.__session.execute(drop, create)
                etl_print("", ETLMessageType.Ok)

    def generate_ddl_table(self, table_def):
        """Generate DDL statement for CDM tables.

        Args:
            table_def (dict): Table definition from `self.__cdm_schema_conf`.

        Returns:
            tuple: (table_name, drop_query, create_query), all str.

        """
        schema_tag = getattr(self.__cdm_schema_conf, "schema", self.default_schema_tag)
        drop_ddl = 'DROP TABLE IF EXISTS {schema_name}.{table_name}'.format(
            schema_name=self.__session.quoted(self.__etl_conf.schemas[schema_tag]),
            table_name=self.__session.quoted(table_def['table'])
        )

        storage_format = table_def.get("storage_format") or getattr(self.__cdm_schema_conf,
                                                                    "storage_format",
                                                                    self.__session.default_storage_format)

        create_ddl = 'CREATE {external} TABLE {schema_name}.{table_name}\n(\n{fields}\n){format}\n{location}'.format(
            external='EXTERNAL' if self.__session.ddl_external_tables else '',
            schema_name=self.__session.quoted(self.__etl_conf.schemas[schema_tag]),
            table_name=self.__session.quoted(table_def['table']),
            fields=self._generate_ddl_fields(table_def),
            format='\nSTORED AS {}'.format(storage_format) if storage_format else "",
            location=self.__session.s3_location.format(
                s3=self.__etl_conf.db.get('data_location'),
                schema=self.__etl_conf.schemas[schema_tag],
                table=table_def['table']
            ),
        )
        return table_def['table'], drop_ddl, create_ddl

    def _generate_ddl_fields(self, table_def):
        """Generate DDL definition for table fields.

        Args:
            table_def (dict): Table definition from `self.__cdm_schema_conf`.

        Returns:
            str: Part of DDL query which defines table fields.

        """
        fields = table_def['fields'] + (self.util_fields if self.__row_id and table_def.get('generate_util_columns', True) else [])
        fields_ddl = ",\n".join([
            self._get_field_sql_expr(f) for f in fields
        ])
        return fields_ddl

    def _get_field_sql_expr(self, field_def):
        native_type = self.__session.types.to_native(
            field_def['type'],
            length=field_def.get("length"),
            precision=field_def.get("precision"),
            scale=field_def.get("scale")
        )
        return '{field} {field_type} {nullable}'.format(
            field=self.__session.quoted(field_def['field']),
            field_type=native_type,
            nullable=self.__session.ddl_declare_nullable[field_def.get('required', False)]
        )

    def __is_table_excluded(self, table_name):
        for specified_table in self.__tables:
            if table_name == specified_table:
                return False
        for specified_table in self.__tables:
            if self.__typo_checker.check(specified_table, table_name):
                etl_print(
                    "Table '{tbl}' is skipped on your command."
                    " Did you make a typo or misspell the name? ('{tbl_by_user}')"
                    .format(tbl=table_name, tbl_by_user=specified_table),
                    ETLMessageType.Warning
                )
                return True

        etl_print("Table {} is skipped on your command".format(table_name))
        return True

    @property
    def default_schema_tag(self):
        if "target_schema" in self.__etl_conf.schemas:
            return "target_schema"
        else:
            # legacy configuration fallback
            return "cdm_schema"

    def set_ddl_conf(self, ddl_conf):
        self.__cdm_schema_conf = ddl_conf


class SrcToCdmCounts:

    # constant
    none_table = 'NO Events or Visits'

    # source to cdm counts record (Link record)
    class SdcLink:
        def __init__(self, src_table_id, cdm_table_id, cdm_partial_count):
            self.src_table_id = src_table_id
            self.cdm_table_id = cdm_table_id
            self.cdm_partial_count = cdm_partial_count

        # as record in a flat list
        def to_json(self):
            return {
                "cdm_partial_count": self.cdm_partial_count,
                "cdm_table_id": self.cdm_table_id,
                "src_table_id": self.src_table_id
            }

    # total count for a source or cdm table (Node record)
    class SdcNode:
        def __init__(self, table_id, table_count):
            self.table_id = table_id
            self.table_count = table_count

        # as record in the flat list
        def to_json(self):
            return {
                "table_count": self.table_count,
                "table_id": self.table_id
            }

    # basic sdc list, aka Nodes list
    class SdcNodesList:
        sdc_list_type = 'nodes'
        sdc_items = []

        def clear(self):
            self.sdc_items = []

        def append_plain(self, sdc_item):
            self.sdc_items.append(sdc_item)

        def append(self, table_id, table_count):
            sdc_item = SrcToCdmCounts.SdcNode(table_id, table_count)
            self.sdc_items.append(sdc_item)

        def append_many(self, sdc_items):
            for sdc_item in sdc_items:
                self.sdc_items.append(sdc_item)

        def to_json(self):
            result = []
            for rec in self.sdc_items:
                result.append(rec.to_json())
            return {
                self.sdc_list_type: result
            }

    # Links list
    class SdcLinksList (SdcNodesList):
        sdc_list_type = 'links'

        def append(self, src_table_id, cdm_table_id, cdm_partial_count):
            strec = SrcToCdmCounts.SdcLink(src_table_id, cdm_table_id, cdm_partial_count)
            self.sdc_items.append(strec)

        def get_source_tables(self):
            result = []
            for rec in self.sdc_items:
                if rec.src_table_id not in result:
                    result.append(rec.src_table_id)
            return result

        def get_cdm_tables(self, src_table=""):
            result = []
            if src_table is None:
                src_table = ""
            for rec in self.sdc_items:
                if src_table == rec.src_table_id or src_table == "":
                    if ((rec.cdm_table_id not in result) and (not rec.cdm_table_id == SrcToCdmCounts.none_table)):
                        result.append(rec.cdm_table_id)
            return result

    # connector to a SQL session (to get counts from database)
    class SQLConnector:
        def __init__(self, session, src_schema, cdm_schema):
            self.session = session
            self.cdm_schema = cdm_schema
            self.src_schema = src_schema

            self.sql_mapped = \
                "SELECT rule_id, COUNT(*) AS cnt FROM {cdm_schema}.{cdm_table} GROUP BY rule_id "

            self.sql_unmapped = \
                "SELECT COUNT(*) AS cnt FROM {src_schema}.{src_table} s " + \
                "LEFT JOIN ({sql_mapped_ids}) c " + \
                "ON s.load_row_id = c.load_row_id " + \
                "WHERE c.load_row_id IS NULL "

            # template sqls for union queries
            self.sql_mapped_ids = \
                "SELECT rule_id, load_row_id FROM {schema}.{table_id} "

            self.sql_total_count = \
                "SELECT '{table_id}' AS table_id, COUNT(*) AS cnt FROM  {schema}.{table_id} "

        def get_sql_union(self, schema, tables_list, sql_single):
            result = ""
            for table_id in tables_list:
                if len(result) > 0:
                    result = result + " UNION ALL "
                result = result + sql_single.format(
                    schema=schema, table_id=table_id)
            return result

        def get_counts_mapped(self, cdm_table):
            result = [
                SrcToCdmCounts.SdcLink(row[0], cdm_table, row[1])
                for row in self.session.select(
                    self.sql_mapped.format(cdm_schema=self.cdm_schema, cdm_table=cdm_table)
                )
            ]
            return result

        def get_counts_unmapped(self, src_table, cdm_tables):
            result = [
                SrcToCdmCounts.SdcLink(src_table, SrcToCdmCounts.none_table, row[0])
                for row in self.session.select(
                    self.sql_unmapped.format(
                        src_schema=self.src_schema, src_table=src_table,
                        sql_mapped_ids=self.get_sql_union(self.cdm_schema, cdm_tables, self.sql_mapped_ids)
                    )
                )
            ]
            return result

        def get_total_counts(self, schema, tables_list):
            result = [
                SrcToCdmCounts.SdcNode(row[0], row[1])
                for row in self.session.select(
                    self.get_sql_union(schema, tables_list, self.sql_total_count)
                )
            ]
            return result

    # SrcToCdmCounts methods
    def __init__(self):
        self.sdc_links = SrcToCdmCounts.SdcLinksList()
        self.sdc_nodes = SrcToCdmCounts.SdcNodesList()
        self.db_connector = None

    def to_json(self):
        report = {}
        report.update({'created_date': datetime.datetime.now()})
        report.update(self.sdc_links.to_json())
        report.update(self.sdc_nodes.to_json())
        return report

    def connect(self, session, src_schema, cdm_schema):
        self.db_connector = SrcToCdmCounts.SQLConnector(session, src_schema, cdm_schema)

    def fill_out(self, cdm_tables):
        # clean up
        self.sdc_links.clear()
        self.sdc_nodes.clear()

        # append links
        # append mapped
        for cdm_table in cdm_tables:
            counts = self.db_connector.get_counts_mapped(cdm_table)
            self.sdc_links.append_many(counts)
        # append unmapped
        src_tables = self.sdc_links.get_source_tables()
        for src_table in src_tables:
            counts = self.db_connector.get_counts_unmapped(
                src_table, self.sdc_links.get_cdm_tables(src_table))
            self.sdc_links.append_many(counts)

        # append nodes
        # append for source tables, only actual nodes
        nodes_list = self.sdc_links.get_source_tables()
        counts = self.db_connector.get_total_counts(
            self.db_connector.src_schema,
            nodes_list)
        self.sdc_nodes.append_many(counts)

        # append for cdm tables, only actual nodes
        nodes_list = self.sdc_links.get_cdm_tables()
        counts = self.db_connector.get_total_counts(
            self.db_connector.cdm_schema,
            nodes_list)
        self.sdc_nodes.append_many(counts)

    def save_to_json(self, output_file_name):
        try:
            with open(output_file_name, 'w') as outfile:
                json.dump(self.to_json(), outfile, indent=4)
            etl_print('', ETLMessageType.Ok)
            etl_print('Have written output file {0}'.format(output_file_name))
        except (OSError, ValueError, TypeError, IOError) as e:
            etl_print('', ETLMessageType.Failed)
            etl_print('Could not write output file {0}'.format(output_file_name))
            raise e


class QARunner:
    """QA Scripts adapter."""

    def __init__(self, session, etl_home, etl_conf, conf=None, skip_warnings=False):
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.__etl_home = etl_home
        self.skip_warnings = skip_warnings
        self.__qa_results = list()
        self.run_log = RunLog()

    def run(self):
        """Run all QA scripts referenced in configuration file."""
        for script in self.__conf.scripts:
            script_path = os.path.join(self.__etl_home, "qa", script["script"])
            self.run_file(script_path)

    def run_file(self, file_path):
        """Run a single QA script, referenced by file path.

        Args:
            file_path (str): a full path to QA script.

        Returns:
            None

        """
        logging.info("Running QA script '%s'", file_path)
        etl_print("Running QA script '{script}'".format(script=file_path))
        with open(file_path) as script_file:
            script_contents = script_file.read()
        self.__qa_results.extend(self._run_qa_script(script_contents, file_path))

    def qa_results(self):
        return self.__qa_results

    def _get_params(self):
        """Get parameter values from ETLConf.

        Takes general 'params' section and 'params' from 'qa',
        values from the latter take precedence.

        Returns:
            dict: parameter names/values.

        """
        main_params = self.__etl_conf.params
        qa_params = dict()
        if self.__conf is not None:
            qa_params = self.__conf.get('params', {})
        return utils.merge_dicts(main_params, qa_params)

    def _run_qa_script(self, qa_script, file_name):
        """Run a set of QA queries from a single QA script.

        Transforms SQL code before execution, in this order:
        1) replaces schema tags with values;
        2) replaces parameter tags with values;
        3) splits the code into separate queries.

        Args:
            qa_script (str): the contents of QA script, SQL code.
            file_name (str): full path to QA script file.

        Returns:
            list: QA results.

        """
        qa_results = []
        script_name = os.path.split(file_name)[-1]
        qa_script = apply_schemas(qa_script, self.__etl_conf.schemas)
        qa_script = apply_params(qa_script, self._get_params())
        for query_id, sql_statement in enumerate(split_into_queries(qa_script)):
            if only_comments_in(sql_statement):
                continue
            etl_print('QA statement:\n{stm}'.format(stm=sql_statement))
            etl_print('Running QA statement', ETLMessageType.Running)
            with self.run_log.running("qa_run_statement", script_name=script_name, query_id=query_id):
                run_info = self._run_qa_statement(sql_statement, script_name)
            qa_results.append(run_info)
            if str(run_info.result).startswith("ERROR"):
                etl_print('', ETLMessageType.Failed)
            else:
                etl_print('', ETLMessageType.Ok)
            if run_info.result is None:
                etl_print('Previous QA query was skipped.', ETLMessageType.Warning)

        return qa_results

    def _run_qa_statement(self, sql_statement, script_name=None):
        """Run a single QA query.

        Args:
            sql_statement (str): Description of parameter `sql_statement`.

        Returns:
            type: Description of returned object.

        """
        qa_info = QAStepInfo.from_statement(sql_statement, script_name)
        if self.skip_warnings and qa_info.severity == "warning":
            return qa_info

        logging.info("Running SQL Statement: %s", sql_statement)
        try:
            qa_info.result = self.__session.select_scalar(sql_statement)
            logging.info('QA Query returned ' + str(qa_info.result))
        except Exception as e:
            # do not raise, record error message for report
            qa_info.result = "ERROR:\n{}".format(e)
            logging.error("Failed to run statement. " + traceback.format_exc())

        return qa_info


class CustomVocMerger:
    """Builds custom vocabulary tables from vocabulary stage files."""

    POSTFIXES = {
        'new':      '_stage_new',
        'old':      '_stage_old',
        'amend':    '_amend'
    }

    def __init__(self, session, etl_conf, conf):
        self.__session = session
        self.__etl_conf = etl_conf
        self.__conf = conf
        self.__update_etl_conf_schemas(conf.schemas)
        self.__etl_conf.__dict__['params']['dbms'] = self.__session.dialect
        self.CHECK_FUNCTIONS_MAPPING = {
            'concept':                self.__check_concept_stage,
            'concept_relationship':   self.__check_concept_relationship_stage,
            'concept_ancestor':       self.__check_concept_ancestor_stage,
            'vocabulary':             self.__check_vocabulary_stage
        }
        self.__ddl_creator = CDMDDLCreator(session, etl_conf, row_id=False, cdm_schema_conf=None, tables=None)
        self.__workflow_runner = WorkflowRunner(session, etl_conf, should_count=False)
        self.error_list = []
        self.warning_list = []
        self.run_log = RunLog()
        # reuse run_log in child runners to collect full run info
        self.__ddl_creator.run_log = self.run_log
        self.__workflow_runner.run_log = self.run_log

    def __update_etl_conf_schemas(self, schema_refs):
        for schema_ref_name in schema_refs.keys():
            schema_ref = schema_refs[schema_ref_name]
            self.__etl_conf.schemas[schema_ref_name] = self.__etl_conf.schemas[schema_ref]

    def run(self):
        etl_print("Building custom vocabs")
        for ddl_conf_file in self.__conf.ddl_conf_files:
            ddl_conf = configs.CDMTablesConfig(ddl_conf_file)
            if ddl_conf_file.endswith("old_stage_ddl.conf"):
                schema_name = self.__etl_conf.schemas[ddl_conf.schema]
                # filter out stage tables that already exist
                already_exist = list()
                for tbl in [t['table'] for t in ddl_conf.tables]:
                    try:
                        voc_table_name = utils.locate_table(self.__session, schema_name, tbl)
                        already_exist.append(tbl)
                    except ValueError:
                        pass
                if not already_exist and not self.__conf.empty_old:
                    raise E.JobExecException(
                        "No 'old' custom voc stages found. Either load the old stage files or use '--empty-old'"
                    )
                ddl_conf.tables = [t for t in ddl_conf.tables if t['table'] not in already_exist]
            elif ddl_conf_file.endswith("new_stage_ddl.conf"):
                schema_name = self.__etl_conf.schemas[ddl_conf.schema]
                already_exist = list()
                for tbl in [t['table'] for t in ddl_conf.tables]:
                    try:
                        voc_table_name = utils.locate_table(self.__session, schema_name, tbl)
                        already_exist.append(tbl)
                    except ValueError:
                        pass
                if not already_exist and not self.__conf.empty_new:
                    raise E.JobExecException(
                        "No 'new' custom voc stages found. Either load the new stage files or use '--empty-new'"
                    )
                ddl_conf.tables = [t for t in ddl_conf.tables if t['table'] not in already_exist]

            self.__ddl_creator.set_ddl_conf(ddl_conf)
            self.__ddl_creator.run()

        if not self._check_custom_voc_stages():
            raise E.JobExecException("There are errors in the custom voc stages")

        etl_print("Run workflow")
        for script in self.__conf.workflow:
            self.__workflow_runner.run(script['statements'])

    def _check_custom_voc_stages(self):
        """Checks freshly uploaded stage with the previous one and OMOP vocs

        Returns:
            bool: True if no errors found, False otherwise
        """

        tables_to_check = [
           'concept',
           'concept_relationship',
           'concept_ancestor',
            'vocabulary'
        ]
        for table in tables_to_check:
            self.CHECK_FUNCTIONS_MAPPING [table]()


        for warning in self.warning_list:
            etl_print(warning['message'] + '\n' + warning['info'], ETLMessageType.Warning)
        for error in self.error_list:
            etl_print(error['message'] + '\n' + error['info'], ETLMessageType.Error)
        failed_checks_counts = {
            'no': len(self.warning_list) | len(self.error_list),
            'warning': len(self.error_list),
            'error': 0
        }
        return failed_checks_counts[self.__conf.ignore_level] == 0

    def __check_concept_stage(self):
        etl_print("Check concept stage", ETLMessageType.Running)
        pass
        etl_print("", ETLMessageType.Ok)

    def __check_concept_relationship_stage(self):
        etl_print("Check concept_relationship stage", ETLMessageType.Running)
        stages = ['old', 'new']
        for stage in stages:
            codes = self.__get_nonexistent_codes('concept_relationship', 'concept_code_1', 'vocabulary_id_1', stage)
            if len(codes) > 0:
                self.error_list.append({
                    'message': 'Nonexistent codes (no OMOP or staged) in concept_relationship_{stage}'.format(stage=stage),
                    'info': 'Concepts: ' + ';\n'.join(map(lambda x: str(x), codes))
                })
        etl_print("", ETLMessageType.Ok)

    def __check_concept_ancestor_stage(self):
        etl_print("Check concept_ancestor stage", ETLMessageType.Running)
        stages = ['old', 'new']
        for stage in stages:
            codes = self.__get_nonexistent_codes('concept_ancestor', 'ancestor_concept_code', 'ancestor_vocabulary_id', stage)
            if len(codes) > 0:
                self.warning_list.append({
                    'message': 'Nonexistent codes (no OMOP or staged) in concept_ancestor_{stage}'.format(stage=stage),
                    'info': 'Concepts: ' + ';\n'.join(map(lambda x: str(x), codes))
                })
        etl_print("", ETLMessageType.Ok)

    def __check_vocabulary_stage(self):
        etl_print("Check vocabulary stage", ETLMessageType.Running)
        voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['omop_voc_schema'], 'vocabulary')
        new_voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['new_stage_schema'], 'vocabulary'+self.POSTFIXES['new'])
        old_voc_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['old_stage_schema'], 'vocabulary'+self.POSTFIXES['old'])

        voc_date = self.__get_voc_version_date(voc_table_name)
        new_voc_date = self.__get_voc_version_date(new_voc_table_name)
        old_voc_date = self.__get_voc_version_date(old_voc_table_name)

        if new_voc_date < old_voc_date and not (self.__conf.empty_old or self.__conf.empty_new):
            self.error_list.append({
                'message': 'Version of vocabularies in new stage is older than in the old',
                'info': 'New version: ' + str(new_voc_date) + '\nOld version: ' + str(old_voc_date)
            })
        if new_voc_date != voc_date and not self.__conf.empty_new:
            self.error_list.append({
                'message': 'Version of vocabularies in new stage does not match version of OMOP vocabularies',
                'info': 'New version: ' + str(new_voc_date) + '\nOMOP voc version: ' + str(voc_date)
            })
        etl_print("", ETLMessageType.Ok)

    def __get_nonexistent_codes(self, table_name, code_field, voc_field, stage='new'):
        """Searches for nonexistent codes in the specified table.

        Args:
            table_name (str): Name of the table to check
            code_field (str): Name of the field with concept code
            voc_field (str): Name of the field with vocab id
            stage (str): Name of the stage to check

        Returns:
            list: List of nonexistent codes
        """

        concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas['omop_voc_schema'], 'concept')
        stage_concept_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[stage+'_stage_schema'], 'concept'+self.POSTFIXES[stage])
        target_table_name = utils.locate_table(self.__session, self.__etl_conf.schemas[stage+'_stage_schema'], table_name+self.POSTFIXES[stage])

        query = """
            SELECT
                src.{code_field},
                src.{voc_field}
            FROM
                {table} src
            WHERE
                NOT EXISTS (
                    SELECT 1
                    FROM
                        {stndr_concept_tbl} sct
                    WHERE
                        sct.concept_code = src.{code_field}
                        AND sct.vocabulary_id = src.{voc_field}
                )
                AND NOT EXISTS (
                    SELECT 1
                    FROM
                        {stage_concept_tbl} sct
                    WHERE
                        sct.concept_code = src.{code_field}
                        AND sct.vocabulary_id = src.{voc_field}
                )
        """.format(
            code_field=code_field,
            voc_field=voc_field,
            table=target_table_name,
            stndr_concept_tbl=concept_table_name,
            stage_concept_tbl=stage_concept_table_name
        )

        res = self.__session.select(query)

        return res

    def __get_voc_version_date(self, table):
        """Fetch date of vocabularies in provided voc tables.
        This function is assumed that

        Args:
            table ([Str]): Vocabulary's table name with schema. String must match the pattern {schema}.{table}

        Returns:
            [datetime]: Date of release of current vocabs set
        """
        try:
            query = """
            SELECT
                {expr} as vocab_version
            FROM
                {table}
            WHERE
                vocabulary_id = 'None'
            """.format(expr=self.__session.substr_func.format(column='vocabulary_version', start=6, length=9), table=table)

            date = self.__session.select(query)
            if len(date) == 0:
                return datetime.datetime.min
        except IndexError:
            return datetime.datetime.min
        return datetime.datetime.strptime(date[0][0], '%d-%b-%y')


class CustomVocStatsGenerator:
    """Custom vocabularies Statistics generator."""

    POSTFIXES = {
        'final':    '_stage',
        'new':      '_stage_new',
        'old':      '_stage_old',
        'amend':    '_amend'
    }

    SCHEMAS = {
        'final':    'final_stage_schema',
        'new':      'new_stage_schema',
        'old':      'old_stage_schema',
        'amend':    'amend_schema'
    }

    TABLES = ['cdm_vocabulary', 'cdm_concept', 'cdm_concept_relationship', 'cdm_concept_ancestor']

    def __init__(self, session, etl_conf):
        self.__session = session
        self.__etl_conf = etl_conf

    def run(self):

        pie_stats = {
            'cdm_concept_stage': ['vocabulary_id', 'domain_id'],
            'cdm_concept_stage_old': ['vocabulary_id', 'domain_id'],
            'cdm_concept_relationship_stage': ['vocabulary_id_1', 'vocabulary_id_2', 'relationship_id']
        }
        stats = []
        for table in self.TABLES:
            for k, postfix in self.POSTFIXES.items():
                table_name = table+postfix
                full_table_name = utils.locate_table(
                    self.__session,
                    self.__etl_conf.schemas[self.SCHEMAS[k]],
                    table_name
                )

                # Calculate total
                table_stat = {'table': table_name, 'count': self.get_total(full_table_name), 'custom_stats': []}

                # Calculate stats for pie charts
                if pie_stats.get(table_name):
                    for column in pie_stats[table_name]:
                        table_stat['custom_stats'].append({
                            'type': 'pie',
                            'data': self.get_counts_by_column(full_table_name, column),
                            'column': column
                        })
                # Delta: new vocs
                if table_name == 'cdm_vocabulary_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_new_vocs()
                    })
                # Delta: changes in relationships
                if table_name == 'cdm_concept_relationship_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_relationship_delta()
                    })
                # Delta: new concepts
                if table_name == 'cdm_concept_stage':
                    table_stat['custom_stats'].append({
                        'type': 'delta',
                        'data': self.get_new_concepts()
                    })

                stats.append(table_stat)
        self.stats = stats

    def get_total(self, table):
        query = "SELECT COUNT(*) AS cnt FROM {table}".format(table=table)
        return self.__session.select_scalar(query, as_type=int)

    def get_counts_by_column(self, table, column_name, limit=100):
        query = (
            "SELECT {top} {column_name}, COUNT(*) AS cnt "
            "FROM {table} "
            "GROUP BY {column_name} "
            "{limit}"
        ).format(table=table, column_name=column_name,
                 top=self.__session.top_query.format(num=limit),
                 limit=self.__session.limit_query.format(num=limit))

        df = self.__session.select(query)

        return [{'value': r[0], 'count': r[1]} for r in df]

    def get_new_vocs(self):
        query = (
            "SELECT vocabulary_name "
            "FROM {final_stage_schema}.cdm_vocabulary_stage "
            "WHERE vocabulary_name IN ( "
            "  SELECT vocabulary_name "
            "  FROM {new_stage_schema}.cdm_vocabulary_stage_new "
            "  EXCEPT "
            "  SELECT vocabulary_name "
            "  FROM {old_stage_schema}.cdm_vocabulary_stage_old)".format(
                final_stage_schema=self.__etl_conf.schemas['final_stage_schema'],
                new_stage_schema=self.__etl_conf.schemas['new_stage_schema'],
                old_stage_schema=self.__etl_conf.schemas['old_stage_schema']
                )
        )

        df = self.__session.select(query)

        results = [{'vocabulary_name': r[0]} for r in df]
        return {
            'added': {
                'count': len(results),
                'data': results
            }
        }

    def get_new_concepts(self):
        query = (
            "SELECT COUNT(*) AS cnt "
            "FROM {final_stage_schema}.cdm_concept_stage a "
            "LEFT JOIN {old_stage_schema}.cdm_concept_stage_old b "
            "  ON a.vocabulary_id = b.vocabulary_id "
            "  AND a.concept_code = b.concept_code "
            "WHERE b.concept_code IS NULL".format(
                final_stage_schema=self.__etl_conf.schemas['final_stage_schema'],
                old_stage_schema=self.__etl_conf.schemas['old_stage_schema'],
            )
        )

        n_concepts = self.__session.select_scalar(query)

        return {
            'added': {
                'count': n_concepts
            }
        }

    def get_relationship_delta(self):

        def get_delta_count(table1, table2):
            query = (
                "SELECT COUNT(*) AS cnt "
                "FROM {table1} a "
                "  LEFT JOIN {table2} b "
                "  ON a.concept_code_1 = b.concept_code_1 "
                "  AND a.vocabulary_id_1 = b.vocabulary_id_1 "
                "  AND a.relationship_id = b.relationship_id "
                "  AND a.concept_id_2 = b.concept_id_2 "
                "WHERE a.relationship_id IN ('Maps to', 'Maps to value') "
                "  AND b.concept_code_1 IS NULL"
                .format(
                    schema_name=self.__etl_conf.schemas['cdm_schema'],
                    table1=table1,
                    table2=table2,
                )
            )
            return self.__session.select_scalar(query)

        tables = [
            self.__etl_conf.schemas['final_stage_schema']+'.'+'cdm_concept_relationship_stage',
            self.__etl_conf.schemas['old_stage_schema']+'.'+'cdm_concept_relationship_stage_old'
        ]
        return {
                'added': {
                    'count': get_delta_count(tables[0], tables[1])
                },
                'replaced': {
                    'count': get_delta_count(tables[1], tables[0])
                },
            }
