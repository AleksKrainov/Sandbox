"""coverage_report.py
"""

import argparse
import os
import sys

from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core.utils import create_log_file
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E
try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core.')
from cdmkit.cdmredshift import etl_core as sql_core


# ======= Start ===============================================================

etl_print('Job coverage_report.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-s", dest="cdm_tables_conf_file", required=True)
parser.add_argument("-f", dest="row_id", action="store_false")  # sic!

cdm_schema_name = None
output_file = None
cdm_tables = None

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to coverage_report.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(1)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
cdm_tables_conf_file = parsed.cdm_tables_conf_file
run_id = parsed.run_id
row_id = parsed.row_id

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

etl_conf = configs.ETLConf.from_file(os.path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'mapping_counts')

try:
    cdm_tables_conf_path = os.path.join(etl_home, 'conf', cdm_tables_conf_file)
    cdm_tables_conf = configs.CDMTablesConfig(cdm_tables_conf_path)
except (OSError, IOError, ValueError) as e:
    etl_print(
        'Failed to read configuration file "{filename}"\n{exception}'.format(
            filename=cdm_tables_conf_file,
            exception=str(e)
        ),
        ETLMessageType.Error
    )
    sys.exit(1)

cdm_schema_name = etl_conf.schemas['cdm_schema']
src_schema_name = etl_conf.schemas['source_schema']
output_file = os.path.join(
    etl_home, 'reports',
    os.path.splitext(etl_conf_file)[0], 'coverage_report.json')
cdm_tables = [x['table'] for x in cdm_tables_conf.tables]

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="coverage_report")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.SrcToCdmCounts()
else:
    runner = sql_core.SrcToCdmCounts()

# ======= 4. Run job ==========================================================

runner.connect(session, src_schema_name, cdm_schema_name)
runner.fill_out(cdm_tables)

# ======= 5. Write job report =================================================

runner.save_to_json(output_file)

# ======= 6. Create run log ===================================================

# if run_id is None:
#     etl_print(
#         'Run report is not created. Missing -r parameter',
#         ETLMessageType.Warning
#     )
# else:
#     try:
#         write_run_report(etl_home, etl_conf_file, run_id, runner.run_log, 'mapping_counts')
#     except Exception as e:
#         etl_print(
#             'Run report is not created\n' + str(e),
#             ETLMessageType.Warning)


etl_print('Job coverage_report.py finished')

# ======= End ================================================================
