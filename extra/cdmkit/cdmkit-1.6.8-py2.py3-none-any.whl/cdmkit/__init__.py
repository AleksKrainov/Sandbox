__version__ = "1.6.8"

from cdmkit.etl_run import run
