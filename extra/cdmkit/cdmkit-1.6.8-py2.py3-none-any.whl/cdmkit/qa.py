"""Run etl convertion step
"""

import argparse
import sys
import traceback
import json
from os import path

from cdmkit.core.utils import create_log_file, write_run_report, format_script_name
from cdmkit.core import etl_print, ETLMessageType
from cdmkit.core import configs
from cdmkit.core import connections
from cdmkit.core import exceptions as E
from cdmkit.core import job_reports
try:
    from cdmkit.cdmspark import etl_core as spark_core
except ImportError:
    etl_print('PySpark is not available in this environment. Using SQL core')
from cdmkit.cdmredshift import etl_core as sql_core


def write_qa_report(etl_home, etl_conf_file, qa_results, script_name=None):
    etl_print('Writing intermediate qa report', ETLMessageType.Running)
    qa_results_json = list()

    for qa_info in qa_results:
        qa_results_json.append(qa_info.to_json())

    try:
        report_path = '{home}/temp/{conf}/qa{script}.json'.format(
            home=etl_home,
            conf=path.splitext(etl_conf_file)[0],
            script=format_script_name(script_name)
        )
        with open(report_path, 'wt') as report_file:
            json.dump(qa_results_json, report_file, indent=4)
    except (ValueError, OSError, IOError) as exc:
        etl_print('', ETLMessageType.Failed)
        raise E.JobReportException(cause=exc)

    etl_print('', ETLMessageType.Ok)


# ======= Start ==============================================================

etl_print('Job qa.py started', log=False)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("-h", dest="etl_home", type=str)
parser.add_argument("-e", dest="etl_conf_file", type=str, required=True)
parser.add_argument("-s", dest="script_file", type=str, required=True)
parser.add_argument("-r", dest="run_id", type=str)
parser.add_argument("-d", dest="notebook_run", action="store_true")
parser.add_argument("-sw", dest="skip_warnings", action='store_true')
parser.add_argument("--rule-col", dest="rule_col_name", type=str)

# ======= 1. Parse command line args ==========================================

etl_print(
    'Parsing command line arguments',
    message_type=ETLMessageType.Running,
    log=False
)
try:
    parsed = parser.parse_args(sys.argv[1:])
except argparse.ArgumentError:
    etl_print('', message_type=ETLMessageType.Failed, log=False)
    etl_print(
        'Wrong arguments passed to qa.py job',
        message_type=ETLMessageType.Error,
        log=False
    )
    sys.exit(2)

etl_home = parsed.etl_home
etl_conf_file = parsed.etl_conf_file
script_file = parsed.script_file
run_id = parsed.run_id
notebook_run = parsed.notebook_run

script_full_path = path.join(etl_home, 'qa', script_file)
if not path.exists(script_full_path):
    etl_print('', message_type=ETLMessageType.Failed)
    etl_print(
        "QA script '{f}' ({p}) doesn't exist".format(f=script_file, p=script_full_path),
        message_type=ETLMessageType.Error
    )
    sys.exit(2)

etl_print('', message_type=ETLMessageType.Ok, log=False)

# ======= 2. Load configuration files =========================================

qa_conf_file = None
qa_conf = None

etl_conf = configs.ETLConf.from_file(path.join(etl_home, 'conf', etl_conf_file))
create_log_file(etl_home, etl_conf_file, 'qa', script_file)

# ======= 3. Set up spark session and runner ==================================

builder = connections.ConnectionBuilder()
session = builder.get_connection_by_etlconf(etl_conf, appname="qa")

if isinstance(session, connections.SparkConnection):
    runner = spark_core.QARunner(session, etl_home, etl_conf, qa_conf, parsed.skip_warnings)
else:
    runner = sql_core.QARunner(session, etl_home, etl_conf, qa_conf, parsed.skip_warnings)

# ======= 4. Run job ==========================================================

try:
    runner.run_file(path.join(etl_home, 'qa', script_file))
except E.JobExecException as e:
    etl_print(
        'Job qa.py failed\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    traceback.print_exc(file=sys.stdout)
    sys.exit(1)

# ======= 5. Write job report =================================================

try:
    write_qa_report(etl_home, etl_conf_file, runner.qa_results(), script_file)
except (E.JobReportException, AttributeError) as e:
    etl_print(
        'Job qa.py failed\n{exception}'.format(exception=str(e)),
        ETLMessageType.Error
    )
    sys.exit(1)

# ======= 6. Create run log ===================================================

if run_id is None:
    etl_print(
        'Run report is not created. Missing -r parameter',
        ETLMessageType.Warning
    )
else:
    try:
        write_run_report(etl_home, etl_conf_file, run_id, runner.run_log.serialize(), 'qa')
    except (E.JobReportException, AttributeError) as e:
        etl_print(
            'Run report is not created\n' + str(e),
            ETLMessageType.Warning
        )
        sys.exit(1)

if notebook_run: return_code = 0

etl_print('Job qa.py finished')
has_exec_errors = any([str(x.result).startswith("ERROR") for x in runner.qa_results()])
if has_exec_errors:
    # eremoteio to indicate that errors happened during execution
    sys.exit(121)
