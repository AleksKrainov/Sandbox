import argparse
from datetime import datetime as dt
import json
import os

from cdmkit.core import exceptions as E
from cdmkit import __version__


CDMKIT_DESCRIPTION = """
    CDMKit is a tool designed to automate all steps of raw-to-OMOP data conversions. The steps include:

    - Loading the standard OMOP vocabularies and auxiliary custom mapping files into transformation database;
    - Integration of custom data mapping into standard vocabularies;
    - Source raw data profiling and statistics collection;
    - Execution of the transformation workflow;
    - Automated unit testing of the transformation output against the OMOP and business logic constraints;
    - Execution of the additional complex business logic tests;
    - OMOP data profiling and statistics, gathering information about mapping rates;
    - Unloading the final OMOP data files into target storage.

    Each step produces a run log and a detailed execution report.

    The tool itself does not contain any business logic related to any specific data set;
    instead, CDMKit is designed to work with multiple datasets ("projects")
    and multiple conversion steps ("environments") at once.
    All dataset-specific configuration, mapping files, and SQL scripts
    are imported into CDMKit as a project that can be put under version control.
"""


class CmdArgsParser(object):

    JOB_ALIASES = {
        'source_stats': 'srcstats',
        'src_stats':    'srcstats',
        'cdm_stats':    'cdmstats',
        'stats':        'cdmstats',
        'run_workflow': 'run',
    }
    JOB_DESCRIPTIONS = [
        ('setup', '    Configure CDMKit'),
        ('new_project', '[P] Create new project'),
        ('import_project', '[P] Try to import existing project'),
        ('delete_project', '[P] Delete project'),
        ('new_env', '[E] Create new environment'),
        ('update_env', '[E] Update <env>.etlconf file'),
        ('delete_env', '[E] Delete environment'),
        ('ddl', '[E] Create empty tables'),
        ('load', '[E] Load source data from files'),
        ('custom_voc', '[E] Build custom OMOP vocabularies'),
        ('srcstats', '[E] Run source data profiling'),
        ('build_graph', '[E] Generate workflow from SQL scripts'),
        ('run', '[E] Generate and run workflow from SQL scripts'),
        ('verify', '[E] Run automated unit testing'),
        ('qa', '[E] Run QA scripts'),
        ('cdmstats', '[E] Run target data profiling'),
        ('unload', '[E] Unload target data to files'),
        ('patients_history', '[E] Generate sample patients history'),
        ('coverage_report', '[E] Generate source to CDM codes mapping report'),
    ]
    PROJECT_HELP = (
        'project name, two notations available:\n'
        '<project>            - for project-level jobs\n'
        '<project>.<env>      - for environment-level jobs\n'
    )

    def __init__(self, accentor_home=None):
        self.job = None
        self.project = None
        self.etl_conf_name = None
        self.job_params = list()
        self.accentor_home = os.getenv("CDMKIT_HOME", accentor_home or os.path.abspath(os.path.expanduser("~/cdmkit/")))
        self.project_conf = None
        self.table = list()
        self.script_files = list()
        FNULL = open(os.devnull, 'w')
        self.stderr = FNULL

        self.parser = self._init_parser()

    def load_conf_files(self):
        # load projects.conf
        projects_conf_path = os.path.join(self.accentor_home, 'conf', 'projects.conf')
        with open(projects_conf_path, 'r') as projects_conf_file:
            self.projects_conf = json.load(projects_conf_file)
        # load accentor.conf
        accentor_conf_path = os.path.join(self.accentor_home, 'conf', 'accentor.conf')
        with open(accentor_conf_path, 'r') as acc_conf_file:
            accentor_conf = json.load(acc_conf_file)
            self.projects_home = os.getenv("CDMKIT_PROJECTS_HOME", accentor_conf['projects_home'])
            self._rule_col_name = accentor_conf.get("business_rule_column_name")    # related: CDMK-75

    def _init_parser(self):
        """
        Creates custom argparse.ArgumentParser instance.
        """
        parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog="cdmkit",
            description=CDMKIT_DESCRIPTION,
            epilog="(c)2015-{}, Odysseus Data Services, Inc. All rights reserved.".format(dt.today().year)
        )
        parser.add_argument('--version', action="version",
                            version='%(prog)s {}'.format(__version__))
        # shared args
        proj_parser = argparse.ArgumentParser(add_help=False)
        proj_parser.add_argument('project', help=self.PROJECT_HELP)
        proj_parser.add_argument('--verbose', '--spamlog', action='store_true',
                            help='do not suppress errors')
        proj_parser.add_argument('--noid', action='store_true',
                            help='do not add utility columns')

        # required
        jobs = parser.add_subparsers(dest='job', metavar='', title="available jobs (use 'cdmkit job --help' for more info)")
        job_parsers = dict()
        for job_name, job_help in self.JOB_DESCRIPTIONS:
            aliases = [x for x, y in self.JOB_ALIASES.items() if y == job_name]
            # TODO: assign parent parser for project/env level jobs here
            job_parsers[job_name] = jobs.add_parser(job_name, aliases=aliases, help=job_help,
                                                    description=job_help,
                                                    formatter_class=argparse.RawTextHelpFormatter,
                                                    parents=[proj_parser] if job_help[0] == '[' else [])

        # optional
        job_parsers['setup'].add_argument('-c', '--cdmkit-home', default=self.accentor_home,
                                          help='directory for CDMKit itself (default: %(default)s)')
        job_parsers['setup'].add_argument('-p', '--projects-home', default=os.path.join(self.accentor_home, 'projects'),
                                          help='directory for CDMKit projects (default: %(default)s)')
        job_parsers['run'].add_argument(
            '--scripts', nargs='*', metavar="A.sql",
            help='run only specific SQL file(s); path is relative to src/')
        job_parsers['run'].add_argument(
            '--folders', nargs='*', metavar="FOLDER",
            help='run only SQL files in given folders; path is relative to src/')
        job_parsers['delete_project'].add_argument('--clean-files', action='store_true',
            help='delete project folder completely')
        job_parsers['delete_env'].add_argument('--clean-files', action='store_true',
            help='delete environment files completely')
        job_parsers['load'].add_argument('--generate-config', action='store_true', dest='gen_config',
            help='generate srcstats configuration for loaded data')
        job_parsers['import_project'].add_argument('-nec', '--no-etlconf-check', action='store_false', dest='check_etlconfs',
            help='disable etlconf structure checks')
        job_parsers['run'].add_argument('--no-count', action='store_true',
            help='do not collect table count information (may improve performance)')
        job_parsers['run'].add_argument('--start',
            help='start execution from the specified workflow script')
        job_parsers['run'].add_argument('--stop',
            help='stop execution after the specified workflow script')
        job_parsers['ddl'].add_argument('--tables', nargs='+', default=None, metavar="TABLE",
            help='run ddl job only for specified tables')
        job_parsers['run'].add_argument('--reset', action='store_true',
            help='force job to start from the first workflow script')
        job_parsers['cdmstats'].add_argument('--reset', action='store_true',
            help='force job to start from the first table in the config')
        job_parsers['cdmstats'].add_argument('--update-report', action='store_true',
            help='update existing cdmstats report for given tables; --tables must be specified')
        job_parsers['cdmstats'].add_argument('--tables', nargs='+', default=None, metavar="TABLE",
            help='run cdmstats job only for specified tables')
        job_parsers['srcstats'].add_argument('--update-report', action='store_true',
            help='update existing srcstats report for given tables; --tables must be specified')
        job_parsers['srcstats'].add_argument('--tables', nargs='+', default=None, metavar="TABLE",
            help='run srcstats job only for specified tables')
        job_parsers['qa'].add_argument('--update-report', action='store_true',
            help='update existing qa report for given scripts; --scripts must be specified')
        job_parsers['qa'].add_argument(
            '--scripts', nargs='*', metavar="A.sql",
            help='run only specific SQL file(s); path is relative to qa/')
        job_parsers['qa'].add_argument(
            '--skip-warnings', action='store_true', dest='skip_warnings',
            help='skip non-critical checks')
        job_parsers['verify'].add_argument('--update-report', action='store_true',
            help='update existing verify report for given tables; --tables must be specified')
        job_parsers['verify'].add_argument('--tables', nargs='+', default=None, metavar="TABLE",
            help='run verify job only for specified tables')
        job_parsers['verify'].add_argument(
            '--skip-warnings', action='store_true', dest='skip_warnings',
            help='skip non-critical checks')
        job_parsers['verify'].add_argument('--reset', action='store_true',
            help='force job to start from the beginning')
        job_parsers['new_env'].add_argument('--cdm-version', default='5.4.0',
            help='choose target OMOP CDM version (default: %(default)s)')
        job_parsers['run'].add_argument(
            '--no-inference', default=True, action='store_false', dest='infer_doc_info',
            help='do not infer target/source tables from SQL queries, use only user-provided information')  # note the reversed logic
        job_parsers['build_graph'].add_argument(
            '--no-inference', default=True, action='store_false', dest='infer_doc_info',
            help='do not infer target/source tables from SQL queries, use only user-provided information')  # note the reversed logic
        job_parsers['custom_voc'].add_argument(
            '--no-voc-merge', default=True, action='store_false', dest='merge_with_voc',
            help='do not merge custom-built vocabularies with OMOP vocabs')
        job_parsers['custom_voc'].add_argument(
            '--empty-old', default=False, action='store_true',
            help='use if no previous custom mapping files are available')
        job_parsers['custom_voc'].add_argument(
            '--empty-new', default=False, action='store_true',
            help='use if no new custom mapping files are available')
        job_parsers['custom_voc'].add_argument(
            '--ignore-level', default='warning', choices=['no', 'warning', 'error'],
            help='level of errors to ignore during custom mapping validation (default: %(default)s)')
        job_parsers['custom_voc'].add_argument(
            '--stats-only', default=False, action='store_true', dest='stats_only',
            help='skip vocabulary build phase and only calculate stats')
        job_parsers['ddl'].add_argument(
            '-cs', '--create-schema', choices=("no", "yes", "overwrite"), default="yes",
            help="\n    ".join([
                "create or overwrite DB schema (default: %(default)s):",
                "'no'        - do nothing",
                "'yes'       - create only if doesnt exist",
                "'overwrite' - always drop and recreate"])
        )
        job_parsers['load'].add_argument(
            '-cs', '--create-schema', choices=("no", "yes", "overwrite"), default="yes",
            help="\n    ".join([
                "create or overwrite DB schema (default: %(default)s):",
                "'no'        - do nothing",
                "'yes'       - create only if doesnt exist",
                "'overwrite' - always drop and recreate"])
        )
        job_parsers['custom_voc'].add_argument(
            '-cs', '--create-schema', choices=("no", "yes", "overwrite"), default="yes",
            help="\n    ".join([
                "create or overwrite DB schema (default: %(default)s):",
                "'no'        - do nothing",
                "'yes'       - create only if doesnt exist",
                "'overwrite' - always drop and recreate"])
        )
        job_parsers['load'].add_argument(
            '--cdp-compatible', action='store_true',
            help='change the mechanism for saving data into tables on Cloudera Data Platform (CDP); this option is not used on any other platform'),
        job_parsers['update_env'].add_argument(
            '--schemas', nargs='*', metavar="key=val", help='update schema names'),
        job_parsers['update_env'].add_argument(
            '--params', nargs='*', metavar="key=val", help='update general parameters'),
        etlconf_job_sections = (
            "load", "srcstats", "ddl", "custom_voc",
            "run", "verify", "qa", "stats", "unload"
        )
        for x in etlconf_job_sections:
            job_parsers['update_env'].add_argument(
                '--{}'.format(x), nargs='*', metavar='CONF', help='update {} job parameters'.format(x)),
        # DBX workaround
        job_parsers['ddl'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                        help='run inside current Databricks notebook')
        job_parsers['load'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                         help='run inside current Databricks notebook')
        job_parsers['verify'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                           help='run inside current Databricks notebook')
        job_parsers['qa'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                       help='run inside current Databricks notebook')
        job_parsers['srcstats'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                             help='run inside current Databricks notebook')
        job_parsers['cdmstats'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                             help='run inside current Databricks notebook')
        job_parsers['unload'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                           help='run inside current Databricks notebook')
        job_parsers['run'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                                 help='run inside current Databricks notebook')
        job_parsers['patients_history'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                                     help='run inside current Databricks notebook')
        job_parsers['coverage_report'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                                    help='run inside current Databricks notebook')
        job_parsers['build_graph'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                                help='run inside current Databricks notebook')
        job_parsers['custom_voc'].add_argument('--notebook-run', action='store_true', dest='notebook_run',
                                               help='run inside current Databricks notebook')

        return parser

    @classmethod
    def parse_job(cls, arg):
        return cls.JOB_ALIASES.get(arg, arg)

    @staticmethod
    def parse_project_entity(arg):
        try:
            project, environment = arg.lower().split('.')
        except ValueError:
            project, environment = arg.lower(), None
        return project, environment

    # TODO refactor - too many if
    def parse_cmdargs(self, argv):
        """Parses sys.argv and loads project/env assets.

        Args:
            argv (sys.argv): 'dirty' CLI args.

        Returns:
            self

        """
        args = self.parser.parse_args(argv[1:])

        self.__dict__.update(args.__dict__)
        self.job = self.parse_job(args.job)
        if self.job == "setup":
            return self

        self.load_conf_files()
        self.project, self.environment = self.parse_project_entity(args.project)

        # check project existence
        if self.job not in ('new_project', 'import_project'):
            if self.project not in self.projects_conf:
                raise E.CLIArgsException(
                    'Unknown project "{project}".\n'
                    'Please make sure your project is added to {conf}\n'.format(
                        project=self.project,
                        conf=os.path.join(self.accentor_home, 'conf', 'projects.conf')
                    )
                )
            self.project_conf = self.projects_conf[self.project]

            if self.job not in ('new_env', 'delete_project'):
                # because new envs don't have a record in project_conf
                if self.environment is None:
                    raise E.CLIArgsException(
                        "Job '{self.job}' requires <project>.<enviroment> syntax. "
                        "Your input '{args.project}' doesn't match it."
                        .format(self=self, args=args))
                if self.environment not in self.project_conf['environments']:
                    raise E.CLIArgsException(
                        "Environment '{self.environment}' is not found within project '{self.project}'. "
                        "If it's a new one, try running 'new_env' command first."
                        .format(self=self))
                self.etl_conf_name = self.project_conf['environments'][self.environment]['conf']

        # optional args
        if args.verbose:
            self.stderr.close()
            self.stderr = None
        if args.noid:
            self.job_params.append('-f')
        if getattr(args, "no_count", False) is True:
            self.job_params.append('-n')
        if getattr(args, "tables", None) is not None:
            self.job_params.extend(['-t', ','.join(args.tables)])
        if getattr(args, "skip_warnings", False) is True:
            self.job_params.append('-sw')
        if self._rule_col_name is not None:
            self.job_params.extend(['--rule-col', self._rule_col_name.strip()])

        return self

    def __del__(self):
        if self.stderr is not None:
            self.stderr.close()
