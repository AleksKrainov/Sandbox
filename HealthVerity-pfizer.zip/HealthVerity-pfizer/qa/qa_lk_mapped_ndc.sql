--- table: lk_mapped_ndc
--- column: none
--- rule_id: pharmacy_claims_closed_cut.ndc_code
--- comment: counts
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_ndc
    WHERE
        rule_id = 'pharmacy_claims_closed_cut.ndc_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_pharmacy_claims_closed_cut pcct
    --checking person
    INNER JOIN
        @target_schema.lk_person p
            ON p.person_source_value = pcct.hvid
    --source and target concepts
    LEFT JOIN
        @voc_schema.voc_concept ndc
            ON  regexp_replace(ndc.concept_code,'\\.', '') = pcct.ndc_code
            AND ndc.vocabulary_id = 'NDC'
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr
            ON  (
                    CASE
                        WHEN ndc.concept_id IS NOT NULL
                        THEN ndc.concept_id
                        ELSE ''
                    END
                ) = cr.concept_id_1
            AND cr.relationship_id = 'Maps to'
            AND cr.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept c_stand
            ON  cr.concept_id_2 = c_stand.concept_id
            AND c_stand.standard_concept = 'S'
            AND c_stand.invalid_reason IS NULL
    --value as concept_id
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr_value
         ON  (
                CASE
                    WHEN ndc.concept_id IS NOT NULL
                    THEN ndc.concept_id
                    ELSE ''
                END
             ) = cr_value.concept_id_1 
         AND cr_value.relationship_id = 'Maps to value'
         AND cr_value.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept value_stand
            ON  cr_value.concept_id_2 = value_stand.concept_id
            AND value_stand.standard_concept = 'S'
            AND value_stand.invalid_reason IS NULL
    --provider_id
    LEFT JOIN
        @target_schema.cdm_provider prov1 
            ON prov1.provider_source_value=pcct.prov_prescribing_npi
    WHERE
    --filtering rules:
        pcct.ndc_code IS NOT NULL
        AND pcct.hvid IS NOT NULL
        AND pcct.p_hvid = 'c'
);

--- table: lk_mapped_ndc
--- column: all values
--- rule_id: pharmacy_claims_closed_cut.ndc_code
--- comment: value check
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_ndc
    WHERE
        rule_id = 'pharmacy_claims_closed_cut.ndc_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_ndc lk
    INNER JOIN
        @source_schema.src_pharmacy_claims_closed_cut pcct
            ON  lk.rule_id = 'pharmacy_claims_closed_cut.ndc_code'
            AND lk.load_row_id = pcct.load_row_id
    --checking person
    INNER JOIN
        @target_schema.lk_person p
            ON p.person_source_value = pcct.hvid
    --source and target concepts
    LEFT JOIN
        @voc_schema.voc_concept ndc
            ON  regexp_replace(ndc.concept_code,'\\.', '') = pcct.ndc_code
            AND ndc.vocabulary_id = 'NDC'
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr 
        ON  (
                CASE
                    WHEN ndc.concept_id IS NOT NULL
                    THEN ndc.concept_id
                    ELSE ''
                END
            ) = cr.concept_id_1
        AND cr.relationship_id = 'Maps to'
        AND cr.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept c_stand
            ON  cr.concept_id_2 = c_stand.concept_id
            AND c_stand.standard_concept = 'S'
            AND c_stand.invalid_reason IS NULL
    --value as concept_id
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr_value 
        ON  (
                CASE
                    WHEN ndc.concept_id IS NOT NULL
                    THEN ndc.concept_id
                    ELSE ''
                END
            ) = cr_value.concept_id_1
        AND cr_value.relationship_id = 'Maps to value'
        AND cr_value.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept value_stand
            ON  cr_value.concept_id_2 = value_stand.concept_id
            AND value_stand.standard_concept = 'S'
            AND value_stand.invalid_reason IS NULL
    --provider_id
    LEFT JOIN
        @target_schema.cdm_provider prov1
            ON prov1.provider_source_value = pcct.prov_prescribing_npi
    WHERE
    --filtering rules
        pcct.ndc_code IS NOT NULL
        AND pcct.hvid IS NOT NULL
    --value checking
        AND lk.person_id = p.person_id
    --dates checking
        AND lk.event_start_date = pcct.date_service
    --source- and standard concepts
        AND (
                lk.event_concept_id = c_stand.concept_id
                OR (lk.event_concept_id = 0 AND c_stand.concept_id IS NULL)
            )
        AND (
                CASE
                    WHEN ndc.concept_id IS NOT NULL
                    THEN ndc.concept_id = lk.event_source_concept_id
                    ELSE lk.event_source_concept_id = 0
                END
            )
        AND lk.event_type_concept_id = 31980
    --value as concept ids
        AND (
                lk.value_as_concept_id = value_stand.concept_id
                OR (lk.value_as_concept_id IS NULL AND value_stand.concept_id IS NULL)
            )
        AND (
                lk.provider_id = prov1.provider_id
                OR (lk.provider_id IS NULL AND prov1.provider_id IS NULL)
            )
    --days supply
        AND (
                CASE
                    --WHEN (c_stand.domain_id = 'Drug' OR c_stand.domain_id IS NULL)
                    WHEN COALESCE(c_stand.domain_id, ndc.domain_id, 'Drug') = 'Drug'
                          AND pcct.days_supply IS NOT NULL
                          AND pcct.days_supply RLIKE '\\b\\d+(\\.\\d+)?\\b'
                          AND TRY_CAST(pcct.days_supply AS FLOAT) >=1
                          AND TRY_CAST(pcct.days_supply AS FLOAT) <=365
                    THEN pcct.days_supply = lk.days_supply
                    ELSE lk.days_supply IS NULL
                END
            )
        AND pcct.p_hvid = 'c'
);
