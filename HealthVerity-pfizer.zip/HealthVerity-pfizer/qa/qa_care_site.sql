--- table: cdm_care_site
--- column: care_source_value
--- rule_id: none
--- comment: check for matching source_value
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.cdm_care_site
)
-
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.cdm_care_site cs
    INNER JOIN
        (
            SELECT DISTINCT
                prov_facility_npi,
                prov_facility_name_1,
                prov_facility_name_2
            FROM
                @source_schema.src_medical_claims
            WHERE
                prov_facility_npi IS NOT NULL
                OR prov_facility_name_1 IS NOT NULL
                OR prov_facility_name_2 IS NOT NULL
        ) m
        ON cs.care_site_source_value = COALESCE(m.prov_facility_npi, '') || '|' ||
                                       COALESCE(m.prov_facility_name_1, '')  || '|' ||
                                       COALESCE(m.prov_facility_name_2, '')
);
