--- table: lk_mapped_proc
--- column: none
--- rule_id: medical_claims_closed_cut.procedure
--- comment: counts
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc
    WHERE
        rule_id = 'medical_claims_closed_cut.procedure'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_medical_claims_closed_cut mcct
    --checking person
    INNER JOIN
        @target_schema.lk_person p
            ON p.person_source_value = mcct.hvid
   --source and target concepts
    LEFT JOIN
        @voc_schema.voc_concept c_cpt4
            ON  regexp_replace(c_cpt4.concept_code,'\\.', '') = mcct.procedure_code
            AND c_cpt4.vocabulary_id = 'CPT4'
    LEFT JOIN
        @voc_schema.voc_concept c_hcpcs
            ON  regexp_replace(c_hcpcs.concept_code,'\\.', '') = mcct.procedure_code
            AND c_hcpcs.vocabulary_id = 'HCPCS'
    LEFT JOIN
        @voc_schema.voc_concept c_icd10pcs
            ON  regexp_replace(c_icd10pcs.concept_code,'\\.', '') = mcct.procedure_code
            AND c_icd10pcs.vocabulary_id = 'ICD10PCS'
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr
            ON  (
                    CASE
                        WHEN (c_cpt4.concept_id IS NOT NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NOT NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NOT NULL)
                        THEN COALESCE(c_cpt4.concept_id, c_hcpcs.concept_id, c_icd10pcs.concept_id, '')
                        ELSE ''
                    END
                ) = cr.concept_id_1
            AND cr.relationship_id = 'Maps to'
            AND cr.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept c_stand
            ON  cr.concept_id_2 = c_stand.concept_id
            AND c_stand.standard_concept = 'S'
            AND c_stand.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr_value 
            ON  (
                    CASE
                        WHEN (c_cpt4.concept_id IS NOT NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NOT NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NOT NULL)
                        THEN COALESCE(c_cpt4.concept_id, c_hcpcs.concept_id, c_icd10pcs.concept_id, '')
                        ELSE ''
                    END
                ) = cr_value.concept_id_1
            AND cr_value.relationship_id = 'Maps to value'
            AND cr_value.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept value_stand
            ON  cr_value.concept_id_2 = value_stand.concept_id
            AND value_stand.standard_concept = 'S'
            AND value_stand.invalid_reason IS NULL
    --provider_id
    LEFT JOIN
        @target_schema.cdm_provider prov1
            ON prov1.provider_source_value = mcct.prov_rendering_npi
    LEFT JOIN
        @target_schema.cdm_provider prov2
            ON prov2.provider_source_value = mcct.prov_billing_npi
    --visit_occurrence_id
    LEFT JOIN
        @target_schema.cdm_visit_occurrence visit
            ON (
                    CASE
                        WHEN (
                                (
                                    mcct.claim_type = 'I'
                                    AND mcct.inst_type_of_bill_std_id LIKE '1%'
                                    AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                                )
                                OR
                                (
                                    mcct.claim_type = 'P'
                                    AND  mcct.place_of_service_std_id = '21'
                                 )
                              )
                        THEN mcct.confinement_id = visit.visit_id_source_value
                             AND visit.person_id = p.person_id
                        ELSE visit.visit_id_source_value = mcct.hv_enc_id
                             AND visit.person_id = p.person_id
                             AND visit.visit_start_date = mcct.date_service
                    END
                )
    WHERE
    --filtering rules:
        mcct.procedure_code IS NOT NULL
        AND mcct.hvid IS NOT NULL
        AND mcct.p_hvid = 'c'
);

--- table: lk_mapped_proc
--- column: all values except visit_occurrence_id
--- rule_id: medical_claims_closed_cut.procedure
--- comment: value check
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc
    WHERE
        rule_id = 'medical_claims_closed_cut.procedure'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc lk
    INNER JOIN
        @source_schema.src_medical_claims_closed_cut mcct
            ON  lk.rule_id='medical_claims_closed_cut.procedure'
            AND lk.load_row_id=mcct.load_row_id
    --checking person
    INNER JOIN
        @target_schema.lk_person p
            ON p.person_source_value = mcct.hvid
    --source and target concepts
    LEFT JOIN
        @voc_schema.voc_concept c_cpt4
            ON  regexp_replace(c_cpt4.concept_code,'\\.', '') = mcct.procedure_code
            AND c_cpt4.vocabulary_id = 'CPT4'
    LEFT JOIN
        @voc_schema.voc_concept c_hcpcs
            ON  regexp_replace(c_hcpcs.concept_code,'\\.', '') = mcct.procedure_code
            AND c_hcpcs.vocabulary_id = 'HCPCS'
    LEFT JOIN
        @voc_schema.voc_concept c_icd10pcs
            ON  regexp_replace(c_icd10pcs.concept_code,'\\.', '') = mcct.procedure_code
            AND c_icd10pcs.vocabulary_id = 'ICD10PCS'
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr
            ON  (
                    CASE
                        WHEN (c_cpt4.concept_id IS NOT NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NOT NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NOT NULL)
                        THEN COALESCE(c_cpt4.concept_id, c_hcpcs.concept_id, c_icd10pcs.concept_id)
                        ELSE ''
                    END
                ) = cr.concept_id_1
            AND cr.relationship_id = 'Maps to'
            AND cr.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept c_stand
            ON  cr.concept_id_2 = c_stand.concept_id
            AND c_stand.standard_concept = 'S'
            AND c_stand.invalid_reason IS NULL
    --value as concept_id
    LEFT JOIN
        @voc_schema.voc_concept_relationship cr_value
            ON (
                    CASE
                        WHEN (c_cpt4.concept_id IS NOT NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NOT NULL AND c_icd10pcs.concept_id IS NULL)
                             OR
                             (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NOT NULL)
                        THEN COALESCE(c_cpt4.concept_id, c_hcpcs.concept_id, c_icd10pcs.concept_id)
                        ELSE ''
                    END
                ) = cr_value.concept_id_1
            AND cr_value.relationship_id = 'Maps to value'
            AND cr_value.invalid_reason IS NULL
    LEFT JOIN
        @voc_schema.voc_concept value_stand
            ON  cr_value.concept_id_2 = value_stand.concept_id
            AND value_stand.standard_concept = 'S'
            AND value_stand.invalid_reason IS NULL
    --provider_id
    LEFT JOIN
        @target_schema.cdm_provider prov1
            ON prov1.provider_source_value = mcct.prov_rendering_npi
    LEFT JOIN
        @target_schema.cdm_provider prov2
            ON prov2.provider_source_value = mcct.prov_billing_npi
    WHERE
    --filtering rules:
        mcct.procedure_code IS NOT NULL
        AND mcct.hvid IS NOT NULL
    --value checking:
        AND lk.person_id=p.person_id
        AND lk.event_start_date = mcct.date_service
        AND (
                lk.event_concept_id = c_stand.concept_id
                OR (lk.event_concept_id = 0 AND c_stand.concept_id IS NULL)
            )
        AND ( 
                CASE
                    WHEN (c_cpt4.concept_id IS NOT NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NULL)
                         OR
                         (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NOT NULL AND c_icd10pcs.concept_id IS NULL)
                         OR
                         (c_cpt4.concept_id IS NULL AND c_hcpcs.concept_id IS NULL AND c_icd10pcs.concept_id IS NOT NULL)
                    THEN lk.event_source_concept_id = COALESCE(c_cpt4.concept_id, c_hcpcs.concept_id, c_icd10pcs.concept_id)
                    ELSE lk.event_source_concept_id = 0
                END
            )
        AND lk.event_type_concept_id = 31980
        AND (
                lk.value_as_concept_id = value_stand.concept_id
                OR (lk.value_as_concept_id IS NULL AND value_stand.concept_id IS NULL)
            )
        AND (
                lk.provider_id = COALESCE(prov1.provider_id, prov2.provider_id)
                OR (lk.provider_id IS NULL AND COALESCE(prov1.provider_id, prov2.provider_id) IS NULL)
            )
        AND mcct.p_hvid = 'c'
);

--- table: lk_mapped_proc
--- column:  visit_occurrence_id, inpatient visits
--- rule_id: medical_claims_closed_cut.procedure
--- comment: value check
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc lk
    INNER JOIN
        @source_schema.src_medical_claims_closed_cut mcct
            ON lk.load_row_id = mcct.load_row_id
    WHERE
        rule_id = 'medical_claims_closed_cut.procedure'
        AND
    --inpatient visit criteria
            (
                (
                    mcct.claim_type = 'I'
                    AND mcct.inst_type_of_bill_std_id LIKE '1%'
                    AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                )
                OR
                (
                    mcct.claim_type = 'P'
                    AND  mcct.place_of_service_std_id = '21'
                )
            )
        AND mcct.p_hvid = 'c'
)
-
(
    WITH visit_sub AS
    (
        SELECT
            p.person_id,
            mcct.hvid,
            mcct.date_service,
            mcct.hv_enc_id,
            MIN(confinement_id) AS confinement_id
        FROM
            @source_schema.src_medical_claims_closed_cut mcct
        INNER JOIN
            @target_schema.lk_person p
                ON p.person_source_value = mcct.hvid
        WHERE 
        --inpatient visit criteria
            (
                mcct.claim_type = 'I'
                AND mcct.inst_type_of_bill_std_id LIKE '1%'
                AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
            )
            OR
            (
                mcct.claim_type = 'P'
                AND  mcct.place_of_service_std_id = '21'
            )
            AND mcct.p_hvid = 'c'
        GROUP BY
            p.person_id,
            mcct.hvid,
            mcct.date_service,
            mcct.hv_enc_id
    )
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc lk
    INNER JOIN
        @source_schema.src_medical_claims_closed_cut mcct
            ON  lk.rule_id = 'medical_claims_closed_cut.procedure'
            AND lk.load_row_id = mcct.load_row_id
            AND
    --inpatient visit criteria
                (
                    (
                        mcct.claim_type = 'I'
                        AND mcct.inst_type_of_bill_std_id LIKE '1%'
                        AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                    )
                    OR
                    (
                        mcct.claim_type = 'P'
                        AND  mcct.place_of_service_std_id = '21'
                    )
                )
    INNER JOIN
        visit_sub v
            ON  v.hvid = mcct.hvid
            AND v.date_service=mcct.date_service
            AND v.hv_enc_id=mcct.hv_enc_id
    --visit_occurrence_id
    LEFT JOIN
        @target_schema.cdm_visit_occurrence visit
            ON  COALESCE(v.confinement_id, '') = visit.visit_id_source_value
            AND v.person_id = visit.person_id
    WHERE
    --filtering rules:
        mcct.procedure_code IS NOT NULL
        AND mcct.hvid IS NOT NULL
    --value checking:
        AND (
                lk.visit_occurrence_id = visit.visit_occurrence_id
                OR (lk.visit_occurrence_id IS NULL AND visit.visit_occurrence_id IS NULL)
            )
        AND mcct.p_hvid = 'c'
);

--- table: lk_mapped_proc
--- column: visit_occurrence_id, outpatient visits
--- rule_id: medical_claims_closed_cut.procedure
--- comment: value check

SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc lk
    INNER JOIN
        @source_schema.src_medical_claims_closed_cut mcct
            ON lk.load_row_id = mcct.load_row_id
    WHERE
        rule_id = 'medical_claims_closed_cut.procedure'
     --negating inpatient visit criteria
    AND NOT (
                (
                    mcct.claim_type = 'I'
                    AND mcct.inst_type_of_bill_std_id LIKE '1%'
                    AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                )
                OR
                (
                    mcct.claim_type = 'P'
                    AND  mcct.place_of_service_std_id = '21'
                )
            )
    AND mcct.p_hvid = 'c'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.lk_mapped_proc lk
    INNER JOIN
        @source_schema.src_medical_claims_closed_cut mcct
            ON  lk.rule_id = 'medical_claims_closed_cut.procedure'
            AND lk.load_row_id = mcct.load_row_id
    --negating inpatient visit criteria
            AND NOT (
                        (
                            mcct.claim_type = 'I'
                            AND mcct.inst_type_of_bill_std_id LIKE '1%'
                            AND SUBSTRING(mcct.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                        )
                        OR
                        (
                            mcct.claim_type = 'P'
                            AND mcct.place_of_service_std_id = '21'
                        )
                    )
    --checking person
    INNER JOIN
        @target_schema.lk_person p
            ON p.person_source_value = mcct.hvid
    --visit_occurrence_id
    LEFT JOIN
        @target_schema.cdm_visit_occurrence visit
            ON  visit.visit_id_source_value = mcct.hv_enc_id
            AND visit.person_id = p.person_id
            AND visit.visit_start_date = mcct.date_service
    WHERE
    --filtering rules:
        mcct.procedure_code IS NOT NULL
        AND mcct.hvid IS NOT NULL
      --value checking:
        AND (
                lk.visit_occurrence_id = visit.visit_occurrence_id
                OR (lk.visit_occurrence_id IS NULL AND visit.visit_occurrence_id IS NULL)
            )
        AND mcct.p_hvid = 'c'
);
