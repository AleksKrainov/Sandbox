--- table: cdm_person
--- column: none
--- rule_id: none
--- comment: checking that all patients from SUBSCRIPTION_PATIENT_MASTER_LIST are exists in cdm_person
SELECT
    COUNT(*)
FROM
(
    SELECT DISTINCT
        hvid
    FROM
        @source_schema.src_subscription_patient_master_list
    WHERE
        hvid IS NOT NULL
        AND patient_yob_most_recent IS NOT NULL
        AND CAST(patient_yob_most_recent AS INTEGER) <= YEAR(CAST('@max_date_of_dataset' AS DATE))
        AND p_hvid = 'c'
) src
LEFT JOIN
    @target_schema.cdm_person cdm
        ON cdm.person_source_value = src.hvid
WHERE
    cdm.person_source_value IS NULL
;
