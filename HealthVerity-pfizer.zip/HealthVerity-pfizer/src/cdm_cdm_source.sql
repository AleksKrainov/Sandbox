-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Load Table: Cdm_source
-- -------------------------------------------------------------------
TRUNCATE TABLE @cdm_schema.cdm_cdm_source;

INSERT INTO @cdm_schema.cdm_cdm_source
SELECT
    'HealthVerity'                      AS cdm_source_name,
    'HealthVerity'                      AS cdm_source_abbreviation,
    'Odysseus Data Services, Inc.'      AS cdm_holder,
    'HealthVerity'                      AS source_description,
    NULL                                AS source_documentation_reference,

    'https://github.com/OHDSI/CommonDataModel/releases/tag/v5.4.0'
                                        AS cdm_etl_reference,

    TO_DATE("@source_release_date")     AS source_release_date,
    current_date                        AS cdm_release_date,
    'v5.4.0'                            AS cdm_version,
    756265                              AS cdm_version_concept_id,  -- OMOP CDM Version 5.4.0
    v.vocabulary_version                AS vocabulary_version,
    NULL                                AS rule_id,
    NULL                                AS load_table_id,
    NULL                                AS load_row_id
FROM
    @voc_schema.voc_vocabulary v
WHERE
    vocabulary_id = 'None'
;

-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
