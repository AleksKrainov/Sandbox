-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: CDM Drug Exposure
!*/

-- -------------------------------------------------------------------
-- Populate table: tmp_drug
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_drug;
CREATE TABLE @target_schema.tmp_drug
(
    person_id               bigint,
    target_concept_id       int,
    event_start_date        timestamp,
    event_end_date          timestamp,
    type_concept_id         int,
    quantity                double,
    days_supply             double,
    sig                     string,
    refills                 int,
    provider_id             bigint,
    visit_occurrence_id     bigint,
    event_source_value      string,
    source_concept_id       int,
    route_source_value      string,
    route_concept_id        int,
    dose_unit_source_value  string,
-- cost fields
    submitted_gross_due     double,
    paid_gross_due          double,
    cost_flag               integer,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- From lk_mapped_proc
-- -------------------------------------------------------------------
/*!
    @insert
    @table:  @target_schema.tmp_drug
    @source_table: @target_schema.lk_mapped_proc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_drug
PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,
    lk.event_end_date           AS event_end_date,
    lk.event_type_concept_id    AS type_concept_id,
    NULL                        AS quantity,
    NULL                        AS days_supply,
    NULL                        AS sig,
    NULL                        AS refills,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    NULL                        AS route_source_value,
    0                           AS route_concept_id,
    NULL                        AS dose_unit_source_value,
-- cost fields
    NULL                        AS submitted_gross_due,
    NULL                        AS paid_gross_due,
    NULL                        AS cost_flag,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_proc lk
WHERE
    lk.domain_id = 'Drug'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- From lk_mapped_ndc
-- -------------------------------------------------------------------
/*!
    @insert
    @table:  @target_schema.tmp_drug
    @source_table: @target_schema.lk_mapped_ndc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_drug
PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,

    LEAST(lk.event_end_date,
          CAST('@max_date_of_dataset' AS DATE))
                                AS event_end_date,

    lk.event_type_concept_id    AS type_concept_id,
    lk.quantity                 AS quantity,
    lk.days_supply              AS days_supply,
    NULL                        AS sig,
    NULL                        AS refills,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    NULL                        AS route_source_value,
    0                           AS route_concept_id,
    NULL                        AS dose_unit_source_value,
-- cost fields
    lk.submitted_gross_due      AS submitted_gross_due,
    lk.paid_gross_due           AS paid_gross_due,
    lk.cost_flag                AS cost_flag,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_ndc lk
WHERE
    lk.domain_id = 'Drug'
    AND lk.event_start_date <= LEAST(lk.event_end_date,
                                     CAST('@max_date_of_dataset' AS DATE))
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's and Post Dedupe
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_drug_id;
CREATE TABLE @target_schema.tmp_drug_id
@PROPERTY PARTITIONED BY (p_hvid) AS
SELECT
    monotonically_increasing_id()   AS drug_exposure_id,
    de.*
FROM
    @target_schema.tmp_drug de
WHERE
    de.event_start_date >= CAST('@min_date_of_dataset' AS DATE)
;

DROP TABLE IF EXISTS @target_schema.lk_drug_cost;
CREATE TABLE @target_schema.lk_drug_cost
(
    drug_exposure_id        bigint,
    submitted_gross_due     double,
    paid_gross_due          double,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.lk_drug_cost
    @source_table: @target_schema.tmp_drug_id
    @summary: Lookup for cost-related Drug data
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_drug_cost
PARTITION (p_hvid)
SELECT
    t.drug_exposure_id          AS drug_exposure_id,
-- cost fields
    t.submitted_gross_due       AS submitted_gross_due,
    t.paid_gross_due            AS paid_gross_due,
-- --
    t.rule_id                   AS rule_id,
    t.load_table_id             AS load_table_id,
    t.load_row_id               AS load_row_id,
    t.p_hvid                    AS p_hvid
FROM
    @target_schema.tmp_drug_id t
WHERE
    t.cost_flag = 1
    -- partition filter
    AND t.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load Table: cdm_drug_exposure
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_drug_exposure;
/*!
      @insert
      @table: @target_schema.cdm_drug_exposure
      @source_table: @target_schema.tmp_drug_id
      @summary: Population CDM drug_exposure
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_drug_exposure
SELECT
    t.drug_exposure_id          AS drug_exposure_id,
    t.person_id                 AS person_id,
    t.target_concept_id         AS drug_concept_id,
    t.event_start_date          AS drug_exposure_start_date,
    NULL                        AS drug_exposure_start_datetime,
    t.event_end_date            AS drug_exposure_end_date,
    NULL                        AS drug_exposure_end_datetime,
    NULL                        AS verbatim_end_date,
    t.type_concept_id           AS drug_type_concept_id,
    NULL                        AS stop_reason,
    t.refills                   AS refills,
    t.quantity                  AS quantity,
    t.days_supply               AS days_supply,
    t.sig                       AS sig,
    t.route_concept_id          AS route_concept_id,
    NULL                        AS lot_number,
    t.provider_id               AS provider_id,
    t.visit_occurrence_id       AS visit_occurrence_id,
    NULL                        AS visit_detail_id,
    t.event_source_value        AS drug_source_value,
    t.source_concept_id         AS drug_source_concept_id,
    t.route_source_value        AS route_source_value,
    t.dose_unit_source_value    AS dose_unit_source_value,
-- --
    t.p_hvid                    AS p_hvid,
    t.rule_id                   AS rule_id,
    t.load_table_id             AS load_table_id,
    t.load_row_id               AS load_row_id
FROM
    @target_schema.tmp_drug_id t
WHERE
    -- partition filter
    t.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.cdm_drug_exposure ZORDER BY (
    person_id,
    drug_concept_id,
    drug_exposure_start_date,
    drug_exposure_end_date,
    drug_source_value
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_drug;
DROP TABLE IF EXISTS @target_schema.tmp_drug_id;
DROP TABLE IF EXISTS @target_schema.tmp_drug_dedupe_map;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/
