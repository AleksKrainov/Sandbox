-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: Provider
!*/

-- -------------------------------------------------------------------
-- Collecting provider data
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_prov_data;
/*!
    @insert
    @table: @target_schema.tmp_prov_data
    @source_table: @@source_schema.src_emr_encounter
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_data
(
    prov_source_value  STRING,
    prov_specialty     STRING,
    dea                STRING,
    basic_record_date  DATE,
    cs_source_value    STRING,
-- --
    rule_id            STRING,
    load_table_id      STRING
)
@PROPERTY
;

DROP TABLE IF EXISTS @target_schema.tmp_medical_clms_prov;
CREATE TABLE @target_schema.tmp_medical_clms_prov
(
    prov_source_value   STRING,
    prov_specialty      STRING,
    dea                 STRING,
    basic_record_date   DATE,
    cs_source_value     STRING,
-- --
    rule_id             STRING,
    load_table_id       STRING,
    p_hvid              STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clms_prov
PARTITION (p_hvid)
SELECT
    src.prov_rendering_npi                      AS prov_source_value,
    src.prov_rendering_vendor_specialty         AS prov_specialty,
    src.prov_rendering_dea_id                   AS dea,
    src.created                                 AS basic_record_date,
    src.place_of_service_std_id                 AS cs_source_value,
-- --
    'medical_claims.prov_rendering_npi'         AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.p_hvid                                  AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_rendering_npi, '')) = 10
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clms_prov
PARTITION (p_hvid)
SELECT
    src.prov_billing_npi                        AS prov_source_value,
    src.prov_billing_vendor_specialty           AS prov_specialty,
    src.prov_billing_dea_id                     AS dea,
    src.created                                 AS basic_record_date,
    src.place_of_service_std_id                 AS cs_source_value,
-- --
    'medical_claims.prov_billing_npi'           AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.p_hvid                                  AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_billing_npi, '')) = 10
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_data
SELECT DISTINCT
    src.prov_source_value                       AS prov_source_value,
    src.prov_specialty                          AS prov_specialty,
    src.dea                                     AS dea,
    src.basic_record_date                       AS basic_record_date,
    src.cs_source_value                         AS cs_source_value,
-- --
    src.rule_id                                 AS rule_id,
    src.load_table_id                           AS load_table_id
FROM
    @target_schema.tmp_medical_clms_prov src
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_medical_clms_prov;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_data
SELECT DISTINCT
    src.prov_prescribing_npi                    AS prov_source_value,
    src.prov_prescribing_vendor_specialty       AS prov_specialty,
    NULL                                        AS dea,
    NULL                                        AS basic_record_date,
    NULL                                        AS cs_source_value,
-- --
    'pharmacy_claims.prov_prescribing_npi'      AS rule_id,
    src.load_table_id                           AS load_table_id
FROM
    @source_schema.src_pharmacy_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_prescribing_npi, '')) = 10
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_prov_data ZORDER BY (
    prov_source_value,
    prov_specialty,
    basic_record_date
);

-- --------------------------------------------------------
-- definition of care_site for provider by the latest date
-- --------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_prov_cs_max_dt;
/*!
    @insert
    @table: @target_schema.tmp_prov_cs_max_dt
    @source_table: @target_schema.tmp_prov_data
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_cs_max_dt
@PROPERTY
AS SELECT
    src.prov_source_value,
    MAX(src.basic_record_date)  AS max_record_date
FROM
    @target_schema.tmp_prov_data src
WHERE
    src.cs_source_value IS NOT NULL
GROUP BY
    src.prov_source_value
;

OPTIMIZE @target_schema.tmp_prov_cs_max_dt ZORDER BY (
    prov_source_value,
    max_record_date
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_cs;
/*!
    @insert
    @table: @target_schema.tmp_prov_cs
    @source_table: @target_schema.tmp_prov_data
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_cs
@PROPERTY
AS SELECT DISTINCT
    src.prov_source_value,
    src.cs_source_value
FROM
    @target_schema.tmp_prov_data src
LEFT JOIN
    @target_schema.tmp_prov_cs_max_dt dt
        ON src.prov_source_value = dt.prov_source_value
WHERE
    src.basic_record_date = dt.max_record_date
;

OPTIMIZE @target_schema.tmp_prov_cs ZORDER BY (
    prov_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_cs_max_dt;

-- ----------------------------------------------------------
-- The most prevalent specialty
-- ----------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_prov_spclty_cnt;
CREATE TABLE @target_schema.tmp_prov_spclty_cnt
(
    prov_npi            STRING,
    prov_specialty_id   STRING,
    cnt_prov_spclty     INTEGER
)
@PROPERTY
;

DROP TABLE IF EXISTS @target_schema.tmp_med_clm_prov_spclty;
CREATE TABLE @target_schema.tmp_med_clm_prov_spclty
(
    prov_source_value   string,
    prov_specialty      string,
    p_hvid              string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_med_clm_prov_spclty
PARTITION (p_hvid)
SELECT
    src.prov_rendering_npi                  AS prov_source_value,
    src.prov_rendering_vendor_specialty     AS prov_specialty,
    src.p_hvid                              AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_rendering_npi, '')) = 10
    AND src.prov_rendering_vendor_specialty IS NOT NULL
    AND src.prov_rendering_vendor_specialty != 'UNDEFINED'
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_med_clm_prov_spclty PARTITION (p_hvid)
SELECT
    src.prov_billing_npi                    AS prov_source_value,
    src.prov_billing_vendor_specialty       AS prov_specialty,
    src.p_hvid                              AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_billing_npi, '')) = 10
    AND src.prov_billing_vendor_specialty IS NOT NULL
    AND src.prov_billing_vendor_specialty != 'UNDEFINED'
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_spclty_cnt
SELECT
    src.prov_source_value       AS prov_source_value,
    src.prov_specialty          AS prov_specialty_id,
    COUNT(*)                    AS cnt_prov_spclty
FROM
    @target_schema.tmp_med_clm_prov_spclty src
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    src.prov_source_value,
    src.prov_specialty,
    src.p_hvid
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_med_clm_prov_spclty;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_spclty_cnt
SELECT
    src.prov_prescribing_npi                AS prov_npi,
    src.prov_prescribing_vendor_specialty   AS prov_specialty_id,
    COUNT(*)                                AS cnt_prov_spclty
FROM
    @source_schema.src_pharmacy_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_prescribing_npi, '')) = 10
    AND src.prov_prescribing_vendor_specialty IS NOT NULL
    AND src.prov_prescribing_vendor_specialty != 'UNDEFINED'
    AND src.p_hvid = '@hvid_char'
GROUP BY
    src.prov_prescribing_npi,
    src.prov_prescribing_vendor_specialty
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_prov_spclty_cnt_sum;
CREATE TABLE @target_schema.tmp_prov_spclty_cnt_sum
@PROPERTY
AS SELECT
    src.prov_npi                AS prov_npi,
    src.prov_specialty_id       AS prov_specialty_id,
    SUM(src.cnt_prov_spclty)    AS cnt_prov_spclty
FROM
    @target_schema.tmp_prov_spclty_cnt src
GROUP BY
    src.prov_npi,
    src.prov_specialty_id
;

OPTIMIZE @target_schema.tmp_prov_spclty_cnt_sum ZORDER BY (
    prov_npi,
    prov_specialty_id
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_1;
/*!
    @insert
    @table: @target_schema.tmp_prov_1
    @source_table: @target_schema.tmp_prov_data
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_1
@PROPERTY
AS SELECT
    src.prov_source_value               AS prov_source_value,
    src.dea                             AS dea,
    cs.cs_source_value                  AS cs_source_value,
    src.prov_specialty                  AS prov_specialty,
    ROW_NUMBER() OVER (
        PARTITION BY
            src.prov_source_value
        ORDER BY
            cnt_sp.cnt_prov_spclty)     AS row_id,
-- --
    src.rule_id                         AS rule_id,
    src.load_table_id                   AS load_table_id
FROM
    @target_schema.tmp_prov_data src
LEFT JOIN
    @target_schema.tmp_prov_cs cs
        ON  src.prov_source_value = cs.prov_source_value
LEFT JOIN
    @target_schema.tmp_prov_spclty_cnt_sum cnt_sp
        ON  src.prov_source_value = cnt_sp.prov_npi
        AND src.prov_specialty = cnt_sp.prov_specialty_id
;

OPTIMIZE @target_schema.tmp_prov_1 ZORDER BY (
    prov_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_other_cnts;
/*!
    @insert
    @table: @target_schema.tmp_prov_other_cnts
    @source_table: @target_schema.tmp_prov
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_other_cnts
@PROPERTY
AS SELECT
    t.prov_source_value     AS prov_source_value,
    COUNT(DISTINCT t.dea)   AS dist_cnt_dea
FROM
    @target_schema.tmp_prov_1 t
GROUP BY
    t.prov_source_value
;

OPTIMIZE @target_schema.tmp_prov_other_cnts ZORDER BY (
    prov_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_final;
/*!
    @insert
    @table: @target_schema.tmp_prov_final
    @source_table: @target_schema.tmp_prov
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_final
@PROPERTY
AS SELECT
    monotonically_increasing_id()           AS row_id,
    t.prov_source_value                     AS prov_source_value,
    t.prov_specialty                        AS prov_specialty,
    t.prov_source_value                     AS npi,
    IF(cnts.dist_cnt_dea = 1, t.dea, NULL)  AS dea,
    t.cs_source_value                       AS cs_source_value,
-- --
    t.rule_id                               AS rule_id,
    t.load_table_id                         AS load_table_id
FROM
    @target_schema.tmp_prov_1 t
LEFT JOIN
    @target_schema.tmp_prov_other_cnts cnts
        ON t.prov_source_value = cnts.prov_source_value
WHERE
    t.row_id = 1
;

OPTIMIZE @target_schema.tmp_prov_final ZORDER BY (
    prov_specialty,
    cs_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_lk_concept_prov_specialty;
CREATE TABLE @target_schema.tmp_lk_concept_prov_specialty
@PROPERTY
AS SELECT
    lk1.*
FROM
    @target_schema.lk_concept lk1
INNER JOIN
(
    SELECT
        lk.src_code,
        COUNT(*)            AS cnt_mapp
    FROM
        @target_schema.lk_concept lk
    WHERE
        lk.src_code_type = 'prov_specialty'
    GROUP BY
        lk.src_code
    HAVING
        COUNT(*) = 1
    ) lk2
    ON lk1.src_code = lk2.src_code
WHERE
    lk1.src_code_type = 'prov_specialty'
;

-- -------------------------------------------------------------------
-- Load table: Provider
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_provider;
/*!
    @insert
    @table: @target_schema.cdm_provider
    @source_table: @target_schema.tmp_prov_final
    @summary:
!*/
INSERT INTO @target_schema.cdm_provider
SELECT
    t.row_id                            AS provider_id,
    NULL                                AS provider_name,
    t.npi                               AS npi,
    t.dea                               AS dea,
    COALESCE(lkc.target_concept_id, 0)  AS specialty_concept_id,
    cs.care_site_id                     AS care_site_id,
    NULL                                AS year_of_birth,
    0                                   AS gender_concept_id,
    t.prov_source_value                 AS provider_source_value,
    t.prov_specialty                    AS specialty_source_value,
    0                                   AS specialty_source_concept_id,
    NULL                                AS gender_source_value,
    0                                   AS gender_source_concept_id,
-- --
    t.rule_id                           AS rule_id,
    t.load_table_id                     AS load_table_id,
    NULL                                AS load_row_id
FROM
    @target_schema.tmp_prov_final t
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON  t.cs_source_value = cs.care_site_source_value
LEFT JOIN
    @target_schema.tmp_lk_concept_prov_specialty lkc
        ON  lkc.src_code = t.prov_specialty
        AND lkc.src_code_type = 'prov_specialty'
;

OPTIMIZE @target_schema.cdm_provider ZORDER BY (
    provider_source_value
);

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_prov_data;
DROP TABLE IF EXISTS @target_schema.tmp_medical_clms_prov;
DROP TABLE IF EXISTS @target_schema.tmp_prov_cs_max_dt;
DROP TABLE IF EXISTS @target_schema.tmp_prov_cs;
DROP TABLE IF EXISTS @target_schema.tmp_prov_spclty_cnt;
DROP TABLE IF EXISTS @target_schema.tmp_med_clm_prov_spclty;
DROP TABLE IF EXISTS @target_schema.tmp_prov_spclty_cnt_sum;
DROP TABLE IF EXISTS @target_schema.tmp_prov_1;
DROP TABLE IF EXISTS @target_schema.tmp_prov_other_cnts;
DROP TABLE IF EXISTS @target_schema.tmp_prov_final;
DROP TABLE IF EXISTS @target_schema.tmp_lk_concept_prov_specialty;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------