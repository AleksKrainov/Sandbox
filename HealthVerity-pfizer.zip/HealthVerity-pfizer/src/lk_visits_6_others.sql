-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- VISIT_DETAIL records that roll up to the CONCEPT_ID 9203
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_others_visit_ancestor;
CREATE TABLE @target_schema.lk_others_visit_ancestor
(
    visit_detail_id             BIGINT,
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    new_load_row_id             BIGINT,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.lk_others_visit_ancestor
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_join_voc_visit
    @summary: defining spans of visits
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_others_visit_ancestor
PARTITION (p_hvid)
SELECT
    src.visit_detail_id                 AS visit_detail_id,
    src.person_id                       AS person_id,
    COALESCE(v.concept_id, 0)           AS visit_detail_concept_id,
    src.visit_detail_start_date         AS visit_detail_start_date,
    src.visit_detail_end_date           AS visit_detail_end_date,
    src.provider_id                     AS provider_id,
    src.care_site_id                    AS care_site_id,
    src.visit_detail_source_value       AS visit_detail_source_value,
-- --
    src.rule_id                         AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id,

    MIN(src.load_row_id) OVER (
        PARTITION BY
            src.person_id,
            COALESCE(v.concept_id, 0),
            src.visit_detail_start_date,
            src.visit_detail_end_date,
            src.care_site_id,
            src.p_hvid
        )                               AS new_load_row_id,

    src.p_hvid                          AS p_hvid
FROM
    @target_schema.cdm_visit_detail src
LEFT JOIN
    @target_schema.lk_join_voc_visit v
        ON v.descendant_concept_id = src.visit_detail_concept_id
WHERE
    NOT EXISTS
    (
        SELECT 1
          FROM @target_schema.lk_visit_detail lk
         WHERE lk.visit_detail_id = src.visit_detail_id
    )
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Collapse records with the same VISIT_DETAIL_START_DATE
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_others_visit_grp;
CREATE TABLE @target_schema.lk_others_visit_grp
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
    source_value_count          INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    new_load_row_id             BIGINT,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.lk_others_visit_grp
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_join_voc_visit
    @summary: defining spans of visits
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_others_visit_grp
PARTITION (p_hvid)
SELECT
    person_id                                   AS person_id,
    visit_detail_concept_id                     AS visit_detail_concept_id,
    visit_detail_start_date                     AS visit_detail_start_date,
    visit_detail_end_date                       AS visit_detail_end_date,
    MIN(provider_id)                            AS provider_id,
    care_site_id                                AS care_site_id,
    MIN(visit_detail_source_value)              AS visit_detail_source_value,
    COUNT(DISTINCT visit_detail_source_value)   AS source_value_count,
-- --
    MIN(rule_id)                                AS rule_id,
    MIN(load_table_id)                          AS load_table_id,
    MIN(load_row_id)                            AS load_row_id,
    MIN(new_load_row_id)                        AS new_load_row_id,
    p_hvid                                      AS p_hvid
FROM
    @target_schema.lk_others_visit_ancestor
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    person_id,
    visit_detail_concept_id,
    visit_detail_start_date,
    visit_detail_end_date,
    care_site_id,
    p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Insert into tmp_visit_occurrence
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_occurrence
    @source_table: @target_schema.lk_others_visit_grp
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_occurrence
PARTITION (p_hvid)
SELECT
    (SELECT COALESCE(MAX(visit_occurrence_id), 0)
       FROM @target_schema.tmp_visit_occurrence)
        + 1 + monotonically_increasing_id()
                                                AS visit_occurrence_id,

    src.person_id                               AS person_id,
    src.visit_detail_concept_id                 AS visit_concept_id,
    src.visit_detail_start_date                 AS visit_start_date,
    src.visit_detail_start_date                 AS visit_start_datetime,
    src.visit_detail_end_date                   AS visit_end_date,
    src.visit_detail_end_date                   AS visit_end_datetime,
    32810                                       AS visit_type_concept_id,  -- Claim
    src.provider_id                             AS provider_id,
    src.care_site_id                            AS care_site_id,

    CASE
        WHEN src.source_value_count = 1
        THEN src.visit_detail_source_value
        ELSE NULL
    END                                         AS visit_source_value,

    0                                           AS visit_source_concept_id,
    0                                           AS admitted_from_concept_id,
    CAST(NULL AS STRING)                        AS admitted_from_source_value,
    0                                           AS discharged_to_concept_id,
    CAST(NULL AS STRING)                        AS discharged_to_source_value,
-- --
    src.p_hvid                                  AS p_hvid,
-- --
    'medical_claims.others'                     AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.new_load_row_id                         AS load_row_id
FROM
    @target_schema.lk_others_visit_grp src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_visit_occurrence ZORDER BY (
    person_id,
    visit_start_date,
    visit_end_date,
    rule_id
);

-- -------------------------------------------------------------------
-- LK_VISIT_DETAIL - link visit_detail_id to visit_occurrence_id
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_visit_detail
    @source_table: @target_schema.lk_others_visit_ancestor,
                   @target_schema.tmp_visit_occurrence
    @summary: visit starts on the first day of an Inpatient visit
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.lk_others_visit_ancestor src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND src.visit_detail_start_date = vo.visit_start_date
        AND src.visit_detail_end_date = vo.visit_end_date
        AND src.new_load_row_id = vo.load_row_id
        AND vo.rule_id = 'medical_claims.others'
WHERE
    src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
