-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Load Table: Metadata
-- -------------------------------------------------------------------
TRUNCATE TABLE @cdm_schema.cdm_metadata;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    1                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'LOCATION'              AS name,
    'Patient state of residence and health care facilities, addresses'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    2                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'CARE SITE'             AS name,
    'Unique identifiers for health care facilities'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    3                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'PROVIDER'              AS name,
    'Unique identifiers of the providers and their specialities'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    4                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'PERSON'                AS name,
    'Unique identifiers of the patients and patient demographical attributes'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    5                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'DEATH'                 AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    6                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'OBSERVATION PERIOD'    AS name,
    'Based on the dates in the event tables'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    7                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'PAYER PLAN PERIOD'     AS name,
    'Patient insurance/payer information, allows multiple records per patient'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    8                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'VISIT OCCURRENCE'      AS name,
    'Events where Persons engage with the healthcare system for a duration of time'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    9                       AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'CONDITION OCCURRENCE'  AS name,
    'Events of a Person suggesting the presence of a disease or medical condition stated as a diagnosis, a sign, or a symptom'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    10                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'PROCEDURE OCCURRENCE'  AS name,
    'Activities or processes ordered by, or carried out on the patient with a diagnostic or therapeutic purpose'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    11                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'MEASUREMENT'           AS name,
    'Structured values (numerical or categorical) obtained through systematic and standardized examination or testing of a Person'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    12                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'OBSERVATION'           AS name,
    'Clinical facts about a Person obtained in the context of examination, questioning or a procedure'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    13                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'DEVICE EXPOSURE'       AS name,
    'Person’s exposure to a foreign physical object or instrument which is used for diagnostic or therapeutic purposes through a mechanism beyond chemical action'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    14                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'DRUG EXPOSURE'         AS name,
    'Exposure to a Drug ingested or otherwise introduced into the body'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    15                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'COST'                  AS name,
    'Records containing costs of medical events from claim tables'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    16                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'CONDITION ERA'         AS name,
    'Spans of time when Persons are assumed to have a given conditions'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    17                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'DRUG ERA'              AS name,
    'Spans of time when Persons are assumed to be exposed to a particular active ingredient'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    18                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'CDM SOURSE'            AS name,
    'Detail about the source database and the process used to transform the data into the OMOP CDM'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    19                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'VISIT DETAIL'          AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    20                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'FACT RELATIONSHIP'     AS name,
    'Not populated'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    21                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'SPECIMEN'              AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    22                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'NOTE'                  AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    23                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'NOTE NLP'              AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    24                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'COHORT'                AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    26                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'COHORT DEFINITION'     AS name,
    'Not populated'
                            AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

INSERT INTO @cdm_schema.cdm_metadata
SELECT
    27                      AS metadata_id,
    0                       AS metadata_concept_id,
    32843                   AS metadata_type_concept_id,
    'DOSE ERA'              AS name,
    'Not populated'         AS value_as_string,
    0                       AS value_as_concept_id,
    NULL                    AS value_as_number,
    current_date            AS metadata_date,
    NULL                    AS metadata_datetime,
-- --
    NULL                    AS rule_id,
    NULL                    AS load_table_id,
    NULL                    AS load_row_id
;

-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
