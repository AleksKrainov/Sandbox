-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Rolling additional visit detail into Non-hospital institution visit
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_visit_detail
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.tmp_visit_occurrence
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.cdm_visit_detail src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND src.visit_detail_start_date BETWEEN vo.visit_start_date AND vo.visit_end_date
        AND vo.rule_id = 'medical_claims.non_hospital'
WHERE
    NOT EXISTS
    (
        SELECT 1
          FROM @target_schema.lk_visit_detail lk
         WHERE lk.visit_detail_id = src.visit_detail_id
    )
    AND src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
