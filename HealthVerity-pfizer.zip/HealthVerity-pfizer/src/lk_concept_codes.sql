-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: LK_concept
!*/

-- -------------------------------------------------------------------
-- Create tmp_map_codes_lvl_1
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_map_codes_lvl_1;
CREATE TABLE @target_schema.tmp_map_codes_lvl_1
(
    src_code                    string,
    src_code_type               string,
    concept_code                string,
    source_concept_id           int,
    source_domain_id            string,
    source_concept_class_id     string,
    source_vocabulary_id        string,
    source_standard_concept     string,
    source_invalid_reason       string,
    custom_vocabulary_id        string,
    default_domain_id           string,
    cnt_src_voc                 smallint
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Create lk_concept
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_concept;
CREATE TABLE @target_schema.lk_concept
(
    src_code                    string,
    src_code_type               string,
    concept_code                string,
    source_concept_id           int,
    target_concept_id           int,
    value_as_concept_id         int,
    source_domain_id            string,
    target_domain_id            string,
    domain_id                   string,
    source_concept_class_id     string,
    target_concept_class_id     string,
    source_vocabulary_id        string,
    target_vocabulary_id        string,
    custom_vocabulary_id        string,
    source_standard_concept     string,
    target_standard_concept     string,
    ambig_mapping               smallint
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- place_of_service_std_id codes (CARE_CITE)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_all_pos_std_id;
/*!
    @insert
    @table: @target_schema.tmp_all_pos_std_id
    @source_table: @source_schema.src_medical_claims
    @summary:
!*/
CREATE TABLE @target_schema.tmp_all_pos_std_id
@PROPERTY
AS SELECT DISTINCT
    place_of_service_std_id         AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(place_of_service_std_id, '') != ''
;

DROP TABLE IF EXISTS @target_schema.tmp_all_pos_std_id_dist;
CREATE TABLE @target_schema.tmp_all_pos_std_id_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_all_pos_std_id
;

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_all_pos_std_id_dist
    @summary:
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT
    src.src_code                AS src_code,
    'place_of_service_code'     AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    '-'                         AS custom_vocabulary_id,
    'Visit'                     AS default_domain_id,
    0                           AS cnt_src_voc
FROM
    @target_schema.tmp_all_pos_std_id_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code = vc.concept_code
        AND vc.vocabulary_id IN ('CMS Place of Service', 'UB04 Typ bill')
;

-- -------------------------------------------------------------------
-- prov_specialty_id codes
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_medical_clm_spclty
    @source_table: @source_schema.src_medical_claims
    @summary:
!*/
DROP TABLE IF EXISTS @target_schema.tmp_medical_clm_spclty;
CREATE TABLE @target_schema.tmp_medical_clm_spclty
(
    src_code    string,
    p_hvid      string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clm_spclty
SELECT
    prov_rendering_vendor_specialty     AS src_code,
    p_hvid                              AS p_hvid
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(prov_rendering_vendor_specialty, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clm_spclty
SELECT
    prov_billing_vendor_specialty       AS src_code,
    p_hvid                              AS p_hvid
FROM
     @source_schema.src_medical_claims
WHERE
    COALESCE(prov_billing_vendor_specialty, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;
/*
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clm_spclty
SELECT
    prov_referring_vendor_specialty     AS src_code,
    p_hvid                              AS p_hvid
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(prov_referring_vendor_specialty, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;
*/

OPTIMIZE @target_schema.tmp_medical_clm_spclty ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_specialty_id;
CREATE TABLE @target_schema.tmp_prov_specialty_id
(
    src_code    string
)
@PROPERTY
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_specialty_id
SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_medical_clm_spclty
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_medical_clm_spclty;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_prov_specialty_id
SELECT DISTINCT
    prov_prescribing_vendor_specialty      AS src_code
FROM
    @source_schema.src_pharmacy_claims
WHERE
    COALESCE(prov_prescribing_vendor_specialty, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_prov_specialty_id ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_prov_specialty_dist;
/*!
    @insert
    @table: @target_schema.tmp_prov_specialty_dist
    @source_table:  @source_schema.tmp_prov_specialty_id
    @summary:
!*/
CREATE TABLE @target_schema.tmp_prov_specialty_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
     @target_schema.tmp_prov_specialty_id
;

OPTIMIZE @target_schema.tmp_prov_specialty_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_prov_specialty_dist
    @summary:
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT
    src.src_code                AS src_code,
    'prov_specialty'            AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    'HV_PROVIDER'               AS custom_vocabulary_id,
    '-'                         AS default_domain_id,
    0                           AS cnt_src_voc
FROM
    @target_schema.tmp_prov_specialty_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  LOWER(src.src_code) = LOWER(vc.concept_code)
        AND vc.vocabulary_id = 'HV_PROVIDER'
;

-- -------------------------------------------------------------------
-- diag_cd codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_diag_cd;

CREATE TABLE @target_schema.tmp_diag_cd
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: diag codes from Medical Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_diag_cd
SELECT DISTINCT
    diagnosis_code      AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(diagnosis_code, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

/*!
    @insert
    @summary: diag codes from Pharmacy Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_diag_cd
SELECT DISTINCT
    diagnosis_code      AS src_code
FROM
    @source_schema.src_pharmacy_claims
WHERE
    COALESCE(diagnosis_code, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_diag_cd ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_diag_cd_dist;
/*!
    @insert
    @summary: unique diag codes
!*/
CREATE TABLE @target_schema.tmp_diag_cd_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_diag_cd
;

OPTIMIZE @target_schema.tmp_diag_cd_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_diag_cd_dist
    @summary: diag ICD codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code                AS src_code,
    'diag_code'                 AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    '-'                         AS custom_vocabulary_id,
    'Condition'                 AS default_domain_id,
    COUNT(vc.vocabulary_id) OVER (
        PARTITION BY
            src.src_code)       AS cnt_src_voc
FROM
    @target_schema.tmp_diag_cd_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  LOWER(src.src_code) = LOWER(TRANSLATE(vc.concept_code, '.', ''))
        AND vc.vocabulary_id IN ('ICD9CM', 'ICD10CM')
;

-- -------------------------------------------------------------------
-- proc_code codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_proc_cd;

CREATE TABLE @target_schema.tmp_proc_cd
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: proc codes from Medical Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_proc_cd
SELECT DISTINCT
    procedure_code      AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(procedure_code, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

/*!
    @insert
    @summary: proc codes from Pharmacy Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_proc_cd
SELECT DISTINCT
    procedure_code      AS src_code
FROM
    @source_schema.src_pharmacy_claims
WHERE
    COALESCE(procedure_code, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_proc_cd ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_proc_cd_dist;
/*!
    @insert
    @summary: unique proc codes
!*/
CREATE TABLE @target_schema.tmp_proc_cd_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_proc_cd
;

OPTIMIZE @target_schema.tmp_proc_cd_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_proc_cd_dist
    @summary: proc codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code                AS src_code,
    'proc_code'                 AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    '-'                         AS custom_vocabulary_id,
    'Procedure'                 AS default_domain_id,
    COUNT(vc.vocabulary_id) OVER (
        PARTITION BY
            src.src_code)       AS cnt_src_voc
FROM
    @target_schema.tmp_proc_cd_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code = vc.concept_code
        AND vc.vocabulary_id IN ('CPT4', 'HCPCS', 'ICD10PCS')
;

-- -------------------------------------------------------------------
-- ndc_code codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_ndc_code;

CREATE TABLE @target_schema.tmp_ndc_code
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: NDC codes from Medical Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_ndc_code
SELECT DISTINCT
    ndc_code        AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(ndc_code, '0') != '0'
    AND p_hvid = '@hvid_char'
--@FOR_END
;
/*!
    @insert
    @summary: NDC codes from Pharmacy Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_ndc_code
SELECT DISTINCT
    ndc_code        AS src_code
FROM
    @source_schema.src_pharmacy_claims
WHERE
    COALESCE(ndc_code, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_ndc_code ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_ndc_code_dist;
/*!
    @insert
    @summary: unique NDC codes
!*/
CREATE TABLE @target_schema.tmp_ndc_code_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_ndc_code
;

OPTIMIZE @target_schema.tmp_ndc_code_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_ndc_code_dist
    @summary: NDC codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code                AS src_code,
    'ndc_code'                  AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    '-'                         AS custom_vocabulary_id,
    'Drug'                      AS default_domain_id,
    0                           AS cnt_src_voc
FROM
    @target_schema.tmp_ndc_code_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code = vc.concept_code
        AND vc.vocabulary_id = 'NDC'
;

-- -------------------------------------------------------------------
-- proc_modifier codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_modifier_codes;

CREATE TABLE @target_schema.tmp_modifier_codes
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: proc_modifier from Medical Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_modifier_codes
SELECT DISTINCT
    COALESCE(procedure_modifier_1,
             procedure_modifier_2,
             procedure_modifier_3,
             procedure_modifier_4)      AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(procedure_modifier_1,
             procedure_modifier_2,
             procedure_modifier_3,
             procedure_modifier_4, '') != ''
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_modifier_codes ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_modifier_codes_dist;
/*!
    @insert
    @summary: unique proc_modifier codes
!*/
CREATE TABLE @target_schema.tmp_modifier_codes_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_modifier_codes
;

OPTIMIZE @target_schema.tmp_modifier_codes_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_modifier_codes_dist
    @summary: proc_modifier codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code            AS src_code,
    'proc_modifier_code'    AS src_code_type,
    vc.concept_code         AS concept_code,
    vc.concept_id           AS source_concept_id,
    vc.domain_id            AS source_domain_id,
    vc.concept_class_id     AS source_concept_class_id,
    vc.vocabulary_id        AS source_vocabulary_id,
    vc.standard_concept     AS source_standard_concept,
    vc.invalid_reason       AS source_invalid_reason,
    '-'                     AS custom_vocabulary_id,
    '-'                     AS default_domain_id,
    0                       AS cnt_src_voc
FROM
    @target_schema.tmp_modifier_codes_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code     = vc.concept_code
        AND vc.vocabulary_id = 'CPT4'
;

-- -------------------------------------------------------------------
-- payer codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_payer_codes;

CREATE TABLE @target_schema.tmp_payer_codes
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: payer_type from Enrollment
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_payer_codes
SELECT DISTINCT
    payer_type       AS src_code
FROM
    @source_schema.src_enrollment
WHERE
    payer_type IS NOT NULL
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_payer_codes ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_payer_codes_dist;
/*!
    @insert
    @summary: unique payer_type
!*/
CREATE TABLE @target_schema.tmp_payer_codes_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_payer_codes
;

OPTIMIZE @target_schema.tmp_payer_codes_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_payer_codes_dist
    @summary: payer_type codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code                        AS src_code,
    'payer_code'                        AS src_code_type,
    vc.concept_code                     AS concept_code,
    vc.concept_id                       AS source_concept_id,
    vc.domain_id                        AS source_domain_id,
    vc.concept_class_id                 AS source_concept_class_id,
    vc.vocabulary_id                    AS source_vocabulary_id,
    vc.standard_concept                 AS source_standard_concept,
    vc.invalid_reason                   AS source_invalid_reason,
    '-'                                 AS custom_vocabulary_id,
    '-'                                 AS default_domain_id,
    0                                   AS cnt_src_voc
FROM
    @target_schema.tmp_payer_codes_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code     = vc.concept_code
        AND vc.vocabulary_id = 'HV_PAYER'
;

DROP TABLE IF EXISTS @target_schema.tmp_payer_codes_dist;

-- -------------------------------------------------------------------
-- plan codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_benefit_type_codes;

CREATE TABLE @target_schema.tmp_benefit_type_codes
(
    src_code string
)
@PROPERTY
;

/*!
    @insert
    @summary: benefit_type from Enrollment
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_benefit_type_codes
SELECT DISTINCT
    benefit_type        AS src_code
FROM
    @source_schema.src_enrollment
WHERE
    benefit_type IS NOT NULL
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_benefit_type_codes ZORDER BY (
    src_code
);

DROP TABLE IF EXISTS @target_schema.tmp_benefit_type_codes_dist;
/*!
    @insert
    @summary: unique benefit_type
!*/
CREATE TABLE @target_schema.tmp_benefit_type_codes_dist
@PROPERTY
AS SELECT DISTINCT
    src_code
FROM
    @target_schema.tmp_benefit_type_codes
;

OPTIMIZE @target_schema.tmp_benefit_type_codes_dist ZORDER BY (
    src_code
);

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_benefit_type_codes_dist
    @summary: benefit_type codes
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT DISTINCT
    src.src_code                        AS src_code,
    'plan_code'                         AS src_code_type,
    vc.concept_code                     AS concept_code,
    vc.concept_id                       AS source_concept_id,
    vc.domain_id                        AS source_domain_id,
    vc.concept_class_id                 AS source_concept_class_id,
    vc.vocabulary_id                    AS source_vocabulary_id,
    vc.standard_concept                 AS source_standard_concept,
    vc.invalid_reason                   AS source_invalid_reason,
    '-'                                 AS custom_vocabulary_id,
    '-'                                 AS default_domain_id,
    0                                   AS cnt_src_voc
FROM
    @target_schema.tmp_benefit_type_codes_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code     = vc.concept_code
        AND vc.vocabulary_id = 'HV_BENEFIT_TYPE'
;

DROP TABLE IF EXISTS @target_schema.tmp_benefit_type_codes_dist;

-- -------------------------------------------------------------------
-- inst_discharge_status_std_id codes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_status_std_id_dist;
/*!
    @insert
    @table: @target_schema.tmp_status_std_id_dist
    @source_table: @source_schema.src_medical_claims
    @summary:
!*/
CREATE TABLE @target_schema.tmp_status_std_id_dist
@PROPERTY
AS SELECT DISTINCT
    inst_discharge_status_std_id    AS src_code
FROM
    @source_schema.src_medical_claims
WHERE
    COALESCE(inst_discharge_status_std_id, '') != ''
;

/*!
    @insert
    @table: @target_schema.tmp_map_codes_lvl_1
    @source_table: @target_schema.tmp_status_std_id_dist
    @summary:
!*/
INSERT INTO @target_schema.tmp_map_codes_lvl_1
SELECT
    src.src_code                AS src_code,
    'discharged_code'           AS src_code_type,
    vc.concept_code             AS concept_code,
    vc.concept_id               AS source_concept_id,
    vc.domain_id                AS source_domain_id,
    vc.concept_class_id         AS source_concept_class_id,
    vc.vocabulary_id            AS source_vocabulary_id,
    vc.standard_concept         AS source_standard_concept,
    vc.invalid_reason           AS source_invalid_reason,
    '-'                         AS custom_vocabulary_id,
    'Visit'                     AS default_domain_id,
    0                           AS cnt_src_voc
FROM
    @target_schema.tmp_status_std_id_dist src
LEFT JOIN
    @voc_schema.voc_concept vc
        ON  src.src_code = vc.concept_code
        AND vc.vocabulary_id = 'UB04 Pt dis status'
;

-- -------------------------------------------------------------------
-- Populating table lk_concept
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_concept
    @source_table: @target_schema.tmp_map_codes_lvl_1
    @summary:
!*/
INSERT INTO @target_schema.lk_concept
SELECT DISTINCT
    map1.src_code                           AS src_code,
    map1.src_code_type                      AS src_code_type,
    map1.concept_code                       AS concept_code,
-- --
    COALESCE(map1.source_concept_id, 0)     AS source_concept_id,
    COALESCE(vc2.concept_id, 0)             AS target_concept_id,
    vc3.concept_id                          AS value_as_concept_id,
-- --
    map1.source_domain_id                   AS source_domain_id,
    vc2.domain_id                           AS target_domain_id,
    COALESCE( vc2.domain_id,
              map1.source_domain_id,
              map1.default_domain_id)       AS domain_id,
-- --
    map1.source_concept_class_id            AS source_concept_class_id,
    vc2.concept_class_id                    AS target_concept_class_id,
-- --
    map1.source_vocabulary_id               AS source_vocabulary_id,
    vc2.vocabulary_id                       AS target_vocabulary_id,
    map1.custom_vocabulary_id               AS custom_vocabulary_id,
    map1.source_standard_concept            AS source_standard_concept,
    vc2.standard_concept                    AS target_standard_concept,
    IF(map1.cnt_src_voc <= 1, 0, 1)         AS ambig_mapping
FROM
    @target_schema.tmp_map_codes_lvl_1 map1
LEFT JOIN
    @voc_schema.voc_concept_relationship vcr
        ON  map1.source_concept_id = vcr.concept_id_1
        AND vcr.relationship_id    = 'Maps to'
        AND vcr.invalid_reason     IS NULL
LEFT JOIN
    @voc_schema.voc_concept vc2
        ON  vcr.concept_id_2     = vc2.concept_id
        AND vc2.standard_concept = 'S'
        AND vc2.invalid_reason   IS NULL
LEFT JOIN
    @voc_schema.voc_concept_relationship vcr2
        ON  map1.source_concept_id = vcr2.concept_id_1
        AND vcr2.relationship_id   = 'Maps to value'
        AND vcr2.invalid_reason    IS NULL
LEFT JOIN
    @voc_schema.voc_concept vc3
        ON vcr2.concept_id_2     = vc3.concept_id
        AND vc3.standard_concept = 'S'
        AND vc3.invalid_reason   IS NULL
;

OPTIMIZE @target_schema.lk_concept ZORDER BY (
    src_code,
    src_code_type,
    source_vocabulary_id,
    ambig_mapping
);

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_map_codes_lvl_1;
DROP TABLE IF EXISTS @target_schema.tmp_all_pos_std_id;
DROP TABLE IF EXISTS @target_schema.tmp_all_pos_std_id_dist;
DROP TABLE IF EXISTS @target_schema.tmp_prov_specialty_id;
DROP TABLE IF EXISTS @target_schema.tmp_medical_clm_spclty;
DROP TABLE IF EXISTS @target_schema.tmp_diag_cd;
DROP TABLE IF EXISTS @target_schema.tmp_diag_cd_dist;
DROP TABLE IF EXISTS @target_schema.tmp_proc_cd;
DROP TABLE IF EXISTS @target_schema.tmp_proc_cd_dist;
DROP TABLE IF EXISTS @target_schema.tmp_ndc_code;
DROP TABLE IF EXISTS @target_schema.tmp_ndc_code_dist;
DROP TABLE IF EXISTS @target_schema.tmp_modifier_codes;
DROP TABLE IF EXISTS @target_schema.tmp_modifier_codes_dist;
DROP TABLE IF EXISTS @target_schema.tmp_payer_codes;
DROP TABLE IF EXISTS @target_schema.tmp_benefit_type_codes;
DROP TABLE IF EXISTS @target_schema.tmp_status_std_id_dist;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
