-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate lookup table lk_mapped_ndc
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.lk_mapped_ndc;
CREATE TABLE @target_schema.lk_mapped_ndc
(
    event_source_value              STRING,
    event_concept_id                INTEGER,
    event_source_concept_id         INTEGER,
    value_as_string                 STRING,
    value_as_concept_id             INTEGER,
    value_as_number                 DOUBLE,
    unit_source_value               STRING,
    unit_concept_id                 INTEGER,
    event_start_date                DATE,
    event_end_date                  DATE,
    domain_id                       STRING,
    event_type_concept_id           INTEGER,
-- ------------------ additional columns -------------------
    quantity                        DOUBLE,
    days_supply                     INTEGER,
-- ---------------------------------------------------------
    person_id                       BIGINT,
    provider_id                     BIGINT,
    visit_occurrence_id             BIGINT,
-- cost fields ---------------------------------------
    submitted_gross_due             DOUBLE,
    paid_gross_due                  DOUBLE,
    cost_flag                       INTEGER,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- Join to provider, visit occurrence
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_ndc_prov_cs;
CREATE TABLE @target_schema.tmp_ndc_prov_cs
(
    person_id           BIGINT,
    provider_id         BIGINT,
    care_site_id        BIGINT,
    event_start_date    DATE,
-- --
    load_table_id       STRING,
    load_row_id         BIGINT,
    p_hvid              STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

/*!
    @insert
    @table: @target_schema.tmp_ndc_prov_cs
    @source_table: @target_schema.lk_event_ndc,
                   @target_schema.cdm_provider,
                   @target_schema.cdm_care_site
    @summary: populate provider_id and care_site_id
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_ndc_prov_cs
PARTITION (p_hvid)
SELECT /*+ MERGE (prov) */
    lk.person_id            AS person_id,
    prov.provider_id        AS provider_id,
    cs.care_site_id         AS care_site_id,
    lk.event_start_date     AS event_start_date,
-- -
    lk.load_table_id        AS load_table_id,
    lk.load_row_id          AS load_row_id,
    lk.p_hvid               AS p_hvid
FROM
    @target_schema.lk_event_ndc lk
LEFT JOIN
    @target_schema.cdm_provider prov
        ON prov.provider_source_value = lk.provider_source_value
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON cs.care_site_source_value = lk.care_site_source_value
WHERE
    lk.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_ndc_prov_cs ZORDER BY (
    person_id,
    provider_id,
    care_site_id,
    event_start_date,
    load_table_id
);

DROP TABLE IF EXISTS @target_schema.tmp_ndc_vis;
CREATE TABLE @target_schema.tmp_ndc_vis
(
    visit_occurrence_id     BIGINT,
    provider_id             BIGINT,
-- --
    load_table_id           STRING,
    load_row_id             BIGINT,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

/*!
    @insert
    @table: @target_schema.tmp_ndc_vis
    @source_table: @target_schema.tmp_ndc_prov_cs,
                   @target_schema.cdm_visit_occurrence
    @summary: join to Visit for pharmacy_claims records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_ndc_vis
PARTITION (p_hvid)
SELECT
    vo.visit_occurrence_id      AS visit_occurrence_id,
    lk.provider_id              AS provider_id,
-- --
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.tmp_ndc_prov_cs lk
LEFT JOIN
    @target_schema.cdm_visit_occurrence vo
        ON  vo.person_id = lk.person_id
        AND vo.visit_start_date = lk.event_start_date
        AND vo.provider_id = lk.provider_id
        AND vo.care_site_id = lk.care_site_id
        AND vo.load_table_id LIKE 'pharmacy_claims%'
WHERE
    lk.load_table_id LIKE 'pharmacy_claims%'
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_ndc_vis ZORDER BY (
    load_row_id,
    load_table_id
);

-- -------------------------------------------------------------------
-- Populating lk_mapped_ndc
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_mapped_ndc
    @source_table: @target_schema.lk_event_ndc,
                   @target_schema.cdm_provider
    @summary: link to Provider
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_mapped_ndc
PARTITION (p_hvid)
SELECT /*+ BROADCAST (lkc) */
    lk.event_source_value                   AS event_source_value,
    COALESCE(lkc.target_concept_id, 0)      AS event_concept_id,
    COALESCE(lkc.source_concept_id, 0)      AS event_source_concept_id,
    NULL                                    AS value_as_string,
    lkc.value_as_concept_id                 AS value_as_concept_id,
    NULL                                    AS value_as_number,
    NULL                                    AS unit_source_value,
    NULL                                    AS unit_concept_id,
    lk.event_start_date                     AS event_start_date,

    CASE
        WHEN COALESCE(lkc.domain_id, 'Drug') IN ('Drug', 'Device')
        THEN CASE
                WHEN lk.days_supply BETWEEN 1 AND 365
                THEN DATE_ADD(lk.event_start_date, lk.days_supply - 1)
                WHEN lk.days_supply > 365
                THEN DATE_ADD(lk.event_start_date, 365)
                ELSE lk.event_start_date
             END
        ELSE NULL
    END                                         AS event_end_date,

    COALESCE(lkc.domain_id, 'Drug')             AS domain_id,

    lk.event_type_concept_id                    AS event_type_concept_id,

    CASE
        WHEN CEIL(CAST(lk.quantity AS DOUBLE)) > 10000
        THEN NULL
        WHEN COALESCE(lkc.domain_id, 'Drug') = 'Device'
        THEN CEIL(CAST(lk.quantity AS DOUBLE))
        WHEN COALESCE(lkc.domain_id, 'Drug') = 'Drug'
        THEN CAST(lk.quantity AS DOUBLE)
    END                                         AS quantity,

    CASE
        WHEN COALESCE(lkc.domain_id, 'Drug') = 'Drug'
             AND lk.days_supply BETWEEN 1 AND 365
        THEN lk.days_supply
        ELSE NULL
    END                                         AS days_supply,
-- --
    lk.person_id                                AS person_id,
    v.provider_id                               AS provider_id, 
    v.visit_occurrence_id                       AS visit_occurrence_id,
-- --
    lk.submitted_gross_due                      AS submitted_gross_due,
    lk.paid_gross_due                           AS paid_gross_due,

    CASE
        WHEN COALESCE(lk.submitted_gross_due, 0) != 0
             OR COALESCE(lk.paid_gross_due, 0) != 0
        THEN 1
        ELSE 0
    END                                         AS cost_flag,
-- --
    lk.rule_id                                  AS rule_id,
    lk.load_table_id                            AS load_table_id,
    lk.load_row_id                              AS load_row_id,
    lk.p_hvid                                   AS p_hvid
FROM
    @target_schema.lk_event_ndc lk
LEFT JOIN
    @target_schema.lk_concept lkc
        ON  lk.event_source_value   = lkc.src_code
        AND lk.source_vocabulary_id = lkc.source_vocabulary_id
        AND lkc.src_code_type       = 'ndc_code'
LEFT JOIN
    @target_schema.tmp_ndc_vis v
        ON  v.load_row_id   = lk.load_row_id
        AND v.load_table_id = lk.load_table_id
        AND v.p_hvid = '@hvid_char'
WHERE
    -- partition filter
    lk.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.lk_mapped_ndc ZORDER BY (
    person_id,
    domain_id
);

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_ndc_prov_cs;
DROP TABLE IF EXISTS @target_schema.tmp_ndc_vis;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------