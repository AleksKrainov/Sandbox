-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: CDM Condition Occurrence
!*/

DROP TABLE IF EXISTS @target_schema.tmp_condition;
CREATE TABLE @target_schema.tmp_condition
(
    person_id                       bigint,
    target_concept_id               int,
    event_start_date                timestamp,
    event_end_date                  timestamp,
    type_concept_id                 int,
    provider_id                     bigint,
    visit_occurrence_id             bigint,
    event_source_value              string,
    source_concept_id               int,
-- --
    rule_id                         string,
    load_table_id                   string,
    load_row_id                     bigint,
    p_hvid                          string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- From lk_mapped_diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_condition
    @source_table: @target_schema.lk_mapped_diag
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_condition
PARTITION (p_hvid)
SELECT
    lk.person_id                    AS person_id,
    lk.event_concept_id             AS target_concept_id,
    lk.event_start_date             AS event_start_date,
    lk.event_end_date               AS event_end_date,
    lk.event_type_concept_id        AS type_concept_id,
    lk.provider_id                  AS provider_id,
    lk.visit_occurrence_id          AS visit_occurrence_id,
    lk.event_source_value           AS event_source_value,
    lk.event_source_concept_id      AS source_concept_id,
-- --
    lk.rule_id                      AS rule_id,
    lk.load_table_id                AS load_table_id,
    lk.load_row_id                  AS load_row_id,
    lk.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_mapped_diag lk
WHERE
    lk.domain_id = 'Condition'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's and Post Dedupe
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_condition_id;
CREATE TABLE @target_schema.tmp_condition_id
@PROPERTY PARTITIONED BY (p_hvid) AS
SELECT
    monotonically_increasing_id()   AS condition_occurrence_id,
    co.*
FROM
    @target_schema.tmp_condition co
WHERE
    co.event_start_date >= CAST('@min_date_of_dataset' AS DATE)
    AND COALESCE(co.event_end_date, co.event_start_date) <= CAST('@max_date_of_dataset' AS DATE)
;

DROP TABLE IF EXISTS @target_schema.tmp_condition_dedupe_map;
CREATE TABLE @target_schema.tmp_condition_dedupe_map
(
    new_condition_occurrence_id     BIGINT,
    condition_occurrence_id         BIGINT,
    p_hvid                          STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.tmp_condition_dedupe_map
    @source_table: @target_schema.tmp_condition_id
    @summary: Group the data to remove duplicates during the next step:
    - person_id,
    - condition_concept_id,
    - condition_start_date,
    - condition_end_date,
    - condition_type_concept_id,
    - provider_id,
    - visit_occurrence_id,
    - condition_source_value,
    - condition_source_concept_id
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_condition_dedupe_map
PARTITION (p_hvid)
SELECT
    MIN(t.condition_occurrence_id) OVER (
        PARTITION BY
            t.person_id,
            t.target_concept_id,
            t.event_start_date,
            t.event_end_date,
            t.type_concept_id,
            t.provider_id,
            t.visit_occurrence_id,
            t.event_source_value,
            t.source_concept_id
        )                       AS new_condition_occurrence_id,
    t.condition_occurrence_id   AS condition_occurrence_id,
    t.p_hvid                    AS p_hvid
FROM
    @target_schema.tmp_condition_id t
WHERE
    -- partition filter
    t.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load table: Condition_occurrence
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_condition_occurrence;
/*!
    @insert
    @table: @target_schema.cdm_condition_occurrence
    @source_table: @target_schema.tmp_condition_id
    @summary: populate cdm_condition_occurrence
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_condition_occurrence
SELECT
    t.condition_occurrence_id          AS condition_occurrence_id,
    t.person_id                        AS person_id,
    t.target_concept_id                AS condition_concept_id,
    t.event_start_date                 AS condition_start_date,
    NULL                               AS condition_start_datetime,
    t.event_end_date                   AS condition_end_date,
    NULL                               AS condition_end_datetime,
    t.type_concept_id                  AS condition_type_concept_id,
    0                                  AS condition_status_concept_id,
    NULL                               AS stop_reason,
    t.provider_id                      AS provider_id,
    t.visit_occurrence_id              AS visit_occurrence_id,
    NULL                               AS visit_detail_id,
    t.event_source_value               AS condition_source_value,
    t.source_concept_id                AS condition_source_concept_id,
    NULL                               AS condition_status_source_value,
-- --
    t.p_hvid                           AS p_hvid,
    t.rule_id                          AS rule_id,
    t.load_table_id                    AS load_table_id,
    t.load_row_id                      AS load_row_id

FROM
    @target_schema.tmp_condition_id t
WHERE
    EXISTS
        (
            SELECT 1
              FROM @target_schema.tmp_condition_dedupe_map dm
             WHERE dm.new_condition_occurrence_id = t.condition_occurrence_id
               AND dm.p_hvid = '@hvid_char'
        )
    AND t.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.cdm_condition_occurrence ZORDER BY (
    person_id,
    condition_concept_id,
    condition_start_date,
    condition_end_date,
    condition_source_value
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_condition;
DROP TABLE IF EXISTS @target_schema.tmp_condition_id;
DROP TABLE IF EXISTS @target_schema.tmp_condition_dedupe_map;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/
