-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- VISIT_DETAIL records that roll up to the CONCEPT_ID 9203
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_emergency_visit_ancestor;
CREATE TABLE @target_schema.lk_emergency_visit_ancestor
(
    visit_detail_id             BIGINT,
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
    inp_visit_flag              INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    new_load_row_id             BIGINT,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.lk_emergency_visit_ancestor
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_join_voc_visit
    @summary: defining spans of visits
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_emergency_visit_ancestor
PARTITION (p_hvid)
SELECT
    src.visit_detail_id                     AS visit_detail_id,
    src.person_id                           AS person_id,
    lk.concept_id                           AS visit_detail_concept_id,
    src.visit_detail_start_date             AS visit_detail_start_date,
    src.visit_detail_end_date               AS visit_detail_end_date,
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,

    CASE
        WHEN vo1.person_id IS NOT NULL
        THEN 1  -- Emergency Room visit starts on the first day of an Inpatient visit
        WHEN vo2.person_id IS NOT NULL
        THEN 2  -- Emergency Room visit occurs at any other point during an inpatient stay
        ELSE 3  -- Otherwise
    END                                     AS inp_visit_flag,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,

    MIN(src.load_row_id) OVER (
        PARTITION BY
            src.person_id,
            lk.concept_id,
            src.visit_detail_start_date,
            src.p_hvid
        )                                   AS new_load_row_id,

    src.p_hvid                              AS p_hvid
FROM
    @target_schema.cdm_visit_detail src
INNER JOIN
    @target_schema.lk_join_voc_visit lk
        ON  lk.descendant_concept_id = src.visit_detail_concept_id
LEFT JOIN
    @target_schema.tmp_visit_occurrence vo1
        ON  vo1.person_id = src.person_id
        AND vo1.visit_start_date = src.visit_detail_start_date
        AND vo1.rule_id = 'medical_claims.inpatient_visits'
LEFT JOIN
    @target_schema.tmp_visit_occurrence vo2
        ON  vo2.person_id = src.person_id
        AND src.visit_detail_start_date > vo2.visit_start_date
        AND src.visit_detail_start_date <= vo2.visit_end_date
        AND vo2.rule_id = 'medical_claims.inpatient_visits'
WHERE
    lk.concept_id = 9203
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Collapse records with the same VISIT_DETAIL_START_DATE
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_emergency_visit_grp;
CREATE TABLE @target_schema.lk_emergency_visit_grp
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
    source_value_count          INTEGER,
    inp_visit_flag              INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    new_load_row_id             BIGINT,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;
/*!
    @insert
    @table: @target_schema.lk_emergency_visit_grp
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_join_voc_visit
    @summary: defining spans of visits
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_emergency_visit_grp
PARTITION (p_hvid)
SELECT
    person_id                                   AS person_id,
    visit_detail_concept_id                     AS visit_detail_concept_id,
    visit_detail_start_date                     AS visit_detail_start_date,
    MAX(visit_detail_end_date)                  AS visit_detail_end_date,
    MIN(provider_id)                            AS provider_id,
    MIN(care_site_id)                           AS care_site_id,
    MIN(visit_detail_source_value)              AS visit_detail_source_value,
    COUNT(DISTINCT visit_detail_source_value)   AS source_value_count,
    MIN(inp_visit_flag)                         AS inp_visit_flag,
-- --
    MIN(rule_id)                                AS rule_id,
    MIN(load_table_id)                          AS load_table_id,
    MIN(load_row_id)                            AS load_row_id,
    MIN(new_load_row_id)                        AS new_load_row_id,
    p_hvid                                      AS p_hvid
FROM
    @target_schema.lk_emergency_visit_ancestor
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    person_id,
    visit_detail_concept_id,
    visit_detail_start_date,
    p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Insert into tmp_visit_occurrence
-- Emergency Room visit starts on the first day of an Inpatient visit
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_occurrence
    @source_table: @target_schema.lk_emergency_visit_grp
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_occurrence
PARTITION (p_hvid)
SELECT
    (SELECT COALESCE(MAX(visit_occurrence_id), 0)
       FROM @target_schema.tmp_visit_occurrence)
        + 1 + monotonically_increasing_id()
                                            AS visit_occurrence_id,

    src.person_id                           AS person_id,
    262                                     AS visit_concept_id,  -- Emergency Room and Inpatient Visit
    src.visit_detail_start_date             AS visit_start_date,
    src.visit_detail_start_date             AS visit_start_datetime,
    src.visit_detail_end_date               AS visit_end_date,
    src.visit_detail_end_date               AS visit_end_datetime,
    32810                                   AS visit_type_concept_id,  -- Claim
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,

    CASE
        WHEN src.source_value_count = 1
        THEN src.visit_detail_source_value
        ELSE NULL
    END                                     AS visit_source_value,

    0                                       AS visit_source_concept_id,
    0                                       AS admitted_from_concept_id,
    CAST(NULL AS STRING)                    AS admitted_from_source_value,
    0                                       AS discharged_to_concept_id,
    CAST(NULL AS STRING)                    AS discharged_to_source_value,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    'medical_claims.emergency_room_1'       AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.new_load_row_id                     AS load_row_id
FROM
    @target_schema.lk_emergency_visit_grp src
WHERE
    src.inp_visit_flag = 1
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Insert into tmp_visit_occurrence
-- Otherwise
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_occurrence
    @source_table: @target_schema.lk_emergency_visit_grp
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_occurrence
PARTITION (p_hvid)
SELECT
    (SELECT COALESCE(MAX(visit_occurrence_id), 0)
       FROM @target_schema.tmp_visit_occurrence)
        + 1 + monotonically_increasing_id()
                                            AS visit_occurrence_id,

    src.person_id                           AS person_id,
    9203                                    AS visit_concept_id,  -- Emergency Room Visit
    src.visit_detail_start_date             AS visit_start_date,
    src.visit_detail_start_date             AS visit_start_datetime,
    src.visit_detail_end_date               AS visit_end_date,
    src.visit_detail_end_date               AS visit_end_datetime,
    32810                                   AS visit_type_concept_id,  -- Claim
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,

    CASE
        WHEN src.source_value_count = 1
        THEN src.visit_detail_source_value
        ELSE NULL
    END                                     AS visit_source_value,

    0                                       AS visit_source_concept_id,
    0                                       AS admitted_from_concept_id,
    CAST(NULL AS STRING)                    AS admitted_from_source_value,
    0                                       AS discharged_to_concept_id,
    CAST(NULL AS STRING)                    AS discharged_to_source_value,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    'medical_claims.emergency_room_3'       AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.new_load_row_id                     AS load_row_id
FROM
    @target_schema.lk_emergency_visit_grp src
WHERE
    src.inp_visit_flag = 3
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_visit_occurrence ZORDER BY (
    person_id,
    visit_start_date,
    visit_end_date,
    rule_id
);

-- -------------------------------------------------------------------
-- LK_VISIT_DETAIL - link visit_detail_id to visit_occurrence_id
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_visit_detail
    @source_table: @target_schema.lk_emergency_visit_ancestor,
                   @target_schema.tmp_visit_occurrence
    @summary: visit starts on the first day of an Inpatient visit
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.lk_emergency_visit_ancestor src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND src.visit_detail_start_date = vo.visit_start_date
        AND src.new_load_row_id = vo.load_row_id
        AND vo.rule_id = 'medical_claims.emergency_room_1'
WHERE
    src.inp_visit_flag = 1
    AND src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

/*!
    @insert
    @table: @target_schema.lk_visit_detail
    @source_table: @target_schema.lk_emergency_visit_ancestor,
                   @target_schema.tmp_visit_occurrence
    @summary: visit occurs at any other point during an Inpatient stay
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.lk_emergency_visit_ancestor src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND src.visit_detail_start_date > vo.visit_start_date
        AND src.visit_detail_start_date <= vo.visit_end_date
        AND vo.rule_id = 'medical_claims.inpatient_visits'
WHERE
    src.inp_visit_flag = 2
    AND src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

/*!
    @insert
    @table: @target_schema.lk_visit_detail
    @source_table: @target_schema.lk_emergency_visit_ancestor,
                   @target_schema.tmp_visit_occurrence
    @summary: otherwise
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.lk_emergency_visit_ancestor src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND src.visit_detail_start_date BETWEEN vo.visit_start_date AND vo.visit_end_date
        AND src.new_load_row_id = vo.load_row_id
        AND vo.rule_id = 'medical_claims.emergency_room_3'
WHERE
    src.inp_visit_flag = 3
    AND src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
