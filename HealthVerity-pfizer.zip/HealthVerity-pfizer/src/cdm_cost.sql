-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Target Table: cost
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_cost;
CREATE TABLE @target_schema.tmp_cost
(
    cost_event_id               BIGINT,
    cost_domain_id              STRING,
    cost_type_concept_id        INTEGER,
    total_charge                DOUBLE,
    total_paid                  DOUBLE,
    amount_allowed              DOUBLE,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- Rule 1 (medical_claims)
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_cost
    @source_table: @target_schema.src_medical_claims
    @summary: rule medical_claims records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cost
PARTITION (p_hvid)
SELECT
    vd.visit_occurrence_id      AS cost_event_id,
    'Visit'                     AS cost_domain_id,
    32810                       AS cost_type_concept_id,  -- Claim
    NULL                        AS total_charge,
    NULL                        AS total_paid,
    SUM(src.total_charge)       AS amount_allowed,
-- --
    MIN(src.load_table_id)      AS rule_id,
    MIN(src.load_table_id)      AS load_table_id,
    MIN(src.load_row_id)        AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
INNER JOIN
    @target_schema.lk_visit_detail vd
        ON vd.load_row_id = src.load_row_id
WHERE
    src.logical_delete_reason IN ('INITIAL PAY CLAIM',
                                  'UNKNOWN',
                                  'ADJUSTMENT TO ORIGINAL CLAIM')
    AND COALESCE(src.total_charge, 0) != 0
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
    AND vd.p_hvid = '@hvid_char'
GROUP BY
    vd.visit_occurrence_id,
    src.p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule 2 (pharmacy_claims_closed_cut)
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_cost
    @source_table: @target_schema.lk_drug_cost,
                   @target_schema.lk_device_cost
    @summary: rule pharmacy_claims_closed_cut records
!*/

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cost
PARTITION (p_hvid)
SELECT
    lk.drug_exposure_id                     AS cost_event_id,
    'Drug'                                  AS cost_domain_id,
    32810                                   AS cost_type_concept_id,  -- Claim
    lk.submitted_gross_due                  AS total_charge,
    lk.paid_gross_due                       AS total_paid,
    NULL                                    AS amount_allowed,
-- --
    'pharmacy_claims_closed_cut.ndc_code'   AS rule_id,
    lk.load_table_id                        AS load_table_id,
    lk.load_row_id                          AS load_row_id,
    lk.p_hvid                               AS p_hvid
FROM
    @target_schema.lk_drug_cost lk
WHERE
    -- partition filter
    lk.p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cost
PARTITION (p_hvid)
SELECT
    lk.device_exposure_id                   AS cost_event_id,
    'Device'                                AS cost_domain_id,
    32810                                   AS cost_type_concept_id,  -- Claim
    lk.submitted_gross_due                  AS total_charge,
    lk.paid_gross_due                       AS total_paid,
    NULL                                    AS amount_allowed,
-- --
    'pharmacy_claims_closed_cut.ndc_code'   AS rule_id,
    lk.load_table_id                        AS load_table_id,
    lk.load_row_id                          AS load_row_id,
    lk.p_hvid                               AS p_hvid
FROM
    @target_schema.lk_device_cost lk
WHERE
    -- partition filter
    lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load Table: Cost
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_cost;

INSERT INTO @target_schema.cdm_cost
SELECT
    monotonically_increasing_id()   AS cost_id,
    cost_event_id                   AS cost_event_id,
    cost_domain_id                  AS cost_domain_id,
    cost_type_concept_id            AS cost_type_concept_id,
    NULL                            AS currency_concept_id,
    total_charge                    AS total_charge,
    NULL                            AS total_cost,
    total_paid                      AS total_paid,
    NULL                            AS paid_by_payer,
    NULL                            AS paid_by_patient,
    NULL                            AS paid_patient_copay,
    NULL                            AS paid_patient_coinsurance,
    NULL                            AS paid_patient_deductible,
    NULL                            AS paid_by_primary,
    NULL                            AS paid_ingredient_cost,
    NULL                            AS paid_dispensing_fee,
    NULL                            AS payer_plan_period_id,
    amount_allowed                  AS amount_allowed,
    0                               AS revenue_code_concept_id,
    NULL                            AS revenue_code_source_value,
    0                               AS drg_concept_id,
    NULL                            AS drg_source_value,
-- --
    p_hvid                          AS p_hvid,
    rule_id                         AS rule_id,
    load_table_id                   AS load_table_id,
    load_row_id                     AS load_row_id
FROM
    @target_schema.tmp_cost
;

OPTIMIZE @target_schema.cdm_cost ZORDER BY (
    cost_event_id,
    cost_domain_id,
    cost_type_concept_id
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_cost;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
