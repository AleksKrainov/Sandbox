-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: Person
!*/

DROP TABLE IF EXISTS @target_schema.tmp_patient_data;
CREATE TABLE @target_schema.tmp_patient_data
(
    hvid                    STRING,
    year_of_birth           INTEGER,
    gender                  STRING,
    p_hvid                  STRING
)
@PROPERTY
;

INSERT INTO @target_schema.tmp_patient_data
SELECT DISTINCT
    src.hvid                                    AS hvid,
    CAST(src.patient_yob_most_recent AS INT)    AS year_of_birth,
    src.patient_gender_most_recent              AS gender,
    src.p_hvid                                  AS p_hvid
FROM
    @source_schema.src_subscription_patient_master_list src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_yob_most_recent IS NOT NULL
    AND CAST(src.patient_yob_most_recent AS INT) <= YEAR(CAST('@max_date_of_dataset' AS DATE))
;

OPTIMIZE @target_schema.tmp_patient_data ZORDER BY (
    hvid
);

DROP TABLE IF EXISTS @target_schema.tmp_pers_cnts;
CREATE TABLE @target_schema.tmp_pers_cnts
(
    hvid                    STRING,
    cnt_gender              INTEGER,
    gender                  STRING,
    cnt_year_of_birth       INTEGER,
    min_year_of_birth       INTEGER,
    p_hvid                  STRING
)
@PROPERTY
;

INSERT INTO @target_schema.tmp_pers_cnts
SELECT
    t.hvid                              AS hvid,
    COUNT(DISTINCT t.gender)            AS cnt_gender,
    MIN(t.gender)                       AS gender,  -- to exclude NULL value
    COUNT(DISTINCT t.year_of_birth)     AS cnt_year_of_birth,
    MIN(t.year_of_birth)                AS min_year_of_birth,
    t.p_hvid                            AS p_hvid
FROM
    @target_schema.tmp_patient_data t
GROUP BY
    t.hvid,
    t.p_hvid
;

OPTIMIZE @target_schema.tmp_pers_cnts ZORDER BY (
    hvid
);

DROP TABLE IF EXISTS @target_schema.tmp_person_1;
CREATE TABLE @target_schema.tmp_person_1
(
    person_source_value     STRING,
    year_of_birth           INTEGER,
    gender                  STRING,
    p_hvid                  STRING
)
@PROPERTY
;

INSERT INTO @target_schema.tmp_person_1
SELECT DISTINCT
    src.hvid                            AS person_source_value,

    IF(pc.cnt_year_of_birth > 1,
       pc.min_year_of_birth,
       src.year_of_birth)               AS year_of_birth,

    IF(pc.cnt_gender > 1,
       NULL,
       IF(pc.gender = 'U',
          NULL,
          pc.gender)
    )                                   AS gender,

    src.p_hvid                          AS p_hvid
FROM
    @target_schema.tmp_patient_data src
INNER JOIN
    @target_schema.tmp_pers_cnts pc
        ON src.hvid = pc.hvid
;

OPTIMIZE @target_schema.tmp_person_1 ZORDER BY (
    person_source_value
);

-- -------------------------------------------------------------------
-- Search of the most frequent provider
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_cnt_provider;
CREATE TABLE @target_schema.tmp_cnt_provider
(
    hvid                    STRING,
    provider                STRING,
    basic_record_date       DATE,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

DROP TABLE IF EXISTS @target_schema.tmp_med_clm_prov_count;
CREATE TABLE @target_schema.tmp_med_clm_prov_count
(
    hvid                    STRING,
    provider                STRING,
    basic_record_date       DATE,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_med_clm_prov_count
PARTITION (p_hvid)
SELECT
    src.hvid                    AS hvid,
    src.prov_rendering_npi      AS provider,
    src.created                 AS basic_record_date,
    src.p_hvid                  AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_rendering_npi, '')) = 10
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_med_clm_prov_count
PARTITION (p_hvid)
SELECT
    src.hvid                    AS hvid,
    src.prov_billing_npi        AS provider,
    src.created                 AS basic_record_date,
    src.p_hvid                  AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND LENGTH(COALESCE(src.prov_billing_npi, '')) = 10
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cnt_provider
PARTITION (p_hvid)
SELECT
    hvid,
    provider,
    basic_record_date,
    p_hvid
FROM
    @target_schema.tmp_med_clm_prov_count
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cnt_provider
PARTITION (p_hvid)
SELECT
    hvid                        AS hvid,
    prov_prescribing_npi        AS provider,
    created                     AS basic_record_date,
    p_hvid                      AS p_hvid
FROM
    @source_schema.src_pharmacy_claims
WHERE
    hvid IS NOT NULL
    AND LENGTH(COALESCE(prov_prescribing_npi, '')) = 10
    AND p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_cnt_provider ZORDER BY (
    hvid,
    basic_record_date
);

DROP TABLE IF EXISTS @target_schema.tmp_dt_provider;
CREATE TABLE @target_schema.tmp_dt_provider
(
    hvid                STRING,
    max_record_date     DATE,
    p_hvid              STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_dt_provider
PARTITION (p_hvid)
SELECT
    hvid                        AS hvid,
    MAX(basic_record_date)      AS max_record_date,
    p_hvid                      AS p_hvid
FROM
    @target_schema.tmp_cnt_provider
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    hvid,
    p_hvid
--@FOR_END
;

OPTIMIZE @target_schema.tmp_dt_provider ZORDER BY (
    hvid,
    max_record_date
);

DROP TABLE IF EXISTS @target_schema.tmp_latest_provider;
CREATE TABLE @target_schema.tmp_latest_provider
(
    hvid                    STRING,
    provider                STRING,
    row_num_provider        BIGINT,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_latest_provider
PARTITION (p_hvid)
SELECT
    dt.hvid                         AS hvid,
    t.provider                      AS provider,
    ROW_NUMBER() OVER (
        PARTITION BY
            dt.hvid
        ORDER BY
            dt.max_record_date)     AS row_num_provider,
    t.p_hvid
FROM
    @target_schema.tmp_cnt_provider t
INNER JOIN
    @target_schema.tmp_dt_provider dt
        ON t.hvid = dt.hvid
        AND t.basic_record_date = dt.max_record_date
WHERE
    t.p_hvid = '@hvid_char'
    AND dt.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_latest_provider ZORDER BY (
    hvid
);

DROP TABLE IF EXISTS @target_schema.tmp_person_with_prov;
CREATE TABLE @target_schema.tmp_person_with_prov
(
    person_source_value     STRING,
    year_of_birth           INTEGER,
    gender                  STRING,
    provider                STRING,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_person_with_prov
PARTITION (p_hvid)
SELECT
    per1.person_source_value,
    per1.year_of_birth,
    per1.gender,
    prov.provider,
    per1.p_hvid
FROM
    @target_schema.tmp_person_1 per1
LEFT JOIN
    @target_schema.tmp_latest_provider prov
        ON  per1.person_source_value = prov.hvid
        AND prov.row_num_provider = 1
        AND prov.p_hvid = '@hvid_char'
WHERE
    per1.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_person_with_prov ZORDER BY (
    person_source_value
);

-- -------------------------------------------------------------------
-- Search the actual location
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_patient_location;

CREATE TABLE @target_schema.tmp_patient_location
(
    hvid                                string,
    loc_source_value                    string,
    basic_record_date                   date,
    p_hvid                              string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_location
PARTITION (p_hvid)
SELECT
    hvid,
    TRIM(CONCAT_WS('|',
                   COALESCE(src.patient_state, ''),
                   COALESCE(src.patient_zip3, ''))
    )                       AS loc_source_value,
    created                 AS basic_record_date,
    p_hvid                  AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_year_of_birth IS NOT NULL
    AND src.patient_state IS NOT NULL
    AND src.patient_zip3  IS NOT NULL
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_location
PARTITION (p_hvid)
SELECT DISTINCT
    hvid,
    TRIM(CONCAT_WS('|',
                   COALESCE(src.patient_state, ''),
                   COALESCE(src.patient_zip3, ''))
    )                       AS loc_source_value,
    src.created             AS basic_record_date,
    p_hvid                  AS p_hvid
FROM
    @source_schema.src_pharmacy_claims src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_year_of_birth IS NOT NULL
    AND src.patient_state IS NOT NULL
    AND src.patient_zip3  IS NOT NULL
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_patient_location ZORDER BY (
    hvid,
    basic_record_date
);

DROP TABLE IF EXISTS @target_schema.tmp_patient_location_dt;
CREATE TABLE @target_schema.tmp_patient_location_dt
(
    hvid                STRING,
    max_record_date     DATE,
    p_hvid              STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_location_dt
PARTITION (p_hvid)
SELECT
    hvid                        AS hvid,
    MAX(basic_record_date)      AS max_record_date,
    p_hvid                      AS p_hvid
FROM
    @target_schema.tmp_patient_location
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    hvid,
    p_hvid
--@FOR_END
;

OPTIMIZE @target_schema.tmp_patient_location_dt ZORDER BY (
    hvid,
    max_record_date
);

DROP TABLE IF EXISTS @target_schema.tmp_patient_location_max_dt;
CREATE TABLE @target_schema.tmp_patient_location_max_dt
(
    hvid                    STRING,
    loc_source_value        STRING,
    basic_record_date       DATE,
    row_id                  BIGINT,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_location_max_dt
PARTITION (p_hvid)
SELECT
    t.hvid                          AS hvid,
    t.loc_source_value              AS loc_source_value,
    t.basic_record_date             AS basic_record_date,
    ROW_NUMBER() OVER (
        PARTITION BY
            t.hvid
        ORDER BY
            dt.max_record_date)     AS row_id,
    t.p_hvid
FROM
    @target_schema.tmp_patient_location t
INNER JOIN
    @target_schema.tmp_patient_location_dt dt
        ON  t.hvid = dt.hvid
        AND t.basic_record_date = dt.max_record_date
WHERE
    t.p_hvid = '@hvid_char'
    AND dt.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_patient_location_max_dt ZORDER BY (
    hvid
);

DROP TABLE IF EXISTS @target_schema.tmp_patient_final;
CREATE TABLE @target_schema.tmp_patient_final
(
    person_source_value     STRING,
    gender                  STRING,
    year_of_birth           INTEGER,
    provider                STRING,
    loc_source_value        STRING,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_final
PARTITION (p_hvid)
SELECT
    t.person_source_value,
    t.gender,
    t.year_of_birth,
    t.provider,
    mdt.loc_source_value,
    t.p_hvid
FROM
    @target_schema.tmp_person_with_prov t
LEFT JOIN
    @target_schema.tmp_patient_location_max_dt mdt
        ON  t.person_source_value = mdt.hvid
        AND mdt.row_id = 1
        AND mdt.p_hvid = '@hvid_char'
WHERE
    t.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_patient_final ZORDER BY (
    person_source_value,
    provider,
    loc_source_value
);

-- -------------------------------------------------------------------
-- Load table: LK_Person
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.lk_person;
/*!
    @insert
    @summary: demographics info lookup for all patients
!*/
CREATE TABLE @target_schema.lk_person
@PROPERTY
PARTITIONED BY (p_hvid)
AS SELECT
    monotonically_increasing_id()   AS person_id,

    CASE
        WHEN t.gender = 'M'
        THEN 8507
        WHEN t.gender = 'F'
        THEN 8532
        ELSE 0
    END                             AS gender_concept_id,

    t.year_of_birth                 AS year_of_birth,
    CAST(NULL AS INT)               AS month_of_birth,
    CAST(NULL AS INT)               AS day_of_birth,
    CAST(NULL AS TIMESTAMP)         AS birth_datetime,

    CASE LOWER(pr.race)
        WHEN 'white'
        THEN 8527  -- White
        WHEN 'black'
        THEN 38003598  -- Black
        WHEN 'asian'
        THEN 8515  -- Asian
        ELSE 0
    END                             AS race_concept_id,

    CASE LOWER(pr.race)
        WHEN 'hispanic'
        THEN 38003563  -- Hispanic or Latino
        ELSE 0
    END                             AS ethnicity_concept_id,

    loc.location_id                 AS location_id,
    prov.provider_id                AS provider_id,
    prov.care_site_id               AS care_site_id,
    t.person_source_value           AS person_source_value,
    t.gender                        AS gender_source_value,

    CASE
        WHEN t.gender = 'M'
        THEN 8507
        WHEN t.gender = 'F'
        THEN 8532
        ELSE 0
    END                             AS gender_source_concept_id,

    pr.race                         AS race_source_value,
    0                               AS race_source_concept_id,
    
    CASE LOWER(pr.race)
        WHEN 'hispanic'
        THEN pr.race
        ELSE CAST(NULL AS STRING)
    END                             AS ethnicity_source_value,

    0                               AS ethnicity_source_concept_id,
-- --
    'patients'                      AS rule_id,
    CAST(NULL AS STRING)            AS load_table_id,
    CAST(NULL AS INT)               AS load_row_id,
    t.p_hvid                        AS p_hvid
FROM
    @target_schema.tmp_patient_final t
LEFT JOIN
    @target_schema.cdm_provider prov
        ON t.provider = prov.provider_source_value
LEFT JOIN
    @target_schema.cdm_location loc
        ON t.loc_source_value = loc.location_source_value
LEFT JOIN
    @source_schema.src_patient_race pr
        ON t.person_source_value = pr.hvid
;

OPTIMIZE @target_schema.lk_person ZORDER BY (
    person_id,
    person_source_value
);

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_patient_data;
DROP TABLE IF EXISTS @target_schema.tmp_pers_cnts;
DROP TABLE IF EXISTS @target_schema.tmp_person_1;
DROP TABLE IF EXISTS @target_schema.tmp_cnt_provider;
DROP TABLE IF EXISTS @target_schema.tmp_med_clm_prov_count;
DROP TABLE IF EXISTS @target_schema.tmp_dt_provider;
DROP TABLE IF EXISTS @target_schema.tmp_latest_provider;
DROP TABLE IF EXISTS @target_schema.tmp_person_with_prov;
DROP TABLE IF EXISTS @target_schema.tmp_patient_location;
DROP TABLE IF EXISTS @target_schema.tmp_patient_location_max_dt;
DROP TABLE IF EXISTS @target_schema.tmp_patient_final;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------