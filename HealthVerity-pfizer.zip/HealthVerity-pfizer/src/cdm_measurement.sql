-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: Measurement
!*/
-- -------------------------------------------------------------------
-- Populate table: tmp_measurement
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_measurement;
CREATE TABLE @target_schema.tmp_measurement
(
    person_id               bigint,
    target_concept_id       int,
    event_start_date        timestamp,
    type_concept_id         int,
    operator_concept_id     int,
    value_as_number         double,
    value_as_concept_id     int,
    unit_concept_id         int,
    range_low               double,
    range_high              double,
    provider_id             bigint,
    visit_occurrence_id     bigint,
    event_source_value      string,
    source_concept_id       int,
    unit_source_value       string,
    value_source_value      string,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- From lk_mapped_diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_measurement
    @source_table: @target_schema.lk_mapped_diag
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_measurement PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,
    lk.event_type_concept_id    AS type_concept_id,
    NULL                        AS operator_concept_id,
    lk.value_as_number          AS value_as_number,
    lk.value_as_concept_id      AS value_as_concept_id,
    lk.unit_concept_id          AS unit_concept_id,
    NULL                        AS range_low,
    NULL                        AS range_high,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    lk.unit_source_value        AS unit_source_value,
    NULL                        AS value_source_value,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_diag lk
WHERE
    lk.domain_id = 'Measurement'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- From lk_mapped_proc
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_measurement
    @source_table: @target_schema.lk_mapped_proc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_measurement PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,
    lk.event_type_concept_id    AS type_concept_id,
    NULL                        AS operator_concept_id,
    lk.value_as_number          AS value_as_number,
    lk.value_as_concept_id      AS value_as_concept_id,
    lk.unit_concept_id          AS unit_concept_id,
    NULL                        AS range_low,
    NULL                        AS range_high,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    lk.unit_source_value        AS unit_source_value,
    NULL                        AS value_source_value,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_proc lk
WHERE
    lk.domain_id = 'Measurement'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's and Post Dedupe
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_measurement_id;
CREATE TABLE @target_schema.tmp_measurement_id
@PROPERTY PARTITIONED BY (p_hvid) AS
SELECT
    monotonically_increasing_id()   AS measurement_id,
    m.*
FROM
    @target_schema.tmp_measurement m
WHERE
    m.event_start_date BETWEEN CAST('@min_date_of_dataset' AS DATE)
                           AND CAST('@max_date_of_dataset' AS DATE)
;

-- -------------------------------------------------------------------
-- Load Table: Measurement
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_measurement;
/*!
    @insert
    @table: @target_schema.cdm_measurement
    @source_table: @target_schema.tmp_measurement_id
    @summary: populate cdm_measurement
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_measurement
SELECT
    t.measurement_id                    AS measurement_id,
    t.person_id                         AS person_id,
    t.target_concept_id                 AS measurement_concept_id,
    t.event_start_date                  AS measurement_date,
    NULL                                AS measurement_datetime,
    NULL                                AS measurement_time,
    t.type_concept_id                   AS measurement_type_concept_id,
    NULLIF(t.operator_concept_id, 0)    AS operator_concept_id,
    t.value_as_number                   AS value_as_number,
    t.value_as_concept_id               AS value_as_concept_id,
    NULLIF(t.unit_concept_id, 0)        AS unit_concept_id,
    t.range_low                         AS range_low,
    t.range_high                        AS range_high,
    t.provider_id                       AS provider_id,
    t.visit_occurrence_id               AS visit_occurrence_id,
    NULL                                AS visit_detail_id,
    t.event_source_value                AS measurement_source_value,
    t.source_concept_id                 AS measurement_source_concept_id,
    t.unit_source_value                 AS unit_source_value,
    NULL                                AS unit_source_concept_id,
    t.value_source_value                AS value_source_value,
    NULL                                AS measurement_event_id,
    NULL                                AS meas_event_field_concept_id,
-- --
    t.p_hvid                            AS p_hvid,
    t.rule_id                           AS rule_id,
    t.load_table_id                     AS load_table_id,
    t.load_row_id                       AS load_row_id
FROM
    @target_schema.tmp_measurement_id t
WHERE
    t.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.cdm_measurement ZORDER BY (
    person_id,
    measurement_concept_id,
    measurement_date,
    measurement_source_value
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_measurement;
DROP TABLE IF EXISTS @target_schema.tmp_measurement_id;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/
