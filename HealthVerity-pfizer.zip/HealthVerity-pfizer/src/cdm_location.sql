-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: Location
!*/

DROP TABLE IF EXISTS @target_schema.tmp_loc_all;
/*!
    @insert
    @table: @target_schema.tmp_loc_all
    @source_table: @target_schema.lk_entities
    @summary:
!*/
CREATE TABLE @target_schema.tmp_loc_all
(
    location_source_value   STRING,
    address_1               STRING,
    address_2               STRING,
    city                    STRING,
    state                   STRING,
    zip                     STRING,
-- --
    rule_id                 STRING,
    load_table_id           STRING
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Collection patient location data
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_patient_loc;
/*!
    @insert
    @table: @target_schema.tmp_patient_loc
    @source_table: @target_schema.lk_entities
    @summary:
!*/
CREATE TABLE @target_schema.tmp_patient_loc
(
    hvid                    STRING, 
    created                 DATE,
    location_source_value   STRING,
    address_1               STRING,
    address_2               STRING,
    city                    STRING,
    state                   STRING,
    zip                     STRING,
-- --
    rule_id                 STRING,
    load_table_id           STRING,
    p_hvid                  STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_loc
PARTITION (p_hvid)
SELECT DISTINCT
    src.hvid                    AS hvid, 
    src.created                 AS created,

    TRIM(CONCAT_WS('|',
                   COALESCE(src.patient_state, ''),
                   COALESCE(src.patient_zip3, ''))
    )                           AS location_source_value,

    CAST(NULL AS STRING)        AS address_1,
    CAST(NULL AS STRING)        AS address_2,
    CAST(NULL AS STRING)        AS city,
    src.patient_state           AS state,
    src.patient_zip3            AS zip,
-- --
    'pat_location'              AS rule_id,
    src.load_table_id           AS load_table_id,
    src.p_hvid                  AS p_hvid
FROM
    @source_schema.src_enrollment src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_state IS NOT NULL
    AND src.patient_zip3 IS NOT NULL
    AND p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_medical_claims_loc;
CREATE TABLE @target_schema.tmp_medical_claims_loc
(
    hvid            STRING,
    created         DATE,
    patient_state   STRING,
    patient_zip3    STRING,
-- --
    load_table_id   STRING,
    p_hvid          STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_claims_loc
PARTITION (p_hvid)
SELECT DISTINCT
    src.hvid,
    src.created,
    src.patient_state,
    src.patient_zip3,
-- --
    src.load_table_id,
    src.p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_year_of_birth IS NOT NULL
    AND src.patient_state IS NOT NULL
    AND src.patient_zip3 IS NOT NULL
    AND p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_loc
PARTITION (p_hvid)
SELECT DISTINCT
    src.hvid                    AS hvid, 
    src.created                 AS created,

    TRIM(CONCAT_WS('|',
                   COALESCE(src.patient_state, ''),
                   COALESCE(src.patient_zip3, ''))
    )                           AS location_source_value,

    CAST(NULL AS STRING)        AS address_1,
    CAST(NULL AS STRING)        AS address_2,
    CAST(NULL AS STRING)        AS city,
    src.patient_state           AS state,
    src.patient_zip3            AS zip,
-- --
    'pat_location'              AS rule_id,
    src.load_table_id           AS load_table_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.tmp_medical_claims_loc src
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_patient_loc
PARTITION (p_hvid)
SELECT DISTINCT
    src.hvid                    AS hvid,
    src.created                 AS created,

    TRIM(CONCAT_WS('|',
                   COALESCE(src.patient_state, ''),
                   COALESCE(src.patient_zip3, ''))
    )                           AS location_source_value,

    CAST(NULL AS STRING)        AS address_1,
    CAST(NULL AS STRING)        AS address_2,
    CAST(NULL AS STRING)        AS city,
    src.patient_state           AS state,
    src.patient_zip3            AS zip,
-- --
    'pat_location'              AS rule_id,
    src.load_table_id           AS load_table_id,
    src.p_hvid                  AS p_hvid
FROM
    @source_schema.src_pharmacy_claims src
WHERE
    src.hvid IS NOT NULL
    AND src.patient_year_of_birth IS NOT NULL
    AND src.patient_state IS NOT NULL
    AND src.patient_zip3 IS NOT NULL
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_patient_loc ZORDER BY (
    hvid,
    created
);

DROP TABLE IF EXISTS @target_schema.tmp_patient_loc_ord;
CREATE TABLE @target_schema.tmp_patient_loc_ord
AS SELECT
    src.*,
    ROW_NUMBER()
        OVER(PARTITION BY src.hvid
             ORDER BY src.created DESC) AS rn
FROM
    @target_schema.tmp_patient_loc src
;

INSERT INTO @target_schema.tmp_loc_all
SELECT DISTINCT
    location_source_value,
    address_1,
    address_2,
    city,
    state,
    zip,
-- --
    rule_id,
    load_table_id
FROM
    @source_schema.tmp_patient_loc_ord
WHERE
    rn = 1
;

-- -------------------------------------------------------------------
-- Collection care_site location data
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_cs_loc;
CREATE TABLE @target_schema.tmp_cs_loc
(
    prov_facility_address_1     STRING,
    prov_facility_address_2     STRING,
    prov_facility_city          STRING,
    prov_facility_state         STRING,
    prov_facility_zip           STRING,
    location_source_value       STRING,
    most_complete_information   INTEGER,
    created                     DATE,
-- --
    load_table_id               STRING,
    p_hvid                      STRING
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cs_loc
PARTITION (p_hvid)
SELECT DISTINCT
    src.prov_facility_address_1     AS prov_facility_address_1,
    src.prov_facility_address_2     AS prov_facility_address_2,
    src.prov_facility_city          AS prov_facility_city,
    src.prov_facility_state         AS prov_facility_state,
    src.prov_facility_zip           AS prov_facility_zip,

    TRIM(CONCAT_WS('|',
                   COALESCE(src.prov_facility_address_1, ''),
                   COALESCE(src.prov_facility_address_2, ''),
                   COALESCE(src.prov_facility_city, ''),
                   COALESCE(src.prov_facility_state, ''),
                   COALESCE(src.prov_facility_zip, ''))
    )                               AS location_source_value,

    (
        IF(prov_facility_address_1 IS NULL, 0, 1) +
        IF(prov_facility_address_2 IS NULL, 0, 1) +
        IF(prov_facility_city IS NULL, 0, 1) +
        IF(prov_facility_state IS NULL, 0, 1) +
        IF(prov_facility_zip IS NULL, 0, 1)
    )                               AS most_complete_information,

    src.created                     AS created,
-- --
    src.load_table_id               AS load_table_id,
    src.p_hvid                      AS p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    COALESCE(src.prov_facility_address_1,
             src.prov_facility_address_2,
             src.prov_facility_city,
             src.prov_facility_state,
             src.prov_facility_zip) IS NOT NULL
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_cs_loc_ord;
CREATE TABLE @target_schema.tmp_cs_loc_ord
AS SELECT
    src.*,
    ROW_NUMBER()
        OVER(PARTITION BY src.location_source_value
             ORDER BY src.most_complete_information DESC,
                      src.created DESC) AS rn
FROM
    @target_schema.tmp_cs_loc src
;

INSERT INTO @target_schema.tmp_loc_all
SELECT DISTINCT
    TRIM(CONCAT_WS('|',
                   COALESCE(src.prov_facility_address_1, ''),
                   COALESCE(src.prov_facility_address_2, ''),
                   COALESCE(src.prov_facility_city,      ''),
                   COALESCE(src.prov_facility_state,     ''),
                   COALESCE(src.prov_facility_zip,       ''))
    )                                   AS location_source_value,
    src.prov_facility_address_1         AS address_1,
    src.prov_facility_address_2         AS address_2,
    src.prov_facility_city              AS city,
    src.prov_facility_state             AS state,
    src.prov_facility_zip               AS zip,
-- --
    'cs_location'                       AS rule_id,
    src.load_table_id                   AS load_table_id
FROM
    @target_schema.tmp_cs_loc_ord src
WHERE
    src.rn = 1
;

OPTIMIZE @target_schema.tmp_loc_all ZORDER BY (
    location_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_location_dedup;
/*!
    @insert
    @table: @target_schema.tmp_location_dedup
    @source_table: @target_schema.tmp_loc_all
    @summary:
!*/
CREATE TABLE @target_schema.tmp_location_dedup
@PROPERTY
AS SELECT
    location_source_value           AS location_source_value,
    NULLIF(TRIM(address_1), '')     AS address_1,
    NULLIF(TRIM(address_2), '')     AS address_2,
    NULLIF(TRIM(city), '')          AS city,
    NULLIF(TRIM(state), '')         AS state,
    NULLIF(TRIM(zip), '')           AS zip,
    MIN(rule_id)                    AS rule_id,
    MIN(load_table_id)              AS load_table_id
FROM
    @target_schema.tmp_loc_all
WHERE
    location_source_value != '|'
GROUP BY
    location_source_value,
    NULLIF(TRIM(address_1), ''),
    NULLIF(TRIM(address_2), ''),
    NULLIF(TRIM(city), ''),
    NULLIF(TRIM(state), ''),
    NULLIF(TRIM(zip), '')
;

-- -------------------------------------------------------------------
-- Load Table: Location
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_location;
/*!
    @insert
    @table: @target_schema.cdm_location
    @source_table: @target_schema.tmp_location_dedup
    @summary: populate cdm_location
!*/
INSERT INTO @target_schema.cdm_location
SELECT
    monotonically_increasing_id()       AS location_id,
    t.address_1                         AS address_1,
    t.address_2                         AS address_2,
    t.city                              AS city,
    t.state                             AS state,
    t.zip                               AS zip,
    NULL                                AS county,
    t.location_source_value             AS location_source_value,
    42046186                            AS country_concept_id,  -- United States
    'United States of America'          AS country_source_value,
    NULL                                AS latitude,
    NULL                                AS longitude,
-- --
    t.rule_id                           AS rule_id,
    t.load_table_id                     AS load_table_id,
    NULL                                AS load_row_id
FROM
    @target_schema.tmp_location_dedup t
;

OPTIMIZE @target_schema.cdm_location ZORDER BY (
    location_source_value
);

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_loc_all;
DROP TABLE IF EXISTS @target_schema.tmp_patient_loc;
DROP TABLE IF EXISTS @target_schema.tmp_patient_loc_ord;
DROP TABLE IF EXISTS @target_schema.tmp_medical_claims_loc;
DROP TABLE IF EXISTS @target_schema.tmp_cs_loc;
DROP TABLE IF EXISTS @target_schema.tmp_cs_loc_ord;
DROP TABLE IF EXISTS @target_schema.tmp_location_dedup;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
