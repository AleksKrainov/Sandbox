-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Rule n.1 Records from medical_claims
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_cs_1;
CREATE TABLE @target_schema.tmp_cs_1
(
    cs_source_value                 STRING,
    cs_name                         STRING,
    place_of_service_source_value   STRING,
    loc_source_value                STRING,
    loc_populating_flag             STRING,
    basic_record_date               DATE,
-- --
    load_table_id                   STRING
)
@PROPERTY
;

DROP TABLE IF EXISTS @target_schema.tmp_medical_clm_cs;
CREATE TABLE @target_schema.tmp_medical_clm_cs
(
    place_of_service_std_id             string,
    prov_facility_address_1             string,
    prov_facility_address_2             string,
    prov_facility_city                  string,
    prov_facility_state                 string,
    prov_facility_zip                   string,
    created                             date,
-- --
    load_table_id                       string,
    p_hvid                              string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

/*!
    @insert
    @summary: facility data from Medical Claims
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_medical_clm_cs
PARTITION (p_hvid)
SELECT
    src.place_of_service_std_id,
    src.prov_facility_address_1,
    src.prov_facility_address_2,
    src.prov_facility_city,
    src.prov_facility_state,
    src.prov_facility_zip,
    src.created,
-- --
    src.load_table_id,
    src.p_hvid
FROM
    @source_schema.src_medical_claims src
WHERE
    src.place_of_service_std_id IS NOT NULL
    AND src.hvid IS NOT NULL
    AND src.patient_year_of_birth IS NOT NULL
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_cs_1
SELECT DISTINCT
    src.place_of_service_std_id                             AS cs_source_value,
    NULL                                                    AS cs_name,
    src.place_of_service_std_id                             AS place_of_service_source_value,
    CASE
        WHEN COALESCE(src.prov_facility_address_1,
                      src.prov_facility_address_2,
                      src.prov_facility_city,
                      src.prov_facility_state,
                      src.prov_facility_zip) IS NULL   THEN NULL
        ELSE  CONCAT_WS('|',
                        COALESCE(src.prov_facility_address_1, ''),
                        COALESCE(src.prov_facility_address_2, ''),
                        COALESCE(src.prov_facility_city,      ''),
                        COALESCE(src.prov_facility_state,     ''),
                        COALESCE(src.prov_facility_zip,       ''))
    END                                                     AS loc_source_value,
      IF(src.prov_facility_address_1 IS NOT NULL, 1, 0)
    + IF(src.prov_facility_address_2 IS NOT NULL, 1, 0)
    + IF(src.prov_facility_city      IS NOT NULL, 1, 0)
    + IF(src.prov_facility_state     IS NOT NULL, 1, 0)
    + IF(src.prov_facility_zip       IS NOT NULL, 1, 0)     AS loc_populating_flag,
    src.created                                             AS basic_record_date,
-- --
    src.load_table_id                                       AS load_table_id
FROM
    @target_schema.tmp_medical_clm_cs src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.tmp_cs_1 ZORDER BY (
    cs_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_cs_max_loc_flag;
CREATE TABLE @target_schema.tmp_cs_max_loc_flag
@PROPERTY
AS SELECT
    src.cs_source_value             AS cs_source_value,
    MAX(src.loc_populating_flag)    AS max_loc_populating_flag
FROM
    @target_schema.tmp_cs_1 src
GROUP BY
    src.cs_source_value
;

OPTIMIZE @target_schema.tmp_cs_max_loc_flag ZORDER BY (
    cs_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_cs_loc_definition;
CREATE TABLE @target_schema.tmp_cs_loc_definition
@PROPERTY
AS SELECT
    monotonically_increasing_id()   AS care_site_id,
    src.*
FROM
    @target_schema.tmp_cs_1 src
LEFT JOIN
    @target_schema.tmp_cs_max_loc_flag t
        ON src.cs_source_value = t.cs_source_value
WHERE
    src.loc_populating_flag = t.max_loc_populating_flag
;

OPTIMIZE @target_schema.tmp_cs_loc_definition ZORDER BY (
    loc_source_value
);

DROP TABLE IF EXISTS @target_schema.tmp_cs_final_dedup;
/*!
    @insert
    @table: @target_schema.tmp_cs_final_dedup
    @source_table: @target_schema.tmp_cs_loc_definition
    @summary:
!*/
CREATE TABLE @target_schema.tmp_cs_final_dedup
@PROPERTY
AS SELECT
    MIN(t.care_site_id) OVER (
        PARTITION BY
            t.cs_source_value)          AS min_care_site_id,
    t.care_site_id                      AS care_site_id,
    t.cs_source_value                   AS cs_source_value,
    t.cs_name                           AS cs_name,
    t.place_of_service_source_value     AS place_of_service_source_value,
    t.loc_source_value                  AS loc_source_value,
    t.basic_record_date                 AS basic_record_date,
    ROW_NUMBER() OVER (
        PARTITION BY
            t.cs_source_value
        ORDER BY
            t.basic_record_date DESC)   AS row_max_date,
    loc.location_id                     AS location_id,
-- --
    t.load_table_id                     AS load_table_id
FROM
    @target_schema.tmp_cs_loc_definition t
LEFT JOIN
    @target_schema.cdm_location loc
        ON  t.loc_source_value = loc.location_source_value
        AND loc.rule_id = 'cs_location'
;

OPTIMIZE @target_schema.tmp_cs_final_dedup ZORDER BY (
    place_of_service_source_value,
    row_max_date
);

-- -------------------------------------------------------------------
-- Load table: Care_site
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_care_site;
/*!
    @insert
    @table: @target_schema.cdm_care_site
    @source_table: @target_schema.tmp_cs_final_dedup
    @summary: records from medical_claims
!*/
INSERT INTO @target_schema.cdm_care_site
SELECT
    t_cs.min_care_site_id               AS care_site_id,
    t_cs.cs_name                        AS care_site_name,
    COALESCE(lkc.target_concept_id, 0)  AS place_of_service_concept_id,
    t_cs.location_id                    AS location_id,
    t_cs.cs_source_value                AS care_site_source_value,
    t_cs.place_of_service_source_value  AS place_of_service_source_value,
-- --
    t_cs.load_table_id                  AS rule_id,
    t_cs.load_table_id                  AS load_table_id,
    NULL                                AS load_row_id
FROM
    @target_schema.tmp_cs_final_dedup t_cs
LEFT JOIN
    @target_schema.lk_concept lkc
        ON  t_cs.place_of_service_source_value = lkc.src_code
        AND lkc.src_code_type = 'place_of_service_code'
        AND lkc.source_vocabulary_id = 'CMS Place of Service'
WHERE
    t_cs.row_max_date = 1
;

/*!
    @insert
    @table: @target_schema.tmp_dist_pharmacy_npi
    @source_table: @target_schema.src_pharmacy_claims
    @summary: records from pharmacy_claims
!*/
DROP TABLE IF EXISTS @target_schema.tmp_dist_pharmacy_npi;
CREATE TABLE @target_schema.tmp_dist_pharmacy_npi
AS SELECT DISTINCT
    pharmacy_npi,
    load_table_id
FROM
    @source_schema.src_pharmacy_claims
WHERE
    pharmacy_npi IS NOT NULL
    AND LENGTH(COALESCE(pharmacy_npi, '')) = 10
    AND TRY_CAST(pharmacy_npi AS BIGINT) IS NOT NULL
;

/*!
    @insert
    @table: @target_schema.cdm_care_site
    @source_table: @target_schema.tmp_dist_pharmacy_npi
    @summary: records from pharmacy_claims
!*/
INSERT INTO @target_schema.cdm_care_site
SELECT
    (SELECT COALESCE(MAX(care_site_id), 0)
       FROM @target_schema.cdm_care_site)
        + 1 + monotonically_increasing_id()
                                        AS care_site_id,

    NULL                                AS care_site_name,
    0                                   AS place_of_service_concept_id,
    NULL                                AS location_id,
    pharmacy_npi                        AS care_site_source_value,
    '01'                                AS place_of_service_source_value,  -- 'Pharmacy' in vocabulary 'CMS Place of Service'
-- --
    load_table_id                       AS rule_id,
    load_table_id                       AS load_table_id,
    NULL                                AS load_row_id
FROM
    @target_schema.tmp_dist_pharmacy_npi
;

OPTIMIZE @target_schema.cdm_care_site ZORDER BY (
    care_site_source_value
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_cs_1;
DROP TABLE IF EXISTS @target_schema.tmp_medical_clm_cs;
DROP TABLE IF EXISTS @target_schema.tmp_cs_max_loc_flag;
DROP TABLE IF EXISTS @target_schema.tmp_cs_loc_definition;
DROP TABLE IF EXISTS @target_schema.tmp_cs_final_dedup;
DROP TABLE IF EXISTS @target_schema.tmp_dist_pharmacy_npi;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------