-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- sample of patients (size is set in stage.etlconf)
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_samp_patient;
--@IF @create_sample = +
CREATE TABLE @target_schema.tmp_samp_patient
@PROPERTY
AS SELECT DISTINCT
   hvid
FROM
   @source_schema.@enrollment
ORDER BY RAND()
LIMIT @SAMPLE_SIZE
--@ENDIF
;

-- --@IF @create_sample = +
-- INSERT INTO @target_schema.tmp_samp_patient
-- SELECT DISTINCT
--    hvid
-- FROM
--    @source_schema.@pharmacy_claims
-- ORDER BY RAND()
-- LIMIT @SAMPLE_SIZE
-- --@ENDIF
-- ;

-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_patient_subset;
--@IF @create_sample = +
CREATE TABLE @target_schema.tmp_patient_subset
@PROPERTY
AS SELECT DISTINCT
    src.hvid
FROM
    @target_schema.tmp_samp_patient src
LIMIT @SAMPLE_SIZE
--@ENDIF
;

--@IF @create_sample = +
OPTIMIZE @target_schema.tmp_patient_subset ZORDER BY (hvid)
--@ENDIF
;

-- -------------------------------------------------------------------
-- enrollment
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_enrollment;
CREATE TABLE @target_schema.src_enrollment
(
    hvid                    string,
    patient_year_of_birth   string,
    patient_gender          string,
    date_start              date,
    date_end                date,
    source_record_date      date,
    created                 date,
    record_id               bigint,
    --model_version           string,
    --data_set                string,
    --data_feed               string,
    --data_vendor             string,
    patient_age             string,
    patient_zip3            string,
    patient_state           string,
    benefit_type            string,
    payer_type              string,
    payer_grp_txt           string,
    --part_mth_alt            string,
    --part_mth                string,
-- --
    load_row_id             bigint,
    load_table_id           string,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_enrollment
SELECT
    src.hvid                            AS hvid,
    patient_year_of_birth               AS patient_year_of_birth,
    NULLIF( TRIM(patient_gender), '')   AS patient_gender,
    date_start                          AS date_start,
    date_end                            AS date_end,
    source_record_date                  AS source_record_date,
    created                             AS created,
    record_id                           AS record_id,
    patient_age                         AS patient_age,
    NULLIF( TRIM(patient_zip3), '')     AS patient_zip3,
    NULLIF( TRIM(patient_state), '')    AS patient_state,
    benefit_type                        AS benefit_type,
    payer_type                          AS payer_type,
    payer_grp_txt                       AS payer_grp_txt,
-- --
    monotonically_increasing_id()       AS load_row_id,
    '@enrollment'                       AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)           AS p_hvid
FROM
    @source_schema.@enrollment src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
WHERE
    src.hvid IS NOT NULL
;

OPTIMIZE @target_schema.src_enrollment ZORDER BY (
    hvid,
    payer_type,
    benefit_type
);

-- -------------------------------------------------------------------
-- medical_claims
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_medical_claims;
CREATE TABLE @target_schema.src_medical_claims
(
    hvid                                string,
    diagnosis_code                      string,
    procedure_code                      string,
    ndc_code                            string,
    date_received                       date,
    date_service                        date,
    date_service_end                    date,
    inst_date_admitted                  date,
    inst_date_discharged                date,
    record_id                           bigint,
    --claim_id                            string,
    hv_enc_id                           string,
    created                             date,
    --model_version                       string,
    --data_set                            string,
    --data_feed                           string,
    data_vendor                         string,
    --source_version                      string,
    --vendor_org_id                       string,
    patient_gender                      string,
    patient_age                         string,
    patient_year_of_birth               string,
    patient_zip3                        string,
    patient_state                       string,
    claim_type                          string,
    --inst_admit_type_std_id              string,
    --inst_admit_type_vendor_id           string,
    --inst_admit_type_vendor_desc         string,
    --inst_admit_source_std_id            string,
    --inst_admit_source_vendor_id         string,
    --inst_admit_source_vendor_desc       string,
    inst_discharge_status_std_id        string,
    --inst_discharge_status_vendor_id     string,
    --inst_discharge_status_vendor_desc   string,
    inst_type_of_bill_std_id            string,
    --inst_type_of_bill_vendor_id         string,
    --inst_type_of_bill_vendor_desc       string,
    inst_drg_std_id                     string,
    inst_drg_vendor_id                  string,
    inst_drg_vendor_desc                string,
    place_of_service_std_id             string,
    --place_of_service_vendor_id          string,
    --place_of_service_vendor_desc        string,
    --service_line_number                 string,
    --service_line_id                     string,
    diagnosis_code_qual                 string,
    diagnosis_priority                  string,
    admit_diagnosis_ind                 string,
    procedure_code_qual                 string,
    --principal_proc_ind                  string,
    --procedure_units_billed              double,
    --procedure_units_paid                double,
    procedure_modifier_1                string,
    procedure_modifier_2                string,
    procedure_modifier_3                string,
    procedure_modifier_4                string,
    revenue_code                        string,
    --medical_coverage_type               string,
    line_charge                         double,
    line_allowed                        double,
    total_charge                        double,
    total_allowed                       double,
    prov_rendering_npi                  string,
    prov_billing_npi                    string,
    prov_referring_npi                  string,
    prov_facility_npi                   string,
    --payer_vendor_id                     string,
    --payer_name                          string,
    --payer_parent_name                   string,
    --payer_org_name                      string,
    --payer_plan_id                       string,
    --payer_plan_name                     string,
    --payer_type                          string,
    prov_rendering_vendor_id            string,
    --prov_rendering_tax_id               string,
    prov_rendering_dea_id               string,
    --prov_rendering_ssn                  string,
    --prov_rendering_state_license        string,
    --prov_rendering_upin                 string,
    --prov_rendering_commercial_id        string,
    --prov_rendering_name_1               string,
    --prov_rendering_name_2               string,
    --prov_rendering_address_1            string,
    --prov_rendering_address_2            string,
    --prov_rendering_city                 string,
    --prov_rendering_state                string,
    --prov_rendering_zip                  string,
    --prov_rendering_std_taxonomy         string,
    prov_rendering_vendor_specialty     string,
    prov_billing_vendor_id              string,
    --prov_billing_tax_id                 string,
    prov_billing_dea_id                 string,
    --prov_billing_ssn                    string,
    --prov_billing_state_license          string,
    --prov_billing_upin                   string,
    --prov_billing_commercial_id          string,
    --prov_billing_name_1                 string,
    --prov_billing_name_2                 string,
    --prov_billing_address_1              string,
    --prov_billing_address_2              string,
    --prov_billing_city                   string,
    --prov_billing_state                  string,
    --prov_billing_zip                    string,
    --prov_billing_std_taxonomy           string,
    prov_billing_vendor_specialty       string,
    prov_referring_vendor_id            string,
    --prov_referring_tax_id               string,
    prov_referring_dea_id               string,
    --prov_referring_ssn                  string,
    --prov_referring_state_license        string,
    --prov_referring_upin                 string,
    --prov_referring_commercial_id        string,
    --prov_referring_name_1               string,
    --prov_referring_name_2               string,
    --prov_referring_address_1            string,
    --prov_referring_address_2            string,
    --prov_referring_city                 string,
    --prov_referring_state                string,
    --prov_referring_zip                  string,
    --prov_referring_std_taxonomy         string,
    prov_referring_vendor_specialty     string,
    --prov_facility_vendor_id             string,
    --prov_facility_tax_id                string,
    --prov_facility_dea_id                string,
    --prov_facility_ssn                   string,
    --prov_facility_state_license         string,
    --prov_facility_upin                  string,
    --prov_facility_commercial_id         string,
    prov_facility_name_1                string,
    prov_facility_name_2                string,
    prov_facility_address_1             string,
    prov_facility_address_2             string,
    prov_facility_city                  string,
    prov_facility_state                 string,
    prov_facility_zip                   string,
    --prov_facility_std_taxonomy          string,
    --prov_facility_vendor_specialty      string,
    --cob_payer_vendor_id_1               string,
    --cob_payer_seq_code_1                string,
    --cob_payer_hpid_1                    string,
    --cob_payer_claim_filing_ind_code_1   string,
    --cob_ins_type_code_1                 string,
    --cob_payer_vendor_id_2               string,
    --cob_payer_seq_code_2                string,
    --cob_payer_hpid_2                    string,
    --cob_payer_claim_filing_ind_code_2   string,
    --cob_ins_type_code_2                 string,
    --vendor_test_id                      string,
    --vendor_test_name                    string,
    claim_transaction_date              date,
    --claim_transaction_date_qual         string,
    claim_transaction_amount            double,
    --claim_transaction_amount_qual       string,
    --medical_claim_link_text             string,
    logical_delete_reason               string,
    --part_mth_alt                        string,
    --part_mth                            string,
    confinement_id                      string,
-- --
    load_row_id                         bigint,
    load_table_id                       string,
    p_hvid                              string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_medical_claims
SELECT
    src.hvid                                                AS hvid,
    NULLIF( TRIM(diagnosis_code), '')                       AS diagnosis_code,
    NULLIF( TRIM(procedure_code), '')                       AS procedure_code,
    NULLIF( TRIM(ndc_code), '')                             AS ndc_code,
    date_received                                           AS date_received,
    date_service                                            AS date_service,
    date_service_end                                        AS date_service_end,
    inst_date_admitted                                      AS inst_date_admitted,
    inst_date_discharged                                    AS inst_date_discharged,
    record_id                                               AS record_id,
    hv_enc_id                                               AS hv_enc_id,
    created                                                 AS created,
    data_vendor                                             AS data_vendor,
    NULLIF( TRIM(patient_gender), '')                       AS patient_gender,
    patient_age                                             AS patient_age,
    patient_year_of_birth                                   AS patient_year_of_birth,
    NULLIF( TRIM(patient_zip3), '')                         AS patient_zip3,
    NULLIF( TRIM(patient_state), '')                        AS patient_state,
    NULLIF( TRIM(claim_type), '')                           AS claim_type,
    NULLIF( TRIM(inst_discharge_status_std_id), '')         AS inst_discharge_status_std_id,
    NULLIF( TRIM(inst_type_of_bill_std_id), '')             AS inst_type_of_bill_std_id,
    inst_drg_std_id                                         AS inst_drg_std_id,
    NULLIF( TRIM(inst_drg_vendor_id), '')                   AS inst_drg_vendor_id,
    NULLIF( TRIM(inst_drg_vendor_desc), '')                 AS inst_drg_vendor_desc,
    NULLIF( TRIM(place_of_service_std_id), '')              AS place_of_service_std_id,
    NULLIF( TRIM(diagnosis_code_qual), '')                  AS diagnosis_code_qual,
    NULLIF( TRIM(diagnosis_priority), '')                   AS diagnosis_priority,
    admit_diagnosis_ind                                     AS admit_diagnosis_ind,
    NULLIF( TRIM(procedure_code_qual), '')                  AS procedure_code_qual,
    NULLIF( TRIM(procedure_modifier_1), '')                 AS procedure_modifier_1,
    NULLIF( TRIM(procedure_modifier_2), '')                 AS procedure_modifier_2,
    NULLIF( TRIM(procedure_modifier_3), '')                 AS procedure_modifier_3,
    NULLIF( TRIM(procedure_modifier_4), '')                 AS procedure_modifier_4,
    NULLIF( TRIM(revenue_code), '')                         AS revenue_code,
    line_charge                                             AS line_charge,
    line_allowed                                            AS line_allowed,
    total_charge                                            AS total_charge,
    total_allowed                                           AS total_allowed,
    NULLIF( TRIM(prov_rendering_npi), '')                   AS prov_rendering_npi,
    NULLIF( TRIM(prov_billing_npi), '')                     AS prov_billing_npi,
    NULLIF( TRIM(prov_referring_npi), '')                   AS prov_referring_npi,
    NULLIF( TRIM(prov_facility_npi), '')                    AS prov_facility_npi,
    NULLIF( TRIM(prov_rendering_vendor_id), '')             AS prov_rendering_vendor_id,
    NULLIF( TRIM(prov_rendering_dea_id), '')                AS prov_rendering_dea_id,
    NULLIF( TRIM(prov_rendering_vendor_specialty), '')      AS prov_rendering_vendor_specialty,
    NULLIF( TRIM(prov_billing_vendor_id), '')               AS prov_billing_vendor_id,
    NULLIF( TRIM(prov_billing_dea_id), '')                  AS prov_billing_dea_id,
    NULLIF( TRIM(prov_billing_vendor_specialty), '')        AS prov_billing_vendor_specialty,
    NULLIF( TRIM(prov_referring_vendor_id), '')             AS prov_referring_vendor_id,
    NULLIF( TRIM(prov_referring_dea_id), '')                AS prov_referring_dea_id,
    NULLIF( TRIM(prov_referring_vendor_specialty), '')      AS prov_referring_vendor_specialty,
    NULLIF( TRIM(prov_facility_name_1), '')                 AS prov_facility_name_1,
    NULLIF( TRIM(prov_facility_name_2), '')                 AS prov_facility_name_2,
    NULLIF( TRIM(prov_facility_address_1), '')              AS prov_facility_address_1,
    NULLIF( TRIM(prov_facility_address_2), '')              AS prov_facility_address_2,
    NULLIF( TRIM(prov_facility_city), '')                   AS prov_facility_city,
    NULLIF( TRIM(prov_facility_state), '')                  AS prov_facility_state,
    NULLIF( TRIM(prov_facility_zip), '')                    AS prov_facility_zip,
    claim_transaction_date                                  AS claim_transaction_date,
    CAST(NULLIF(TRIM(claim_transaction_amount), '') AS int) AS claim_transaction_amount,
    NULLIF( TRIM(logical_delete_reason), '')                AS logical_delete_reason,
    NULLIF( TRIM(confinement_id), '')                       AS confinement_id,
    -- --
    monotonically_increasing_id()                           AS load_row_id,
    '@medical_claims'                                       AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                               AS p_hvid
FROM
    @source_schema.@medical_claims src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
WHERE
    src.hvid IS NOT NULL
    AND src.logical_delete_reason IN ('INITIAL PAY CLAIM',
                                      'UNKNOWN',
                                      'ADJUSTMENT TO ORIGINAL CLAIM',
                                      'DENIED CLAIMS',
                                      'REVERSAL TO ORIGINAL CLAIM',
                                      'PENDED FOR ADJUDICATION')
;

OPTIMIZE @target_schema.src_medical_claims ZORDER BY (
    hvid,
    diagnosis_code,
    procedure_code,
    ndc_code
);

-- -------------------------------------------------------------------
-- medical_claims_closed_cut
-- -------------------------------------------------------------------
/*
DROP TABLE IF EXISTS @target_schema.src_medical_claims_closed_cut;
CREATE TABLE @target_schema.src_medical_claims_closed_cut
(
    hv_enc_id                   string,
    hvid                        string,
    data_vendor                 string,
    patient_gender              string,
    patient_year_of_birth       string,
    patient_zip3                string,
    patient_state               string,
    claim_type                  string,
    date_service                date,
    date_service_end            date,
    place_of_service_std_id     string,
    inst_type_of_bill_std_id    string,
    diagnosis_code              string,
    procedure_code              string,
    total_charge                double,
    prov_rendering_npi          string,
    prov_billing_npi            string,
    confinement_id              string,
-- --
    load_row_id                 bigint,
    load_table_id               string,
    p_hvid                      string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_medical_claims_closed_cut
SELECT
    hv_enc_id                                       AS hv_enc_id,
    src.hvid                                        AS hvid,
    NULLIF(TRIM(data_vendor), '')                   AS data_vendor,
    NULLIF(TRIM(patient_gender), '')                AS patient_gender,
    patient_year_of_birth                           AS patient_year_of_birth,
    NULLIF(TRIM(patient_zip3), '')                  AS patient_zip3,
    NULLIF(TRIM(patient_state), '')                 AS patient_state,
    NULLIF(TRIM(claim_type), '')                    AS claim_type,
    date_service                                    AS date_service,
    date_service_end                                AS date_service_end,
    NULLIF(TRIM(place_of_service_std_id), '')       AS place_of_service_std_id,
    NULLIF(TRIM(inst_type_of_bill_std_id), '')      AS inst_type_of_bill_std_id,
    NULLIF(TRIM(diagnosis_code), '')                AS diagnosis_code,
    NULLIF(TRIM(procedure_code), '')                AS procedure_code,
    total_charge                                    AS total_charge,
    NULLIF(TRIM(prov_rendering_npi), '')            AS prov_rendering_npi,
    NULLIF(TRIM(prov_billing_npi), '')              AS prov_billing_npi,
    NULLIF(TRIM(confinement_id), '')                AS confinement_id,
    -- --
    monotonically_increasing_id()                   AS load_row_id,
    '@medical_claims_closed_cut'                    AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                       AS p_hvid
FROM
    @source_schema.@medical_claims_closed_cut src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
WHERE
    src.hvid IS NOT NULL
;

OPTIMIZE @target_schema.src_medical_claims_closed_cut ZORDER BY (
    hvid,
    diagnosis_code,
    procedure_code
);
*/
-- -------------------------------------------------------------------
-- pharmacy_claims
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_pharmacy_claims;
CREATE TABLE @target_schema.src_pharmacy_claims
(
    hvid                                        string,
    diagnosis_code                              string,
    procedure_code                              string,
    ndc_code                                    string,
    date_service                                date,
    date_written                                date,
    date_authorized                             date,
    discharge_date                              date,
    record_id                                   bigint,
    --claim_id                                    string,
    created                                     date,
    --model_version                               string,
    --data_set                                    string,
    --data_feed                                   string,
    --data_vendor                                 string,
    --source_version                              string,
    patient_gender                              string,
    patient_age                                 string,
    patient_year_of_birth                       string,
    patient_zip3                                string,
    patient_state                               string,
    --time_authorized                             string,
    --transaction_code_std                        string,
    --transaction_code_vendor                     string,
    --response_code_std                           string,
    --response_code_vendor                        string,
    --reject_reason_code_1                        string,
    --reject_reason_code_2                        string,
    --reject_reason_code_3                        string,
    --reject_reason_code_4                        string,
    --reject_reason_code_5                        string,
    diagnosis_code_qual                         string,
    --procedure_code_qual                         string,
    --product_service_id                          string,
    --product_service_id_qual                     string,
    --rx_number                                   string,
    --rx_number_qual                              string,
    --bin_number                                  string,
    --processor_control_number                    string,
    fill_number                                 int,
    refill_auth_amount                          string,
    dispensed_quantity                          double,
    unit_of_measure                             string,
    days_supply                                 int,
    pharmacy_npi                                string,
    --prov_dispensing_npi                         string,
    --payer_id                                    string,
    --payer_id_qual                               string,
    --payer_name                                  string,
    --payer_parent_name                           string,
    --payer_org_name                              string,
    --payer_plan_id                               string,
    --payer_plan_name                             string,
    --payer_type                                  string,
    --compound_code                               string,
    --unit_dose_indicator                         string,
    --dispensed_as_written                        string,
    --prescription_origin                         string,
    --submission_clarification                    string,
    --orig_prescribed_product_service_code        string,
    --orig_prescribed_product_service_code_qual   string,
    orig_prescribed_quantity                    string,
    --prior_auth_type_code                        string,
    --level_of_service                            string,
    --reason_for_service                          string,
    --professional_service_code                   string,
    --result_of_service_code                      string,
    --place_of_service_std_id                     string,
    --place_of_service_vendor_id                  string,
    prov_prescribing_npi                        string,
    --prov_prescribing_name_1                     string,
    --prov_prescribing_name_2                     string,
    --prov_prescribing_address_1                  string,
    --prov_prescribing_address_2                  string,
    --prov_prescribing_city                       string,
    --prov_prescribing_state                      string,
    --prov_prescribing_zip                        string,
    --prov_prescribing_std_taxonomy               string,
    prov_prescribing_vendor_specialty           string,
    --prov_primary_care_npi                       string,
    --cob_count                                   string,
    usual_and_customary_charge                  double,
    product_selection_attributed                double,
    other_payer_recognized                      double,
    periodic_deductible_applied                 double,
    periodic_benefit_exceed                     double,
    accumulated_deductible                      double,
    remaining_deductible                        double,
    remaining_benefit                           double,
    copay_coinsurance                           double,
    --basis_of_cost_determination                 string,
    submitted_ingredient_cost                   double,
    submitted_dispensing_fee                    double,
    submitted_incentive                         double,
    submitted_gross_due                         double,
    submitted_professional_service_fee          double,
    submitted_patient_pay                       double,
    --submitted_other_claimed_qual                string,
    submitted_other_claimed                     double,
    --basis_of_reimbursement_determination        string,
    paid_ingredient_cost                        double,
    paid_dispensing_fee                         double,
    paid_incentive                              double,
    paid_gross_due                              double,
    paid_professional_service_fee               double,
    paid_patient_pay                            double,
    paid_other_claimed_qual                     double,
    paid_other_claimed                          double,
    --tax_exempt_indicator                        string,
    --coupon_type                                 string,
    --coupon_number                               string,
    --coupon_value                                double,
    --pharmacy_other_id                           string,
    --pharmacy_other_qual                         string,
    --pharmacy_postal_code                        string,
    --prov_dispensing_id                          string,
    --prov_dispensing_qual                        string,
    prov_prescribing_id                         string,
    --prov_prescribing_qual                       string,
    --prov_primary_care_id                        string,
    --prov_primary_care_qual                      string,
    --other_payer_coverage_type                   string,
    --other_payer_coverage_id                     string,
    --other_payer_coverage_qual                   string,
    other_payer_date                            date,
    --other_payer_coverage_code                   string,
    logical_delete_reason                       string,
    --part_mth_alt                                string,
    --part_mth                                    string,
-- --
    load_row_id                                 bigint,
    load_table_id                               string,
    p_hvid                                      string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_pharmacy_claims
SELECT
    src.hvid                                                AS hvid,
    NULLIF( TRIM(diagnosis_code), '')                       AS diagnosis_code,
    NULLIF( TRIM(procedure_code), '')                       AS procedure_code,
    NULLIF( TRIM(ndc_code), '')                             AS ndc_code,
    date_service                                            AS date_service,
    date_written                                            AS date_written,
    date_authorized                                         AS date_authorized,
    NULL                                                    AS discharge_date,
    record_id                                               AS record_id,
    created                                                 AS created,
    NULLIF( TRIM(patient_gender), '')                       AS patient_gender,
    patient_age                                             AS patient_age,
    patient_year_of_birth                                   AS patient_year_of_birth,
    NULLIF( TRIM(patient_zip3), '')                         AS patient_zip3,
    NULLIF( TRIM(patient_state), '')                        AS patient_state,
    NULLIF( TRIM(diagnosis_code_qual), '')                  AS diagnosis_code_qual,
    fill_number                                             AS fill_number,
    NULLIF( TRIM(refill_auth_amount), '')                   AS refill_auth_amount,
    CAST(NULLIF(TRIM(dispensed_quantity), '') AS double)    AS dispensed_quantity,
    NULLIF( TRIM(unit_of_measure), '')                      AS unit_of_measure,
    CAST(NULLIF(TRIM(days_supply), '') AS int)              AS days_supply,
    NULLIF( TRIM(pharmacy_npi), '')                         AS pharmacy_npi,
    NULLIF( TRIM(orig_prescribed_quantity), '')             AS orig_prescribed_quantity,
    NULLIF( TRIM(prov_prescribing_npi), '')                 AS prov_prescribing_npi,
    NULLIF( TRIM(prov_prescribing_vendor_specialty), '')    AS prov_prescribing_vendor_specialty,
    usual_and_customary_charge                              AS usual_and_customary_charge,
    product_selection_attributed                            AS product_selection_attributed,
    other_payer_recognized                                  AS other_payer_recognized,
    periodic_deductible_applied                             AS periodic_deductible_applied,
    periodic_benefit_exceed                                 AS periodic_benefit_exceed,
    accumulated_deductible                                  AS accumulated_deductible,
    remaining_deductible                                    AS remaining_deductible,
    remaining_benefit                                       AS remaining_benefit,
    copay_coinsurance                                       AS copay_coinsurance,
    submitted_ingredient_cost                               AS submitted_ingredient_cost,
    submitted_dispensing_fee                                AS submitted_dispensing_fee,
    submitted_incentive                                     AS submitted_incentive,
    submitted_gross_due                                     AS submitted_gross_due,
    submitted_professional_service_fee                      AS submitted_professional_service_fee,
    submitted_patient_pay                                   AS submitted_patient_pay,
    submitted_other_claimed                                 AS submitted_other_claimed,
    paid_ingredient_cost                                    AS paid_ingredient_cost,
    paid_dispensing_fee                                     AS paid_dispensing_fee,
    paid_incentive                                          AS paid_incentive,
    paid_gross_due                                          AS paid_gross_due,
    paid_professional_service_fee                           AS paid_professional_service_fee,
    paid_patient_pay                                        AS paid_patient_pay,
    paid_other_claimed_qual                                 AS paid_other_claimed_qual,
    paid_other_claimed                                      AS paid_other_claimed,
    prov_prescribing_id                                     AS prov_prescribing_id,
    other_payer_date                                        AS other_payer_date,
    NULLIF( TRIM(logical_delete_reason), '')                AS logical_delete_reason,
    -- --
    monotonically_increasing_id()                           AS load_row_id,
    '@pharmacy_claims'                                      AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                               AS p_hvid
FROM
    @source_schema.@pharmacy_claims src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
WHERE
    src.hvid IS NOT NULL
    AND (
            src.logical_delete_reason != 'Pending'
            OR 
            NULLIF(TRIM(src.logical_delete_reason), '') IS NULL
        )
;

OPTIMIZE @target_schema.src_pharmacy_claims ZORDER BY (
    hvid,
    diagnosis_code,
    procedure_code,
    ndc_code
);

-- -------------------------------------------------------------------
-- pharmacy_claims_closed_cut
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_pharmacy_claims_closed_cut;
CREATE TABLE @target_schema.src_pharmacy_claims_closed_cut
(
    claim_id                    string,
    hvid                        string,
    data_vendor                 string,
    patient_gender              string,
    patient_year_of_birth       string,
    patient_zip3                string,
    patient_state               string,
    date_service                date,
    days_supply                 integer,
    dispensed_quantity          double,
    ndc_code                    string,
    pharmacy_npi                string,
    prov_prescribing_npi        string,
    submitted_gross_due         double,
    paid_gross_due              double,
-- --
    load_row_id                 bigint,
    load_table_id               string,
    p_hvid                      string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_pharmacy_claims_closed_cut
SELECT
    claim_id                                                AS claim_id,
    src.hvid                                                AS hvid,
    NULLIF(TRIM(data_vendor), '')                           AS data_vendor,
    NULLIF(TRIM(patient_gender), '')                        AS patient_gender,
    patient_year_of_birth                                   AS patient_year_of_birth,
    NULLIF(TRIM(patient_zip3), '')                          AS patient_zip3,
    NULLIF(TRIM(patient_state), '')                         AS patient_state,
    date_service                                            AS date_service,
    CAST(NULLIF(TRIM(days_supply), '') AS INTEGER)          AS days_supply,
    CAST(NULLIF(TRIM(dispensed_quantity), '') AS DOUBLE)    AS dispensed_quantity,
    NULLIF(TRIM(ndc_code), '')                              AS ndc_code,
    NULLIF(TRIM(pharmacy_npi), '')                          AS pharmacy_npi,
    NULLIF(TRIM(prov_prescribing_npi), '')                  AS prov_prescribing_npi,
    submitted_gross_due                                     AS submitted_gross_due,
    paid_gross_due                                          AS paid_gross_due,
    -- --
    monotonically_increasing_id()                           AS load_row_id,
    '@pharmacy_claims_closed_cut'                           AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                               AS p_hvid
FROM
    @source_schema.@pharmacy_claims_closed_cut src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
WHERE
    src.hvid IS NOT NULL
;

OPTIMIZE @target_schema.src_pharmacy_claims_closed_cut ZORDER BY (
    hvid,
    ndc_code
);

-- -------------------------------------------------------------------
-- patient_race
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_patient_race;
CREATE TABLE @target_schema.src_patient_race
(
    hvid                                string,
    race                                string,
-- --
    load_row_id                         bigint,
    load_table_id                       string,
    p_hvid                              string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_patient_race
SELECT
    src.hvid                            AS hvid,
    race                                AS race,
    -- --
    monotonically_increasing_id()       AS load_row_id,
    '@patient_race'                     AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)           AS p_hvid
FROM
    @source_schema.@patient_race src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
;

OPTIMIZE @target_schema.src_patient_race ZORDER BY (
    hvid
);

-- -------------------------------------------------------------------
-- gilead_cdm_mc_confinement
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_gilead_cdm_mc_confinement;
CREATE TABLE @target_schema.src_gilead_cdm_mc_confinement
(
    hvid                    string,
    confinement_id          string,
    --linking_id              string,
    --linking_id_source       string,
    --data_vendor             string,
    date_start              date,
    date_end                date,
-- --
    load_row_id             bigint,
    load_table_id           string,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_gilead_cdm_mc_confinement
SELECT
    src.hvid                                    AS hvid,
    NULLIF(TRIM(confinement_id), '')            AS confinement_id,
    --NULLIF(TRIM(linking_id), '')                AS linking_id,
    --NULLIF(TRIM(linking_id_source), '')         AS linking_id_source,
    --NULLIF(TRIM(data_vendor), '')               AS data_vendor, 
    CAST(NULLIF(TRIM(date_start), '') AS DATE)  AS date_start,
    CAST(NULLIF(TRIM(date_end), '') AS DATE)    AS date_end,
    -- --
    monotonically_increasing_id()               AS load_row_id,
    '@gilead_cdm_mc_confinement'                AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                   AS p_hvid
FROM
    @source_schema.@gilead_cdm_mc_confinement src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
;

OPTIMIZE @target_schema.src_gilead_cdm_mc_confinement ZORDER BY (
    hvid
);

-- -------------------------------------------------------------------
-- subscription_patient_master_list
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.src_subscription_patient_master_list;
CREATE TABLE @target_schema.src_subscription_patient_master_list
(
    hvid                        string,
    patient_yob_most_recent     string,
    patient_gender_most_recent  string,
-- --
    load_row_id                 bigint,
    load_table_id               string,
    p_hvid                      string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

INSERT INTO @target_schema.src_subscription_patient_master_list
SELECT
    src.hvid                                        AS hvid,
    NULLIF(TRIM(patient_yob_most_recent), '')       AS patient_yob_most_recent,
    NULLIF(TRIM(patient_gender_most_recent), '')    AS patient_gender_most_recent,
    -- --
    monotonically_increasing_id()                   AS load_row_id,
    '@subscription_patient_master_list'             AS load_table_id,
    SUBSTRING(src.hvid, 1, 1)                       AS p_hvid
FROM
    @source_schema.@subscription_patient_master_list src
--@IF @create_sample = +
INNER JOIN
    @target_schema.tmp_patient_subset sub
        ON src.hvid = sub.hvid
--@ENDIF
;

OPTIMIZE @target_schema.src_subscription_patient_master_list ZORDER BY (
    hvid,
    patient_yob_most_recent,
    patient_gender_most_recent
);

-- -------------------------------------------------------------------
-- DROP TABLE IF EXISTS @target_schema.tmp_samp_patient;
-- DROP TABLE IF EXISTS @target_schema.tmp_patient_subset;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
