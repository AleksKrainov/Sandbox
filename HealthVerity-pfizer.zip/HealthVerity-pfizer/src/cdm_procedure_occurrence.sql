-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: Procedure Occurrence
!*/

DROP TABLE IF EXISTS @target_schema.tmp_procedure;
CREATE TABLE @target_schema.tmp_procedure
(
    person_id               bigint,
    target_concept_id       int,
    event_start_date        timestamp,
    event_type_concept_id   int,
    modifier_concept_id     int,
    quantity                bigint,
    provider_id             bigint,
    visit_occurrence_id     bigint,
    event_source_value      string,
    source_concept_id       int,
    modifier_source_value   string,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
PARTITIONED BY (p_hvid)
;

-- -------------------------------------------------------------------
-- From lk_mapped_diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_procedure
    @source_table: @target_schema.lk_mapped_diag
    @summary: 
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_procedure
PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,
    lk.event_type_concept_id    AS event_type_concept_id,
    0                           AS modifier_concept_id,
    1                           AS quantity,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    NULL                        AS modifier_source_value,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_diag lk
WHERE
    lk.domain_id = 'Procedure'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- From lk_mapped_proc
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_procedure
    @source_table: @target_schema.lk_mapped_proc
    @summary: 
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_procedure
PARTITION (p_hvid)
SELECT
    lk.person_id                AS person_id,
    lk.event_concept_id         AS target_concept_id,
    lk.event_start_date         AS event_start_date,
    lk.event_type_concept_id    AS event_type_concept_id,
    lk.modifier_concept_id      AS modifier_concept_id,
    1                           AS quantity,
    lk.provider_id              AS provider_id,
    lk.visit_occurrence_id      AS visit_occurrence_id,
    lk.event_source_value       AS event_source_value,
    lk.event_source_concept_id  AS source_concept_id,
    lk.modifier_source_value    AS modifier_source_value,
-- --
    lk.rule_id                  AS rule_id,
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.lk_mapped_proc lk
WHERE
    lk.domain_id = 'Procedure'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_procedure_id;
CREATE TABLE @target_schema.tmp_procedure_id
@PROPERTY PARTITIONED BY (p_hvid) AS
SELECT
    monotonically_increasing_id()   AS procedure_occurrence_id,
    po.*
FROM
    @target_schema.tmp_procedure po
WHERE
    po.event_start_date BETWEEN CAST('@min_date_of_dataset' AS DATE)
                            AND CAST('@max_date_of_dataset' AS DATE)
;

-- -------------------------------------------------------------------
-- Load Table: Procedure_occurrence
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_procedure_occurrence;
/*!
    @insert
    @table: @target_schema.cdm_procedure_occurrence
    @source_table: @target_schema.tmp_procedure
    @summary: remove duplicates
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_procedure_occurrence
SELECT
    t.procedure_occurrence_id   AS procedure_occurrence_id,
    t.person_id                 AS person_id,
    t.target_concept_id         AS procedure_concept_id,
    t.event_start_date          AS procedure_date,
    NULL                        AS procedure_datetime,
    NULL                        AS procedure_end_date,
    NULL                        AS procedure_end_datetime,
    t.event_type_concept_id     AS procedure_type_concept_id,
    t.modifier_concept_id       AS modifier_concept_id,
    t.quantity                  AS quantity,
    t.provider_id               AS provider_id,
    t.visit_occurrence_id       AS visit_occurrence_id,
    NULL                        AS visit_detail_id,
    t.event_source_value        AS procedure_source_value,
    t.source_concept_id         AS procedure_source_concept_id,
    t.modifier_source_value     AS modifier_source_value,
-- --
    t.p_hvid                    AS p_hvid,
    t.rule_id                   AS rule_id,
    t.load_table_id             AS load_table_id,
    t.load_row_id               AS load_row_id
FROM
    @target_schema.tmp_procedure_id t
WHERE
    t.p_hvid = '@hvid_char'
--@FOR_END
;

OPTIMIZE @target_schema.cdm_procedure_occurrence ZORDER BY (
    person_id,
    procedure_concept_id,
    procedure_date,
    procedure_source_value
);

-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_procedure;
DROP TABLE IF EXISTS @target_schema.tmp_procedure_id;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/
