# Databricks notebook source
# MAGIC %sh
# MAGIC pip install --upgrade --no-index --no-cache-dir /Workspace/Shared/OMOP/cdmkit/cdmkit-1.7.0.dev0-py2.py3-none-any.whl

# COMMAND ----------

import os
CDMKIT_HOME = "/Workspace/Shared/OMOP/cdmkit"
PROJECTS_HOME = "/Workspace/Shared/OMOP/projects"
os.environ["CDMKIT_HOME"] = CDMKIT_HOME
os.environ["CDMKIT_PROJECTS_HOME"] = PROJECTS_HOME

# COMMAND ----------

#from cdmkit import run
#run('cdmkit run_workflow hv_closed_claims.stage --notebook-run --reset'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit srcstats hv_closed_claims.stage --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit load hv_closed_claims.dev --notebook-run --create-schema=no'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit custom_voc hv_closed_claims.dev --notebook-run --empty-old --ignore-level=error'.split())
#run('cdmkit custom_voc hv_closed_claims.dev --notebook-run --ignore-level=error'.split())

# COMMAND ----------

#from cdmkit import run
#run("cdmkit ddl hv_closed_claims.dev --notebook-run".split())

# COMMAND ----------

from cdmkit import run
#run('cdmkit run_workflow hv_closed_claims.dev --notebook-run --reset'.split())
run('cdmkit run_workflow hv_closed_claims.dev --notebook-run --start cdm_visit_detail.sql --reset'.split())

# COMMAND ----------

from cdmkit import run 
run('cdmkit cdmstats hv_closed_claims.dev --notebook-run'.split())

# COMMAND ----------

from cdmkit import run
run('cdmkit verify hv_closed_claims.dev --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit qa hv_closed_claims.dev --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit unload hv_closed_claims.dev --notebook-run'.split())