# Databricks notebook source
# MAGIC %sh
# MAGIC pip install --upgrade --no-index --no-cache-dir /Workspace/Shared/OMOP/cdmkit/cdmkit-1.7.0.dev0-py2.py3-none-any.whl

# COMMAND ----------

import os
CDMKIT_HOME = "/Workspace/Shared/OMOP/cdmkit"
PROJECTS_HOME = "/Workspace/Shared/OMOP/projects"
os.environ["CDMKIT_HOME"] = CDMKIT_HOME
os.environ["CDMKIT_PROJECTS_HOME"] = PROJECTS_HOME

# COMMAND ----------

#from cdmkit import run
#run('cdmkit run_workflow hv_closed_claims.stage_sample --notebook-run --reset'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit srcstats hv_closed_claims.stage_sample --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit load hv_closed_claims.dev_sample --notebook-run --create-schema=no'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit custom_voc hv_closed_claims.dev_sample --notebook-run --empty-old --ignore-level=error'.split())
#run('cdmkit custom_voc hv_closed_claims.dev_sample --notebook-run --ignore-level=error'.split())

# COMMAND ----------

#from cdmkit import run
#run("cdmkit ddl hv_closed_claims.dev_sample --notebook-run".split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit run_workflow hv_closed_claims.dev_sample --notebook-run --reset'.split())
#run('cdmkit run_workflow hv_closed_claims.dev_sample --notebook-run --start cdm_visit_detail.sql --stop lk_visits_6_others.sql --reset'.split())
#run('cdmkit run_workflow hv_closed_claims.dev_sample --notebook-run --scripts cdm_visit_occurrence.sql --reset'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit cdmstats hv_closed_claims.dev_sample --notebook-run'.split())

# COMMAND ----------

from cdmkit import run
run('cdmkit verify hv_closed_claims.dev_sample --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run 
#run('cdmkit qa hv_closed_claims.dev_sample --notebook-run'.split())

# COMMAND ----------

#from cdmkit import run
#run('cdmkit unload hv_closed_claims.dev_sample --notebook-run'.split())