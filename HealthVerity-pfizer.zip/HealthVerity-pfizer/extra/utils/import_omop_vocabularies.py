# Databricks notebook source
import csv
import os
from pyspark.sql import types as T, functions as F

# COMMAND ----------

# Databricks notebook source
dbutils.widgets.text('athena_download_link', '', label='OHDSI Athena download URL')
dbutils.widgets.text('umls_apikey', '', label='UMLS API key')

# COMMAND ----------

os.environ['ATHENA_DOWNLOAD_LINK'] = dbutils.widgets.get('athena_download_link')
os.environ['UMLS_APIKEY'] = dbutils.widgets.get('umls_apikey')

# COMMAND ----------

ATHENA_SOURCE_DIR = "dbfs:/FileStore/omop_vocabularies/"
OMOP_VOC_ROOT_DIR = "dbfs:/user/hive/warehouse/"
OMOP_VOC_PREFIX = "omop_voc"

# COMMAND ----------

# MAGIC %sh
# MAGIC TMPZIP=`mktemp`
# MAGIC wget -q -O $TMPZIP $ATHENA_DOWNLOAD_LINK \
# MAGIC && unzip -d /tmp/omop_voc_stage $TMPZIP \
# MAGIC && rm $TMPZIP

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /tmp/omop_voc_stage/
# MAGIC java -Dumls-apikey=$UMLS_APIKEY -jar cpt4.jar 5

# COMMAND ----------

with open("/tmp/omop_voc_stage/VOCABULARY.csv", "r") as voc_f:
    fmt = csv.Sniffer().sniff(voc_f.read(2048), delimiters="\t,")
    voc_f.seek(0)
    reader = csv.DictReader(voc_f, dialect=fmt)
    voc_version_raw = next((r for r in reader if r['vocabulary_id'] == 'None')).get('vocabulary_version')  # example: 'v5.0 29-FEB-24' 
    voc_version_short = voc_version_raw[-9:].replace("-", "").lower()  # example: '29feb24'
    print(f'Vocabulary version: {voc_version_raw} (truncated to {voc_version_short})')

# COMMAND ----------

# Create DBFS dir for long-term storage
voc_schema = OMOP_VOC_PREFIX + "_" + voc_version_short
source_dir = ATHENA_SOURCE_DIR + OMOP_VOC_PREFIX + '_' + voc_version_short 
voc_dir = OMOP_VOC_ROOT_DIR + OMOP_VOC_PREFIX + '_' + voc_version_short

# COMMAND ----------

# Spark cannot read from local FS directly, have to go through DBFS
dbutils.fs.mv("file:/tmp/omop_voc_stage/", source_dir, recurse=True)

# COMMAND ----------

VOCS = {
    "concept": {
        "fpath": "CONCEPT.csv",
        "fields": [
            {"field": "concept_id", "type": "integer"},
            {"field": "concept_name", "type": "string"},
            {"field": "domain_id", "type": "string"},
            {"field": "vocabulary_id", "type": "string"},
            {"field": "concept_class_id", "type": "string"},
            {"field": "standard_concept", "type": "string"},
            {"field": "concept_code", "type": "string"},
            {"field": "valid_start_date", "type": "timestamp"},
            {"field": "valid_end_date", "type": "timestamp"},
            {"field": "invalid_reason", "type": "string"}
        ]
    },
    "concept_ancestor": {
        "fpath": "CONCEPT_ANCESTOR.csv",
        "fields": [
            {"field": "ancestor_concept_id", "type": "integer"},
            {"field": "descendant_concept_id", "type": "integer"},
            {"field": "min_levels_of_separation", "type": "integer"},
            {"field": "max_levels_of_separation", "type": "integer"}
        ]
    },
    "concept_class": {
        "fpath": "CONCEPT_CLASS.csv",
        "fields": [
            {"field": "concept_class_id", "type": "string"},
            {"field": "concept_class_name", "type": "string"},
            {"field": "concept_class_concept_id", "type": "integer"}
        ]
    },
    "concept_relationship": {
        "fpath": "CONCEPT_RELATIONSHIP.csv",
        "fields": [
            {"field": "concept_id_1", "type": "integer"},
            {"field": "concept_id_2", "type": "integer"},
            {"field": "relationship_id", "type": "string"},
            {"field": "valid_start_date", "type": "timestamp"},
            {"field": "valid_end_date", "type": "timestamp"},
            {"field": "invalid_reason", "type": "string"}
        ]
    },
    "concept_synonym": {
        "fpath": "CONCEPT_SYNONYM.csv",
        "fields": [
            {"field": "concept_id", "type": "integer"},
            {"field": "concept_synonym_name", "type": "string"},
            {"field": "language_concept_id", "type": "integer"}
        ]
    },
    "domain": {
        "fpath": "DOMAIN.csv",
        "fields": [
            {"field": "domain_id", "type": "string"},
            {"field": "domain_name", "type": "string"},
            {"field": "domain_concept_id", "type": "integer"}
        ]
    },
    "drug_strength": {
        "fpath": "DRUG_STRENGTH.csv",
        "fields": [
            {"field": "drug_concept_id", "type": "integer"},
            {"field": "ingredient_concept_id", "type": "integer"},
            {"field": "amount_value", "type": "double"},
            {"field": "amount_unit_concept_id", "type": "integer"},
            {"field": "numerator_value", "type": "double"},
            {"field": "numerator_unit_concept_id", "type": "integer"},
            {"field": "denominator_value", "type": "double"},
            {"field": "denominator_unit_concept_id", "type": "integer"},
            {"field": "box_size", "type": "integer"},
            {"field": "valid_start_date", "type": "timestamp"},
            {"field": "valid_end_date", "type": "timestamp"},
            {"field": "invalid_reason", "type": "string"}
        ]
    },
    "relationship": {
        "fpath": "RELATIONSHIP.csv",
        "fields": [
            {"field": "relationship_id", "type": "string"},
            {"field": "relationship_name", "type": "string"},
            {"field": "is_hierarchical", "type": "string"},
            {"field": "defines_ancestry", "type": "string"},
            {"field": "reverse_relationship_id", "type": "string"},
            {"field": "relationship_concept_id", "type": "integer"}
        ]
    },
    "vocabulary": {
        "fpath": "VOCABULARY.csv",
        "fields": [
            {"field": "vocabulary_id", "type": "string"},
            {"field": "vocabulary_name", "type": "string"},
            {"field": "vocabulary_reference", "type": "string"},
            {"field": "vocabulary_version", "type": "string"},
            {"field": "vocabulary_concept_id", "type": "integer"}
        ]
    }
}

# COMMAND ----------

import os
from pyspark.sql import types as T, functions as F

def get_voc_version(voc_df):
    voc_version_raw = voc_df.filter("vocabulary_id = 'None'").select("vocabulary_version").head()[0]
    # from 'v5.0 29-FEB-24' --> '29feb24'
    voc_version_short = voc_version_raw[-9:].replace("-", "").lower()
    return voc_version_short

def get_structure(fields):
    structure = T.StructType()
    for f in fields:
        structure.add(f['field'], data_type=f['type'])
    return structure

def load_csv(fpath, structure, sep='\t'):
    print("Loading file '{}'...".format(fpath))
    df = spark.read.format("csv") \
                   .options(sep=sep, timestampFormat="yyyyMMdd", dateFormat="yyyyMMdd", header=True) \
                   .load(path=fpath, schema=structure, mode="FAILFAST")
    print("Loaded.")
    return df

def save_parquet(table_df, name, voc_dir, voc_schema):
    full_table_name = ".".join([voc_schema, "voc_" + name])
    prq_path = os.path.join(voc_dir, "voc_" + name)
    print("Saving external table '{}' to '{}'...".format(full_table_name, prq_path))
    table_df.write.parquet(prq_path, mode="overwrite", compression="snappy")
    spark.catalog.createTable(full_table_name, path=prq_path, source='parquet', schema=table_df.schema)
    print("Table '{}' saved successfully.\n".format(full_table_name))

# COMMAND ----------

if spark.catalog._jcatalog.databaseExists(voc_schema):
    existing_version = get_voc_version(spark.table(f"{voc_schema}.vocabulary"))
    if existing_version != voc_version_short:
        spark.sql(f"DROP DATABASE {voc_schema} CASCADE")
        print(f"Dropped previously created schema '{voc_schema}'")
    else:
        print(f"Schema '{voc_schema}' already exists and contains the same data. Skipping vocabulary load.")

if spark.catalog._jcatalog.databaseExists(voc_schema) is False:
    spark.sql(f"CREATE DATABASE {voc_schema} LOCATION '{voc_dir}'")
    print(f"Created schema '{voc_schema}'\n")
    for table, conf in VOCS.items():
        csv_df = load_csv(os.path.join(source_dir, conf["fpath"]), get_structure(conf["fields"]))
        save_parquet(csv_df, table, voc_dir, voc_schema)