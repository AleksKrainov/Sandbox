-- Databricks notebook source
DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.cdm_diag;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.cdm_diag
(
    row_id bigint,
    hv_diag_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_diag_id string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_start_dt date,
    enc_end_dt date,
    diag_cd string,
    diag_cd_qual string,
    diag_prty_cd string,
    admtg_diag_flg string,
    prmy_diag_flg string,
    diag_grp_txt string,
    data_src_cd string,
    prmy_src_tbl_nm string,
    prsnt_on_admsn_cd string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/cdm_diag';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.cdm_diag;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.cdm_enc;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.cdm_enc
(
    row_id bigint,
    hv_enc_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_enc_id string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    enc_start_dt date,
    enc_end_dt date,
    enc_fclty_id string,
    enc_fclty_id_qual string,
    enc_fclty_state_cd string,
    enc_fclty_zip_cd string,
    enc_fclty_geo_txt string,
    enc_fclty_grp_txt string,
    enc_prov_id string,
    enc_prov_id_qual string,
    enc_grp_txt string,
    los_day_cnt string,
    los_txt string,
    admsn_src_std_cd string,
    admsn_src_vdr_cd string,
    admsn_src_vdr_cd_qual string,
    admsn_typ_std_cd string,
    admsn_typ_vdr_cd string,
    admsn_typ_vdr_cd_qual string,
    dischg_stat_std_cd string,
    dischg_stat_vdr_cd string,
    dischg_stat_vdr_cd_qual string,
    bill_typ_std_cd string,
    bill_typ_vdr_cd string,
    bill_typ_vdr_cd_qual string,
    drg_cd string,
    drg_cd_qual string,
    tot_chg_amt float,
    tot_actl_pymt_amt float,
    tot_expctd_pymt_amt float,
    tot_disc_amt float,
    tot_ptnt_liabty_amt float,
    tot_ptnt_pymt_amt float,
    tot_bal_amt float,
    tot_eob_wrtoff_amt float,
    tot_cntrctl_adjmt_amt float,
    tot_other_adjmt_amt float,
    tot_other_pymt_amt float,
    tot_denied_amt float,
    tot_ptnt_cpy_amt float,
    tot_ptnt_ddctbl_amt float,
    tot_secdy_payr_pymt_amt float,
    tot_recalcd_cost_amt float,
    tot_recalcd_cost_amt_qual string,
    payr_grp_txt string,
    data_src_cd string,
    prmy_src_tbl_nm string,
    confinement_ID string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/cdm_enc';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.cdm_enc;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.cdm_enc_dtl;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.cdm_enc_dtl
(
    row_id bigint,
    hv_enc_dtl_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_enc_dtl_id string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_start_dt date,
    enc_end_dt date,
    proc_dt date,
    chg_dt date,
    proc_cd string,
    proc_cd_qual string,
    proc_cd_1_modfr string,
    proc_cd_2_modfr string,
    proc_cd_3_modfr string,
    proc_cd_4_modfr string,
    proc_seq_cd string,
    proc_ndc string,
    proc_unit_qty string,
    proc_uom string,
    proc_grp_txt string,
    medctn_ndc string,
    medctn_molcl_nm string,
    medctn_qty string,
    dtl_chg_amt float,
    chg_meth_desc string,
    cdm_grp_txt string,
    cdm_convsn_txt string,
    cdm_dept_txt string,
    std_cdm_grp_txt string,
    vdr_chg_desc string,
    std_chg_desc string,
    cdm_manfctr_txt string,
    data_src_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/cdm_enc_dtl';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.cdm_enc_dtl;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_clin_obsn;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_clin_obsn
(
    row_id bigint,
    hv_clin_obsn_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_clin_obsn_id string,
    vdr_clin_obsn_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_clin_obsn_dt date,
    clin_obsn_dt date,
    clin_obsn_prov_id string,
    clin_obsn_prov_id_qual string,
    clin_obsn_prov_taxnmy_id string,
    clin_obsn_prov_taxnmy_id_qual string,
    clin_obsn_prov_speclty_id string,
    clin_obsn_prov_speclty_id_qual string,
    clin_obsn_prov_state_cd string,
    clin_obsn_prov_state_cd_qual string,
    clin_obsn_prov_zip_cd string,
    clin_obsn_prov_zip_cd_qual string,
    clin_obsn_onset_dt date,
    clin_obsn_resltn_dt date,
    clin_obsn_typ_cd string,
    clin_obsn_ndc string,
    clin_obsn_alt_cd string,
    clin_obsn_alt_cd_qual string,
    clin_obsn_diag_cd string,
    clin_obsn_diag_cd_qual string,
    clin_obsn_msrmt string,
    clin_obsn_uom string,
    clin_obsn_stat_cd string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_clin_obsn';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_clin_obsn;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_diag;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_diag
(
    row_id bigint,
    hv_diag_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_diag_id string,
    vdr_diag_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_diag_dt date,
    diag_dt date,
    diag_prov_id string,
    diag_prov_id_qual string,
    diag_prov_taxnmy_id string,
    diag_prov_taxnmy_id_qual string,
    diag_prov_speclty_id string,
    diag_prov_speclty_id_qual string,
    diag_prov_state_cd string,
    diag_prov_state_cd_qual string,
    diag_prov_zip_cd string,
    diag_prov_zip_cd_qual string,
    diag_onset_dt date,
    diag_resltn_dt date,
    diag_cd string,
    diag_cd_qual string,
    diag_nm string,
    diag_stat_cd string,
    diag_stat_cd_qual string,
    diag_stat_nm string,
    diag_stat_desc string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_diag';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_diag;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_enc;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_enc
(
    row_id bigint,
    hv_enc_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_enc_id string,
    vdr_enc_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_dt date,
    enc_start_dt date,
    enc_prov_id string,
    enc_prov_id_qual string,
    enc_prov_taxnmy_id string,
    enc_prov_taxnmy_id_qual string,
    enc_prov_speclty_id string,
    enc_prov_speclty_id_qual string,
    enc_prov_state_cd string,
    enc_prov_state_cd_qual string,
    enc_prov_zip_cd string,
    enc_prov_zip_cd_qual string,
    enc_typ_cd string,
    hv_enc_vst_flg string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_enc';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_enc;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_lab_test;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_lab_test
(
    row_id bigint,
    hv_lab_test_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_lab_ord_id string,
    vdr_lab_ord_id_qual string,
    vdr_lab_test_id string,
    vdr_lab_test_id_qual string,
    vdr_lab_result_id string,
    vdr_lab_result_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_xref_lab_ord_id string,
    hv_lab_test_dt date,
    lab_ord_dt date,
    lab_test_smpl_collctn_dt date,
    lab_test_schedd_dt date,
    lab_test_execd_dt date,
    lab_result_dt date,
    lab_test_prov_id string,
    lab_test_prov_id_qual string,
    lab_test_prov_taxnmy_id string,
    lab_test_prov_taxnmy_id_qual string,
    lab_test_prov_speclty_id string,
    lab_test_prov_speclty_id_qual string,
    lab_test_prov_state_cd string,
    lab_test_prov_state_cd_qual string,
    lab_test_prov_zip_cd string,
    lab_test_prov_zip_cd_qual string,
    lab_test_fstg_stat_flg string,
    lab_test_nm string,
    lab_test_loinc_cd string,
    lab_test_vdr_id string,
    lab_result_nm string,
    lab_result_msrmt string,
    lab_result_uom string,
    lab_result_abnorm_flg string,
    lab_result_ref_rng_txt string,
    lab_ord_stat_cd string,
    lab_ord_stat_cd_qual string,
    lab_test_stat_cd string,
    lab_test_stat_cd_qual string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_lab_test';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_lab_test;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_medctn;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_medctn
(
    row_id bigint,
    hv_medctn_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_medctn_ord_id string,
    vdr_medctn_ord_id_qual string,
    vdr_medctn_admin_id string,
    vdr_medctn_admin_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_medctn_dt date,
    medctn_ord_dt date,
    medctn_admin_dt date,
    medctn_prov_id string,
    medctn_prov_id_qual string,
    medctn_prov_taxnmy_id string,
    medctn_prov_taxnmy_id_qual string,
    medctn_prov_speclty_id string,
    medctn_prov_speclty_id_qual string,
    medctn_prov_state_cd string,
    medctn_prov_state_cd_qual string,
    medctn_prov_zip_cd string,
    medctn_prov_zip_cd_qual string,
    medctn_start_dt date,
    medctn_end_dt date,
    medctn_ord_durtn_day_cnt int,
    medctn_ord_stat_dt date,
    medctn_ord_stat_cd string,
    medctn_diag_cd string,
    medctn_diag_cd_qual string,
    medctn_ndc string,
    medctn_alt_cd string,
    medctn_alt_cd_qual string,
    medctn_brd_nm string,
    medctn_genc_nm string,
    medctn_days_supply_cnt string,
    medctn_qty string,
    medctn_qty_qual string,
    medctn_admin_txt string,
    medctn_admin_sig_cd string,
    medctn_remng_rfll_qty string,
    medctn_last_rfll_dt date,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_medctn';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_medctn;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_proc;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_proc
(
    row_id bigint,
    hv_proc_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_proc_id string,
    vdr_proc_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_proc_dt date,
    proc_dt date,
    proc_prov_id string,
    proc_prov_id_qual string,
    proc_prov_taxnmy_id string,
    proc_prov_taxnmy_id_qual string,
    proc_prov_speclty_id string,
    proc_prov_speclty_id_qual string,
    proc_prov_state_cd string,
    proc_prov_state_cd_qual string,
    proc_prov_zip_cd string,
    proc_prov_zip_cd_qual string,
    proc_cd string,
    proc_cd_qual string,
    proc_cd_1_modfr string,
    proc_cd_2_modfr string,
    proc_cd_3_modfr string,
    proc_cd_4_modfr string,
    proc_cd_modfr_qual string,
    proc_ndc string,
    proc_unit_qty string,
    proc_uom string,
    proc_diag_cd string,
    proc_diag_cd_qual string,
    proc_typ_cd string,
    proc_stat_cd string,
    proc_admin_rte_cd string,
    proc_admin_site_cd string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_proc';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_proc;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.emr_prov_ord;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.emr_prov_ord
(
    row_id bigint,
    hv_prov_ord_id string,
    crt_dt date,
    mdl_vrsn_num string,
    data_set_nm string,
    src_vrsn_id string,
    hvm_vdr_id string,
    hvm_vdr_feed_id int,
    vdr_org_id string,
    vdr_prov_ord_id string,
    vdr_prov_ord_id_qual string,
    hvid string,
    ptnt_birth_yr int,
    ptnt_age_num string,
    ptnt_gender_cd string,
    ptnt_state_cd string,
    ptnt_zip3_cd string,
    hv_enc_id string,
    enc_dt date,
    hv_prov_ord_dt date,
    prov_ord_dt date,
    prov_ord_prov_id string,
    prov_ord_prov_id_qual string,
    prov_ord_prov_taxnmy_id string,
    prov_ord_prov_taxnmy_id_qual string,
    prov_ord_prov_speclty_id string,
    prov_ord_prov_speclty_id_qual string,
    prov_ord_prov_state_cd string,
    prov_ord_prov_state_cd_qual string,
    prov_ord_prov_zip_cd string,
    prov_ord_prov_zip_cd_qual string,
    prov_ord_typ_cd string,
    prov_ord_cd string,
    prov_ord_cd_qual string,
    prov_ord_nm string,
    prov_ord_alt_cd string,
    prov_ord_alt_cd_qual string,
    prov_ord_ndc string,
    prov_ord_diag_cd string,
    prov_ord_diag_cd_qual string,
    prov_ord_stat_cd string,
    prov_ord_stat_dt date,
    prov_ord_stat_rsn_cd string,
    data_src_cd string,
    data_captr_dt date,
    rec_stat_cd string,
    prmy_src_tbl_nm string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/emr_prov_ord';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.emr_prov_ord;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.enrollment;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.enrollment
(
    record_id bigint,
    hvid string,
    created date,
    model_version string,
    data_set string,
    data_feed string,
    data_vendor string,
    patient_age string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    patient_gender string,
    source_record_date date,
    date_start date,
    date_end date,
    benefit_type string,
    payer_type string,
    payer_grp_txt string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/enrollment';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.enrollment;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.gilead_cdm_mc_confinement;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.gilead_cdm_mc_confinement
(
    hvid string,
    confinement_ID string,
    linking_id string,
    linking_id_source string,
    data_vendor string,
    date_start date,
    date_end string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/gilead_cdm_mc_confinement';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.manifest;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.manifest
(
    table_name string,
    data_vendor string,
    row_count bigint,
    pat_count bigint,
    min_date string,
    max_date string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/manifest';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.medical_claims;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.medical_claims
(
    record_id bigint,
    claim_id string,
    hv_enc_id string,
    hvid string,
    created date,
    model_version string,
    data_set string,
    data_feed string,
    data_vendor string,
    source_version string,
    vendor_org_id string,
    patient_gender string,
    patient_age string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    claim_type string,
    date_received date,
    date_service date,
    date_service_end date,
    inst_date_admitted date,
    inst_date_discharged date,
    inst_admit_type_std_id string,
    inst_admit_type_vendor_id string,
    inst_admit_type_vendor_desc string,
    inst_admit_source_std_id string,
    inst_admit_source_vendor_id string,
    inst_admit_source_vendor_desc string,
    inst_discharge_status_std_id string,
    inst_discharge_status_vendor_id string,
    inst_discharge_status_vendor_desc string,
    inst_type_of_bill_std_id string,
    inst_type_of_bill_vendor_id string,
    inst_type_of_bill_vendor_desc string,
    inst_drg_std_id string,
    inst_drg_vendor_id string,
    inst_drg_vendor_desc string,
    place_of_service_std_id string,
    place_of_service_vendor_id string,
    place_of_service_vendor_desc string,
    service_line_number string,
    service_line_id string,
    diagnosis_code string,
    diagnosis_code_qual string,
    diagnosis_priority string,
    admit_diagnosis_ind string,
    procedure_code string,
    procedure_code_qual string,
    principal_proc_ind string,
    procedure_units_billed float,
    procedure_units_paid float,
    procedure_modifier_1 string,
    procedure_modifier_2 string,
    procedure_modifier_3 string,
    procedure_modifier_4 string,
    revenue_code string,
    ndc_code string,
    medical_coverage_type string,
    line_charge float,
    line_allowed float,
    total_charge float,
    total_allowed float,
    prov_rendering_npi string,
    prov_billing_npi string,
    prov_referring_npi string,
    prov_facility_npi string,
    payer_vendor_id string,
    payer_name string,
    payer_parent_name string,
    payer_org_name string,
    payer_plan_id string,
    payer_plan_name string,
    payer_type string,
    prov_rendering_vendor_id string,
    prov_rendering_tax_id string,
    prov_rendering_dea_id string,
    prov_rendering_ssn string,
    prov_rendering_state_license string,
    prov_rendering_upin string,
    prov_rendering_commercial_id string,
    prov_rendering_name_1 string,
    prov_rendering_name_2 string,
    prov_rendering_address_1 string,
    prov_rendering_address_2 string,
    prov_rendering_city string,
    prov_rendering_state string,
    prov_rendering_zip string,
    prov_rendering_std_taxonomy string,
    prov_rendering_vendor_specialty string,
    prov_billing_vendor_id string,
    prov_billing_tax_id string,
    prov_billing_dea_id string,
    prov_billing_ssn string,
    prov_billing_state_license string,
    prov_billing_upin string,
    prov_billing_commercial_id string,
    prov_billing_name_1 string,
    prov_billing_name_2 string,
    prov_billing_address_1 string,
    prov_billing_address_2 string,
    prov_billing_city string,
    prov_billing_state string,
    prov_billing_zip string,
    prov_billing_std_taxonomy string,
    prov_billing_vendor_specialty string,
    prov_referring_vendor_id string,
    prov_referring_tax_id string,
    prov_referring_dea_id string,
    prov_referring_ssn string,
    prov_referring_state_license string,
    prov_referring_upin string,
    prov_referring_commercial_id string,
    prov_referring_name_1 string,
    prov_referring_name_2 string,
    prov_referring_address_1 string,
    prov_referring_address_2 string,
    prov_referring_city string,
    prov_referring_state string,
    prov_referring_zip string,
    prov_referring_std_taxonomy string,
    prov_referring_vendor_specialty string,
    prov_facility_vendor_id string,
    prov_facility_tax_id string,
    prov_facility_dea_id string,
    prov_facility_ssn string,
    prov_facility_state_license string,
    prov_facility_upin string,
    prov_facility_commercial_id string,
    prov_facility_name_1 string,
    prov_facility_name_2 string,
    prov_facility_address_1 string,
    prov_facility_address_2 string,
    prov_facility_city string,
    prov_facility_state string,
    prov_facility_zip string,
    prov_facility_std_taxonomy string,
    prov_facility_vendor_specialty string,
    cob_payer_vendor_id_1 string,
    cob_payer_seq_code_1 string,
    cob_payer_hpid_1 string,
    cob_payer_claim_filing_ind_code_1 string,
    cob_ins_type_code_1 string,
    cob_payer_vendor_id_2 string,
    cob_payer_seq_code_2 string,
    cob_payer_hpid_2 string,
    cob_payer_claim_filing_ind_code_2 string,
    cob_ins_type_code_2 string,
    vendor_test_id string,
    vendor_test_name string,
    claim_transaction_date date,
    claim_transaction_date_qual string,
    claim_transaction_amount float,
    claim_transaction_amount_qual string,
    medical_claim_link_text string,
    logical_delete_reason string,
    confinement_ID string,
    part_mth_alt string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/medical_claims';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.medical_claims;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.medical_claims_closed_cut;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.medical_claims_closed_cut
(
    hv_enc_id string,
    hvid string,
    data_vendor string,
    patient_gender string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    claim_type string,
    date_service date,
    date_service_end date,
    place_of_service_std_id string,
    inst_type_of_bill_std_id string,
    diagnosis_code string,
    procedure_code string,
    total_charge float,
    prov_rendering_npi string,
    prov_billing_npi string,
    confinement_ID string
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/medical_claims_closed_cut';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.medical_claims_closed_cut;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.medical_claims_open_cut;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.medical_claims_open_cut
(
    claim_id string,
    hvid string,
    data_vendor string,
    patient_gender string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    claim_type string,
    date_service date,
    date_service_end date,
    place_of_service_std_id string,
    inst_type_of_bill_std_id string,
    diagnosis_code string,
    diagnosis_priority string,
    procedure_code string,
    service_line_number string,
    line_charge float,
    total_charge float,
    prov_rendering_npi string,
    prov_rendering_std_taxonomy string,
    prov_billing_npi string,
    prov_billing_std_taxonomy string,
    prov_referring_npi string,
    prov_referring_std_taxonomy string,
    prov_facility_npi string,
    prov_facility_std_taxonomy string,
    payer_name string,
    confinement_ID string    
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/medical_claims_open_cut';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.medical_claims_open_cut;


-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.patient_race;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.patient_race
(
    hvid string,
    race string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/patient_race';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.pharmacy_claims;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.pharmacy_claims
(
    record_id bigint,
    claim_id string,
    hvid string,
    created date,
    model_version string,
    data_set string,
    data_feed string,
    data_vendor string,
    source_version string,
    patient_gender string,
    patient_age string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    date_service date,
    date_written date,
    date_authorized date,
    time_authorized string,
    transaction_code_std string,
    transaction_code_vendor string,
    response_code_std string,
    response_code_vendor string,
    reject_reason_code_1 string,
    reject_reason_code_2 string,
    reject_reason_code_3 string,
    reject_reason_code_4 string,
    reject_reason_code_5 string,
    diagnosis_code string,
    diagnosis_code_qual string,
    procedure_code string,
    procedure_code_qual string,
    ndc_code string,
    product_service_id string,
    product_service_id_qual string,
    rx_number string,
    rx_number_qual string,
    bin_number string,
    processor_control_number string,
    fill_number int,
    refill_auth_amount string,
    dispensed_quantity double,
    unit_of_measure string,
    days_supply int,
    pharmacy_npi string,
    prov_dispensing_npi string,
    payer_id string,
    payer_id_qual string,
    payer_name string,
    payer_parent_name string,
    payer_org_name string,
    payer_plan_id string,
    payer_plan_name string,
    payer_type string,
    compound_code string,
    unit_dose_indicator string,
    dispensed_as_written string,
    prescription_origin string,
    submission_clarification string,
    orig_prescribed_product_service_code string,
    orig_prescribed_product_service_code_qual string,
    orig_prescribed_quantity string,
    prior_auth_type_code string,
    level_of_service string,
    reason_for_service string,
    professional_service_code string,
    result_of_service_code string,
    place_of_service_std_id string,
    place_of_service_vendor_id string,
    prov_prescribing_npi string,
    prov_prescribing_name_1 string,
    prov_prescribing_name_2 string,
    prov_prescribing_address_1 string,
    prov_prescribing_address_2 string,
    prov_prescribing_city string,
    prov_prescribing_state string,
    prov_prescribing_zip string,
    prov_prescribing_std_taxonomy string,
    prov_prescribing_vendor_specialty string,
    prov_primary_care_npi string,
    cob_count string,
    usual_and_customary_charge float,
    product_selection_attributed float,
    other_payer_recognized float,
    periodic_deductible_applied float,
    periodic_benefit_exceed float,
    accumulated_deductible float,
    remaining_deductible float,
    remaining_benefit float,
    copay_coinsurance float,
    basis_of_cost_determination string,
    submitted_ingredient_cost float,
    submitted_dispensing_fee float,
    submitted_incentive float,
    submitted_gross_due float,
    submitted_professional_service_fee float,
    submitted_patient_pay float,
    submitted_other_claimed_qual float,
    submitted_other_claimed float,
    basis_of_reimbursement_determination string,
    paid_ingredient_cost float,
    paid_dispensing_fee float,
    paid_incentive float,
    paid_gross_due float,
    paid_professional_service_fee float,
    paid_patient_pay float,
    paid_other_claimed_qual float,
    paid_other_claimed float,
    tax_exempt_indicator string,
    coupon_type string,
    coupon_number string,
    coupon_value float,
    pharmacy_other_id string,
    pharmacy_other_qual string,
    pharmacy_postal_code string,
    prov_dispensing_id string,
    prov_dispensing_qual string,
    prov_prescribing_id string,
    prov_prescribing_qual string,
    prov_primary_care_id string,
    prov_primary_care_qual string,
    other_payer_coverage_type string,
    other_payer_coverage_id string,
    other_payer_coverage_qual string,
    other_payer_date date,
    other_payer_coverage_code string,
    logical_delete_reason string,
    part_mth_alt string
)
USING PARQUET
--PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/pharmacy_claims';

--MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.pharmacy_claims;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.pharmacy_claims_closed_cut;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.pharmacy_claims_closed_cut
(
    claim_id string,
    hvid string,
    data_vendor string,
    patient_gender string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    date_service date,
    days_supply int,
    dispensed_quantity double,
    ndc_code string,
    pharmacy_npi string,
    prov_prescribing_npi string,
    submitted_gross_due float,
    paid_gross_due float
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/pharmacy_claims_closed_cut';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.pharmacy_claims_closed_cut;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.pharmacy_claims_open_cut;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.pharmacy_claims_open_cut
(
    claim_id string,
    hvid string,
    data_vendor string,
    patient_gender string,
    patient_year_of_birth string,
    patient_zip3 string,
    patient_state string,
    date_service date,
    days_supply int,
    dispensed_quantity double,
    ndc_code string,
    pharmacy_npi string,
    prov_prescribing_npi string,
    submitted_gross_due float,
    paid_gross_due float
)
USING PARQUET
PARTITIONED BY (part_mth string)
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/pharmacy_claims_open_cut';

MSCK REPAIR TABLE healthverity_marketplace_raw_20250331.pharmacy_claims_open_cut;

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_hcpcs;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_hcpcs
(
    hcpcs_code string,
    long_description string,
    short_description string,
    add_dt string,
    act_eff_dt string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_hcpcs';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_icd10_diagnosis;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_icd10_diagnosis
(
    code string,
    short_description string,
    long_description string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_icd10_diagnosis';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_icd10_procedure;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_icd10_procedure
(
    code string,
    short_description string,
    long_description string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_icd10_procedure';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_icd10_to_icd9_diagnosis;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_icd10_to_icd9_diagnosis
(
    icd10 string,
    icd9 string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_icd10_to_icd9_diagnosis';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_icd10_to_icd9_procedure;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_icd10_to_icd9_procedure
(
    icd10 string,
    icd9 string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_icd10_to_icd9_procedure';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_ndc;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_ndc
(
    ndc_code string,
    level1 string,
    level2 string,
    level3 string,
    level4 string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_ndc';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.ref_ndc_expanded;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.ref_ndc_expanded
(
    ndc_code string,
    generic_name string,
    brand_name string,
    route_of_admin string,
    dosage_form string,
    strength string,
    units_of_measure string,
    level1 string,
    level2 string,
    pharm_classes string
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/ref_ndc_expanded';

-- COMMAND ----------

DROP TABLE IF EXISTS healthverity_marketplace_raw_20250331.subscription_patient_master_list;

CREATE EXTERNAL TABLE healthverity_marketplace_raw_20250331.subscription_patient_master_list
(
    hvid string,
    synthetic_flag string,
    patient_gender_most_recent string,
    patient_gender_min_observed string,
    patient_gender_max_observed string,
    patient_yob_most_recent string,
    patient_yob_min_observed string,
    patient_yob_max_observed string,
    medical_claims_min_observed date,
    medical_claims_max_observed date,
    pharmacy_claims_min_observed date,
    pharmacy_claims_max_observed date,
    cdm_diag_min_observed date,
    cdm_diag_max_observed date,
    cdm_enc_min_observed date,
    cdm_enc_max_observed date,
    cdm_enc_dtl_min_observed date,
    cdm_enc_dtl_max_observed date,
    emr_clin_obsn_min_observed date,
    emr_clin_obsn_max_observed date,
    emr_diag_min_observed date,
    emr_diag_max_observed date,
    emr_enc_min_observed date,
    emr_enc_max_observed date,
    emr_lab_test_min_observed date,
    emr_lab_test_max_observed date,
    emr_medctn_min_observed date,
    emr_medctn_max_observed date,
    emr_proc_min_observed date,
    emr_proc_max_observed date,
    emr_prov_ord_min_observed date,
    emr_prov_ord_max_observed date,
    enrollment_min_observed date,
    enrollment_max_observed date
)
USING PARQUET
LOCATION 's3a://gdash-vendor-data-ingestion-prd/healthverity_marketplace_raw_20250331/2025/04/03/13.55/subscription_patient_master_list';

-- COMMAND ----------

-- Raw tables count verificztion

SELECT "enrollment"                       AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.enrollment
UNION ALL
SELECT "medical_claims"                   AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.medical_claims
UNION ALL
SELECT "medical_claims_closed_cut"        AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.medical_claims_closed_cut
UNION ALL
SELECT "pharmacy_claims"                  AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.pharmacy_claims
UNION ALL
SELECT "pharmacy_claims_closed_cut"       AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.pharmacy_claims_closed_cut
UNION ALL
SELECT "patient_race"                     AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.patient_race
UNION ALL
SELECT "gilead_cdm_mc_confinement"        AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.gilead_cdm_mc_confinement
UNION ALL
SELECT "subscription_patient_master_list" AS table_name, COUNT(*) AS cnt FROM healthverity_marketplace_raw_20250331.subscription_patient_master_list