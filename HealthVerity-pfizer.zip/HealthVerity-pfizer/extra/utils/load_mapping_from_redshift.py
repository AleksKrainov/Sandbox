# Databricks notebook source
# MAGIC %sql
# MAGIC create schema if not exists healthverity_marketplace_custom_mapping;

# COMMAND ----------

dbutils.fs.rm("s3a://gdash-databricks-dev-user-storage/healthverity_marketplace_custom_mapping/", True)

tables = {
    "hv_custom_mapping_aug2024_hv_provider",
    "hv_custom_mapping_aug2024_hv_payer",
    "hv_custom_mapping_aug2024_hv_benefit_type",
    "hv_custom_mapping_aug2024_prov22",
    "hv_custom_mapping_aug2024_hv_clin_obsn",
    "hv_custom_mapping_aug2024_hv_lab_test_results",
    "hv_custom_mapping_aug2024_hv_drug_route"
}

for t in tables:
    print("Loading table " + t + "...")

    drop_table = "drop table if exists healthverity_marketplace_custom_mapping." + t
    spark.sql(drop_table)

    df = spark.read \
            .format("com.databricks.spark.redshift") \
            .option("url", "jdbc:postgresql://gdash-p-usw2-dif-eks-redshift-cluster.ct4xaxb7ww1g.us-west-2.redshift.amazonaws.com:5439/redshiftdb?user="+"akraynov"+"&password="+"Ic9Hj0Ia1El9") \
            .option("query", "SELECT * FROM public." + t) \
            .option("tempdir", "s3a://gdash-databricks-dev-user-storage/healthverity_marketplace_custom_mapping/" + t) \
            .option("forward_spark_s3_credentials", "true") \
            .load()
    df.write.format("parquet").saveAsTable("healthverity_marketplace_custom_mapping." + t)