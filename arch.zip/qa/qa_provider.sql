--- table: cdm_provider
--- column: provider_source_value
--- rule_id: none
--- comment: checking that length of the provider_source_value is equal to 10
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_provider
WHERE
    LENGTH(provider_source_value) != 10
;