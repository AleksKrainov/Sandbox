-- -------------------------------------------------------------------
-- (c)2015-2024, Odysseus Data Services, Inc. All rights reserved
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

--- table: cdm_measurement
--- column: measurement_date
--- rule_id: all
--- comment: none
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_measurement
WHERE
    measurement_date NOT BETWEEN CAST('@min_date_of_dataset' AS DATE)
                             AND CAST('@max_date_of_dataset' AS DATE)
;