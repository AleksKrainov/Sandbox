---table: lk_event_diag
---column: none
---rule_id: medical_claims_closed_cut.diagnosis_code
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_diag
    WHERE
        rule_id = 'medical_claims_closed_cut.diagnosis_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_medical_claims_closed_cut src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_diag lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.diagnosis_code IS NOT NULL
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);

---table: lk_event_diag
---column: none
---rule_id: medical_claims.denied.diag
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_diag
    WHERE
        rule_id = 'medical_claims.denied.diag'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_medical_claims src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_diag lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.diagnosis_code IS NOT NULL
        AND src.logical_delete_reason = 'DENIED CLAIMS'
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);

---table: lk_event_diag
---column: none
---rule_id: medical_claims.reversed.diag
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_diag
    WHERE
        rule_id = 'medical_claims.reversed.diag'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_medical_claims src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_diag lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.diagnosis_code IS NOT NULL
        AND src.logical_delete_reason = 'REVERSAL TO ORIGINAL CLAIM'
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);

---table: lk_event_diag
---column: none
---rule_id: pharmacy_claims.diagnosis_code
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_diag
    WHERE
        rule_id = 'pharmacy_claims.diagnosis_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_pharmacy_claims src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_diag lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.diagnosis_code IS NOT NULL
        AND (src.logical_delete_reason != 'Pending'
             OR src.logical_delete_reason IS NULL)
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);