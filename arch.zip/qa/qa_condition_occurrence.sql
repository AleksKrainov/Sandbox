-- -------------------------------------------------------------------
-- (c)2015-2024, Odysseus Data Services, Inc. All rights reserved
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

--- table: cdm_condition_occurrence
--- column: condition_start_date, condition_end_date
--- rule_id: all
--- comment: none
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_condition_occurrence
WHERE
    condition_start_date NOT BETWEEN CAST('@min_date_of_dataset' AS DATE)
                                 AND CAST('@max_date_of_dataset' AS DATE)
    OR condition_end_date IS NOT NULL
;