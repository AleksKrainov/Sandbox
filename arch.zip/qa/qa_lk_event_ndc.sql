---table: lk_event_ndc
---column: none
---rule_id: pharmacy_claims_closed_cut.ndc_code
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_ndc
    WHERE
        rule_id = 'pharmacy_claims_closed_cut.ndc_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_pharmacy_claims_closed_cut src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_ndc lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.ndc_code IS NOT NULL
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);

---table: lk_event_ndc
---column: none
---rule_id: pharmacy_claims.rejected.ndc_code
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_ndc
    WHERE
        rule_id = 'pharmacy_claims.rejected.ndc_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_pharmacy_claims src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_ndc lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.ndc_code IS NOT NULL
        AND src.logical_delete_reason = 'Claim Rejected'
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);

---table: lk_event_ndc
---column: none
---rule_id: pharmacy_claims.reversed.ndc_code
---comment: count records
SELECT
(   SELECT
        COUNT(*)
    FROM
        @target_schema.lk_event_ndc
    WHERE
        rule_id = 'pharmacy_claims.reversed.ndc_code'
)
-
(
    SELECT
        COUNT(*)
    FROM
        @source_schema.src_pharmacy_claims src
    INNER JOIN
        @target_schema.cdm_person p
            ON p.person_source_value = src.hvid
    LEFT JOIN
        @target_schema.lk_event_ndc lk
            ON lk.load_row_id = p.load_row_id
    WHERE
        src.hvid IS NOT NULL
        AND src.ndc_code IS NOT NULL
        AND src.logical_delete_reason IN ('Reversal',
                                          'Reversed Claim',
                                          'Reversed',
                                          'REVERSAL',
                                          'REVERSED') 
        AND lk.load_row_id IS NULL
        AND src.p_hvid = 'c'
);