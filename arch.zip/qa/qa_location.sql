--- table: location
--- column: location_id
--- rule_id: pat_location
--- comment: count records
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.cdm_location
    WHERE
        rule_id = 'pat_location'
)
-
(
   SELECT
        COUNT(DISTINCT source_value)
   FROM
   (
        SELECT
            source_value        AS source_value,
            ROW_NUMBER()
                OVER(PARTITION BY hvid
                         ORDER BY created DESC)
                                AS rn
        FROM
        (
            SELECT
                hvid            AS hvid,
                created         AS created,
                TRIM(CONCAT_WS('|', COALESCE(patient_state, ''),
                                    COALESCE(patient_zip3, '')))
                                AS source_value
            FROM
                @source_schema.src_enrollment
            WHERE
                hvid IS NOT NULL
                AND patient_state IS NOT NULL
                AND patient_zip3 IS NOT NULL
                AND p_hvid = 'c'
            UNION
            SELECT
                hvid,
                created,
                TRIM(CONCAT_WS('|', COALESCE(patient_state, ''),
                                    COALESCE(patient_zip3, '')))
                                                    AS source_value
            FROM
                @source_schema.src_medical_claims
            WHERE
                hvid IS NOT NULL
                AND patient_year_of_birth IS NOT NULL
                AND patient_state IS NOT NULL
                AND patient_zip3 IS NOT NULL
                AND p_hvid = 'c'
            UNION
            SELECT
                hvid,
                created,
                TRIM(CONCAT_WS('|', COALESCE(patient_state, ''),
                                    COALESCE(patient_zip3, '')))
                                                    AS source_value
            FROM
                @source_schema.src_pharmacy_claims
            WHERE
                hvid IS NOT NULL
                AND patient_year_of_birth IS NOT NULL
                AND patient_state IS NOT NULL
                AND patient_zip3 IS NOT NULL
                AND p_hvid = 'c'
        ) t
    ) t
    WHERE
        rn = 1
);

--- table: location
--- column: location_id
--- rule_id: cs_location
--- comment: count records
SELECT
(
    SELECT
        COUNT(*)
    FROM
        @target_schema.cdm_location
    WHERE
        rule_id = 'cs_location'
)
-
(
   SELECT
        COUNT(*)
   FROM
   (
        SELECT
            source_value    AS source_value,
        ROW_NUMBER()
            OVER(PARTITION BY source_value
                 ORDER BY complete_flag DESC,
                                created DESC)
                            AS rn
        FROM
        (
            SELECT DISTINCT
                TRIM(CONCAT_WS('|', COALESCE(prov_facility_address_1, ''),
                                    COALESCE(prov_facility_address_2, ''),
                                    COALESCE(prov_facility_city, ''),
                                    COALESCE(prov_facility_state, ''),
                                    COALESCE(prov_facility_zip, '')))
                                        AS source_value,
                created                 AS created,
                (
                    IFF(prov_facility_address_1 IS NULL, 0, 1) +
                    IFF(prov_facility_address_2 IS NULL, 0, 1) +
                    IFF(prov_facility_city IS NULL, 0, 1) +
                    IFF(prov_facility_state IS NULL, 0, 1) +
                    IFF(prov_facility_zip IS NULL, 0, 1)
                )                       AS complete_flag
            FROM
                @source_schema.src_medical_claims
            WHERE
                COALESCE(prov_facility_address_1,
                         prov_facility_address_2,
                         prov_facility_city,
                         prov_facility_state,
                         prov_facility_zip) IS NOT NULL
                AND p_hvid = 'c'
        ) t
    ) t
    WHERE
        rn = 1
);