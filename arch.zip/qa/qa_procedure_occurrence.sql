-- -------------------------------------------------------------------
-- (c)2015-2024, Odysseus Data Services, Inc. All rights reserved
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

--- table: cdm_procedure_occurrence
--- column: procedure_date, procedure_end_date
--- rule_id: all
--- comment: none
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_procedure_occurrence
WHERE
    procedure_date < CAST('@min_date_of_dataset' AS DATE)
    OR COALESCE(procedure_end_date, procedure_date) > CAST('@max_date_of_dataset' AS DATE)
    OR procedure_date > COALESCE(procedure_end_date, procedure_date)
;