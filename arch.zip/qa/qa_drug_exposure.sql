-- -------------------------------------------------------------------
-- (c)2015-2024, Odysseus Data Services, Inc. All rights reserved
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

--- table: cdm_drug_exposure
--- columns: drug_exposure_start_date, drug_exposure_end_date
--- rule_id: all
--- comment: none
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_drug_exposure
WHERE
    drug_exposure_start_date < CAST('@min_date_of_dataset' AS DATE)
    OR drug_exposure_end_date > CAST('@max_date_of_dataset' AS DATE)
    OR drug_exposure_start_date > drug_exposure_end_date
;