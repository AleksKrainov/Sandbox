--- table: cdm_visit_occurrence
--- column: none
--- rule_id: gilead_cdm_mc_confinement
--- comment: count records
SELECT
(
    SELECT 
        COUNT(*)
    FROM
        @target_schema.cdm_visit_occurrence
    WHERE
        rule_id = 'gilead_cdm_mc_confinement'
)
-
(
    SELECT
        COUNT(*)
    FROM
    (
        SELECT DISTINCT
            src.hvid,
            src.date_start,
            src.date_end,
            src.confinement_id
        FROM
            @target_schema.src_gilead_cdm_mc_confinement src
        INNER JOIN
            @target_schema.lk_person p
                ON p.person_source_value = src.hvid
        WHERE
            src.hvid IS NOT NULL
            AND src.date_start IS NOT NULL
            AND src.date_start >= CAST('@min_date_of_dataset' AS DATE)
            AND COALESCE(src.date_end, src.date_start) <= CAST('@max_date_of_dataset' AS DATE)
    ) t
);

--- table: cdm_visit_occurrence
--- column: none
--- rule_id: src_medical_claims
--- comment: count records
SELECT
(
    SELECT 
        COUNT(*)
    FROM
        @target_schema.cdm_visit_occurrence
    WHERE
        rule_id = 'medical_claims'
)
-
(
    SELECT
        COUNT(*)
    FROM
    (
        SELECT DISTINCT
            hvid,
            date_service,
            hv_enc_id
        FROM
            @target_schema.src_medical_claims src
        INNER JOIN
            @target_schema.lk_person p
                ON p.person_source_value = src.hvid
        WHERE
            src.hvid IS NOT NULL
            AND src.date_service IS NOT NULL
            AND src.date_service BETWEEN CAST('@min_date_of_dataset' AS DATE)
                                     AND CAST('@max_date_of_dataset' AS DATE)
            AND src.hv_enc_id IS NOT NULL
            AND NOT
            (
                (
                    src.claim_type = 'I'
                    AND src.inst_type_of_bill_std_id LIKE '1%'
                    AND SUBSTRING(src.inst_type_of_bill_std_id, 2, 1) IN ('1', '2')
                )
                OR
                (
                    src.claim_type = 'P'
                    AND src.place_of_service_std_id = '21'
                )
            )
    ) t
);

--- table: cdm_visit_occurrence
--- column: procedure_date, visit_end_date
--- rule_id: all
--- comment: none
SELECT
    COUNT(*)
FROM
    @target_schema.cdm_visit_occurrence
WHERE
    visit_start_date < CAST('@min_date_of_dataset' AS DATE)
    OR COALESCE(visit_end_date, visit_start_date) > CAST('@max_date_of_dataset' AS DATE)
    OR visit_start_date > COALESCE(visit_end_date, visit_start_date)
;