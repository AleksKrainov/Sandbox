# Databricks notebook source
# DBTITLE 1,Cleaning temporary dir
dbutils.fs.rm('s3a://gdash-databricks-dev-user-storage/Test', True)

# COMMAND ----------

# DBTITLE 1,Enrollment (please, use the fields from src_stage.sql)
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, patient_year_of_birth, patient_gender, date_start, date_end, source_record_date, created, record_id, patient_age, patient_zip3, patient_state, benefit_type, payer_type FROM    healthverity_marketplace_raw_20221231.enrollment src WHERE    src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/enrollment") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.enrollment")

# COMMAND ----------

# DBTITLE 1,cdm_diag
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, crt_dt, enc_start_dt, enc_end_dt, diag_cd, hv_diag_id, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, diag_cd_qual, admtg_diag_flg, prmy_diag_flg FROM     healthverity_marketplace_raw_20221231.cdm_diag src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/cdm_diag") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.cdm_diag")

# COMMAND ----------

# DBTITLE 1,cdm_enc
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, crt_dt, enc_start_dt, enc_end_dt, hv_enc_id, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, enc_fclty_id, enc_fclty_state_cd, enc_fclty_zip_cd, enc_fclty_geo_txt, enc_prov_id, los_day_cnt, admsn_src_std_cd, dischg_stat_std_cd, drg_cd, drg_cd_qual, tot_chg_amt, tot_actl_pymt_amt, tot_expctd_pymt_amt, tot_disc_amt, tot_ptnt_liabty_amt, tot_ptnt_pymt_amt, tot_bal_amt, tot_eob_wrtoff_amt, tot_cntrctl_adjmt_amt, tot_other_adjmt_amt, tot_other_pymt_amt, tot_denied_amt, tot_ptnt_cpy_amt, tot_ptnt_ddctbl_amt, tot_secdy_payr_pymt_amt, tot_recalcd_cost_amt FROM healthverity_marketplace_raw_20221231.cdm_enc src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/cdm_enc") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.cdm_enc")

# COMMAND ----------

# DBTITLE 1,cdm_enc_dtl
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT src.hvid, crt_dt, enc_start_dt, enc_end_dt, proc_dt, chg_dt, proc_cd, proc_ndc, hv_enc_dtl_id, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, proc_cd_qual, proc_cd_1_modfr, proc_cd_2_modfr, proc_cd_3_modfr, proc_cd_4_modfr, proc_unit_qty, proc_uom, medctn_ndc, medctn_qty FROM healthverity_marketplace_raw_20221231.cdm_enc_dtl src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/cdm_enc_dtl") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.cdm_enc_dtl")

# COMMAND ----------

# DBTITLE 1,emr_clin_obsn
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT src.hvid, clin_obsn_ndc, enc_dt, hv_clin_obsn_dt, clin_obsn_dt, crt_dt, clin_obsn_onset_dt, clin_obsn_resltn_dt, clin_obsn_prov_id, hv_clin_obsn_id, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, clin_obsn_prov_speclty_id, clin_obsn_typ_cd, clin_obsn_alt_cd, clin_obsn_alt_cd_qual, clin_obsn_msrmt, clin_obsn_uom, clin_obsn_stat_cd, data_captr_dt, prmy_src_tbl_nm FROM healthverity_marketplace_raw_20221231.emr_clin_obsn src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_clin_obsn") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_clin_obsn")

# COMMAND ----------

# DBTITLE 1,emr_diag
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT src.hvid, diag_cd, enc_dt, hv_diag_dt, diag_dt, diag_onset_dt, diag_resltn_dt, hv_diag_id, crt_dt, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, diag_prov_id, diag_prov_speclty_id, diag_cd_qual, diag_stat_cd, diag_stat_desc, data_captr_dt FROM healthverity_marketplace_raw_20221231.emr_diag src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_diag") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_diag")

# COMMAND ----------

# DBTITLE 1,emr_enc
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT src.hvid, hv_enc_dt, enc_start_dt, crt_dt, enc_prov_id, hv_enc_id, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, enc_prov_speclty_id, data_captr_dt FROM healthverity_marketplace_raw_20221231.emr_enc src") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_enc") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_enc")

# COMMAND ----------

# DBTITLE 1,emr_lab_test
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, lab_test_loinc_cd, hv_lab_test_dt, lab_ord_dt, lab_test_smpl_collctn_dt, lab_test_schedd_dt, lab_test_execd_dt, lab_result_dt, lab_test_prov_id, hv_lab_test_id, crt_dt, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, enc_dt, lab_test_prov_speclty_id, lab_test_nm, lab_result_nm, lab_result_msrmt, lab_result_uom, lab_result_ref_rng_txt, lab_test_stat_cd, data_captr_dt FROM healthverity_marketplace_raw_20221231.emr_lab_test src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_lab_test") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_lab_test")

# COMMAND ----------

# DBTITLE 1,emr_medctn
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT  hvid,  medctn_ndc,  enc_dt,  hv_medctn_dt,  medctn_ord_dt,  medctn_admin_dt,  hv_medctn_id,  crt_dt,  ptnt_birth_yr,  ptnt_age_num,  ptnt_gender_cd,  ptnt_state_cd,  ptnt_zip3_cd,  hv_enc_id,  medctn_prov_id,  medctn_prov_speclty_id,  medctn_start_dt,  medctn_end_dt,  medctn_ord_durtn_day_cnt,  medctn_ord_stat_dt,  medctn_ord_stat_cd,  medctn_alt_cd,  medctn_alt_cd_qual,  medctn_brd_nm,  medctn_genc_nm,  medctn_days_supply_cnt,  medctn_qty,  medctn_qty_qual, medctn_admin_txt,  medctn_admin_sig_cd,  medctn_remng_rfll_qty,  medctn_last_rfll_dt,  data_captr_dt FROM     healthverity_marketplace_raw_20221231.emr_medctn src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_medctn") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_medctn")

# COMMAND ----------

# DBTITLE 1,emr_proc
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT  hvid,  proc_cd,  proc_ndc,  enc_dt,  hv_proc_dt,  proc_dt,  hv_proc_id,  crt_dt,  ptnt_birth_yr,  ptnt_age_num,  ptnt_gender_cd,  ptnt_state_cd,  ptnt_zip3_cd,  hv_enc_id,  proc_prov_id,  proc_prov_speclty_id,  proc_cd_qual,  proc_cd_1_modfr,  proc_cd_2_modfr,  proc_cd_3_modfr,  proc_cd_4_modfr,  proc_cd_modfr_qual,  proc_unit_qty,  proc_uom,  proc_stat_cd,  proc_admin_rte_cd,  data_captr_dt FROM     healthverity_marketplace_raw_20221231.emr_proc src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_proc") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_proc")

# COMMAND ----------

# DBTITLE 1,emr_prov_ord
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, prov_ord_cd, enc_dt, hv_prov_ord_dt, prov_ord_dt, hv_prov_ord_id, crt_dt, ptnt_birth_yr, ptnt_age_num, ptnt_gender_cd, ptnt_state_cd, ptnt_zip3_cd, hv_enc_id, prov_ord_prov_id,    prov_ord_prov_speclty_id, prov_ord_stat_dt, data_captr_dt FROM healthverity_marketplace_raw_20221231.emr_prov_ord src WHERE src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/emr_prov_ord") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.emr_prov_ord")

# COMMAND ----------

# DBTITLE 1,pharmacy_claims
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT hvid, diagnosis_code, procedure_code, ndc_code, date_service, date_written, date_authorized, created, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, transaction_code_std, diagnosis_code_qual, fill_number, refill_auth_amount, dispensed_quantity, unit_of_measure, days_supply, orig_prescribed_quantity, prov_prescribing_npi, prov_prescribing_vendor_specialty, usual_and_customary_charge, product_selection_attributed, other_payer_recognized, periodic_deductible_applied, periodic_benefit_exceed, accumulated_deductible, remaining_deductible, remaining_benefit, copay_coinsurance, submitted_ingredient_cost, submitted_dispensing_fee, submitted_incentive, submitted_gross_due, submitted_professional_service_fee, submitted_patient_pay, submitted_other_claimed, paid_ingredient_cost, paid_dispensing_fee, paid_incentive, paid_gross_due, paid_professional_service_fee, paid_patient_pay, paid_other_claimed_qual, paid_other_claimed, prov_prescribing_id, other_payer_date, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.pharmacy_claims src WHERE     src.hvid IS NOT NULL") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/pharmacy_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.pharmacy_claims")

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,medical_claims !!!! Need to copy with filters and by parts ( DATE_PART(year, CAST(created as date))
df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) IN (2015, 2016) AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims")

# COMMAND ----------

df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) IN (2017, 2018) AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims_17_18")

# COMMAND ----------

df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) = 2019 AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims_2019")

# COMMAND ----------

df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) = 2020 AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims_2020")

# COMMAND ----------

df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) = 2021 AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims_2021")

# COMMAND ----------

df = spark.read \
    .format("com.databricks.spark.redshift") \
    .option("url", "jdbc:postgresql://serverless-consumer.241179363089.us-west-2.redshift-serverless.amazonaws.com:5439/redshiftdb?user="+"olomazova"+"&password="+"Gt0Wa7Ye7Mp6") \
    .option("query", "SELECT     hvid, diagnosis_code,  procedure_code,  ndc_code,  date_received,  date_service,  date_service_end,  inst_date_admitted,  inst_date_discharged,  hv_enc_id,  created,  data_vendor, patient_gender, patient_age, patient_year_of_birth, patient_zip3, patient_state, inst_drg_std_id, inst_drg_vendor_id, inst_drg_vendor_desc, place_of_service_std_id, diagnosis_code_qual, diagnosis_priority, admit_diagnosis_ind, procedure_modifier_1, procedure_modifier_2, procedure_modifier_3, procedure_modifier_4, revenue_code, line_charge, line_allowed, total_charge, total_allowed, prov_rendering_npi, prov_billing_npi, prov_referring_npi, prov_facility_npi, prov_rendering_vendor_id, prov_rendering_dea_id, prov_rendering_vendor_specialty, prov_billing_vendor_id, prov_billing_dea_id, prov_billing_vendor_specialty, prov_referring_vendor_id, prov_referring_dea_id, prov_referring_vendor_specialty, prov_facility_name_1, prov_facility_name_2, prov_facility_address_1, prov_facility_address_2, prov_facility_city, prov_facility_state, prov_facility_zip, claim_transaction_date, claim_transaction_amount, logical_delete_reason FROM     healthverity_marketplace_raw_20221231.medical_claims src WHERE date_part(year, cast(created as date)) = 2022 AND (logical_delete_reason in ('INITIAL PAY CLAIM', 'UNKNOWN', 'ADJUSTMENT TO ORIGINAL CLAIM')or (logical_delete_reason is null and data_vendor != 'Private Source 20')) and COALESCE(procedure_code, diagnosis_code, ndc_code) is not null") \
    .option("tempdir", "s3a://gdash-databricks-dev-user-storage/Test/medical_claims") \
    .option("forward_spark_s3_credentials","true")\
    .load()
df.write.format("delta").saveAsTable("healthverity_marketplace_raw_20221231.medical_claims_2022")

# COMMAND ----------

# DBTITLE 1,After load need  to merge parts of medical_claims into single table

