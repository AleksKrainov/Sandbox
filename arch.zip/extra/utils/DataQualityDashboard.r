# Databricks notebook source
# 1. Verify transformation, OMOP and vocabulary schema names (cells 3 and 11)
# 2. Check that github_token (4) is not expired
# 3. Check that Databricks Access token (11) is not expired -> connectionDetails - PWD=dapi0c2dd65f453f0ef15be1b49798268730
# 4. Check cluster HTTP Path (11) -> connectionDetails - httpPath=sql/protocolv1/o/496860753355070/0506-085157-57qzhgon

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS healthverity_marketplace_transform_20250331_omop;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.care_site             AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_care_site;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.cdm_source            AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_cdm_source;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.cohort                AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_cohort;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.cohort_definition     AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_cohort_definition;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.condition_era         AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_condition_era;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.condition_occurrence  AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_condition_occurrence;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.cost                  AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_cost;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.death                 AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_death;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.device_exposure       AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_device_exposure;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.dose_era              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_dose_era;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.drug_era              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_drug_era;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.drug_exposure         AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_drug_exposure;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.episode               AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_episode;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.episode_event         AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_episode_event;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.fact_relationship     AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_fact_relationship;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.location              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_location;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.measurement           AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_measurement;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.metadata              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_metadata;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.note                  AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_note;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.note_nlp              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_note_nlp;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.observation           AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_observation;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.observation_period    AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_observation_period;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.payer_plan_period     AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_payer_plan_period;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.person                AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_person;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.procedure_occurrence  AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_procedure_occurrence;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.provider              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_provider;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.source_to_concept_map AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_source_to_concept_map;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.specimen              AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_specimen;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.visit_detail          AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_visit_detail;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.visit_occurrence      AS SELECT * FROM healthverity_marketplace_transform_20250331.cdm_visit_occurrence;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.concept               AS SELECT * FROM omop_voc_27feb25.voc_concept;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.concept_ancestor      AS SELECT * FROM omop_voc_27feb25.voc_concept_ancestor;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.concept_relationship  AS SELECT * FROM omop_voc_27feb25.voc_concept_relationship;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.concept_class         AS SELECT * FROM omop_voc_27feb25.voc_concept_class;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.concept_synonym       AS SELECT * FROM omop_voc_27feb25.voc_concept_synonym;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.domain                AS SELECT * FROM omop_voc_27feb25.voc_domain;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.drug_strength         AS SELECT * FROM omop_voc_27feb25.voc_drug_strength;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.relationship          AS SELECT * FROM omop_voc_27feb25.voc_relationship;
# MAGIC CREATE OR REPLACE VIEW healthverity_marketplace_transform_20250331_omop.vocabulary            AS SELECT * FROM omop_voc_27feb25.voc_vocabulary;

# COMMAND ----------

# Connecting to a database: https://ohdsi.github.io/DataQualityDashboard/articles/DataQualityDashboard.html
# Executing Data Quality Checks: https://ohdsi.github.io/DataQualityDashboard/articles/DataQualityDashboard.html
github_token = "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"

# COMMAND ----------

# MAGIC %sh
# MAGIC
# MAGIC # Problem: when you install rJava and RJDBC libraries with the following command in a notebook R cell:
# MAGIC # install.packages("rJava")
# MAGIC # You observe the following error: ERROR: configuration failed for package 'rJava'
# MAGIC # Solution: https://kb.databricks.com/r/install-rjava-rjdbc-libraries
# MAGIC
# MAGIC ls -l /usr/bin/java
# MAGIC ls -l /etc/alternatives/java
# MAGIC ln -s /usr/lib/jvm/java-8-openjdk-amd64 /usr/lib/jvm/default-java
# MAGIC R CMD javareconf

# COMMAND ----------

install.packages("rJava", auth_token=github_token)

# In addition to the cell #2 since it was only first part of the solution.
# Second part: https://stackoverflow.com/questions/75629311/rjava-and-rjdbc-on-databricks
# After rJava installion:

dyn.load('/usr/lib/jvm/zulu11-ca-amd64/lib/server/libjvm.so')

# COMMAND ----------

# this package needs to be installed due to the error while running DQD job: namespace ‘vctrs’ 0.6.3 is already loaded, but >= 0.6.4 is required
install.packages("vctrs", auth_token=github_token)

# COMMAND ----------

install.packages("devtools", auth_token=github_token)
library(devtools)
install_github("OHDSI/DatabaseConnector", auth_token=github_token)
install_github("OHDSI/SqlRender", auth_token=github_token)

# COMMAND ----------

library(DatabaseConnector)
downloadJdbcDrivers("spark", pathToDriver = "/dqd_spark_driver")

# COMMAND ----------

install.packages("remotes")
remotes::install_github("OHDSI/DataQualityDashboard", auth_token=github_token)

# COMMAND ----------

connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = "spark", connectionString = "jdbc:databricks://gdash-cdsaa-databricks-dev-deployment.cloud.databricks.com:443/default;transportMode=http;ssl=1;httpPath=sql/protocolv1/o/496860753355070/0506-085157-57qzhgon;AuthMech=3;UID=token;PWD=dapi0c2dd65f453f0ef15be1b49798268730", pathToDriver = "/dqd_spark_driver")

cdmDatabaseSchema <- "healthverity_marketplace_transform_20250331_omop" # CDM schema name
resultsDatabaseSchema <- "" # DQD result schema
cdmSourceName <- "HealthVerity"
#cdmSourceName <- "Merative MarketScan"
cdmVersion <- "5.4"

# how many threads (concurrent SQL sessions) to use
numThreads <- 3 # on Redshift, 3 seems to work well

# specify if you want to execute the queries or inspect them
sqlOnly <- FALSE # set to TRUE if you just want to get the SQL scripts and not actually run the queries
sqlOnlyIncrementalInsert <- FALSE # set to TRUE if you want the generated SQL queries to calculate DQD results and insert them into a database table (@resultsDatabaseSchema.@writeTableName)
sqlOnlyUnionCount <- 1  # in sqlOnlyIncrementalInsert mode, the number of check sqls to union in a single query; higher numbers can improve performance in some DBMS (e.g. a value of 25 may be 25x faster)

# where should the results and logs go?
outputFolder <- "/dqd/output"
outputFile <- "results.json"

# logging type
verboseMode <- TRUE # set to FALSE if you don't want the logs to be printed to the console

# write results to table
writeToTable <- FALSE # set to FALSE if you want to skip writing to a SQL table in the results schema

# the name of the results table (used when writeToTable = TRUE and when sqlOnlyIncrementalInsert = TRUE)
writeTableName <- "dqdashboard_results"

# write results to a csv file
writeToCsv <- FALSE # set to FALSE if you want to skip writing to csv file
csvFile <- "" # only needed if writeToCsv is set to TRUE

# which DQ check levels to run
checkLevels <- c("TABLE", "FIELD", "CONCEPT")

# which DQ checks to run
checkNames <- c() # Names can be found in inst/csv/OMOP_CDM_v5.3_Check_Descriptions.csv

# which CDM tables to exclude
tablesToExclude <- c("CONCEPT", "VOCABULARY", "CONCEPT_ANCESTOR", "CONCEPT_RELATIONSHIP", "CONCEPT_CLASS", "CONCEPT_SYNONYM", "RELATIONSHIP", "DOMAIN")

# COMMAND ----------

# run the job
DataQualityDashboard::executeDqChecks(connectionDetails = connectionDetails, 
                            cdmDatabaseSchema = cdmDatabaseSchema, 
                            resultsDatabaseSchema = resultsDatabaseSchema,
                            cdmSourceName = cdmSourceName, 
                            cdmVersion = cdmVersion,
                            numThreads = numThreads,
                            sqlOnly = sqlOnly, 
                            sqlOnlyUnionCount = sqlOnlyUnionCount,
                            sqlOnlyIncrementalInsert = sqlOnlyIncrementalInsert,
                            outputFolder = outputFolder,
                            outputFile = outputFile,
                            verboseMode = verboseMode,
                            writeToTable = writeToTable,
                            writeToCsv = writeToCsv,
                            csvFile = csvFile,
                            checkLevels = checkLevels,
                            tablesToExclude = tablesToExclude,
                            checkNames = checkNames)

# COMMAND ----------

# MAGIC %sh
# MAGIC cp -r /dqd/output/ /Workspace/Shared/OMOP/dqd/healthverity/20250331/
# MAGIC #cp -r /dqd/output/ /Workspace/Shared/OMOP/dqd/merative/2023_q4/
# MAGIC
# MAGIC #rm /local_disk0/.ephemeral_nfs/envs/rEnv-3c832ea4-c654-4142-a747-5b6167f1c974/DataQualityDashboard/shinyApps/www/results.json
# MAGIC #cp /dqd/output/results.json /local_disk0/.ephemeral_nfs/envs/rEnv-3c832ea4-c654-4142-a747-5b6167f1c974/DataQualityDashboard/shinyApps/www/results.json

# COMMAND ----------

# Inspect logs
#ParallelLogger::launchLogViewer(logFileName = file.path(outputFolder, cdmSourceName, sprintf("log_DqDashboard_%s.txt", cdmSourceName)))

# COMMAND ----------

# Launching Dashboard as Shiny App
#DataQualityDashboard::viewDqDashboard(jsonPath="/dqd/output/results.json")

# COMMAND ----------

# View checks
#checks <- DataQualityDashboard::listDqChecks(cdmVersion = "5.4")