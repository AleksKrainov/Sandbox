# Databricks notebook source
import os
import json

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

TARGET_SCHEMA = "merative_marketscan_cdm_2023_q4"
#TARGET_SCHEMA = "omop_voc_29feb24"
OUTPUT_DIR = "/Workspace/Shared/OMOP/"


def init_spark_session():
    spark = SparkSession.builder.appname("collect_strlen").enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    return spark


def main(spark):
    out = dict()
    for table in spark.catalog.listTables(dbName=TARGET_SCHEMA):
        if not table.name.startswith(("cdm_", "voc_")) or "stage" in table.name or "amend" in table.name:
            continue
        print("\nProcessing '{}' table...".format(table.name))
        out[table.name] = dict()
        table_df = spark.table(TARGET_SCHEMA + '.' + table.name)
        for fname, ftype in table_df.dtypes:
            if ftype == "string":
                print("  -", fname)
                out[table.name][fname] = table_df.select(F.max(F.length(fname))).collect()[0][0]
    print("\nWriting JSON output...")
    with open(os.path.join(OUTPUT_DIR, "strlen_voc.json"), 'w') as f:
        json.dump(out, f, indent=4)


if __name__ == "__main__":
    #spark = init_spark_session()
    main(spark)