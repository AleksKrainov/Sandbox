﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Target Table: visit_detail
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Rule 1 Institutional claims
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail;
CREATE TABLE @target_schema.tmp_visit_detail
(
    hvid                            STRING,
    date_service                    DATE,
    date_service_end                DATE,
    claim_type                      STRING,
    inst_type_of_bill_std_id        STRING,
    place_of_service_std_id         STRING,
    inst_discharge_status_std_id    STRING,
-- --
    person_id                       BIGINT,
    provider_source_value           STRING,
    visit_detail_source_value       STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

/*!
    @insert
    @table: @target_schema.tmp_visit_detail
    @source_table: @source_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule 1 records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail
SELECT
    src.hvid                                AS hvid,
    src.date_service                        AS date_service,
    src.date_service_end                    AS date_service_end,
    src.claim_type                          AS claim_type,
    src.inst_type_of_bill_std_id            AS inst_type_of_bill_std_id,
    NULL                                    AS place_of_service_std_id,
    src.inst_discharge_status_std_id        AS inst_discharge_status_std_id,
-- --
    p.person_id                             AS person_id,

    COALESCE(src.prov_rendering_npi, src.prov_billing_npi)
                                            AS provider_source_value,

    CASE
        WHEN src.revenue_code LIKE '045%'
             OR src.procedure_code IN ("99281",
                                       "99282",
                                       "99283",
                                       "99284",
                                       "99285")
        THEN 'Emergency Room Visit'
        ELSE src.inst_type_of_bill_std_id
    END                                     AS visit_detail_source_value,
-- --
    'medical_claims.institutional_claims'   AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.claim_type = 'I'
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule 2 Professional claims
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_detail
    @source_table: @source_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule 2 records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail
SELECT
    src.hvid                                AS hvid,
    src.date_service                        AS date_service,
    src.date_service_end                    AS date_service_end,
    src.claim_type                          AS claim_type,
    NULL                                    AS inst_type_of_bill_std_id,
    src.place_of_service_std_id             AS place_of_service_std_id,
    src.inst_discharge_status_std_id        AS inst_discharge_status_std_id,
-- --
    p.person_id                             AS person_id,

    COALESCE(src.prov_rendering_npi, src.prov_billing_npi)
                                            AS provider_source_value,

    src.place_of_service_std_id             AS visit_detail_source_value,
-- --
    'medical_claims.professional_claims'    AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.claim_type = 'P'
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Table tmp_visit_detail_grp
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_grp;
CREATE TABLE @target_schema.tmp_visit_detail_grp
(
    hvid                            STRING,
    date_service                    DATE,
    date_service_end                DATE,
    claim_type                      STRING,
    inst_type_of_bill_std_id        STRING,
    place_of_service_std_id         STRING,
    inst_discharge_status_std_id    STRING,
-- --
    person_id                       BIGINT,
    provider_source_value           STRING,
    visit_detail_source_value       STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    new_load_row_id                 BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

/*!
    @insert
    @table: @target_schema.tmp_visit_detail_grp
    @source_table: @source_schema.tmp_visit_detail
    @summary: rule 1 records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail_grp
SELECT
    src.hvid                                AS hvid,
    src.date_service                        AS date_service,
    src.date_service_end                    AS date_service_end,
    src.claim_type                          AS claim_type,
    src.inst_type_of_bill_std_id            AS inst_type_of_bill_std_id,
    src.place_of_service_std_id             AS place_of_service_std_id,
    src.inst_discharge_status_std_id        AS inst_discharge_status_std_id,
-- --
    src.person_id                           AS person_id,
    src.provider_source_value               AS provider_source_value,
    src.visit_detail_source_value           AS visit_detail_source_value,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,

    MIN(src.load_row_id) OVER (
        PARTITION BY
            src.hvid,
            src.date_service,
            src.date_service_end,
            src.claim_type,
            src.inst_type_of_bill_std_id,
            src.place_of_service_std_id,
            src.inst_discharge_status_std_id,
            src.person_id,
            src.provider_source_value,
            src.visit_detail_source_value,
            src.p_hvid
        )                                   AS new_load_row_id,

    src.p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_visit_detail src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Table lk_load_row_id_medical_claims
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_load_row_id_medical_claims;
CREATE TABLE @target_schema.lk_load_row_id_medical_claims
(
    load_row_id         BIGINT,
    new_load_row_id     BIGINT,
-- --
    p_hvid              STRING
)
@PROPERTY
;

/*!
    @insert
    @table: @target_schema.lk_load_row_id_medical_claims
    @source_table: @target_schema.tmp_visit_detail_map
    @summary: final cdm insert
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_load_row_id_medical_claims
SELECT DISTINCT
    src.load_row_id             AS load_row_id,
    src.new_load_row_id         AS new_load_row_id,
-- --
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.tmp_visit_detail_grp src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Mapping to standard concepts Rule 1
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_map;
CREATE TABLE @target_schema.tmp_visit_detail_map
(
    visit_detail_id                 BIGINT,
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_start_date         DATE,
    visit_detail_start_datetime     TIMESTAMP,
    visit_detail_end_date           DATE,
    visit_detail_end_datetime       TIMESTAMP,
    visit_detail_type_concept_id    INTEGER,
    provider_id                     BIGINT,
    care_site_id                    BIGINT,
    visit_detail_source_value       STRING,
    visit_detail_source_concept_id  INTEGER,
    admitted_from_concept_id        INTEGER,
    admitted_from_source_value      STRING,
    discharged_to_source_value      STRING,
    discharged_to_concept_id        INTEGER,
    preceding_visit_detail_id       BIGINT,
    parent_visit_detail_id          BIGINT,
    visit_occurrence_id             BIGINT,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
-- --
    p_hvid                          STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_visit_detail_map
    @source_table: @target_schema.tmp_visit_detail_grp
    @summary: mapping to standard concepts rule 1
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail_map
SELECT
    (SELECT COALESCE(MAX(visit_detail_id), 0)
       FROM @target_schema.tmp_visit_detail_map)
        + 1 + ROW_NUMBER() OVER (ORDER BY NULL)   AS visit_detail_id,

    src.person_id                           AS person_id,

    CASE
        WHEN src.visit_detail_source_value = 'Emergency Room Visit'
        THEN 9203  -- Emergency Room Visit
        WHEN lkc1.target_concept_id IS NOT NULL
        THEN lkc1.target_concept_id
        WHEN SUBSTRING(src.visit_detail_source_value, 1, 1) = 'X'
             AND SUBSTRING(src.visit_detail_source_value, 2, 1) IN ('1', '2')
        THEN 9201  -- Inpatient Visit
        ELSE 9202  -- Outpatient Visit
    END                                     AS visit_detail_concept_id,
    
    src.date_service                        AS visit_detail_start_date,
    src.date_service                        AS visit_detail_start_datetime,

    COALESCE(src.date_service_end, src.date_service)
                                            AS visit_detail_end_date,

    COALESCE(src.date_service_end, src.date_service)
                                            AS visit_detail_end_datetime,

    32810                                   AS visit_detail_type_concept_id,  -- Claim
    prov.provider_id                        AS provider_id,
    cs.care_site_id                         AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,

    CASE
        WHEN src.visit_detail_source_value = 'Emergency Room Visit'
        THEN 9203  -- Emergency Room Visit
        ELSE COALESCE(lkc1.source_concept_id, 0)
    END                                     AS visit_detail_source_concept_id,

    NULL                                    AS admitted_from_concept_id,
    NULL                                    AS admitted_from_source_value,
    src.inst_discharge_status_std_id        AS discharged_to_source_value,
    COALESCE(lkc2.target_concept_id, 0)     AS discharged_to_concept_id,
    NULL                                    AS preceding_visit_detail_id,
    NULL                                    AS parent_visit_detail_id,
    NULL                                    AS visit_occurrence_id,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
-- --
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_visit_detail_grp src
LEFT JOIN
    @target_schema.cdm_provider prov
        ON prov.provider_source_value = src.provider_source_value
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON cs.care_site_source_value = src.place_of_service_std_id
LEFT JOIN
    @target_schema.lk_concept lkc1
        ON  lkc1.src_code = src.visit_detail_source_value
        AND lkc1.src_code_type = 'place_of_service_code'
        AND lkc1.source_vocabulary_id = 'UB04 Typ bill'
LEFT JOIN
    @target_schema.lk_concept lkc2
        ON  lkc2.src_code = src.inst_discharge_status_std_id
        AND lkc2.src_code_type = 'discharged_code'
        AND lkc2.source_vocabulary_id = 'UB04 Pt dis status'
WHERE
    src.claim_type = 'I'
    AND src.load_row_id = src.new_load_row_id
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Mapping to standard concepts Rule 2
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_detail_map
    @source_table: @target_schema.tmp_visit_detail_grp
    @summary: mapping to standard concepts rule 2
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail_map
SELECT
    (SELECT COALESCE(MAX(visit_detail_id), 0)
       FROM @target_schema.tmp_visit_detail_map)
        + 1 + ROW_NUMBER() OVER (ORDER BY NULL)   AS visit_detail_id,

    src.person_id                           AS person_id,
    COALESCE(lkc1.target_concept_id, 9202)  AS visit_detail_concept_id,
    src.date_service                        AS visit_detail_start_date,
    src.date_service                        AS visit_detail_start_datetime,

    COALESCE(src.date_service_end, src.date_service)
                                            AS visit_detail_end_date,

    COALESCE(src.date_service_end, src.date_service)
                                            AS visit_detail_end_datetime,

    32871                                   AS visit_detail_type_concept_id,  -- Professional claim
    prov.provider_id                        AS provider_id,
    cs.care_site_id                         AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,
    COALESCE(lkc1.source_concept_id, 0)     AS visit_detail_source_concept_id,
    NULL                                    AS admitted_from_concept_id,
    NULL                                    AS admitted_from_source_value,
    src.inst_discharge_status_std_id        AS discharged_to_source_value,
    COALESCE(lkc2.target_concept_id, 0)     AS discharged_to_concept_id,
    NULL                                    AS preceding_visit_detail_id,
    NULL                                    AS parent_visit_detail_id,
    NULL                                    AS visit_occurrence_id,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
-- --
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_visit_detail_grp src
LEFT JOIN
    @target_schema.cdm_provider prov
        ON prov.provider_source_value = src.provider_source_value
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON cs.care_site_source_value = src.place_of_service_std_id
LEFT JOIN
    @target_schema.lk_concept lkc1
        ON  lkc1.src_code = src.visit_detail_source_value
        AND lkc1.src_code_type = 'place_of_service_code'
        AND lkc1.source_vocabulary_id = 'CMS Place of Service'
LEFT JOIN
    @target_schema.lk_concept lkc2
        ON  lkc2.src_code = src.inst_discharge_status_std_id
        AND lkc2.src_code_type = 'discharged_code'
        AND lkc2.source_vocabulary_id = 'UB04 Pt dis status'
WHERE
    src.claim_type = 'P'
    AND src.load_row_id = src.new_load_row_id
    AND src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Creating tmp_visit_detail_id to populate visit_detail_id
-- -------------------------------------------------------------------
--DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_id;
/*!
    @insert
    @table: @target_schema.tmp_visit_detail_id
    @source_table: @target_schema.tmp_visit_detail_map
    @summary: populating visit_occurrence_id for all 2 rules
!*/
/*
CREATE TABLE @target_schema.tmp_visit_detail_id
@PROPERTY AS SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS visit_detail_id,
    vd.*
FROM
    @target_schema.tmp_visit_detail_map vd
WHERE
    vd.visit_detail_start_date >= CAST('@min_date_of_dataset' AS DATE)
    AND COALESCE(vd.visit_detail_end_date, vd.visit_detail_start_date) <= CAST('@max_date_of_dataset' AS DATE)
;
*/
-- -------------------------------------------------------------------
-- Deduping visit_detail
-- -------------------------------------------------------------------
/*
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_dedup;
CREATE TABLE @target_schema.tmp_visit_detail_dedup
(
    new_visit_detail_id     BIGINT,
    visit_detail_id         BIGINT,
-- --
    p_hvid                  STRING
)
@PROPERTY
;
*/
/*!
    @insert
    @table: @target_schema.tmp_visit_detail_dedup
    @source_table: @target_schema.tmp_visit_detail_id
    @summary: records deduplication
!*/
/*
INSERT INTO @target_schema.tmp_visit_detail_dedup
SELECT
    MIN(src.visit_detail_id) OVER (
        PARTITION BY
            src.person_id,
            src.visit_detail_concept_id,
            src.visit_detail_start_date,
            src.visit_detail_start_datetime,
            src.visit_detail_end_date,
            src.visit_detail_end_datetime,
            src.visit_detail_type_concept_id,
            src.provider_id,
            src.care_site_id,
            src.visit_detail_source_value,
            src.visit_detail_source_concept_id,
            src.admitted_from_concept_id,
            src.admitted_from_source_value,
            src.discharged_to_source_value,
            src.discharged_to_concept_id,
            src.preceding_visit_detail_id,
            src.parent_visit_detail_id,
            src.visit_occurrence_id
    )                           AS new_visit_detail_id,
    src.visit_detail_id         AS visit_detail_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.tmp_visit_detail_id src
WHERE
    src.p_hvid = '@hvid_char'
;
*/
-- -------------------------------------------------------------------
-- Final CDM insert into cdm_visit_detail
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_visit_detail;
/*!
    @insert
    @table: @target_schema.cdm_visit_detail
    @source_table: @target_schema.tmp_visit_detail_map
    @summary: final cdm insert
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_visit_detail
SELECT
    src.visit_detail_id                     AS visit_detail_id,
    src.person_id                           AS person_id,
    src.visit_detail_concept_id             AS visit_detail_concept_id,
    src.visit_detail_start_date             AS visit_detail_start_date,
    src.visit_detail_start_datetime         AS visit_detail_start_datetime,
    src.visit_detail_end_date               AS visit_detail_end_date,
    src.visit_detail_end_datetime           AS visit_detail_end_datetime,
    src.visit_detail_type_concept_id        AS visit_detail_type_concept_id,
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,
    src.visit_detail_source_concept_id      AS visit_detail_source_concept_id,
    src.admitted_from_concept_id            AS admitted_from_concept_id,
    src.admitted_from_source_value          AS admitted_from_source_value,
    src.discharged_to_source_value          AS discharged_to_source_value,
    src.discharged_to_concept_id            AS discharged_to_concept_id,
    src.preceding_visit_detail_id           AS preceding_visit_detail_id,
    src.parent_visit_detail_id              AS parent_visit_detail_id,
    src.visit_occurrence_id                 AS visit_occurrence_id,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id
FROM
    @target_schema.tmp_visit_detail_map src
WHERE
    /*EXISTS
        (
            SELECT 1
              FROM @target_schema.tmp_visit_detail_dedup dd
             WHERE dd.new_visit_detail_id = src.visit_detail_id
               AND dd.p_hvid = '@hvid_char'
        )*/
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail;
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_grp;
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_map;
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_id;
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_dedup;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------