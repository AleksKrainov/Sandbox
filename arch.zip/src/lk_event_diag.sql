-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate lookup table lk_event_diag
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_event_diag;
CREATE TABLE @target_schema.lk_event_diag
(
    event_source_value              STRING,
    source_vocabulary_id            STRING,
    event_start_date                DATE,
    event_end_date                  DATE,
    event_type_concept_id           INTEGER,
-- --
    person_id                       BIGINT,
    provider_source_value           STRING,
    care_site_source_value          STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Rule medical_claims.diagnosis_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_diag
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.diagnosis_code records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_diag
SELECT
    src.diagnosis_code                      AS event_source_value,
    CAST(NULL AS STRING)                    AS source_vocabulary_id,
    src.date_service                        AS event_start_date,
    NULL                                    AS event_end_date,
    31980                                   AS event_type_concept_id,  -- Paid
-- --
    p.person_id                             AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)          AS provider_source_value,

    NULL                                    AS care_site_source_value,
-- --
    'medical_claims.diagnosis_code'         AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.diagnosis_code IS NOT NULL
    AND logical_delete_reason IN ('INITIAL PAY CLAIM',
                                  'UNKNOWN',
                                  'ADJUSTMENT TO ORIGINAL CLAIM')
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.denied.diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_diag
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.denied.diag records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_diag
SELECT
    src.diagnosis_code                  AS event_source_value,

    CASE
        WHEN src.diagnosis_code_qual = '01'
        THEN 'ICD9CM'
        WHEN src.diagnosis_code_qual = '02'
        THEN 'ICD10CM'
        ELSE NULL
    END                                 AS source_vocabulary_id,

    src.date_service                    AS event_start_date,
    NULL                                AS event_end_date,
    40480940                            AS event_type_concept_id,  -- Denied
-- --
    p.person_id                         AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)      AS provider_source_value,

    NULL                                AS care_site_source_value,
-- --
    'medical_claims.denied.diag'        AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id,
    src.p_hvid                          AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.diagnosis_code IS NOT NULL
    AND src.logical_delete_reason = 'DENIED CLAIMS'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.reversed.diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_diag
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.reversed.diag records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_diag
SELECT
    src.diagnosis_code                  AS event_source_value,

    CASE
        WHEN src.diagnosis_code_qual = '01'
        THEN 'ICD9CM'
        WHEN src.diagnosis_code_qual = '02'
        THEN 'ICD10CM'
        ELSE NULL
    END                                 AS source_vocabulary_id,

    src.date_service                    AS event_start_date,
    NULL                                AS event_end_date,
    0                                   AS event_type_concept_id,
-- --
    p.person_id                         AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)      AS provider_source_value,

    NULL                                AS care_site_source_value,
-- --
    'medical_claims.reversed.diag'      AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id,
    src.p_hvid                          AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.diagnosis_code IS NOT NULL
    AND src.logical_delete_reason = 'REVERSAL TO ORIGINAL CLAIM'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.pended.diagnosis_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_diag
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.pended.diagnosis_code records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_diag
SELECT
    src.diagnosis_code                      AS event_source_value,
    CAST(NULL AS STRING)                    AS source_vocabulary_id,
    src.date_service                        AS event_start_date,
    NULL                                    AS event_end_date,
    618555                                  AS event_type_concept_id,  -- Pending result
-- --
    p.person_id                             AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)          AS provider_source_value,

    NULL                                    AS care_site_source_value,
-- --
    'medical_claims.pended.diagnosis_code'  AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.diagnosis_code IS NOT NULL
    AND logical_delete_reason = 'PENDED FOR ADJUDICATION'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule pharmacy_claims.diagnosis_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_diag
    @source_table: @target_schema.src_pharmacy_claims,
                   @target_schema.lk_person
    @summary: rule pharmacy_claims.diagnosis_code records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_diag
SELECT
    src.diagnosis_code                  AS event_source_value,

    CASE
        WHEN src.diagnosis_code_qual = '01'
        THEN 'ICD9CM'
        WHEN src.diagnosis_code_qual = '02'
        THEN 'ICD10CM'
        ELSE NULL
    END                                 AS source_vocabulary_id,

    src.date_service                    AS event_start_date,
    NULL                                AS event_end_date,

    CASE
        WHEN src.logical_delete_reason IS NULL
        THEN 31980  -- Paid
        WHEN src.logical_delete_reason = 'Claim Rejected'
        THEN 40480940  -- Denied
        ELSE 0
    END                                 AS event_type_concept_id,
-- --
    p.person_id                         AS person_id,
    src.prov_prescribing_npi            AS provider_source_value,
    src.pharmacy_npi                    AS care_site_source_value,
-- --
    'pharmacy_claims.diagnosis_code'    AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id,
    src.p_hvid                          AS p_hvid
FROM
    @target_schema.src_pharmacy_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.diagnosis_code IS NOT NULL
    AND (src.logical_delete_reason != 'Pending' OR src.logical_delete_reason IS NULL)
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;


/*!@endpage!*/
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------