-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate lookup table lk_event_proc
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_event_proc;
CREATE TABLE @target_schema.lk_event_proc
(
    event_source_value              STRING,
    source_vocabulary_id            STRING,
    event_start_date                DATE,
    event_end_date                  DATE,
    event_type_concept_id           INTEGER,
-- ------------------ additional columns -------------------
    modifier_source_value           STRING,
-- ---------------------------------------------------------
    person_id                       BIGINT,
    provider_source_value           STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Rule medical_claims.procedure
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_proc
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.procedure records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_proc
SELECT
    src.procedure_code                          AS event_source_value,
    NULL                                        AS source_vocabulary_id,
    src.date_service                            AS event_start_date,
    src.date_service                            AS event_end_date,
    31980                                       AS event_type_concept_id,  -- Paid
-- --
    NULL                                        AS modifier_source_value,
-- --
    p.person_id                                 AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)              AS provider_source_value,
-- --
    'medical_claims.procedure'                  AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.load_row_id                             AS load_row_id,
    src.p_hvid                                  AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.procedure_code IS NOT NULL
    AND src.logical_delete_reason IN ('INITIAL PAY CLAIM',
                                      'UNKNOWN',
                                      'ADJUSTMENT TO ORIGINAL CLAIM')
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.denied.procedure
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_proc
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.denied.procedure records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_proc
SELECT
    src.procedure_code                          AS event_source_value,
    
    CASE
        WHEN src.procedure_code_qual = 'CP'
        THEN 'CPT4'
        WHEN src.procedure_code_qual = 'HC'
        THEN 'HCPCS'
        WHEN src.procedure_code_qual = '02'
        THEN 'ICD10PCS'
        ELSE NULL
    END                                         AS source_vocabulary_id,
    
    src.date_service                            AS event_start_date,
    src.date_service                            AS event_end_date,
    40480940                                    AS event_type_concept_id,  -- Denied
-- --
    COALESCE(src.procedure_modifier_1,
             src.procedure_modifier_2,
             src.procedure_modifier_3,
             src.procedure_modifier_4)          AS modifier_source_value,
-- --
    p.person_id                                 AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)              AS provider_source_value,
-- --
    'medical_claims.denied.procedure'           AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.load_row_id                             AS load_row_id,
    src.p_hvid                                  AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.procedure_code IS NOT NULL
    AND src.logical_delete_reason = 'DENIED CLAIMS'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.reversed.procedure
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_proc
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.reversed.procedure records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_proc
SELECT
    src.procedure_code                          AS event_source_value,
    
    CASE
        WHEN src.procedure_code_qual = 'CP'
        THEN 'CPT4'
        WHEN src.procedure_code_qual = 'HC'
        THEN 'HCPCS'
        WHEN src.procedure_code_qual = '02'
        THEN 'ICD10PCS'
        ELSE NULL
    END                                         AS source_vocabulary_id,
    
    src.date_service                            AS event_start_date,
    src.date_service                            AS event_end_date,
    0                                           AS event_type_concept_id,
-- --
    COALESCE(src.procedure_modifier_1,
             src.procedure_modifier_2,
             src.procedure_modifier_3,
             src.procedure_modifier_4)          AS modifier_source_value,
-- --
    p.person_id                                 AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)              AS provider_source_value,
-- --
    'medical_claims.reversed.procedure'         AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.load_row_id                             AS load_row_id,
    src.p_hvid                                  AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.procedure_code IS NOT NULL
    AND src.logical_delete_reason = 'REVERSAL TO ORIGINAL CLAIM'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule medical_claims.pended.procedure
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_proc
    @source_table: @target_schema.src_medical_claims,
                   @target_schema.lk_person
    @summary: rule medical_claims.pended.procedure records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_proc
SELECT
    src.procedure_code                          AS event_source_value,
    NULL                                        AS source_vocabulary_id,
    src.date_service                            AS event_start_date,
    src.date_service                            AS event_end_date,
    618555                                      AS event_type_concept_id,  -- Pending result
-- --
    NULL                                        AS modifier_source_value,
-- --
    p.person_id                                 AS person_id,

    COALESCE(src.prov_rendering_npi,
             src.prov_billing_npi)              AS provider_source_value,
-- --
    'medical_claims.pended.procedure'           AS rule_id,
    src.load_table_id                           AS load_table_id,
    src.load_row_id                             AS load_row_id,
    src.p_hvid                                  AS p_hvid
FROM
    @target_schema.src_medical_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.procedure_code IS NOT NULL
    AND src.logical_delete_reason = 'PENDED FOR ADJUDICATION'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------