-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate field visit_occurrence_id in the VISIT_DETAIl table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail;
CREATE TABLE @target_schema.tmp_visit_detail
(
    visit_detail_id                 BIGINT,
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_start_date         DATE,
    visit_detail_start_datetime     TIMESTAMP,
    visit_detail_end_date           DATE,
    visit_detail_end_datetime       TIMESTAMP,
    visit_detail_type_concept_id    INTEGER,
    provider_id                     BIGINT,
    care_site_id                    BIGINT,
    visit_detail_source_value       STRING,
    visit_detail_source_concept_id  INTEGER,
    admitted_from_concept_id        INTEGER,
    admitted_from_source_value      STRING,
    discharged_to_source_value      STRING,
    discharged_to_concept_id        INTEGER,
    preceding_visit_detail_id       BIGINT,
    parent_visit_detail_id          BIGINT,
    visit_occurrence_id             BIGINT,
-- --
    p_hvid                          STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Populate tmp_visit_detail
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_detail
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_visit_detail
    @summary: final cdm insert
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_detail
SELECT
    src.visit_detail_id                     AS visit_detail_id,
    src.person_id                           AS person_id,
    src.visit_detail_concept_id             AS visit_detail_concept_id,
    src.visit_detail_start_date             AS visit_detail_start_date,
    src.visit_detail_start_datetime         AS visit_detail_start_datetime,
    src.visit_detail_end_date               AS visit_detail_end_date,
    src.visit_detail_end_datetime           AS visit_detail_end_datetime,
    src.visit_detail_type_concept_id        AS visit_detail_type_concept_id,
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,
    src.visit_detail_source_concept_id      AS visit_detail_source_concept_id,
    src.admitted_from_concept_id            AS admitted_from_concept_id,
    src.admitted_from_source_value          AS admitted_from_source_value,
    src.discharged_to_source_value          AS discharged_to_source_value,
    src.discharged_to_concept_id            AS discharged_to_concept_id,
    src.preceding_visit_detail_id           AS preceding_visit_detail_id,
    src.parent_visit_detail_id              AS parent_visit_detail_id,
    lk.visit_occurrence_id                  AS visit_occurrence_id,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id
FROM
    @target_schema.cdm_visit_detail src
LEFT JOIN
    @target_schema.lk_visit_detail lk
        ON lk.visit_detail_id = src.visit_detail_id
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Final CDM insert into cdm_visit_detail
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_visit_detail;
/*!
    @insert
    @table: @target_schema.cdm_visit_detail
    @source_table: @target_schema.tmp_visit_detail
    @summary: final cdm insert
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_visit_detail
SELECT
    src.visit_detail_id                     AS visit_detail_id,
    src.person_id                           AS person_id,
    src.visit_detail_concept_id             AS visit_detail_concept_id,
    src.visit_detail_start_date             AS visit_detail_start_date,
    src.visit_detail_start_datetime         AS visit_detail_start_datetime,
    src.visit_detail_end_date               AS visit_detail_end_date,
    src.visit_detail_end_datetime           AS visit_detail_end_datetime,
    src.visit_detail_type_concept_id        AS visit_detail_type_concept_id,
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,
    src.visit_detail_source_value           AS visit_detail_source_value,
    src.visit_detail_source_concept_id      AS visit_detail_source_concept_id,
    src.admitted_from_concept_id            AS admitted_from_concept_id,
    src.admitted_from_source_value          AS admitted_from_source_value,
    src.discharged_to_source_value          AS discharged_to_source_value,
    src.discharged_to_concept_id            AS discharged_to_concept_id,
    src.preceding_visit_detail_id           AS preceding_visit_detail_id,
    src.parent_visit_detail_id              AS parent_visit_detail_id,
    src.visit_occurrence_id                 AS visit_occurrence_id,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    src.rule_id                             AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id
FROM
    @target_schema.tmp_visit_detail src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------