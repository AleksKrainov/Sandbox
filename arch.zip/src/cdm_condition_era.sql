﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*!
    @docpage
    @pagename: Eras
!*/

DROP TABLE IF EXISTS @cdm_schema.tmp_target_condition;
CREATE TABLE @cdm_schema.tmp_target_condition
(
    condition_occurrence_id             bigint,
    person_id                           bigint,
    condition_concept_id                int,
    condition_start_date                date,
    condition_end_date                  date,
    p_hvid                              string
)
@PROPERTY
;
/*!
    @insert
    @table: @cdm_schema.tmp_target_condition
    @source_table: @target_schema.cdm_condition_occurrence
    @summary:
    Defining spans of time when the
    Person is assumed to have a given
    condition.
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @cdm_schema.tmp_target_condition
SELECT
    co.condition_occurrence_id                                              AS condition_occurrence_id,
    co.person_id                                                            AS person_id,
    co.condition_concept_id                                                 AS condition_concept_id,
    co.condition_start_date                                                 AS condition_start_date,
    COALESCE( co.condition_end_date,
              CAST (DATEADD('day', , ) AS date))         AS condition_end_date,
    co.p_hvid                                                               AS p_hvid
    -- Depending on the needs of data, include more filters in cteConditionTarget
    -- For example
    -- - to exclude unmapped condition_concept_id's (i.e. condition_concept_id = 0)
          -- from being included in same era
    -- - to set condition_era_end_date to same condition_era_start_date
          -- or condition_era_start_date + INTERVAL '1 day', when condition_end_date IS NULL
FROM
    @target_schema.cdm_condition_occurrence co
WHERE
    co.condition_concept_id != 0
    -- partition filter
    AND co.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @cdm_schema.tmp_dates_un_condition;
CREATE TABLE @cdm_schema.tmp_dates_un_condition
(
    person_id                           bigint,
    condition_concept_id                int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @cdm_schema.tmp_dates_un_condition
    SELECT
        person_id                               AS person_id,
        condition_concept_id                    AS condition_concept_id,
        CAST(condition_start_date AS date)      AS event_date,
        -1                                      AS event_type,
        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                condition_concept_id
            ORDER BY
                condition_start_date)           AS start_ordinal,
        p_hvid                                  AS p_hvid
    FROM
        @cdm_schema.tmp_target_condition
    WHERE
        p_hvid = '@hvid_char'
UNION ALL
    SELECT
        person_id                                             AS person_id,
        condition_concept_id                                  AS condition_concept_id,
        CAST( DATEADD('day', , ) AS date)      AS event_date,
        1                                                     AS event_type,
        NULL                                                  AS start_ordinal,
        p_hvid                                                AS p_hvid
    FROM
        @cdm_schema.tmp_target_condition
    WHERE
        p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @cdm_schema.tmp_dates_rows_condition;
CREATE TABLE @cdm_schema.tmp_dates_rows_condition
(
    person_id                           bigint,
    condition_concept_id                int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    overall_ord                         int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @cdm_schema.tmp_dates_rows_condition
SELECT
    person_id                       AS person_id,
    condition_concept_id            AS condition_concept_id,
    event_date                      AS event_date,
    event_type                      AS event_type,
    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            condition_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)   AS start_ordinal,
        -- this pulls the current START down from the prior rows
        -- so that the NULLs from the END DATES will contain a value we can compare with
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            condition_concept_id
        ORDER BY
            event_date,
            event_type)             AS overall_ord,
        -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
    p_hvid                          AS p_hvid
FROM
    @cdm_schema.tmp_dates_un_condition
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @cdm_schema.tmp_enddates_condition;
CREATE TABLE @cdm_schema.tmp_enddates_condition
(
    person_id                           bigint,
    condition_concept_id                int,
    end_date                            date,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @cdm_schema.tmp_enddates_condition
SELECT
    person_id                                   AS person_id,
    condition_concept_id                        AS condition_concept_id,
    CAST (DATEADD('day', -, ) AS date)    AS end_date,    -- unpad the end date
    p_hvid                                      AS p_hvid
FROM
    @cdm_schema.tmp_dates_rows_condition e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
    AND e.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @cdm_schema.tmp_conditionends;
CREATE TABLE @cdm_schema.tmp_conditionends
(
    person_id                           bigint,
    condition_concept_id                int,
    condition_start_date                date,
    era_end_date                        date,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @cdm_schema.tmp_conditionends
SELECT
    c.person_id                         AS person_id,
    c.condition_concept_id              AS condition_concept_id,
    c.condition_start_date              AS condition_start_date,
    CAST (MIN (e.end_date) AS date)     AS era_end_date,
    c.p_hvid                            AS p_hvid
FROM
    @cdm_schema.tmp_target_condition c
JOIN
    @cdm_schema.tmp_enddates_condition e
        ON  c.person_id            = e.person_id
        AND c.condition_concept_id = e.condition_concept_id
        AND e.end_date             >= c.condition_start_date
WHERE
        c.p_hvid = '@hvid_char'
    AND e.p_hvid = '@hvid_char'
GROUP BY
    c.condition_occurrence_id,
    c.person_id,
    c.condition_concept_id,
    c.condition_start_date,
    c.p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load Table: Condition_era
-- -------------------------------------------------------------------
TRUNCATE TABLE @cdm_schema.cdm_condition_era;
/*!
    @insert
    @table: @cdm_schema.cdm_condition_era
    @source_table: @cdm_schema.tmp_target_condition
    @summary: It is derived from the records in
    the CONDITION_OCCURRENCE table using
    a standardized algorithm.
    30 days window is allowed.
!*/
INSERT INTO @cdm_schema.cdm_condition_era
SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS condition_era_id,
    person_id                                       AS person_id,
    condition_concept_id                            AS condition_concept_id,
    CAST (MIN (condition_start_date) AS date)       AS condition_era_start_date,
    era_end_date                                    AS condition_era_end_date,
    COUNT(*)                                        AS condition_occurrence_count,
-- --
    'CDM.condition_occurrence.<condition_era>'      AS rule_id,
    NULL                                            AS load_table_id,
    NULL                                            AS load_row_id
FROM
    @cdm_schema.tmp_conditionends
GROUP BY
    person_id,
    condition_concept_id,
    era_end_date
ORDER BY
    person_id,
    condition_concept_id
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @cdm_schema.tmp_conditionends;
DROP TABLE IF EXISTS @cdm_schema.tmp_enddates_condition;
DROP TABLE IF EXISTS @cdm_schema.tmp_dates_rows_condition;
DROP TABLE IF EXISTS @cdm_schema.tmp_dates_un_condition;
DROP TABLE IF EXISTS @cdm_schema.tmp_target_condition;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------