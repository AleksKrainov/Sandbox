﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: Payer plan period
!*/

-- -------------------------------------------------------------------
-- Lookup table LK_ENROLL_2
-- -------------------------------------------------------------------

-- Step 1:
DROP TABLE IF EXISTS @target_schema.lk_enroll_1;
CREATE TABLE @target_schema.lk_enroll_1
AS SELECT DISTINCT
    per.person_id           AS person_id,
    src.date_start          AS date_start,
    src.date_end            AS date_end,
    src.benefit_type        AS benefit_type,
    src.payer_type          AS payer_type,
-- --
    'enrollment'            AS rule_id,
    src.load_table_id       AS load_table_id,
    src.load_row_id         AS load_row_id
FROM
    @target_schema.src_enrollment src
INNER JOIN
    @target_schema.lk_person per
        ON per.person_source_value = src.hvid
WHERE
    src.hvid IS NOT NULL
    AND src.date_start IS NOT NULL
    AND src.date_start <= src.date_end
    AND src.date_start <= CAST('@max_date_of_dataset' AS DATE)
    AND src.date_end IS NOT NULL
;


DROP TABLE IF EXISTS @target_schema.lk_nested_enroll;
CREATE TABLE @target_schema.lk_nested_enroll
AS SELECT
    person_id                       AS person_id,
    date_start                      AS date_start,
    date_end                        AS date_end,
    payer_type                      AS payer_type,
    benefit_type                    AS benefit_type,
    MAX(nested_enrollment_flag)     AS nested_enrollment_flag,
-- --
    MIN(rule_id)                    AS rule_id,
    MIN(load_table_id)              AS load_table_id,
    MIN(load_row_id)                AS load_row_id
FROM
(
    SELECT
        a.person_id         AS person_id,
        a.date_start        AS date_start,
        a.date_end          AS date_end,
        a.payer_type        AS payer_type,
        a.benefit_type      AS benefit_type,
        CASE 
            WHEN (a.date_start >= b.date_start
                 AND a.date_end < b.date_end
                 AND (a.payer_type = b.payer_type 
                     OR (a.payer_type IS NULL AND b.payer_type IS NULL))
                 AND (a.benefit_type = b.benefit_type
                     OR (a.benefit_type IS NULL AND b.benefit_type IS NULL)))
                 OR (a.date_start > b.date_start
                    AND a.date_end <= b.date_end
                    AND (a.payer_type = b.payer_type
                        OR (a.payer_type IS NULL AND b.payer_type IS NULL))
                    AND (a.benefit_type = b.benefit_type
                        OR (a.benefit_type IS NULL AND b.benefit_type IS NULL)))
            THEN 1 
            ELSE 0 
        END                 AS nested_enrollment_flag,
    -- --
        a.rule_id           AS rule_id,
        a.load_table_id     AS load_table_id,
        a.load_row_id       AS load_row_id
    FROM
        @target_schema.lk_enroll_1 a
    INNER JOIN
        @target_schema.lk_enroll_1 b
            ON a.person_id = b.person_id
    WHERE
        a.date_start IS NOT NULL
        AND a.date_end IS NOT NULL
        AND a.date_end >= a.date_start
)
GROUP BY
    person_id,
    date_start,
    date_end,
    payer_type,
    benefit_type
;


-- Step 2:
DROP TABLE IF EXISTS @target_schema.lk_enroll_2;
CREATE TABLE @target_schema.lk_enroll_2
AS SELECT DISTINCT
    person_id                       AS person_id,
    payer_type                      AS payer_type,
    benefit_type                    AS benefit_type,

    MIN(date_start) OVER (
        PARTITION BY
            person_id,
            payer_type,
            benefit_type,
            enrollment_period_id)   AS new_date_start,

    MAX(date_end) OVER (
        PARTITION BY
            person_id,
            payer_type,
            benefit_type,
            enrollment_period_id)   AS new_date_end,
-- --
    rule_id                         AS rule_id,
    load_table_id                   AS load_table_id,

    MIN(load_row_id) OVER (
        PARTITION BY
            person_id,
            payer_type,
            benefit_type,
            enrollment_period_id)   AS load_row_id
FROM
    (
        SELECT
            *,
            SUM(CASE
                    WHEN previous_date_end + 30 >= date_start
                    THEN 0
                    ELSE 1
                END) OVER (
                    PARTITION BY
                        person_id,
                        payer_type,
                        benefit_type
                    ORDER BY
                        rn
                    ROWS BETWEEN UNBOUNDED PRECEDING
                        AND CURRENT ROW)    AS enrollment_period_id 
        FROM
            (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY
                            person_id,
                            payer_type,
                            benefit_type
                        ORDER BY
                            date_start,
                            date_end)       AS rn,

                    LAG(date_end, 1) OVER (
                        PARTITION BY
                            person_id,
                            payer_type,
                            benefit_type
                        ORDER BY
                            date_start,
                            date_end)       AS previous_date_end
                FROM
                    @target_schema.lk_nested_enroll
                WHERE
                    nested_enrollment_flag = 0
            ) a
    ) b
;


-- -------------------------------------------------------------------
-- Load Table: Payer plan period
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_payer_plan_period;
/*!
    @insert
    @table: @target_schema.cdm_payer_plan_period
    @source_table: @target_schema.lk_enroll_2
    @summary: 
!*/
INSERT INTO @target_schema.cdm_payer_plan_period
SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS payer_plan_period_id,
    src.person_id                           AS person_id,
    src.new_date_start                      AS payer_plan_period_start_date,
    src.new_date_end                        AS payer_plan_period_end_date,
    COALESCE(lkc1.target_concept_id, 0)     AS payer_concept_id,
    src.payer_type                          AS payer_source_value,
    0                                       AS payer_source_concept_id,
    COALESCE(lkc2.target_concept_id, 0)     AS plan_concept_id,
    src.benefit_type                        AS plan_source_value,
    0                                       AS plan_source_concept_id,
    0                                       AS sponsor_concept_id,
    CAST(NULL AS STRING)                    AS sponsor_source_value,
    CAST(NULL AS INTEGER)                   AS sponsor_source_concept_id,
    CAST(NULL AS STRING)                    AS family_source_value,
    0                                       AS stop_reason_concept_id,
    CAST(NULL AS STRING)                    AS stop_reason_source_value,
    0                                       AS stop_reason_source_concept_id,
-- --
    'enrollment'                            AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id
FROM
    @target_schema.lk_enroll_2 src
LEFT JOIN
    @target_schema.lk_concept lkc1
        ON  lkc1.src_code = src.payer_type
        AND lkc1.source_vocabulary_id = 'HV_PAYER'
LEFT JOIN
    @target_schema.lk_concept lkc2
        ON  lkc2.src_code = src.benefit_type
        AND lkc2.source_vocabulary_id = 'HV_BENEFIT_TYPE'
;

/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_enroll_1;
DROP TABLE IF EXISTS @target_schema.lk_nested_enroll;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------