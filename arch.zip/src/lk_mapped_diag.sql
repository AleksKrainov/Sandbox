-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate lookup table lk_mapped_diag
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.lk_mapped_diag;
CREATE TABLE @target_schema.lk_mapped_diag
(
    event_source_value              STRING,
    event_concept_id                INTEGER,
    event_source_concept_id         INTEGER,
    value_as_string                 STRING,
    value_as_concept_id             INTEGER,
    value_as_number                 DOUBLE,
    unit_source_value               STRING,
    unit_concept_id                 INTEGER,
    event_start_date                DATE,
    event_end_date                  DATE,
    domain_id                       STRING,
    event_type_concept_id           INTEGER,
-- --
    person_id                       BIGINT,
    provider_id                     BIGINT,
    visit_occurrence_id             BIGINT,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Join to provider, visit occurrence
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_diag_prov_cs;
CREATE TABLE @target_schema.tmp_diag_prov_cs
(
    person_id               BIGINT,
    provider_id             BIGINT,
    care_site_id            BIGINT,
    event_start_date        DATE,
-- --
    load_table_id           STRING,
    load_row_id             BIGINT,
    p_hvid                  STRING
)
@PROPERTY
;

/*!
    @insert
    @table: @target_schema.tmp_diag_prov_cs
    @source_table: @target_schema.lk_event_diag,
                   @target_schema.cdm_provider,
                   @target_schema.cdm_care_site
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_diag_prov_cs
SELECT /*+ MERGE (prov, cs) */
    lk.person_id            AS person_id,
    prov.provider_id        AS provider_id,
    cs.care_site_id         AS care_site_id,
    lk.event_start_date     AS event_start_date,
-- --
    lk.load_table_id        AS load_table_id,
    lk.load_row_id          AS load_row_id,
    lk.p_hvid               AS p_hvid
FROM
    @target_schema.lk_event_diag lk
LEFT JOIN
    @target_schema.cdm_provider prov
        ON prov.provider_source_value = lk.provider_source_value
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON cs.care_site_source_value = lk.care_site_source_value
WHERE
    lk.p_hvid = '@hvid_char'
--@FOR_END
;


DROP TABLE IF EXISTS @target_schema.tmp_diag_vis;
CREATE TABLE @target_schema.tmp_diag_vis
(
    visit_occurrence_id     BIGINT,
    provider_id             BIGINT,
-- --
    load_table_id           STRING,
    load_row_id             BIGINT,
    p_hvid                  STRING
)
@PROPERTY
;

/*!
    @insert
    @table: @target_schema.tmp_diag_vis
    @source_table: @target_schema.tmp_diag_prov_cs,
                   @target_schema.cdm_visit_occurrence
    @summary: join to Visit for pharmacy_claims records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_diag_vis
SELECT
    vo.visit_occurrence_id      AS visit_occurrence_id,
    lk.provider_id              AS provider_id,
-- --
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.tmp_diag_prov_cs lk
LEFT JOIN
    @target_schema.cdm_visit_occurrence vo
        ON  vo.person_id = lk.person_id
        AND vo.visit_start_date = lk.event_start_date
        AND vo.provider_id = lk.provider_id
        AND vo.care_site_id = lk.care_site_id
        AND vo.load_table_id LIKE 'pharmacy_claims%'
WHERE
    lk.load_table_id LIKE 'pharmacy_claims%'
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

/*!
    @insert
    @table: @target_schema.tmp_diag_vis
    @source_table: @target_schema.tmp_diag_prov_cs,
                   @target_schema.lk_visit_detail
    @summary: join to Visit for medical_claims records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_diag_vis
SELECT
    vd.visit_occurrence_id      AS visit_occurrence_id,
    lk.provider_id              AS provider_id,
-- --
    lk.load_table_id            AS load_table_id,
    lk.load_row_id              AS load_row_id,
    lk.p_hvid                   AS p_hvid
FROM
    @target_schema.tmp_diag_prov_cs lk
LEFT JOIN
    @target_schema.lk_load_row_id_medical_claims rd
        ON rd.load_row_id = lk.load_row_id
LEFT JOIN
    @target_schema.lk_visit_detail vd
        ON vd.load_row_id = rd.new_load_row_id
WHERE
    lk.load_table_id = 'medical_claims'
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Populating lk_mapped_diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_mapped_diag
    @source_table: @target_schema.lk_event_diag
    @summary: Take event record from lk_event_diag
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_mapped_diag
SELECT /*+ BROADCAST (lkc1, lkc2) */
    lk.event_source_value                       AS event_source_value,
    COALESCE(lkc1.target_concept_id,
             lkc2.target_concept_id, 0)         AS event_concept_id,
    COALESCE(lkc1.source_concept_id,
             lkc2.source_concept_id, 0)         AS event_source_concept_id,
    NULL                                        AS value_as_string,
    COALESCE(lkc1.value_as_concept_id,
             lkc2.value_as_concept_id)          AS value_as_concept_id,
    NULL                                        AS value_as_number,
    NULL                                        AS unit_source_value,
    NULL                                        AS unit_concept_id,
    lk.event_start_date                         AS event_start_date,
    lk.event_end_date                           AS event_end_date,
    COALESCE(lkc1.domain_id,
             lkc2.domain_id, 'Condition')       AS domain_id,
    lk.event_type_concept_id                    AS event_type_concept_id,
-- --
    lk.person_id                                AS person_id,
    v.provider_id                               AS provider_id,
    v.visit_occurrence_id                       AS visit_occurrence_id,
-- --
    lk.rule_id                                  AS rule_id,
    lk.load_table_id                            AS load_table_id,
    lk.load_row_id                              AS load_row_id,
    lk.p_hvid                                   AS p_hvid
FROM
    @target_schema.lk_event_diag lk
LEFT JOIN
    @target_schema.lk_concept lkc1
        ON  lk.event_source_value   = lkc1.src_code
        AND lkc1.src_code_type      = 'diag_code'
        AND lk.source_vocabulary_id = lkc1.source_vocabulary_id
LEFT JOIN
    @target_schema.lk_concept lkc2
        ON  lk.event_source_value = lkc2.src_code
        AND lkc2.src_code_type    = 'diag_code'
        AND lk.source_vocabulary_id IS NULL
        AND lkc2.ambig_mapping    = 0
LEFT JOIN
    @target_schema.tmp_diag_vis v
        ON  lk.load_row_id   = v.load_row_id
        AND lk.load_table_id = v.load_table_id
        AND v.p_hvid = '@hvid_char'
WHERE
    -- partition filter
    lk.p_hvid = '@hvid_char'
--@FOR_END
;


/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_diag_vis;
DROP TABLE IF EXISTS @target_schema.tmp_diag_prov_cs;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------