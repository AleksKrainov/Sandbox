-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: CDM Observation
!*/

-- -------------------------------------------------------------------
-- OBSERVATION table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_observation;
CREATE TABLE @target_schema.tmp_observation
(
    person_id                   bigint,
    target_concept_id           int,
    event_start_date            timestamp,
    type_concept_id             int,
    value_as_number             double,
    value_as_string             string,
    value_as_concept_id         int,
    value_source_value          string,
    qualifier_concept_id        int,
    unit_concept_id             int,
    provider_id                 bigint,
    visit_occurrence_id         bigint,
    event_source_value          string,
    source_concept_id           int,
    unit_source_value           string,
    qualifier_source_value      string,
-- --
    rule_id                     string,
    load_table_id               string,
    load_row_id                 bigint,
    p_hvid                      string
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- From lk_mapped_diag
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_observation
    @source_table: @target_schema.lk_mapped_diag
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_observation
SELECT
    lk.person_id                    AS person_id,
    lk.event_concept_id             AS target_concept_id,
    lk.event_start_date             AS event_start_date,
    lk.event_type_concept_id        AS type_concept_id,
    lk.value_as_number              AS value_as_number,
    lk.value_as_string              AS value_as_string,
    lk.value_as_concept_id          AS value_as_concept_id,
    NULL                            AS value_source_value,
    0                               AS qualifier_concept_id,
    lk.unit_concept_id              AS unit_concept_id,
    lk.provider_id                  AS provider_id,
    lk.visit_occurrence_id          AS visit_occurrence_id,
    lk.event_source_value           AS event_source_value,
    lk.event_source_concept_id      AS source_concept_id,
    lk.unit_source_value            AS unit_source_value,
    NULL                            AS qualifier_source_value,
-- --
    lk.rule_id                      AS rule_id,
    lk.load_table_id                AS load_table_id,
    lk.load_row_id                  AS load_row_id,
    lk.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_mapped_diag lk
WHERE
    lk.domain_id = 'Observation'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- From lk_mapped_proc
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_observation
    @source_table: @target_schema.lk_mapped_proc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_observation
SELECT
    lk.person_id                    AS person_id,
    lk.event_concept_id             AS target_concept_id,
    lk.event_start_date             AS event_start_date,
    lk.event_type_concept_id        AS type_concept_id,
    lk.value_as_number              AS value_as_number,
    lk.value_as_string              AS value_as_string,
    lk.value_as_concept_id          AS value_as_concept_id,
    NULL                            AS value_source_value,
    0                               AS qualifier_concept_id,
    lk.unit_concept_id              AS unit_concept_id,
    lk.provider_id                  AS provider_id,
    lk.visit_occurrence_id          AS visit_occurrence_id,
    lk.event_source_value           AS event_source_value,
    lk.event_source_concept_id      AS source_concept_id,
    lk.unit_source_value            AS unit_source_value,
    NULL                            AS qualifier_source_value,
-- --
    lk.rule_id                      AS rule_id,
    lk.load_table_id                AS load_table_id,
    lk.load_row_id                  AS load_row_id,
    lk.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_mapped_proc lk
WHERE
    lk.domain_id = 'Observation'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's and Post Dedupe
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_observation_id;
CREATE TABLE @target_schema.tmp_observation_id
@PROPERTY AS SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS observation_id,
    o.*
FROM
    @target_schema.tmp_observation o
WHERE
    o.event_start_date BETWEEN CAST('@min_date_of_dataset' AS DATE)
                           AND CAST('@max_date_of_dataset' AS DATE)
;

DROP TABLE IF EXISTS @target_schema.tmp_observation_dedupe_map;
CREATE TABLE @target_schema.tmp_observation_dedupe_map
(
    new_observation_id      BIGINT,
    observation_id          BIGINT,
    p_hvid                  STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_observation_dedupe_map
    @source_table: @target_schema.tmp_observation_id
    @summary: The same ID is assigned for the duplicates
    on the following fields:
    - person_id,
    - observation_concept_id,
    - observation_date,
    - observation_type_concept_id,
    - value_as_number,
    - value_as_string,
    - value_as_concept_id,
    - unit_concept_id,
    - provider_id,
    - visit_occurrence_id,
    - observation_source_value,
    - observation_source_concept_id,
    - unit_source_value
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_observation_dedupe_map
SELECT
    MIN(t.observation_id) OVER (
        PARTITION BY
            t.person_id,
            t.target_concept_id,
            t.event_start_date,
            t.type_concept_id,
            t.value_as_concept_id,
            t.value_as_number,
            t.value_as_string,
            t.provider_id,
            t.event_source_value,
            t.source_concept_id,
            t.visit_occurrence_id,
            t.unit_source_value,
            t.unit_concept_id,
            t.value_source_value,
            t.qualifier_concept_id,
            t.qualifier_source_value
        )                   AS new_observation_id,
    t.observation_id        AS observation_id,
    t.p_hvid                AS p_hvid
FROM
    @target_schema.tmp_observation_id t
WHERE
    -- partition filter
    t.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load Table: Observation
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_observation;
/*!
    @insert
    @table: @target_schema.cdm_observation
    @source_table: @target_schema.tmp_observation_id
    @summary: populate cdm_observation
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_observation
SELECT
    t.observation_id                    AS observation_id,
    t.person_id                         AS person_id,
    t.target_concept_id                 AS observation_concept_id,
    t.event_start_date                  AS observation_date,
    NULL                                AS observation_datetime,
    t.type_concept_id                   AS observation_type_concept_id,
    t.value_as_number                   AS value_as_number,
    t.value_as_string                   AS value_as_string,
    t.value_as_concept_id               AS value_as_concept_id,
    t.qualifier_concept_id              AS qualifier_concept_id,
    NULLIF(t.unit_concept_id, 0)        AS unit_concept_id,
    t.provider_id                       AS provider_id,
    t.visit_occurrence_id               AS visit_occurrence_id,
    NULL                                AS visit_detail_id,
    t.event_source_value                AS observation_source_value,
    t.source_concept_id                 AS observation_source_concept_id,
    t.unit_source_value                 AS unit_source_value,
    t.qualifier_source_value            AS qualifier_source_value,
    t.value_source_value                AS value_source_value,
    NULL                                AS observation_event_id,
    NULL                                AS obs_event_field_concept_id,
-- --
    t.p_hvid                            AS p_hvid,
    t.rule_id                           AS rule_id,
    t.load_table_id                     AS load_table_id,
    t.load_row_id                       AS load_row_id
FROM
    @target_schema.tmp_observation_id t
WHERE
    EXISTS
        (
            SELECT 1
              FROM @target_schema.tmp_observation_dedupe_map dm
             WHERE dm.new_observation_id = t.observation_id
               AND dm.p_hvid = '@hvid_char'
        )
    AND t.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_observation;
DROP TABLE IF EXISTS @target_schema.tmp_observation_id;
DROP TABLE IF EXISTS @target_schema.tmp_observation_dedupe_map;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/