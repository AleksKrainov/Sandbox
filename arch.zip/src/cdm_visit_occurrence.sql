﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Target Table: visit_occurrence
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Rule 2 (pharmacy_claims)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_pharmacy_claims_grp;
CREATE TABLE @target_schema.tmp_pharmacy_claims_grp
(
    person_id           BIGINT,
    date_service        DATE,
    provider_id         BIGINT,
    care_site_id        BIGINT,
-- --
    rule_id             STRING,
    load_table_id       STRING,
    load_row_id         BIGINT,
    p_hvid              STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_pharmacy_claims_grp
    @source_table: @source_schema.src_pharmacy_claims,
                   @target_schema.lk_person
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_pharmacy_claims_grp
SELECT
    pers.person_id              AS person_id,
    src.date_service            AS date_service,
    prov.provider_id            AS provider_id,
    cs.care_site_id             AS care_site_id,
-- --
    MIN(src.load_table_id)      AS rule_id,
    MIN(src.load_table_id)      AS load_table_id,
    MIN(src.load_row_id)        AS load_row_id,
-- --
    src.p_hvid                  AS p_hvid
FROM
    @source_schema.src_pharmacy_claims src
INNER JOIN
    @target_schema.lk_person pers
        ON src.hvid = pers.person_source_value
LEFT JOIN
    @target_schema.cdm_provider prov
        ON prov.provider_source_value = src.prov_prescribing_npi
LEFT JOIN
    @target_schema.cdm_care_site cs
        ON cs.care_site_source_value = src.pharmacy_npi
WHERE
    src.hvid IS NOT NULL
    AND src.date_service IS NOT NULL
    AND src.p_hvid = '@hvid_char'
    AND pers.p_hvid = '@hvid_char'
GROUP BY
    pers.person_id,
    src.date_service,
    prov.provider_id,
    cs.care_site_id,
    src.p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Insert into tmp_visit_occurrence
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.tmp_visit_occurrence
    @source_table: @source_schema.tmp_pharmacy_claims_grp
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_occurrence
SELECT
    (SELECT COALESCE(MAX(visit_occurrence_id), 0)
       FROM @target_schema.tmp_visit_occurrence)
        + 1 + ROW_NUMBER() OVER (ORDER BY NULL)   AS visit_occurrence_id,

    src.person_id                   AS person_id,
    581458                          AS visit_concept_id,  -- Pharmacy Visit
    src.date_service                AS visit_start_date,
    src.date_service                AS visit_start_datetime,
    src.date_service                AS visit_end_date,
    src.date_service                AS visit_end_datetime,
    32869                           AS visit_type_concept_id,  -- Pharmacy claim
    src.provider_id                 AS provider_id,
    src.care_site_id                AS care_site_id,
    CAST(NULL AS STRING)            AS visit_source_value,
    0                               AS visit_source_concept_id,
    0                               AS admitted_from_concept_id,
    CAST(NULL AS STRING)            AS admitted_from_source_value,
    0                               AS discharged_to_concept_id,
    CAST(NULL AS STRING)            AS discharged_to_source_value,
-- --
    src.p_hvid                      AS p_hvid,
-- --
    'pharmacy_claims.all_visits'    AS rule_id,
    src.load_table_id               AS load_table_id,
    src.load_row_id                 AS load_row_id
FROM
    @source_schema.tmp_pharmacy_claims_grp src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Populating preceding_visit_occurrence_id
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_preceding_visit_id;
CREATE TABLE @target_schema.tmp_preceding_visit_id
(
    visit_occurrence_id             BIGINT,
    preceding_visit_occurrence_id   BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_preceding_visit_id
    @source_table: @target_schema.tmp_visit_occurrence
    @summary: populating preceding_visit_occurrence_id
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_preceding_visit_id
SELECT
    src.visit_occurrence_id             AS visit_occurrence_id,

    LAG(src.visit_occurrence_id)
        OVER (
            PARTITION BY
                src.person_id
            ORDER BY
                src.visit_start_date)   AS preceding_visit_occurrence_id,

    src.p_hvid                          AS p_hvid
FROM
    @target_schema.tmp_visit_occurrence src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Final CDM insert into cdm_visit_occurrence
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_visit_occurrence;
/*!
    @insert
    @table: @target_schema.cdm_visit_occurrence
    @source_table: @target_schema.tmp_visit_occurrence,
                   @target_schema.tmp_preceding_visit_id
    @summary: final cdm insert
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_visit_occurrence
SELECT
    src.visit_occurrence_id             AS visit_occurrence_id,
    src.person_id                       AS person_id,
    src.visit_concept_id                AS visit_concept_id,
    src.visit_start_date                AS visit_start_date,
    src.visit_start_datetime            AS visit_start_datetime,
    src.visit_end_date                  AS visit_end_date,
    src.visit_end_datetime              AS visit_end_datetime,
    src.visit_type_concept_id           AS visit_type_concept_id,
    src.provider_id                     AS provider_id,
    src.care_site_id                    AS care_site_id,
    src.visit_source_value              AS visit_source_value,
    src.visit_source_concept_id         AS visit_source_concept_id,
    src.admitted_from_concept_id        AS admitted_from_concept_id,
    src.admitted_from_source_value      AS admitted_from_source_value,
    src.discharged_to_concept_id        AS discharged_to_concept_id,
    src.discharged_to_source_value      AS discharged_to_source_value,
    vid.preceding_visit_occurrence_id   AS preceding_visit_occurrence_id,
-- --
    src.p_hvid                          AS p_hvid,
-- --
    src.rule_id                         AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id
FROM
    @target_schema.tmp_visit_occurrence src
LEFT JOIN
    @target_schema.tmp_preceding_visit_id vid
        ON vid.visit_occurrence_id = src.visit_occurrence_id
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_pharmacy_claims_grp;
DROP TABLE IF EXISTS @target_schema.tmp_visit_occurrence;
DROP TABLE IF EXISTS @target_schema.tmp_preceding_visit_id;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------