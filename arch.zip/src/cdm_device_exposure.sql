-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

/*! @docpage
    @pagename: CDM Device Exposure
!*/

-- -------------------------------------------------------------------
-- Populate table: tmp_device_exposure
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_device;
CREATE TABLE @target_schema.tmp_device
(
    person_id               bigint,
    target_concept_id       int,
    event_start_date        timestamp,
    event_end_date          timestamp,
    type_concept_id         int,
    quantity                int,
    provider_id             bigint,
    visit_occurrence_id     bigint,
    event_source_value      string,
    source_concept_id       int,
    unit_concept_id         int,
    unit_source_value       string,
-- cost fields
    submitted_gross_due     double,
    paid_gross_due          double,
    cost_flag               integer,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- From lk_mapped_proc
-- ------------------------------------ -------------------------------
/*!
    @insert
    @table: @target_schema.tmp_device
    @source_table: @target_schema.lk_mapped_proc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_device
SELECT
    lk.person_id                    AS person_id,
    lk.event_concept_id             AS target_concept_id,
    lk.event_start_date             AS event_start_date,
    lk.event_end_date               AS event_end_date,
    lk.event_type_concept_id        AS type_concept_id,
    1                               AS quantity,
    lk.provider_id                  AS provider_id,
    lk.visit_occurrence_id          AS visit_occurrence_id,
    lk.event_source_value           AS event_source_value,
    lk.event_source_concept_id      AS source_concept_id,
    lk.unit_concept_id              AS unit_concept_id,
    lk.unit_source_value            AS unit_source_value,
-- cost fields
    NULL                            AS submitted_gross_due,
    NULL                            AS paid_gross_due,
    NULL                            AS cost_flag,
-- --
    lk.rule_id                      AS rule_id,
    lk.load_table_id                AS load_table_id,
    lk.load_row_id                  AS load_row_id,
    lk.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_mapped_proc lk
WHERE
    lk.domain_id = 'Device'
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- From lk_mapped_ndc
-- ------------------------------------ -------------------------------
/*!
    @insert
    @table: @target_schema.tmp_device
    @source_table: @target_schema.lk_mapped_ndc
    @summary:
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_device
SELECT
    lk.person_id                    AS person_id,
    lk.event_concept_id             AS target_concept_id,
    lk.event_start_date             AS event_start_date,

    LEAST(lk.event_end_date,
          CAST('@max_date_of_dataset' AS DATE))
                                    AS event_end_date,

    lk.event_type_concept_id        AS type_concept_id,
    COALESCE(lk.quantity, 1)        AS quantity,
    lk.provider_id                  AS provider_id,
    lk.visit_occurrence_id          AS visit_occurrence_id,
    lk.event_source_value           AS event_source_value,
    lk.event_source_concept_id      AS source_concept_id,
    lk.unit_concept_id              AS unit_concept_id,
    lk.unit_source_value            AS unit_source_value,
-- cost fields
    lk.submitted_gross_due          AS submitted_gross_due,
    lk.paid_gross_due               AS paid_gross_due,
    lk.cost_flag                    AS cost_flag,
-- --
    lk.rule_id                      AS rule_id,
    lk.load_table_id                AS load_table_id,
    lk.load_row_id                  AS load_row_id,
    lk.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_mapped_ndc lk
WHERE
    lk.domain_id = 'Device'
    AND lk.event_start_date <= LEAST(lk.event_end_date,
                                     CAST('@max_date_of_dataset' AS DATE))
    -- partition filter
    AND lk.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Assignment of id's and Post Dedupe
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_device_id;
CREATE TABLE @target_schema.tmp_device_id
@PROPERTY AS
SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS device_exposure_id,
    de.*
FROM
    @target_schema.tmp_device de
WHERE
    de.event_start_date >= CAST('@min_date_of_dataset' AS DATE)
;

DROP TABLE IF EXISTS @target_schema.tmp_device_dedupe_map;
CREATE TABLE @target_schema.tmp_device_dedupe_map
(
    new_device_exposure_id      BIGINT,
    device_exposure_id          BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_device_dedupe_map
    @source_table: @target_schema.tmp_device_id
    @summary: Group the data to remove duplicates during the next step:
    - person_id,
    - device_concept_id,
    - device_exposure_start_date,
    - device_exposure_end_date,
    - device_type_concept_id,
    - quantity,
    - provider_id,
    - visit_occurrence_id,
    - device_source_value,
    - device_source_concept_id,
    - unit_concept_id,
    - unit_source_value
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTo @target_schema.tmp_device_dedupe_map
SELECT
    MIN(t.device_exposure_id) OVER (
        PARTITION BY
            t.person_id,
            t.target_concept_id,
            t.event_start_date,
            t.event_end_date,
            t.type_concept_id,
            t.quantity,
            t.provider_id,
            t.visit_occurrence_id,
            t.event_source_value,
            t.source_concept_id,
            t.unit_concept_id,
            t.unit_source_value
        )                   AS new_device_exposure_id,
    t.device_exposure_id    AS device_exposure_id,
    t.p_hvid                AS p_hvid
FROM
    @target_schema.tmp_device_id t
WHERE
    -- partition filter
    t.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.lk_device_cost;
CREATE TABLE @target_schema.lk_device_cost
(
    device_exposure_id      bigint,
    submitted_gross_due     double,
    paid_gross_due          double,
-- --
    rule_id                 string,
    load_table_id           string,
    load_row_id             bigint,
    p_hvid                  string
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.lk_device_cost
    @source_table: @target_schema.tmp_device_id, @target_schema.tmp_device_dedupe_map
    @summary: Lookup for cost-related Device data
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_device_cost
SELECT
    dm.new_device_exposure_id       AS device_exposure_id,
-- cost fields
    t.submitted_gross_due           AS submitted_gross_due,
    t.paid_gross_due                AS paid_gross_due,
-- --
    t.rule_id                       AS rule_id,
    t.load_table_id                 AS load_table_id,
    t.load_row_id                   AS load_row_id,
    t.p_hvid                        AS p_hvid
FROM
    @target_schema.tmp_device_id t
INNER JOIN
    @target_schema.tmp_device_dedupe_map dm
        ON  dm.device_exposure_id = t.device_exposure_id
        AND dm.p_hvid = '@hvid_char'
WHERE
    t.cost_flag = 1
    -- partition filter
    AND t.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load table: Device Exposure
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_device_exposure;
/*!
    @insert
    @table: @target_schema.cdm_device_exposure
    @source_table: @target_schema.tmp_device
    @summary: remove duplicates
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.cdm_device_exposure
SELECT
    t.device_exposure_id    AS device_exposure_id,
    t.person_id             AS person_id,
    t.target_concept_id     AS device_concept_id,
    t.event_start_date      AS device_exposure_start_date,
    NULL                    AS device_exposure_start_datetime,
    t.event_end_date        AS device_exposure_end_date,
    NULL                    AS device_exposure_end_datetime,
    t.type_concept_id       AS device_type_concept_id,
    NULL                    AS unique_device_id,
    NULL                    AS production_id,
    t.quantity              AS quantity,
    t.provider_id           AS provider_id,
    t.visit_occurrence_id   AS visit_occurrence_id,
    NULL                    AS visit_detail_id,
    t.event_source_value    AS device_source_value,
    t.source_concept_id     AS device_source_concept_id,
    t.unit_concept_id       AS unit_concept_id,
    t.unit_source_value     AS unit_source_value,
    NULL                    AS unit_source_concept_id,
-- --
    t.p_hvid                AS p_hvid,
    t.rule_id               AS rule_id,
    t.load_table_id         AS load_table_id,
    t.load_row_id           AS load_row_id
FROM
    @target_schema.tmp_device_id t
WHERE
    EXISTS
        (
            SELECT 1
              FROM @target_schema.tmp_device_dedupe_map dm
             WHERE dm.new_device_exposure_id = t.device_exposure_id
               AND dm.p_hvid = '@hvid_char'
        )
    AND t.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_device;
DROP TABLE IF EXISTS @target_schema.tmp_device_id;
DROP TABLE IF EXISTS @target_schema.tmp_device_dedupe_map;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------
/*!@endpage!*/