-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------
/*! @docpage
    @pagename: cdm_person
!*/
-- -------------------------------------------------------------------
-- -------------------------------------------------------------------
-- cache patients with events
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @cdm_schema.event_patients;
/*!
    @insert
    @table: @cdm_schema.event_patients
    @source_table: @source_schema.src_patient
    @summary: cache patients with events
!*/
CREATE TABLE @cdm_schema.event_patients 
@PROPERTY 
AS SELECT DISTINCT
    src.person_id        AS person_id
FROM
    @target_schema.cdm_observation_period src
;

-- -------------------------------------------------------------------
-- populate table: cdm_person
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_person;
/*!
    @insert
    @table: @target_schema.cdm_person
    @source_table: @target_schema.lk_person
    @summary: populate cdm_person
!*/
INSERT INTO @target_schema.cdm_person
SELECT
    src.person_id                       AS person_id,
    src.gender_concept_id               AS gender_concept_id,
    src.year_of_birth                   AS year_of_birth,
    src.month_of_birth                  AS month_of_birth,
    src.day_of_birth                    AS day_of_birth,
    src.birth_datetime                  AS birth_datetime,
    src.race_concept_id                 AS race_concept_id,
    src.ethnicity_concept_id            AS ethnicity_concept_id,
    src.location_id                     AS location_id,
    src.provider_id                     AS provider_id, 
    src.care_site_id                    AS care_site_id,
    src.person_source_value             AS person_source_value,
    src.gender_source_value             AS gender_source_value,
    src.gender_source_concept_id        AS gender_source_concept_id,
    src.race_source_value               AS race_source_value,
    src.race_source_concept_id          AS race_source_concept_id,
    src.ethnicity_source_value          AS ethnicity_source_value,
    src.ethnicity_source_concept_id     AS ethnicity_source_concept_id,
-- --
    src.rule_id                         AS rule_id,
    src.load_table_id                   AS load_table_id,
    src.load_row_id                     AS load_row_id
FROM
    @target_schema.lk_person src
INNER JOIN
    @cdm_schema.event_patients ep
        ON ep.person_id = src.person_id
;


/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @cdm_schema.event_patients;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------