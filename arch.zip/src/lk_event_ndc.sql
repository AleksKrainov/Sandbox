-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate lookup table lk_event_ndc
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_event_ndc;
CREATE TABLE @target_schema.lk_event_ndc
(
    event_source_value              STRING,
    event_source_value_id           STRING,
    source_vocabulary_id            STRING,
    event_start_date                DATE,
    event_type_concept_id           INTEGER,
-- ------------------ additional columns -------------
    quantity                        DOUBLE,
    days_supply                     INTEGER,
-- ---------------------------------------------------
    person_id                       BIGINT,
    provider_source_value           STRING,
    care_site_source_value          STRING,
-- cost fields ---------------------------------------
    submitted_gross_due             DOUBLE,
    paid_gross_due                  DOUBLE,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;

-- -------------------------------------------------------------------
-- Rule pharmacy_claims_closed_cut.ndc_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_ndc
    @source_table: @source_schema.src_pharmacy_claims_closed_cut
    @summary: rule pharmacy_claims_closed_cut.ndc_code records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_ndc
SELECT
    src.ndc_code                            AS event_source_value,
    NULL                                    AS event_source_value_id,
    'NDC'                                   AS source_vocabulary_id,
    src.date_service                        AS event_start_date,
    31980                                   AS event_type_concept_id,  -- Paid

    CASE
        WHEN src.dispensed_quantity > 0
             AND src.dispensed_quantity < 10000
        THEN src.dispensed_quantity
        ELSE NULL
    END                                     AS quantity,
    
    TRY_CAST(src.days_supply AS INTEGER)    AS days_supply,
    p.person_id                             AS person_id,
    src.prov_prescribing_npi                AS provider_source_value,
    src.pharmacy_npi                        AS care_site_source_value,
-- --
    src.submitted_gross_due                 AS submitted_gross_due,
    src.paid_gross_due                      AS paid_gross_due,
-- --
    'pharmacy_claims_closed_cut.ndc_code'   AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @source_schema.src_pharmacy_claims_closed_cut src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.ndc_code IS NOT NULL
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule pharmacy_claims.rejected.ndc_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_ndc
    @source_table: @source_schema.src_pharmacy_claims
    @summary: rule pharmacy_claims.rejected.ndc_code
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_ndc
SELECT
    src.ndc_code                            AS event_source_value,
    NULL                                    AS event_source_value_id,
    'NDC'                                   AS source_vocabulary_id,
    src.date_service                        AS event_start_date,
    40480940                                AS event_type_concept_id,  -- Denied

    CASE
        WHEN src.dispensed_quantity > 0
             AND src.dispensed_quantity < 10000
        THEN src.dispensed_quantity
        ELSE NULL
    END                                     AS quantity,
    
    IFF(src.days_supply BETWEEN 1 AND 365,
       src.days_supply,
       NULL)                                AS days_supply,

    p.person_id                             AS person_id,
    src.prov_prescribing_npi                AS provider_source_value,
    src.pharmacy_npi                        AS care_site_source_value,
-- --
    NULL                                    AS submitted_gross_due,
    NULL                                    AS paid_gross_due,
-- --
    'pharmacy_claims.rejected.ndc_code'     AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @source_schema.src_pharmacy_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.ndc_code IS NOT NULL
    AND src.logical_delete_reason = 'Claim Rejected'
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Rule pharmacy_claims.reversed.ndc_code
-- -------------------------------------------------------------------
/*!
    @insert
    @table: @target_schema.lk_event_ndc
    @source_table: @source_schema.src_pharmacy_claims
    @summary: rule pharmacy_claims.reversed.ndc_code
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_event_ndc
SELECT
    src.ndc_code                            AS event_source_value,
    NULL                                    AS event_source_value_id,
    'NDC'                                   AS source_vocabulary_id,
    src.date_service                        AS event_start_date,
    0                                       AS event_type_concept_id,

    CASE
        WHEN src.dispensed_quantity > 0
             AND src.dispensed_quantity < 10000
        THEN src.dispensed_quantity
        ELSE NULL
    END                                     AS quantity,
    
    IFF(src.days_supply BETWEEN 1 AND 365,
       src.days_supply,
       NULL)                                AS days_supply,

    p.person_id                             AS person_id,
    src.prov_prescribing_npi                AS provider_source_value,
    src.pharmacy_npi                        AS care_site_source_value,
-- --
    NULL                                    AS submitted_gross_due,
    NULL                                    AS paid_gross_due,
-- --
    'pharmacy_claims.reversed.ndc_code'     AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id,
    src.p_hvid                              AS p_hvid
FROM
    @source_schema.src_pharmacy_claims src
INNER JOIN
    @target_schema.lk_person p
        ON p.person_source_value = src.hvid
WHERE
    src.ndc_code IS NOT NULL
    AND src.logical_delete_reason IN ('Reversal',
                                      'Reversed Claim',
                                      'Reversed',
                                      'REVERSAL',
                                      'REVERSED') 
    -- partition filter
    AND src.p_hvid = '@hvid_char'
    AND p.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------