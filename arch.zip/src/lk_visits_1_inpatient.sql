﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.lk_join_voc_visit;
CREATE TABLE @target_schema.lk_join_voc_visit AS
WITH max_separation_level AS
(
    SELECT
        ca.descendant_concept_id            AS descendant_concept_id,
        MAX(ca.max_levels_of_separation)    AS max_levels_of_separation,
        MAX(c2.standard_concept)            AS descendant_standard_concept
    FROM
        @voc_schema.voc_concept_ancestor ca
    INNER JOIN
        @voc_schema.voc_concept c1
            ON  c1.concept_id = ca.ancestor_concept_id
            AND c1.vocabulary_id = 'Visit'
    INNER JOIN
        @voc_schema.voc_concept c2
            ON  c2.concept_id = ca.descendant_concept_id
    GROUP BY
        descendant_concept_id
),
max_level_ancestor_count AS
(
    SELECT
        ca.descendant_concept_id            AS descendant_concept_id,
        sl.descendant_standard_concept      AS descendant_standard_concept,
        MAX(c.concept_id)                   AS ancestor_concept_id,
        COUNT(DISTINCT c.concept_id)        AS ancestor_count
    FROM
        @voc_schema.voc_concept_ancestor ca
    INNER JOIN
        max_separation_level sl
            ON  sl.descendant_concept_id = ca.descendant_concept_id
            AND sl.max_levels_of_separation = ca.max_levels_of_separation
    INNER JOIN
        @voc_schema.voc_concept c
            ON  c.concept_id = ca.ancestor_concept_id
            AND c.vocabulary_id = 'Visit'
    GROUP BY
        ca.descendant_concept_id,
        sl.descendant_standard_concept
)
SELECT DISTINCT
    descendant_concept_id                   AS descendant_concept_id,
    CASE
        WHEN ancestor_count > 1 AND descendant_standard_concept = 'S'
        THEN descendant_concept_id
        WHEN ancestor_count > 1 AND descendant_standard_concept != 'S'
        THEN 0
        ELSE ancestor_concept_id
    END                                     AS concept_id
FROM
    max_level_ancestor_count
;

DROP TABLE IF EXISTS @target_schema.lk_inpatient_visit_ancestor;
CREATE TABLE @target_schema.lk_inpatient_visit_ancestor
(
    visit_detail_id             BIGINT,
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.lk_inpatient_visit_ancestor
    @source_table: @target_schema.cdm_visit_detail,
                   @target_schema.lk_join_voc_visit
    @summary: defining spans of visits
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_inpatient_visit_ancestor
SELECT
    d.visit_detail_id                   AS visit_detail_id,
    d.person_id                         AS person_id,
    v.concept_id                        AS visit_detail_concept_id,
    d.visit_detail_start_date           AS visit_detail_start_date,
    d.visit_detail_end_date             AS visit_detail_end_date,
    d.provider_id                       AS provider_id,
    d.care_site_id                      AS care_site_id,
    d.visit_detail_source_value         AS visit_detail_source_value,
-- --
    d.rule_id                           AS rule_id,
    d.load_table_id                     AS load_table_id,
    d.load_row_id                       AS load_row_id,
    d.p_hvid                            AS p_hvid
FROM
    @target_schema.cdm_visit_detail d
INNER JOIN
    @target_schema.lk_join_voc_visit v
        ON v.descendant_concept_id = d.visit_detail_concept_id
WHERE
    v.concept_id = 9201
    AND d.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_un_visit;
CREATE TABLE @target_schema.tmp_subenddates_un_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    event_date                  DATE,
    event_type                  INTEGER,
    start_ordinal               INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_un_visit
    SELECT
        person_id                               AS person_id,
        visit_detail_concept_id                 AS visit_detail_concept_id,
        visit_detail_start_date                 AS event_date,
        -1                                      AS event_type,

        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                visit_detail_concept_id
            ORDER BY
                visit_detail_start_date)        AS start_ordinal,
    -- --
        rule_id                                 AS rule_id,
        load_table_id                           AS load_table_id,
        load_row_id                             AS load_row_id,
        p_hvid                                  AS p_hvid
    FROM
        @target_schema.lk_inpatient_visit_ancestor
    WHERE
        p_hvid = '@hvid_char'
UNION ALL
    SELECT
        person_id,
        visit_detail_concept_id,
        visit_detail_end_date                   AS event_date,
        1                                       AS event_type,
        NULL                                    AS start_ordinal,
    -- --
        rule_id                                 AS rule_id,
        load_table_id                           AS load_table_id,
        load_row_id                             AS load_row_id,
        p_hvid                                  AS p_hvid
    FROM
        @target_schema.lk_inpatient_visit_ancestor
    WHERE
        p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_rows_visit;
CREATE TABLE @target_schema.tmp_subenddates_rows_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    event_date                  DATE,
    event_type                  INTEGER,
    start_ordinal               INTEGER,
    overall_ord                 INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_rows_visit
SELECT
    person_id                           AS person_id,
    visit_detail_concept_id             AS visit_detail_concept_id,
    event_date                          AS event_date,
    event_type                          AS event_type,

    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            visit_detail_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)       AS start_ordinal,
            -- this pulls the current START down from the prior rows so that the NULLs
            -- from the END DATES will contain a value we can compare with

    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            visit_detail_concept_id
        ORDER BY
            event_date,
            event_type)                 AS overall_ord,
            -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
-- --
    rule_id                             AS rule_id,
    load_table_id                       AS load_table_id,
    load_row_id                         AS load_row_id,
    p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_subenddates_un_visit
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_visit;
CREATE TABLE @target_schema.tmp_subenddates_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    end_date                    DATE,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_visit
SELECT
    person_id                   AS person_id,
    visit_detail_concept_id     AS visit_detail_concept_id,
    event_date                  AS end_date,
-- --
    rule_id                     AS rule_id,
    load_table_id               AS load_table_id,
    load_row_id                 AS load_row_id,
    p_hvid                      AS p_hvid
FROM
    @target_schema.tmp_subenddates_rows_visit e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
    AND e.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_ends_visit;
CREATE TABLE @target_schema.tmp_ends_visit
(
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_start_date         DATE,
    visit_detail_sub_end_date       DATE,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_ends_visit
SELECT
    dt.person_id                    AS person_id,
    dt.visit_detail_concept_id      AS visit_detail_concept_id,
    dt.visit_detail_start_date      AS visit_detail_start_date,
    MIN(e.end_date)                 AS visit_detail_sub_end_date,
-- --
    MIN(dt.rule_id)                 AS rule_id,
    MIN(dt.load_table_id)           AS load_table_id,
    MIN(dt.load_row_id)             AS load_row_id,
    dt.p_hvid                       AS p_hvid
FROM
    @target_schema.lk_inpatient_visit_ancestor dt
INNER JOIN
    @target_schema.tmp_subenddates_visit e
        ON  dt.person_id = e.person_id
        AND dt.visit_detail_concept_id = e.visit_detail_concept_id
        AND e.end_date >= dt.visit_detail_start_date
WHERE
    dt.p_hvid = '@hvid_char'
    AND e.p_hvid = '@hvid_char'
GROUP BY
    dt.person_id,
    dt.visit_detail_concept_id,
    dt.visit_detail_start_date,
    dt.p_hvid
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_sub_visit;
CREATE TABLE @target_schema.tmp_sub_visit
(
    row_num                         INTEGER,
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_sub_start_date     DATE,
    visit_detail_sub_end_date       DATE,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_sub_visit
SELECT
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            visit_detail_concept_id,
            visit_detail_sub_end_date
        ORDER BY
            person_id,
            visit_detail_concept_id)    AS row_num,
    person_id                           AS person_id,
    visit_detail_concept_id             AS visit_detail_concept_id,
    MIN(visit_detail_start_date)        AS visit_detail_sub_start_date,
    visit_detail_sub_end_date           AS visit_detail_sub_end_date,
-- --
    MIN(rule_id)                        AS rule_id,
    MIN(load_table_id)                  AS load_table_id,
    MIN(load_row_id)                    AS load_row_id,
    p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_ends_visit
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    person_id,
    visit_detail_concept_id,
    visit_detail_sub_end_date,
    p_hvid
ORDER BY
    person_id,
    visit_detail_concept_id
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_finaltarget_visit;
CREATE TABLE @target_schema.tmp_finaltarget_visit
(
    row_num                         INTEGER,
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_sub_start_date     DATE,
    visit_detail_sub_end_date       DATE,
    days_exposed                    INTEGER,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_finaltarget_visit
SELECT
    row_num                                 AS row_num,
    person_id                               AS person_id,
    visit_detail_concept_id                 AS visit_detail_concept_id,
    visit_detail_sub_start_date             AS visit_detail_sub_start_date,
    visit_detail_sub_end_date               AS visit_detail_sub_end_date,

    DATEDIFF('day',
             visit_detail_sub_start_date,
             visit_detail_sub_end_date)      AS days_exposed,
-- --
    rule_id                                 AS rule_id,
    load_table_id                           AS load_table_id,
    load_row_id                             AS load_row_id,
    p_hvid                                  AS p_hvid
FROM
    @target_schema.tmp_sub_visit
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_un_visit;
CREATE TABLE @target_schema.tmp_enddates_un_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    event_date                  DATE,
    event_type                  INTEGER,
    start_ordinal               INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_un_visit
    SELECT
        person_id                                               AS person_id,
        visit_detail_concept_id                                 AS visit_detail_concept_id,
        CAST(visit_detail_sub_start_date AS DATE)               AS event_date,
        -1                                                      AS event_type,

        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                visit_detail_concept_id
            ORDER BY
                visit_detail_sub_start_date)                    AS start_ordinal,
    -- --
        rule_id                                                 AS rule_id,
        load_table_id                                           AS load_table_id,
        load_row_id                                             AS load_row_id,
        p_hvid                                                  AS p_hvid
    FROM
        @target_schema.tmp_finaltarget_visit
    WHERE
        p_hvid = '@hvid_char'
UNION ALL
-- pad the end dates by 1 to allow a grace period for overlapping ranges.
    SELECT
        person_id                                               AS person_id,
        visit_detail_concept_id                                 AS visit_detail_concept_id,
        CAST(DATEADD('day', 1, visit_detail_sub_end_date) AS DATE) AS event_date,
        1                                                       AS event_type,
        NULL                                                    AS start_ordinal,
    -- --
        rule_id                                                 AS rule_id,
        load_table_id                                           AS load_table_id,
        load_row_id                                             AS load_row_id,
        p_hvid                                                  AS p_hvid
    FROM
        @target_schema.tmp_finaltarget_visit
    WHERE
        p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_rows_visit;
CREATE TABLE @target_schema.tmp_enddates_rows_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    event_date                  DATE,
    event_type                  INTEGER,
    start_ordinal               INTEGER,
    overall_ord                 INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_rows_visit
SELECT
    person_id                           AS person_id,
    visit_detail_concept_id             AS visit_detail_concept_id,
    event_date                          AS event_date,
    event_type                          AS event_type,

    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            visit_detail_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)       AS start_ordinal,
      -- this pulls the current START down from the prior rows so that the NULLs
      -- from the END DATES will contain a value we can compare with

    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            visit_detail_concept_id
        ORDER BY
            event_date,
            event_type)                 AS overall_ord,
      -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
-- --
    rule_id                             AS rule_id,
    load_table_id                       AS load_table_id,
    load_row_id                         AS load_row_id,
    p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_enddates_un_visit
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_visit;
CREATE TABLE @target_schema.tmp_enddates_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    end_date                    DATE,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_visit
SELECT
    person_id                               AS person_id,
    visit_detail_concept_id                 AS visit_detail_concept_id,
    CAST(DATEADD('day', -1, event_date) AS DATE) AS end_date,  -- unpad the end date
-- --
    rule_id                                 AS rule_id,
    load_table_id                           AS load_table_id,
    load_row_id                             AS load_row_id,
    p_hvid                                  AS p_hvid
FROM
    @target_schema.tmp_enddates_rows_visit e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
    AND e.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_visitera_ends_visit;
CREATE TABLE @target_schema.tmp_visitera_ends_visit
(
    person_id                       BIGINT,
    visit_detail_concept_id         INTEGER,
    visit_detail_sub_start_date     DATE,
    visit_detail_era_end_date       DATE,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT,
    p_hvid                          STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visitera_ends_visit
SELECT
    ft.person_id                        AS person_id,
    ft.visit_detail_concept_id          AS visit_detail_concept_id,
    ft.visit_detail_sub_start_date      AS visit_detail_sub_start_date,
    MIN(e.end_date)                     AS visit_detail_era_end_date,
-- --
    MIN(ft.rule_id)                     AS rule_id,
    MIN(ft.load_table_id)               AS load_table_id,
    MIN(ft.load_row_id)                 AS load_row_id,
    ft.p_hvid                           AS p_hvid
FROM
    @target_schema.tmp_finaltarget_visit ft
INNER JOIN
    @target_schema.tmp_enddates_visit e
        ON  ft.person_id = e.person_id
        AND e.end_date >= ft.visit_detail_sub_start_date
        AND ft.visit_detail_concept_id = e.visit_detail_concept_id
WHERE
    ft.p_hvid = '@hvid_char'
    AND e.p_hvid = '@hvid_char'
GROUP BY
    ft.person_id,
    ft.visit_detail_concept_id,
    ft.visit_detail_sub_start_date,
    ft.p_hvid
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_visitera_starts_visit;
CREATE TABLE @target_schema.tmp_visitera_starts_visit
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visitera_starts_visit
SELECT
    ev.person_id                                        AS person_id,
    ev.visit_detail_concept_id                          AS visit_detail_concept_id,
    CAST(MIN(ev.visit_detail_sub_start_date) AS DATE)   AS visit_detail_start_date,
    ev.visit_detail_era_end_date                        AS visit_detail_end_date,
-- --
    MIN(ev.rule_id)                                     AS rule_id,
    MIN(ev.load_table_id)                               AS load_table_id,
    MIN(ev.load_row_id)                                 AS load_row_id,
    ev.p_hvid                                           AS p_hvid
FROM
    @target_schema.tmp_visitera_ends_visit ev
WHERE
    ev.p_hvid = '@hvid_char'
GROUP BY
    ev.person_id,
    ev.visit_detail_concept_id,
    ev.visit_detail_era_end_date,
    ev.p_hvid
ORDER BY
    ev.person_id,
    ev.visit_detail_concept_id
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_visitera_prov_cs;
CREATE TABLE @target_schema.tmp_visitera_prov_cs
(
    person_id                   BIGINT,
    visit_detail_concept_id     INTEGER,
    visit_detail_start_date     DATE,
    visit_detail_end_date       DATE,
    provider_id                 BIGINT,
    care_site_id                BIGINT,
    visit_detail_source_value   STRING,
    source_value_count          INTEGER,
-- --
    rule_id                     STRING,
    load_table_id               STRING,
    load_row_id                 BIGINT,
    p_hvid                      STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visitera_prov_cs
SELECT
    ev.person_id                                    AS person_id,
    ev.visit_detail_concept_id                      AS visit_detail_concept_id,
    ev.visit_detail_start_date                      AS visit_detail_start_date,
    ev.visit_detail_end_date                        AS visit_detail_end_date,
    MIN(pv.provider_id)                             AS provider_id,
    MIN(pv.care_site_id)                            AS care_site_id,
    MIN(pv.visit_detail_source_value)               AS visit_detail_source_value,
    COUNT(DISTINCT pv.visit_detail_source_value)    AS source_value_count,
-- --
    MIN(ev.rule_id)                                 AS rule_id,
    MIN(ev.load_table_id)                           AS load_table_id,
    MIN(ev.load_row_id)                             AS load_row_id,
    ev.p_hvid                                       AS p_hvid
FROM
    @target_schema.tmp_visitera_starts_visit ev
LEFT JOIN
    @target_schema.lk_inpatient_visit_ancestor pv
    ON  pv.person_id = ev.person_id
    AND pv.visit_detail_concept_id = ev.visit_detail_concept_id
    AND pv.visit_detail_start_date BETWEEN ev.visit_detail_start_date AND ev.visit_detail_end_date
WHERE
    ev.p_hvid = '@hvid_char'
GROUP BY
    ev.person_id,
    ev.visit_detail_concept_id,
    ev.visit_detail_start_date,
    ev.visit_detail_end_date,
    ev.p_hvid
ORDER BY
    ev.person_id,
    ev.visit_detail_concept_id
--@FOR_END
;

-- -------------------------------------------------------------------
-- Insert into tmp_visit_occurrence
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_visit_occurrence;
CREATE TABLE @target_schema.tmp_visit_occurrence
(
    visit_occurrence_id             BIGINT,
    person_id                       BIGINT,
    visit_concept_id                INTEGER,
    visit_start_date                DATE,
    visit_start_datetime            TIMESTAMP,
    visit_end_date                  DATE,
    visit_end_datetime              TIMESTAMP,
    visit_type_concept_id           INTEGER,
    provider_id                     BIGINT,
    care_site_id                    BIGINT,
    visit_source_value              STRING,
    visit_source_concept_id         INTEGER,
    admitted_from_concept_id        INTEGER,
    admitted_from_source_value      STRING,
    discharged_to_concept_id        INTEGER,
    discharged_to_source_value      STRING,
-- --
    p_hvid                          STRING,
-- --
    rule_id                         STRING,
    load_table_id                   STRING,
    load_row_id                     BIGINT
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_visit_occurrence
    @source_table: @target_schema.tmp_visitera_prov_cs
    @summary: rule 1 records
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_visit_occurrence
SELECT
    (SELECT COALESCE(MAX(visit_occurrence_id), 0)
       FROM @target_schema.tmp_visit_occurrence)
        + 1 + ROW_NUMBER() OVER (ORDER BY NULL)   AS visit_occurrence_id,

    src.person_id                           AS person_id,
    9201                                    AS visit_concept_id,  -- Inpatient Visit
    src.visit_detail_start_date             AS visit_start_date,
    src.visit_detail_start_date             AS visit_start_datetime,
    src.visit_detail_end_date               AS visit_end_date,
    src.visit_detail_end_date               AS visit_end_datetime,
    32810                                   AS visit_type_concept_id,  -- Claim
    src.provider_id                         AS provider_id,
    src.care_site_id                        AS care_site_id,

    CASE
        WHEN src.source_value_count = 1
        THEN src.visit_detail_source_value
        ELSE NULL
    END                                     AS visit_source_value,

    0                                       AS visit_source_concept_id,
    0                                       AS admitted_from_concept_id,
    CAST(NULL AS STRING)                    AS admitted_from_source_value,
    0                                       AS discharged_to_concept_id,
    CAST(NULL AS STRING)                    AS discharged_to_source_value,
-- --
    src.p_hvid                              AS p_hvid,
-- --
    'medical_claims.inpatient_visits'       AS rule_id,
    src.load_table_id                       AS load_table_id,
    src.load_row_id                         AS load_row_id
FROM
    @target_schema.tmp_visitera_prov_cs src
WHERE
    src.p_hvid = '@hvid_char'
--@FOR_END
;


-- -------------------------------------------------------------------
-- LK_VISIT_DETAIL - link visit_detail_id to visit_occurrence_id
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.lk_visit_detail;
CREATE TABLE @target_schema.lk_visit_detail
(
    person_id               BIGINT,
    visit_detail_id         BIGINT,
    visit_occurrence_id     BIGINT,
    visit_concept_id        INTEGER,
-- --
    rule_id                 STRING,
    load_table_id           STRING,
    load_row_id             BIGINT,
    p_hvid                  STRING
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.lk_visit_detail
SELECT
    src.person_id               AS person_id,
    src.visit_detail_id         AS visit_detail_id,
    vo.visit_occurrence_id      AS visit_occurrence_id,
    vo.visit_concept_id         AS visit_concept_id,
-- --
    vo.rule_id                  AS rule_id,
    src.load_table_id           AS load_table_id,
    src.load_row_id             AS load_row_id,
    src.p_hvid                  AS p_hvid
FROM
    @target_schema.lk_inpatient_visit_ancestor src
INNER JOIN
    @target_schema.tmp_visit_occurrence vo
        ON  vo.person_id = src.person_id
        AND vo.visit_concept_id = 9201
        AND src.visit_detail_start_date BETWEEN vo.visit_start_date AND vo.visit_end_date
WHERE
    src.p_hvid = '@hvid_char'
    AND vo.p_hvid = '@hvid_char'
--@FOR_END
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_un_visit;
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_rows_visit;
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_visit;
DROP TABLE IF EXISTS @target_schema.tmp_ends_visit;
DROP TABLE IF EXISTS @target_schema.tmp_sub_visit;
DROP TABLE IF EXISTS @target_schema.tmp_finaltarget_visit;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_un_visit;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_rows_visit;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_visit;
DROP TABLE IF EXISTS @target_schema.tmp_visitera_ends_visit;
DROP TABLE IF EXISTS @target_schema.tmp_visitera_starts_visit;
DROP TABLE IF EXISTS @target_schema.tmp_visitera_prov_cs;
DROP TABLE IF EXISTS @target_schema.tmp_visit_detail_vo_id;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------