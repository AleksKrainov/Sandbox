﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.lk_join_voc_drug;
CREATE TABLE @target_schema.lk_join_voc_drug
@PROPERTY
AS SELECT DISTINCT
    ca.descendant_concept_id    AS descendant_concept_id,
    ca.ancestor_concept_id      AS ancestor_concept_id,
    c.concept_id                AS concept_id
FROM
    @voc_schema.voc_concept_ancestor ca
JOIN
    @voc_schema.voc_concept c
        ON  ca.ancestor_concept_id = c.concept_id
        AND c.vocabulary_id        IN ('RxNorm', 'RxNorm Extension')    -- selects RxNorm, RxNorm Extension vocabulary_id
        AND c.concept_class_id     = 'Ingredient'                       -- selects the Ingredients only.
                                                                        -- There are other concept_classes in RxNorm that
                                                                            -- we are not interested in.
;

DROP TABLE IF EXISTS @target_schema.tmp_pretarget_drug;
CREATE TABLE @target_schema.tmp_pretarget_drug
(
    drug_exposure_id                    bigint,
    person_id                           bigint,
    ingredient_concept_id               int,
    drug_exposure_start_date            date,
    days_supply                         int,
    drug_exposure_end_date              date,
    p_hvid                              string
)
@PROPERTY
;
/*!
    @insert
    @table: @target_schema.tmp_pretarget_drug
    @source_table: @target_schema.cdm_drug_exposure
    @summary:
    Defining spans of time when the Person
    is assumed to be exposed to a particular
    active ingredient.
    The drug_concept_id field only contains
    Concepts that have the concept_class 'Ingredient'
!*/
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_pretarget_drug
SELECT
    d.drug_exposure_id          AS drug_exposure_id,
    d.person_id                 AS person_id,
    v.concept_id                AS ingredient_concept_id,
    d.drug_exposure_start_date  AS drug_exposure_start_date,
    d.days_supply               AS days_supply,
    d.drug_exposure_end_date    AS drug_exposure_end_date,
    d.p_hvid                    AS p_hvid
FROM
    @target_schema.cdm_drug_exposure d
JOIN
    @target_schema.lk_join_voc_drug v
        ON v.descendant_concept_id = d.drug_concept_id
WHERE
    d.drug_concept_id != 0
    -- partition filter
    AND d.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_un_drug;
CREATE TABLE @target_schema.tmp_subenddates_un_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_un_drug
    SELECT
        person_id                           AS person_id,
        ingredient_concept_id               AS ingredient_concept_id,
        drug_exposure_start_date            AS event_date,
        -1                                  AS event_type,
        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                ingredient_concept_id
            ORDER BY
                drug_exposure_start_date)   AS start_ordinal,
        p_hvid                              AS p_hvid
    FROM
        @target_schema.tmp_pretarget_drug
    WHERE
        p_hvid = '@hvid_char'
UNION ALL
    SELECT
        person_id                   AS person_id,
        ingredient_concept_id       AS ingredient_concept_id,
        drug_exposure_end_date      AS event_date,
        1                           AS event_type,
        NULL                        AS start_ordinal,
        p_hvid                      AS p_hvid
    FROM
        @target_schema.tmp_pretarget_drug
    WHERE
        p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_rows_drug;
CREATE TABLE @target_schema.tmp_subenddates_rows_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    overall_ord                         int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_rows_drug
SELECT
    person_id                       AS person_id,
    ingredient_concept_id           AS ingredient_concept_id,
    event_date                      AS event_date,
    event_type                      AS event_type,
    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            ingredient_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)   AS start_ordinal,
            -- this pulls the current START down from the prior rows so that the NULLs
            -- from the END DATES will contain a value we can compare with
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            ingredient_concept_id
        ORDER BY
            event_date,
            event_type)             AS overall_ord,
            -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
    p_hvid                          AS p_hvid
FROM
    @target_schema.tmp_subenddates_un_drug
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_subenddates_drug;
CREATE TABLE @target_schema.tmp_subenddates_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    end_date                            date,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_subenddates_drug
SELECT
    person_id               AS person_id,
    ingredient_concept_id   AS ingredient_concept_id,
    event_date              AS end_date,
    p_hvid                  AS p_hvid
FROM
    @target_schema.tmp_subenddates_rows_drug e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
    AND e.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.temp_ends_drug;
CREATE TABLE @target_schema.temp_ends_drug
(
    person_id                           bigint,
    drug_concept_id                     int,
    drug_exposure_start_date            date,
    drug_sub_exposure_end_date          date,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.temp_ends_drug
SELECT
    dt.person_id                    AS person_id,
    dt.ingredient_concept_id        AS drug_concept_id,
    dt.drug_exposure_start_date     AS drug_exposure_start_date,
    MIN(e.end_date)                 AS drug_sub_exposure_end_date,
    dt.p_hvid                       AS p_hvid
FROM
    @target_schema.tmp_pretarget_drug dt
JOIN
    @target_schema.tmp_subenddates_drug e
        ON  dt.person_id             = e.person_id
        AND dt.ingredient_concept_id = e.ingredient_concept_id
        AND e.end_date               >= dt.drug_exposure_start_date
WHERE
       dt.p_hvid = '@hvid_char'
    AND e.p_hvid = '@hvid_char'
GROUP BY
    dt.drug_exposure_id,
    dt.person_id,
    dt.ingredient_concept_id,
    dt.drug_exposure_start_date,
    dt.p_hvid
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_sub_drug;
CREATE TABLE @target_schema.tmp_sub_drug
(
    row_num                             int,
    person_id                           bigint,
    drug_concept_id                     int,
    drug_sub_exposure_start_date        date,
    drug_sub_exposure_end_date          date,
    drug_exposure_count                 int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_sub_drug
SELECT
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            drug_concept_id,
            drug_sub_exposure_end_date
        ORDER BY
            person_id,
            drug_concept_id)        AS row_num,
    person_id                       AS person_id,
    drug_concept_id                 AS drug_concept_id,
    MIN(drug_exposure_start_date)   AS drug_sub_exposure_start_date,
    drug_sub_exposure_end_date      AS drug_sub_exposure_end_date,
    COUNT(*)                        AS drug_exposure_count,
    p_hvid                          AS p_hvid
FROM
    @target_schema.temp_ends_drug
WHERE
    p_hvid = '@hvid_char'
GROUP BY
    person_id,
    drug_concept_id,
    drug_sub_exposure_end_date,
    p_hvid
ORDER BY
    person_id,
    drug_concept_id
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_finaltarget_drug;
CREATE TABLE @target_schema.tmp_finaltarget_drug
(
    row_num                             int,
    person_id                           bigint,
    ingredient_concept_id               int,
    drug_sub_exposure_start_date        date,
    drug_sub_exposure_end_date          date,
    drug_exposure_count                 int,
    days_exposed                        int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_finaltarget_drug
SELECT
    row_num                                 AS row_num,
    person_id                               AS person_id,
    drug_concept_id                         AS ingredient_concept_id,
    drug_sub_exposure_start_date            AS drug_sub_exposure_start_date,
    drug_sub_exposure_end_date              AS drug_sub_exposure_end_date,
    drug_exposure_count                     AS drug_exposure_count,
    DATEDIFF('day',
             drug_sub_exposure_start_date,
             drug_sub_exposure_end_date)    AS days_exposed,
    p_hvid                                  AS p_hvid
FROM
    @target_schema.tmp_sub_drug
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_un_drug;
CREATE TABLE @target_schema.tmp_enddates_un_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_un_drug
    SELECT
        person_id                                       AS person_id,
        ingredient_concept_id                           AS ingredient_concept_id,
        CAST(drug_sub_exposure_start_date AS date)      AS event_date,
        -1                                              AS event_type,
        ROW_NUMBER() OVER (
            PARTITION BY
                person_id,
                ingredient_concept_id
            ORDER BY
                drug_sub_exposure_start_date)           AS start_ordinal,
        p_hvid                                          AS p_hvid
    FROM
        @target_schema.tmp_finaltarget_drug
    WHERE
        p_hvid = '@hvid_char'
UNION ALL
-- pad the end dates by 30 to allow a grace period for overlapping ranges.
    SELECT
        person_id                       AS person_id,
        ingredient_concept_id           AS ingredient_concept_id,
        CAST(
            DATEADD('day', 30, drug_sub_exposure_end_date)
            AS date
        )                               AS event_date,
        1                               AS event_type,
        NULL                            AS start_ordinal,
        p_hvid                          AS p_hvid
    FROM
        @target_schema.tmp_finaltarget_drug
    WHERE
        p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_rows_drug;
CREATE TABLE @target_schema.tmp_enddates_rows_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    event_date                          date,
    event_type                          int,
    start_ordinal                       int,
    overall_ord                         int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_rows_drug
SELECT
    person_id                       AS person_id,
    ingredient_concept_id           AS ingredient_concept_id,
    event_date                      AS event_date,
    event_type                      AS event_type,
    MAX(start_ordinal) OVER (
        PARTITION BY
            person_id,
            ingredient_concept_id
        ORDER BY
            event_date,
            event_type
        ROWS UNBOUNDED PRECEDING)   AS start_ordinal,
      -- this pulls the current START down from the prior rows so that the NULLs
      -- from the END DATES will contain a value we can compare with
    ROW_NUMBER() OVER (
        PARTITION BY
            person_id,
            ingredient_concept_id
        ORDER BY
            event_date,
            event_type)             AS overall_ord,
      -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
    p_hvid                          AS p_hvid
FROM
    @target_schema.tmp_enddates_un_drug
WHERE
    p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_enddates_drug;
CREATE TABLE @target_schema.tmp_enddates_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    end_date                            date,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_enddates_drug
SELECT
    person_id                           AS person_id,
    ingredient_concept_id               AS ingredient_concept_id,
    CAST(
        DATEADD('day', -30, event_date)
        AS date
    )                                   AS end_date,    -- unpad the end date
    p_hvid                              AS p_hvid
FROM
    @target_schema.tmp_enddates_rows_drug e
WHERE
    (2 * e.start_ordinal) - e.overall_ord = 0
    AND e.p_hvid = '@hvid_char'
--@FOR_END
;

DROP TABLE IF EXISTS @target_schema.tmp_drugera_ends_drug;
CREATE TABLE @target_schema.tmp_drugera_ends_drug
(
    person_id                           bigint,
    ingredient_concept_id               int,
    drug_sub_exposure_start_date        date,
    drug_era_end_date                   date,
    drug_exposure_count                 int,
    days_exposed                        int,
    p_hvid                              string
)
@PROPERTY
;
--@FOR @hvid_char IN @p_hvid_values
--@FOR_BEGIN
INSERT INTO @target_schema.tmp_drugera_ends_drug
SELECT
    ft.person_id                        AS person_id,
    ft.ingredient_concept_id            AS ingredient_concept_id,
    ft.drug_sub_exposure_start_date     AS drug_sub_exposure_start_date,
    MIN(e.end_date)                     AS drug_era_end_date,
    ft.drug_exposure_count              AS drug_exposure_count,
    ft.days_exposed                     AS days_exposed,
    ft.p_hvid                           AS p_hvid
FROM
    @target_schema.tmp_finaltarget_drug ft
JOIN
    @target_schema.tmp_enddates_drug e
        ON ft.person_id              = e.person_id
        AND e.end_date               >= ft.drug_sub_exposure_start_date
        AND ft.ingredient_concept_id = e.ingredient_concept_id
WHERE
       ft.p_hvid = '@hvid_char'
    AND e.p_hvid = '@hvid_char'
GROUP BY
    ft.person_id,
    ft.days_exposed,
    ft.drug_exposure_count,
    ft.ingredient_concept_id,
    ft.drug_sub_exposure_start_date,
    ft.p_hvid
--@FOR_END
;

-- -------------------------------------------------------------------
-- Load Table: Drug_era
-- -------------------------------------------------------------------
TRUNCATE TABLE @target_schema.cdm_drug_era;
/*!
    @insert
    @table: @target_schema.cdm_drug_era
    @source_table: @target_schema.tmp_pretarget_drug
    @summary: 30 days window is allowed
!*/
INSERT INTO @target_schema.cdm_drug_era
SELECT
    ROW_NUMBER() OVER (ORDER BY NULL)   AS drug_era_id,
    person_id                                                           AS person_id,
    ingredient_concept_id                                               AS drug_concept_id,
    CAST (MIN (drug_sub_exposure_start_date) AS timestamp)              AS drug_era_start_date,
    drug_era_end_date                                                   AS drug_era_end_date,
    SUM(drug_exposure_count)                                            AS drug_exposure_count,
    DATEDIFF('day',
             MIN(drug_sub_exposure_start_date),
             drug_era_end_date) - SUM(days_exposed)                     AS gap_days,
    'CDM.<drug_era>'                                                    AS rule_id,
    NULL                                                                AS load_table_id,
    NULL                                                                AS load_row_id
FROM
    @target_schema.tmp_drugera_ends_drug
GROUP BY
    person_id,
    drug_era_end_date,
    ingredient_concept_id
ORDER BY
    person_id,
    ingredient_concept_id
;

-- -------------------------------------------------------------------
-- Drop temporary table
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_drugera_ends_drug;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_drug;
DROP TABLE IF EXISTS @target_schema.tmp_finaltarget_drug;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_un_drug;
DROP TABLE IF EXISTS @target_schema.tmp_sub_drug;
DROP TABLE IF EXISTS @target_schema.temp_ends_drug;
DROP TABLE IF EXISTS @target_schema.tmp_pretarget_drug;
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_un_drug;
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_rows_drug;
DROP TABLE IF EXISTS @target_schema.tmp_subenddates_drug;
DROP TABLE IF EXISTS @target_schema.tmp_enddates_rows_drug;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------