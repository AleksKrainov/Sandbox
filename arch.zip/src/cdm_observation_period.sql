﻿-- -------------------------------------------------------------------
-- (c)2024, Odysseus Data Services, Inc. All rights reserved.
-- HealthVerity OMOP CDM Conversion v5.4.0
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Populate Observation_period table
-- -------------------------------------------------------------------

-- -------------------------------------------------------------------
-- Tmp_observation_period - records from event tables
-- -------------------------------------------------------------------

DROP TABLE IF EXISTS @target_schema.tmp_observation_period_collected;
CREATE TABLE @target_schema.tmp_observation_period_collected
(
    person_id                           bigint,
    observation_period_start_date       date,
    observation_period_end_date         date
)
@PROPERTY
;

/*!
    @insert
    @summary: distinct Condition dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    condition_start_date                AS observation_period_start_date,
    COALESCE(
        condition_end_date,
        condition_start_date)           AS observation_period_end_date
FROM
    @target_schema.cdm_condition_occurrence
;
/*!
    @insert
    @summary: distinct Procedure dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    procedure_date                      AS observation_period_start_date,
    procedure_date                      AS observation_period_end_date
FROM
    @target_schema.cdm_procedure_occurrence
;
/*!
    @insert
    @summary: distinct Measurement dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    measurement_date                    AS observation_period_start_date,
    measurement_date                    AS observation_period_end_date
FROM
    @target_schema.cdm_measurement
;
/*!
    @insert
    @summary: distinct Observation dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    observation_date                    AS observation_period_start_date,
    observation_date                    AS observation_period_end_date
FROM
    @target_schema.cdm_observation
;
/*!
    @insert
    @summary: distinct Drug dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    drug_exposure_start_date            AS observation_period_start_date,
    COALESCE(
        drug_exposure_end_date,
        drug_exposure_start_date)       AS observation_period_end_date
FROM
    @target_schema.cdm_drug_exposure
;
/*!
    @insert
    @summary: distinct Device dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    device_exposure_start_date          AS observation_period_start_date,
    COALESCE(
        device_exposure_end_date,
        device_exposure_start_date)     AS observation_period_end_date
FROM
    @target_schema.cdm_device_exposure
;
/*!
    @insert
    @summary: distinct Visit dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    visit_start_date                    AS observation_period_start_date,
    COALESCE(
        visit_end_date,
        visit_start_date)               AS observation_period_end_date
FROM
    @target_schema.cdm_visit_occurrence
;
/*!
    @insert
    @summary: distinct Payer Plan Period dates
!*/
INSERT INTO @target_schema.tmp_observation_period_collected
SELECT DISTINCT
    person_id                           AS person_id,
    payer_plan_period_start_date        AS observation_period_start_date,
    payer_plan_period_end_date          AS observation_period_end_date
FROM
    @target_schema.cdm_payer_plan_period
;

DROP TABLE IF EXISTS @target_schema.tmp_observation_period;
/*!
    @insert
    @summary: build Obs Period using min/max dates
!*/
CREATE TABLE @target_schema.tmp_observation_period
@PROPERTY
AS SELECT
    src.person_id                                                       AS person_id,
    MIN(src.observation_period_start_date)                              AS observation_period_start_date,
    MAX(src.observation_period_end_date)                                AS observation_period_end_date,
    32881                                                               AS period_type_concept_id    -- Standard algorithm from claims
FROM
    @target_schema.tmp_observation_period_collected src
GROUP BY
    src.person_id
;

-- -------------------------------------------------------------------
-- Cdm_observation_period
-- -------------------------------------------------------------------

TRUNCATE TABLE @target_schema.cdm_observation_period;

INSERT INTO @target_schema.cdm_observation_period
SELECT
    ROW_NUMBER() OVER (ORDER BY NULL) + 1   AS observation_period_id,
    op.person_id                        AS person_id,
    op.observation_period_start_date    AS observation_period_start_date,
    op.observation_period_end_date      AS observation_period_end_date,
    op.period_type_concept_id           AS period_type_concept_id,
-- --
    'from_cdm_events'                   AS rule_id,
    NULL                                AS load_table_id,
    NULL                                AS load_row_id
FROM
    @target_schema.tmp_observation_period op
--INNER JOIN
--    @target_schema.lk_person p
--        ON  p.person_id = op.person_id
;


/*!@endpage!*/
-- -------------------------------------------------------------------
-- Drop temporary tables
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS @target_schema.tmp_observation_period_collected;
DROP TABLE IF EXISTS @target_schema.tmp_observation_period;
-- -------------------------------------------------------------------
-- Loading finished
-- -------------------------------------------------------------------